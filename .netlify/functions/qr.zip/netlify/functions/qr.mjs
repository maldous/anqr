
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/qr.ts
import * as Sentry2 from "@sentry/node";
import { createHash } from "node:crypto";
import { createCanvas, loadImage } from "@napi-rs/canvas";
import gifenc from "gifenc";
import { decompressFrames as decompressFrames3, parseGIF as parseGIF3 } from "gifuct-js";

// src/lib/logger.ts
import * as Sentry from "@sentry/react";
import loglevel from "loglevel";
import prefix from "loglevel-plugin-prefix";
var MAX_BUFFER_SIZE = 2e3;
var MAX_STRUCTURED_BUFFER_SIZE = 5e3;
var MAX_CONTEXT_DEPTH = 10;
var logBufferEnabled = false;
var logBuffer = [];
var structuredLogBuffer = [];
function safeSerializeContext(context) {
  if (context === null || context === void 0) {
    return context;
  }
  try {
    return structuredClone(context);
  } catch {
  }
  try {
    const jsonStr = JSON.stringify(context, (_key, value) => {
      if (value instanceof Error) {
        return {
          __type: "Error",
          name: value.name,
          message: value.message,
          stack: value.stack
        };
      }
      if (value instanceof Set) {
        return { __type: "Set", values: Array.from(value) };
      }
      if (value instanceof Map) {
        return { __type: "Map", entries: Array.from(value.entries()) };
      }
      if (typeof value === "function") {
        return "[Function]";
      }
      if (value instanceof HTMLElement) {
        return `[HTMLElement: ${value.tagName}]`;
      }
      if (value instanceof Node) {
        return `[Node: ${value.nodeName}]`;
      }
      if (ArrayBuffer.isView(value) && !(value instanceof DataView)) {
        return { __type: value.constructor.name, values: Array.from(value) };
      }
      return value;
    });
    return JSON.parse(jsonStr);
  } catch {
  }
  if (typeof context === "object") {
    const result = {};
    try {
      for (const [key, value] of Object.entries(context)) {
        try {
          if (value === null || value === void 0) {
            result[key] = value;
          } else if (typeof value === "function") {
            result[key] = "[Function]";
          } else if (typeof value === "object") {
            result[key] = JSON.parse(JSON.stringify(value));
          } else {
            result[key] = value;
          }
        } catch {
          result[key] = `[Unserializable: ${typeof value}]`;
        }
      }
      return result;
    } catch {
      return "[Unserializable object]";
    }
  }
  return "[Unserializable]";
}
function captureToBuffer(scope, level, message, context) {
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  if (structuredLogBuffer.length >= MAX_STRUCTURED_BUFFER_SIZE) {
    structuredLogBuffer.shift();
  }
  const serializedContext = context ? safeSerializeContext(context) : void 0;
  structuredLogBuffer.push({
    timestamp,
    scope,
    level,
    message,
    context: serializedContext
  });
  if (!logBufferEnabled) return;
  const prefix2 = `${timestamp} [${scope}:${level}]`;
  let logLine;
  if (context && typeof context === "object") {
    try {
      const dataStr = Object.entries(context).map(([k, v]) => {
        if (typeof v === "object" && v !== null) {
          return `${k}=${JSON.stringify(v)}`;
        }
        return `${k}=${v}`;
      }).join(", ");
      logLine = `${prefix2} ${message} {${dataStr}}`;
    } catch {
      logLine = `${prefix2} ${message} {[serialization failed]}`;
    }
  } else {
    logLine = `${prefix2} ${message}`;
  }
  if (logBuffer.length >= MAX_BUFFER_SIZE) {
    logBuffer.shift();
  }
  logBuffer.push(logLine);
}
var SENSITIVE_KEYS = /* @__PURE__ */ new Set([
  "password",
  "token",
  "secret",
  "apikey",
  "api_key",
  "authorization",
  "auth",
  "credential",
  "sessionid",
  "session_id",
  "accesstoken",
  "access_token",
  "refreshtoken",
  "refresh_token",
  "privatekey",
  "private_key"
]);
var REDACTED = "[REDACTED]";
prefix.reg(loglevel);
prefix.apply(loglevel, {
  format(_level, name) {
    return `[${name}]`;
  }
});
var isDev = typeof import.meta?.env?.DEV !== "undefined" ? import.meta.env.DEV : process.env.NODE_ENV !== "production";
var defaultLevel = isDev ? "debug" : "error";
loglevel.setLevel(defaultLevel);
function redactSensitive(obj, depth = 0) {
  if (depth > MAX_CONTEXT_DEPTH) return "[MAX_DEPTH]";
  if (obj === null || obj === void 0) return obj;
  if (typeof obj !== "object") return obj;
  if (Array.isArray(obj)) {
    return obj.map((item) => redactSensitive(item, depth + 1));
  }
  if (obj instanceof Error) return obj;
  if (obj instanceof Set || obj instanceof Map) return obj;
  if (typeof Node !== "undefined" && obj instanceof Node) return obj;
  if (ArrayBuffer.isView(obj)) return obj;
  const result = {};
  for (const [key, value] of Object.entries(obj)) {
    if (SENSITIVE_KEYS.has(key.toLowerCase())) {
      result[key] = REDACTED;
    } else {
      result[key] = redactSensitive(value, depth + 1);
    }
  }
  return result;
}
function createLogger(scope) {
  const upperScope = scope.toUpperCase();
  const logger = loglevel.getLogger(upperScope);
  logger.setLevel(loglevel.getLevel());
  return {
    trace(message, context) {
      const safe = context ? redactSensitive(context) : void 0;
      captureToBuffer(upperScope, "trace", message, safe);
      if (safe) {
        logger.trace(message, safe);
      } else {
        logger.trace(message);
      }
    },
    debug(message, context) {
      const safe = context ? redactSensitive(context) : void 0;
      captureToBuffer(upperScope, "debug", message, safe);
      if (safe) {
        logger.debug(message, safe);
      } else {
        logger.debug(message);
      }
    },
    info(message, context) {
      const safe = context ? redactSensitive(context) : void 0;
      captureToBuffer(upperScope, "info", message, safe);
      if (safe) {
        logger.info(message, safe);
      } else {
        logger.info(message);
      }
    },
    warn(message, context) {
      const safe = context ? redactSensitive(context) : void 0;
      captureToBuffer(upperScope, "warn", message, safe);
      if (context) {
        logger.warn(message, safe);
      } else {
        logger.warn(message);
      }
      Sentry.addBreadcrumb({
        category: upperScope,
        message,
        level: "warning",
        data: safe
      });
    },
    error(message, context) {
      const safe = context ? redactSensitive(context) : void 0;
      captureToBuffer(upperScope, "error", message, safe);
      if (context) {
        logger.error(message, safe);
      } else {
        logger.error(message);
      }
      Sentry.withScope((sentryScope) => {
        sentryScope.setTag("logger.scope", upperScope);
        if (safe) {
          sentryScope.setExtras(safe);
        }
        const errorObj = context?.error;
        if (errorObj instanceof Error) {
          sentryScope.setExtra("originalMessage", message);
          Sentry.captureException(errorObj);
        } else {
          Sentry.captureMessage(`[${upperScope}] ${message}`, "error");
        }
      });
    }
  };
}

// src/modules/core/color.ts
var _log = createLogger("COLOR");
var BLACK = { r: 0, g: 0, b: 0, a: 1 };
function parseHex(hex) {
  hex = hex.replace("#", "");
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  }
  return {
    r: Number.parseInt(hex.substring(0, 2), 16),
    g: Number.parseInt(hex.substring(2, 4), 16),
    b: Number.parseInt(hex.substring(4, 6), 16)
  };
}
function parseHexAlpha(hex) {
  hex = hex.replace("#", "");
  if (hex.length === 4) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
  }
  const rgb = parseHex(hex.substring(0, 6));
  const a = hex.length >= 8 ? Number.parseInt(hex.substring(6, 8), 16) / 255 : 1;
  return { ...rgb, a };
}
function parseRgbString(str) {
  const rgbRegex = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/;
  const match = rgbRegex.exec(str);
  if (match) {
    return {
      r: Number.parseInt(match[1], 10),
      g: Number.parseInt(match[2], 10),
      b: Number.parseInt(match[3], 10),
      a: match[4] === void 0 ? 1 : Number.parseFloat(match[4])
    };
  }
  return { r: 0, g: 0, b: 0, a: 1 };
}
function parseHslString(str) {
  const hslRegex = /hsla?\((\d+),\s*([\d.]+)%?,\s*([\d.]+)%?(?:,\s*([\d.]+))?\)/;
  const match = hslRegex.exec(str);
  if (match) {
    return {
      h: Number.parseInt(match[1], 10),
      s: Number.parseFloat(match[2]),
      l: Number.parseFloat(match[3]),
      a: match[4] === void 0 ? 1 : Number.parseFloat(match[4])
    };
  }
  return { h: 0, s: 0, l: 0, a: 1 };
}
var NAMED_COLORS = {
  black: "#000000",
  white: "#ffffff",
  red: "#ff0000",
  green: "#00ff00",
  blue: "#0000ff",
  yellow: "#ffff00",
  cyan: "#00ffff",
  magenta: "#ff00ff",
  gray: "#808080",
  grey: "#808080",
  transparent: "#00000000"
};
function parseColor(color) {
  color = color.trim().toLowerCase();
  if (color.startsWith("#")) {
    return parseHexAlpha(color);
  }
  if (color.startsWith("rgb")) {
    return parseRgbString(color);
  }
  if (color.startsWith("hsl")) {
    const hsl = parseHslString(color);
    const rgb = hslToRgb(hsl.h, hsl.s, hsl.l);
    return { ...rgb, a: hsl.a };
  }
  if (NAMED_COLORS[color]) {
    return parseHexAlpha(NAMED_COLORS[color]);
  }
  return null;
}
function rgbToHex(r, g, b) {
  const toHex = (n) => Math.round(n).toString(16).padStart(2, "0");
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
function rgbaToString(r, g, b, a) {
  return `rgba(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)}, ${a})`;
}
function rgbToGray(r, g, b) {
  return r * 0.299 + g * 0.587 + b * 0.114;
}
function rgbToHsl(r, g, b) {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        break;
      case g:
        h = ((b - r) / d + 2) / 6;
        break;
      case b:
        h = ((r - g) / d + 4) / 6;
        break;
    }
  }
  return { h: h * 360, s: s * 100, l: l * 100 };
}
function hslToRgb(h, s, l) {
  h /= 360;
  s /= 100;
  l /= 100;
  let r, g, b;
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p2, q2, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p2 + (q2 - p2) * 6 * t;
      if (t < 1 / 2) return q2;
      if (t < 2 / 3) return p2 + (q2 - p2) * (2 / 3 - t) * 6;
      return p2;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return {
    r: Math.round(r * 255),
    g: Math.round(g * 255),
    b: Math.round(b * 255)
  };
}
function hslToRgbTuple(h, s, l) {
  const rgb = hslToRgb(h, s, l);
  return [rgb.r, rgb.g, rgb.b];
}
function blendColors(color1, color2, ratio) {
  const c1 = parseColor(color1) ?? BLACK;
  const c2 = parseColor(color2) ?? BLACK;
  const r = Math.round(c1.r + (c2.r - c1.r) * ratio);
  const g = Math.round(c1.g + (c2.g - c1.g) * ratio);
  const b = Math.round(c1.b + (c2.b - c1.b) * ratio);
  const a = c1.a + (c2.a - c1.a) * ratio;
  if (a < 1) {
    return rgbaToString(r, g, b, a);
  }
  return rgbToHex(r, g, b);
}
function getRelativeLuminance(color) {
  const c = typeof color === "string" ? parseColor(color) ?? BLACK : color;
  const rsRGB = c.r / 255;
  const gsRGB = c.g / 255;
  const bsRGB = c.b / 255;
  const r = rsRGB <= 0.03928 ? rsRGB / 12.92 : ((rsRGB + 0.055) / 1.055) ** 2.4;
  const g = gsRGB <= 0.03928 ? gsRGB / 12.92 : ((gsRGB + 0.055) / 1.055) ** 2.4;
  const b = bsRGB <= 0.03928 ? bsRGB / 12.92 : ((bsRGB + 0.055) / 1.055) ** 2.4;
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function getContrastRatio(color1, color2) {
  const l1 = getRelativeLuminance(color1);
  const l2 = getRelativeLuminance(color2);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

// src/modules/core/gradient.ts
var _log2 = createLogger("GRADIENT");

// src/modules/core/harmony.ts
var _log3 = createLogger("COLOR");

// src/modules/core/math.ts
var _log4 = createLogger("COLOR");
function createSeededRandom(seed) {
  let s = seed;
  return () => {
    s = Math.sin(s * 9999) * 1e4;
    return s - Math.floor(s);
  };
}
function createRNG(seed) {
  let state = seed >>> 0;
  return () => {
    state = state + 1831565813 >>> 0;
    let t = state;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

// src/modules/core/index.ts
var _log5 = createLogger("CORE");

// src/modules/dither-algorithms/matrices.ts
var _log6 = createLogger("DITHER");

// src/modules/dither-algorithms/utils.ts
var _log7 = createLogger("DITHER");
var createRNG2 = createRNG;

// src/modules/dither-algorithms/blue-noise.ts
var _log8 = createLogger("DITHER");
function generateBlueNoiseTile(size, seed) {
  const tile = new Array(size * size);
  const phi = 1.618033988749895;
  const rng = createRNG2(seed);
  const offset = rng();
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const noise = (offset + i * phi) % 1;
      tile[i] = noise;
    }
  }
  return tile;
}
function sampleBlueNoise(x, y, tile, tileSize) {
  const tx = (x % tileSize + tileSize) % tileSize;
  const ty = (y % tileSize + tileSize) % tileSize;
  return tile[ty * tileSize + tx];
}

// src/modules/dither-algorithms/kernels.ts
var _log9 = createLogger("DITHER");
var DIFFUSION_KERNELS = {
  floyd_steinberg: {
    matrix: [
      [0, 0, 7],
      [3, 5, 1]
    ],
    divisor: 16,
    offset: 1
  },
  jarvis_judice_ninke: {
    matrix: [
      [0, 0, 0, 7, 5],
      [3, 5, 7, 5, 3],
      [1, 3, 5, 3, 1]
    ],
    divisor: 48,
    offset: 2
  },
  stucki: {
    matrix: [
      [0, 0, 0, 8, 4],
      [2, 4, 8, 4, 2],
      [1, 2, 4, 2, 1]
    ],
    divisor: 42,
    offset: 2
  },
  burkes: {
    matrix: [
      [0, 0, 0, 8, 4],
      [2, 4, 8, 4, 2]
    ],
    divisor: 32,
    offset: 2
  },
  sierra: {
    matrix: [
      [0, 0, 0, 5, 3],
      [2, 4, 5, 4, 2],
      [0, 2, 3, 2, 0]
    ],
    divisor: 32,
    offset: 2
  },
  sierra_2: {
    matrix: [
      [0, 0, 0, 4, 3],
      [1, 2, 3, 2, 1]
    ],
    divisor: 16,
    offset: 2
  },
  sierra_lite: {
    matrix: [
      [0, 0, 2],
      [1, 1, 0]
    ],
    divisor: 4,
    offset: 1
  },
  two_row_sierra: {
    matrix: [
      [0, 0, 0, 4, 3],
      [1, 2, 3, 2, 1]
    ],
    divisor: 16,
    offset: 2
  },
  atkinson: {
    matrix: [
      [0, 0, 1, 1],
      [1, 1, 1, 0],
      [0, 1, 0, 0]
    ],
    divisor: 8,
    offset: 1
  }
};

// src/modules/dither-algorithms/error-diffusion.ts
var _log10 = createLogger("DITHER");

// src/modules/dither-algorithms/advanced.ts
var _log11 = createLogger("DITHER");

// src/modules/dither-algorithms/noise.ts
var _log12 = createLogger("DITHER");

// src/modules/dither-algorithms/ordered.ts
var _log13 = createLogger("DITHER");

// src/modules/dither-algorithms/temporal.ts
var _log14 = createLogger("DITHER");

// src/modules/dither-algorithms/index.ts
var _log15 = createLogger("DITHER");

// src/modules/animation/state.ts
var _log16 = createLogger("ANIMATION");

// src/modules/animation/animation-loop.ts
var _log17 = createLogger("ANIMATION");

// src/modules/animation/animation-patterns.ts
var _log18 = createLogger("ANIMATION");

// src/modules/animation/apply-animation-pattern.ts
var _log19 = createLogger("ANIMATION");

// src/modules/animation/color-cycle.ts
var _log20 = createLogger("ANIMATION");

// src/modules/animation/decimation.ts
var _log21 = createLogger("ANIMATION");

// src/modules/animation/format-detection.ts
var _log22 = createLogger("ANIMATION");

// src/modules/animation/gif-compositor.ts
import { decompressFrames, parseGIF } from "gifuct-js";
var _log23 = createLogger("ANIMATION");

// src/modules/animation/interpolate-frames.ts
var _log24 = createLogger("ANIMATION");

// src/modules/animation/parsing.ts
import { decompressFrames as decompressFrames2, parseGIF as parseGIF2 } from "gifuct-js";
var log = createLogger("ANIMATION");

// src/modules/animation/shared-patterns.ts
var _log25 = createLogger("ANIMATION");
function applyAnimationEasing(progress, easing) {
  switch (easing) {
    case "ease_in":
      return progress * progress;
    case "ease_out":
      return 1 - (1 - progress) * (1 - progress);
    case "ease_in_out":
      return progress < 0.5 ? 2 * progress * progress : 1 - (-2 * progress + 2) ** 2 / 2;
    case "bounce":
      if (progress < 0.5) {
        return 8 * progress * progress * progress * progress;
      } else {
        return 1 - (-2 * progress + 2) ** 4 / 2;
      }
    default:
      return progress;
  }
}
function applyAnimationPulse(data, progress, seed) {
  const pulsePhase = Math.sin(progress * Math.PI * 2);
  const intensity = 0.3 + 0.2 * Math.abs(pulsePhase);
  const hue = seed * 31 % 360;
  const pulseColor = hslToRgbTuple(hue, 70, 50);
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const brightness2 = (r + g + b) / 3;
    const isDark2 = brightness2 < 128;
    if (isDark2) {
      const tintAmount = intensity * (0.5 + pulsePhase * 0.5);
      data[i] = Math.min(255, r + pulseColor[0] * tintAmount);
      data[i + 1] = Math.min(255, g + pulseColor[1] * tintAmount);
      data[i + 2] = Math.min(255, b + pulseColor[2] * tintAmount);
    } else {
      const bf = 1 - intensity * 0.1 * (1 + pulsePhase);
      data[i] = Math.max(0, Math.round(r * bf));
      data[i + 1] = Math.max(0, Math.round(g * bf));
      data[i + 2] = Math.max(0, Math.round(b * bf));
    }
  }
}
function applyAnimationWave(data, progress, width, height, seed) {
  const waveFrequency = 3 + seed % 5;
  const baseHue = seed * 23 % 360;
  for (let y = 0; y < height; y++) {
    const wavePhase = Math.sin(y / height * waveFrequency * Math.PI * 2 + progress * Math.PI * 2);
    const waveIntensity = (wavePhase + 1) / 2;
    const rowHue = ((baseHue + wavePhase * 30) % 360 + 360) % 360;
    const waveColor = hslToRgbTuple(rowHue, 70, 50);
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const brightness2 = (r + g + b) / 3;
      const isDark2 = brightness2 < 128;
      if (isDark2) {
        const tintAmount = waveIntensity * 0.6;
        data[i] = Math.min(255, r + waveColor[0] * tintAmount);
        data[i + 1] = Math.min(255, g + waveColor[1] * tintAmount);
        data[i + 2] = Math.min(255, b + waveColor[2] * tintAmount);
      } else {
        const darkenAmount = waveIntensity * 0.15;
        data[i] = Math.round(r * (1 - darkenAmount));
        data[i + 1] = Math.round(g * (1 - darkenAmount));
        data[i + 2] = Math.round(b * (1 - darkenAmount));
      }
    }
  }
}
function applyAnimationScanline(data, progress, width, height, seed) {
  const lineWidth = Math.max(4, height * 0.08);
  const lineY = progress * (height + lineWidth * 2) - lineWidth;
  const horizontal = seed % 2 === 0;
  const baseHue = seed * 17 % 360;
  const scanColor = hslToRgbTuple(baseHue, 80, 50);
  const trailColor = hslToRgbTuple((baseHue + 180) % 360, 60, 60);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      const pos = horizontal ? y : x;
      const linePos = horizontal ? lineY : progress * (width + lineWidth * 2) - lineWidth;
      const distance = Math.abs(pos - linePos);
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const brightness2 = (r + g + b) / 3;
      const isDark2 = brightness2 < 128;
      if (distance < lineWidth) {
        const intensity = 1 - distance / lineWidth;
        if (isDark2) {
          data[i] = Math.min(255, r + scanColor[0] * intensity * 0.8);
          data[i + 1] = Math.min(255, g + scanColor[1] * intensity * 0.8);
          data[i + 2] = Math.min(255, b + scanColor[2] * intensity * 0.8);
        } else {
          data[i] = Math.max(0, r - trailColor[0] * intensity * 0.3);
          data[i + 1] = Math.max(0, g - trailColor[1] * intensity * 0.3);
          data[i + 2] = Math.max(0, b - trailColor[2] * intensity * 0.3);
        }
      }
    }
  }
}
function applyAnimationShimmer(data, progress, width, height, seed) {
  const random = createSeededRandom(seed + Math.floor(progress * 1e3));
  const spotCount = Math.floor(width * height * 0.02);
  const baseHue = (seed * 13 + progress * 100) % 360;
  for (let s = 0; s < spotCount; s++) {
    const x = Math.floor(random() * width);
    const y = Math.floor(random() * height);
    const i = (y * width + x) * 4;
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const brightness2 = (r + g + b) / 3;
    const isDark2 = brightness2 < 128;
    const spotHue = (baseHue + random() * 60) % 360;
    const sparkleColor = hslToRgbTuple(spotHue, 90, isDark2 ? 60 : 40);
    const intensity = 0.5 + random() * 0.5;
    if (isDark2) {
      data[i] = Math.min(255, r + sparkleColor[0] * intensity);
      data[i + 1] = Math.min(255, g + sparkleColor[1] * intensity);
      data[i + 2] = Math.min(255, b + sparkleColor[2] * intensity);
    } else {
      data[i] = Math.max(0, r - (255 - sparkleColor[0]) * intensity * 0.3);
      data[i + 1] = Math.max(0, g - (255 - sparkleColor[1]) * intensity * 0.3);
      data[i + 2] = Math.max(0, b - (255 - sparkleColor[2]) * intensity * 0.3);
    }
  }
}
function applyAnimationDrift(data, progress, width, height, seed) {
  const scale = 0.015 + seed % 10 * 3e-3;
  const timeOffset = progress * Math.PI * 2;
  const baseHue = (seed * 41 + progress * 60) % 360;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const brightness2 = (r + g + b) / 3;
      const isDark2 = brightness2 < 128;
      const drift = Math.sin(x * scale + timeOffset) * Math.cos(y * scale + timeOffset);
      const driftIntensity = (drift + 1) / 2;
      const driftHue = ((baseHue + drift * 40) % 360 + 360) % 360;
      const driftColor = hslToRgbTuple(driftHue, 60, 50);
      if (isDark2) {
        const tintAmount = driftIntensity * 0.5;
        data[i] = Math.min(255, r + driftColor[0] * tintAmount);
        data[i + 1] = Math.min(255, g + driftColor[1] * tintAmount);
        data[i + 2] = Math.min(255, b + driftColor[2] * tintAmount);
      } else {
        const darkenAmount = driftIntensity * 0.1;
        data[i] = Math.round(r * (1 - darkenAmount));
        data[i + 1] = Math.round(g * (1 - darkenAmount));
        data[i + 2] = Math.round(b * (1 - darkenAmount));
      }
    }
  }
}
function applyAnimationColorCycle(data, progress, seed) {
  const baseHue = (progress * 360 + seed) % 360;
  const tintColor = hslToRgbTuple(baseHue, 80, 50);
  const complementHue = (baseHue + 180) % 360;
  const complementColor = hslToRgbTuple(complementHue, 30, 70);
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const brightness2 = (r + g + b) / 3;
    const isDark2 = brightness2 < 128;
    if (isDark2) {
      const tintAmount = 0.7;
      data[i] = Math.min(255, r + tintColor[0] * tintAmount);
      data[i + 1] = Math.min(255, g + tintColor[1] * tintAmount);
      data[i + 2] = Math.min(255, b + tintColor[2] * tintAmount);
    } else {
      const tintAmount = 0.15;
      data[i] = Math.max(0, Math.round(r - (255 - complementColor[0]) * tintAmount));
      data[i + 1] = Math.max(0, Math.round(g - (255 - complementColor[1]) * tintAmount));
      data[i + 2] = Math.max(0, Math.round(b - (255 - complementColor[2]) * tintAmount));
    }
  }
}

// src/modules/animation/temporal-dither.ts
var _log26 = createLogger("ANIMATION");

// src/modules/animation/index.ts
var _log27 = createLogger("ANIMATION");

// src/modules/qr-encoder/bit-buffer.ts
var _log28 = createLogger("ENCODER");
function qrBitBuffer() {
  const _buffer = [];
  let _length = 0;
  const _this = {
    getBuffer: () => _buffer,
    getAt: (index) => {
      const bufIndex = Math.floor(index / 8);
      return (_buffer[bufIndex] >>> 7 - index % 8 & 1) === 1;
    },
    put: (num, length) => {
      for (let i = 0; i < length; i += 1) {
        _this.putBit((num >>> length - i - 1 & 1) === 1);
      }
    },
    getLengthInBits: () => _length,
    putBit: (bit) => {
      const bufIndex = Math.floor(_length / 8);
      if (_buffer.length <= bufIndex) {
        _buffer.push(0);
      }
      if (bit) {
        _buffer[bufIndex] |= 128 >>> _length % 8;
      }
      _length += 1;
    }
  };
  return _this;
}

// src/modules/qr-encoder/string-bytes.ts
var _log29 = createLogger("ENCODER");
var _stringToBytes = (s) => {
  const bytes = [];
  for (let i = 0; i < s.length; i += 1) {
    const c = s.charCodeAt(i);
    bytes.push(c & 255);
  }
  return bytes;
};
function stringToBytesFn(s) {
  return _stringToBytes(s);
}
function setStringToBytes(fn) {
  _stringToBytes = fn;
}
function resetStringToBytes() {
  _stringToBytes = (s) => {
    const bytes = [];
    for (let i = 0; i < s.length; i += 1) {
      const c = s.charCodeAt(i);
      bytes.push(c & 255);
    }
    return bytes;
  };
}

// src/modules/qr-encoder/types.ts
var _log30 = createLogger("ENCODER");
var QRMode = {
  MODE_NUMBER: 1 << 0,
  // 0001
  MODE_ALPHA_NUM: 1 << 1,
  // 0010
  MODE_8BIT_BYTE: 1 << 2,
  // 0100
  MODE_KANJI: 1 << 3
  // 1000
};
var QRErrorCorrectionLevel = {
  L: 1,
  // ~7% recovery
  M: 0,
  // ~15% recovery
  Q: 3,
  // ~25% recovery
  H: 2
  // ~30% recovery
};

// src/modules/qr-encoder/data-modes.ts
var _log31 = createLogger("ENCODER");
function qrNumber(data) {
  const _mode = QRMode.MODE_NUMBER;
  const _data = data;
  const strToNum = (s) => {
    let num = 0;
    for (let i = 0; i < s.length; i += 1) {
      num = num * 10 + charToNum(s.charAt(i));
    }
    return num;
  };
  const charToNum = (c) => {
    if ("0" <= c && c <= "9") {
      return c.charCodeAt(0) - "0".charCodeAt(0);
    }
    throw new Error(`illegal char :${c}`);
  };
  return {
    getMode: () => _mode,
    getLength: () => _data.length,
    write: (buffer) => {
      let i = 0;
      while (i + 2 < _data.length) {
        buffer.put(strToNum(_data.substring(i, i + 3)), 10);
        i += 3;
      }
      if (i < _data.length) {
        if (_data.length - i === 1) {
          buffer.put(strToNum(_data.substring(i, i + 1)), 4);
        } else if (_data.length - i === 2) {
          buffer.put(strToNum(_data.substring(i, i + 2)), 7);
        }
      }
    }
  };
}
function qrAlphaNum(data) {
  const _mode = QRMode.MODE_ALPHA_NUM;
  const _data = data;
  const getCode = (c) => {
    if ("0" <= c && c <= "9") {
      return c.charCodeAt(0) - "0".charCodeAt(0);
    } else if ("A" <= c && c <= "Z") {
      return c.charCodeAt(0) - "A".charCodeAt(0) + 10;
    } else {
      switch (c) {
        case " ":
          return 36;
        case "$":
          return 37;
        case "%":
          return 38;
        case "*":
          return 39;
        case "+":
          return 40;
        case "-":
          return 41;
        case ".":
          return 42;
        case "/":
          return 43;
        case ":":
          return 44;
        default:
          throw new Error(`illegal char :${c}`);
      }
    }
  };
  return {
    getMode: () => _mode,
    getLength: () => _data.length,
    write: (buffer) => {
      const s = _data;
      let i = 0;
      while (i + 1 < s.length) {
        buffer.put(getCode(s.charAt(i)) * 45 + getCode(s.charAt(i + 1)), 11);
        i += 2;
      }
      if (i < s.length) {
        buffer.put(getCode(s.charAt(i)), 6);
      }
    }
  };
}
function qr8BitByte(data) {
  const _mode = QRMode.MODE_8BIT_BYTE;
  const _bytes = stringToBytesFn(data);
  return {
    getMode: () => _mode,
    getLength: () => _bytes.length,
    write: (buffer) => {
      for (let i = 0; i < _bytes.length; i += 1) {
        buffer.put(_bytes[i], 8);
      }
    }
  };
}
function qrKanji(data) {
  const _mode = QRMode.MODE_KANJI;
  const test = stringToBytesFn("\u53CB");
  if (test.length !== 2 || (test[0] << 8 | test[1]) !== 38726) {
    throw new Error("sjis not supported.");
  }
  const _bytes = stringToBytesFn(data);
  return {
    getMode: () => _mode,
    getLength: () => ~~(_bytes.length / 2),
    write: (buffer) => {
      let i = 0;
      while (i + 1 < _bytes.length) {
        let c = (255 & _bytes[i]) << 8 | 255 & _bytes[i + 1];
        if (33088 <= c && c <= 40956) {
          c -= 33088;
        } else if (57408 <= c && c <= 60351) {
          c -= 49472;
        } else {
          throw new Error(`illegal char at ${i + 1}/${c}`);
        }
        c = (c >>> 8 & 255) * 192 + (c & 255);
        buffer.put(c, 13);
        i += 2;
      }
      if (i < _bytes.length) {
        throw new Error(`illegal char at ${i + 1}`);
      }
    }
  };
}

// src/modules/qr-encoder/math.ts
var _log32 = createLogger("ENCODER");
var EXP_TABLE = new Array(256);
var LOG_TABLE = new Array(256);
for (let i = 0; i < 8; i += 1) {
  EXP_TABLE[i] = 1 << i;
}
for (let i = 8; i < 256; i += 1) {
  EXP_TABLE[i] = EXP_TABLE[i - 4] ^ EXP_TABLE[i - 5] ^ EXP_TABLE[i - 6] ^ EXP_TABLE[i - 8];
}
for (let i = 0; i < 255; i += 1) {
  LOG_TABLE[EXP_TABLE[i]] = i;
}
function glog(n) {
  if (n < 1) {
    throw new Error(`glog(${n})`);
  }
  return LOG_TABLE[n];
}
function gexp(n) {
  let exp = n;
  while (exp < 0) {
    exp += 255;
  }
  while (exp >= 256) {
    exp -= 255;
  }
  return EXP_TABLE[exp];
}
function qrPolynomial(num, shift) {
  if (typeof num.length === "undefined") {
    throw new Error(`${num.length}/${shift}`);
  }
  const _num = (() => {
    let offset = 0;
    while (offset < num.length && num[offset] === 0) {
      offset += 1;
    }
    const result = new Array(num.length - offset + shift);
    for (let i = 0; i < num.length - offset; i += 1) {
      result[i] = num[i + offset];
    }
    return result;
  })();
  const _this = {
    getAt: (index) => _num[index],
    getLength: () => _num.length,
    multiply: (e) => {
      const result = new Array(_this.getLength() + e.getLength() - 1);
      for (let i = 0; i < result.length; i++) {
        result[i] = 0;
      }
      for (let i = 0; i < _this.getLength(); i += 1) {
        for (let j = 0; j < e.getLength(); j += 1) {
          result[i + j] ^= gexp(glog(_this.getAt(i)) + glog(e.getAt(j)));
        }
      }
      return qrPolynomial(result, 0);
    },
    mod: (e) => {
      if (_this.getLength() - e.getLength() < 0) {
        return _this;
      }
      const ratio = glog(_this.getAt(0)) - glog(e.getAt(0));
      const result = new Array(_this.getLength());
      for (let i = 0; i < _this.getLength(); i += 1) {
        result[i] = _this.getAt(i);
      }
      for (let i = 0; i < e.getLength(); i += 1) {
        result[i] ^= gexp(glog(e.getAt(i)) + ratio);
      }
      return qrPolynomial(result, 0).mod(e);
    }
  };
  return _this;
}

// src/modules/qr-encoder/output.ts
var _log33 = createLogger("ENCODER");
function byteArrayOutputStream() {
  const _bytes = [];
  return {
    writeByte: (b) => {
      _bytes.push(b & 255);
    },
    writeShort: (i) => {
      _bytes.push(i & 255);
      _bytes.push(i >>> 8 & 255);
    },
    writeBytes: (b, off = 0, len) => {
      const length = len ?? b.length;
      for (let i = 0; i < length; i += 1) {
        _bytes.push(b[i + off] & 255);
      }
    },
    writeString: (s) => {
      for (let i = 0; i < s.length; i += 1) {
        _bytes.push(s.charCodeAt(i) & 255);
      }
    },
    toByteArray: () => _bytes,
    toString: () => {
      let s = "[";
      for (let i = 0; i < _bytes.length; i += 1) {
        if (i > 0) s += ",";
        s += _bytes[i];
      }
      s += "]";
      return s;
    }
  };
}
function base64EncodeOutputStream() {
  let _buffer = 0;
  let _buflen = 0;
  let _length = 0;
  let _base64 = "";
  const encode = (n) => {
    if (n < 0) {
      throw new Error(`n:${n}`);
    } else if (n < 26) {
      return 65 + n;
    } else if (n < 52) {
      return 97 + (n - 26);
    } else if (n < 62) {
      return 48 + (n - 52);
    } else if (n === 62) {
      return 43;
    } else if (n === 63) {
      return 47;
    } else {
      throw new Error(`n:${n}`);
    }
  };
  const writeEncoded = (b) => {
    _base64 += String.fromCharCode(encode(b & 63));
  };
  return {
    writeByte: (n) => {
      _buffer = _buffer << 8 | n & 255;
      _buflen += 8;
      _length += 1;
      while (_buflen >= 6) {
        writeEncoded(_buffer >>> _buflen - 6);
        _buflen -= 6;
      }
    },
    flush: () => {
      if (_buflen > 0) {
        writeEncoded(_buffer << 6 - _buflen);
        _buffer = 0;
        _buflen = 0;
      }
      if (_length % 3 !== 0) {
        const padlen = 3 - _length % 3;
        for (let i = 0; i < padlen; i += 1) {
          _base64 += "=";
        }
      }
    },
    toString: () => _base64
  };
}
function gifImage(width, height) {
  const _data = new Array(width * height);
  const lzwTable = () => {
    const _map = {};
    let _size = 0;
    return {
      add: (key) => {
        if (typeof _map[key] !== "undefined") {
          throw new Error(`dup key:${key}`);
        }
        _map[key] = _size;
        _size += 1;
      },
      size: () => _size,
      indexOf: (key) => _map[key],
      contains: (key) => typeof _map[key] !== "undefined"
    };
  };
  const bitOutputStream = (out) => {
    let _bitLength = 0;
    let _bitBuffer = 0;
    return {
      write: (data, length) => {
        if (data >>> length !== 0) {
          throw new Error("length over");
        }
        while (_bitLength + length >= 8) {
          out.writeByte(255 & (data << _bitLength | _bitBuffer));
          length -= 8 - _bitLength;
          data >>>= 8 - _bitLength;
          _bitBuffer = 0;
          _bitLength = 0;
        }
        _bitBuffer = data << _bitLength | _bitBuffer;
        _bitLength = _bitLength + length;
      },
      flush: () => {
        if (_bitLength > 0) {
          out.writeByte(_bitBuffer);
        }
      }
    };
  };
  const getLZWRaster = (lzwMinCodeSize) => {
    const clearCode = 1 << lzwMinCodeSize;
    const endCode = (1 << lzwMinCodeSize) + 1;
    let bitLength = lzwMinCodeSize + 1;
    const table = lzwTable();
    for (let i = 0; i < clearCode; i += 1) {
      table.add(String.fromCharCode(i));
    }
    table.add(String.fromCharCode(clearCode));
    table.add(String.fromCharCode(endCode));
    const byteOut = byteArrayOutputStream();
    const bitOut = bitOutputStream(byteOut);
    bitOut.write(clearCode, bitLength);
    let dataIndex = 0;
    let s = String.fromCharCode(_data[dataIndex]);
    dataIndex += 1;
    while (dataIndex < _data.length) {
      const c = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;
      if (table.contains(s + c)) {
        s = s + c;
      } else {
        bitOut.write(table.indexOf(s), bitLength);
        if (table.size() < 4095) {
          if (table.size() === 1 << bitLength) {
            bitLength += 1;
          }
          table.add(s + c);
        }
        s = c;
      }
    }
    bitOut.write(table.indexOf(s), bitLength);
    bitOut.write(endCode, bitLength);
    bitOut.flush();
    return byteOut.toByteArray();
  };
  return {
    setPixel: (x, y, pixel) => {
      _data[y * width + x] = pixel;
    },
    write: (out) => {
      out.writeString("GIF87a");
      out.writeShort(width);
      out.writeShort(height);
      out.writeByte(128);
      out.writeByte(0);
      out.writeByte(0);
      out.writeByte(0);
      out.writeByte(0);
      out.writeByte(0);
      out.writeByte(255);
      out.writeByte(255);
      out.writeByte(255);
      out.writeString(",");
      out.writeShort(0);
      out.writeShort(0);
      out.writeShort(width);
      out.writeShort(height);
      out.writeByte(0);
      const lzwMinCodeSize = 2;
      const raster = getLZWRaster(lzwMinCodeSize);
      out.writeByte(lzwMinCodeSize);
      let offset = 0;
      while (raster.length - offset > 255) {
        out.writeByte(255);
        out.writeBytes(raster, offset, 255);
        offset += 255;
      }
      out.writeByte(raster.length - offset);
      out.writeBytes(raster, offset, raster.length - offset);
      out.writeByte(0);
      out.writeString(";");
    }
  };
}
function createDataURL(width, height, getPixel) {
  const gif = gifImage(width, height);
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      gif.setPixel(x, y, getPixel(x, y));
    }
  }
  const b = byteArrayOutputStream();
  gif.write(b);
  const base64 = base64EncodeOutputStream();
  const bytes = b.toByteArray();
  for (let i = 0; i < bytes.length; i += 1) {
    base64.writeByte(bytes[i]);
  }
  base64.flush();
  return `data:image/gif;base64,${base64.toString()}`;
}

// src/modules/qr-encoder/rs-blocks.ts
var _log34 = createLogger("ENCODER");
var RS_BLOCK_TABLE = [
  // L
  // M
  // Q
  // H
  // 1
  [1, 26, 19],
  [1, 26, 16],
  [1, 26, 13],
  [1, 26, 9],
  // 2
  [1, 44, 34],
  [1, 44, 28],
  [1, 44, 22],
  [1, 44, 16],
  // 3
  [1, 70, 55],
  [1, 70, 44],
  [2, 35, 17],
  [2, 35, 13],
  // 4
  [1, 100, 80],
  [2, 50, 32],
  [2, 50, 24],
  [4, 25, 9],
  // 5
  [1, 134, 108],
  [2, 67, 43],
  [2, 33, 15, 2, 34, 16],
  [2, 33, 11, 2, 34, 12],
  // 6
  [2, 86, 68],
  [4, 43, 27],
  [4, 43, 19],
  [4, 43, 15],
  // 7
  [2, 98, 78],
  [4, 49, 31],
  [2, 32, 14, 4, 33, 15],
  [4, 39, 13, 1, 40, 14],
  // 8
  [2, 121, 97],
  [2, 60, 38, 2, 61, 39],
  [4, 40, 18, 2, 41, 19],
  [4, 40, 14, 2, 41, 15],
  // 9
  [2, 146, 116],
  [3, 58, 36, 2, 59, 37],
  [4, 36, 16, 4, 37, 17],
  [4, 36, 12, 4, 37, 13],
  // 10
  [2, 86, 68, 2, 87, 69],
  [4, 69, 43, 1, 70, 44],
  [6, 43, 19, 2, 44, 20],
  [6, 43, 15, 2, 44, 16],
  // 11
  [4, 101, 81],
  [1, 80, 50, 4, 81, 51],
  [4, 50, 22, 4, 51, 23],
  [3, 36, 12, 8, 37, 13],
  // 12
  [2, 116, 92, 2, 117, 93],
  [6, 58, 36, 2, 59, 37],
  [4, 46, 20, 6, 47, 21],
  [7, 42, 14, 4, 43, 15],
  // 13
  [4, 133, 107],
  [8, 59, 37, 1, 60, 38],
  [8, 44, 20, 4, 45, 21],
  [12, 33, 11, 4, 34, 12],
  // 14
  [3, 145, 115, 1, 146, 116],
  [4, 64, 40, 5, 65, 41],
  [11, 36, 16, 5, 37, 17],
  [11, 36, 12, 5, 37, 13],
  // 15
  [5, 109, 87, 1, 110, 88],
  [5, 65, 41, 5, 66, 42],
  [5, 54, 24, 7, 55, 25],
  [11, 36, 12, 7, 37, 13],
  // 16
  [5, 122, 98, 1, 123, 99],
  [7, 73, 45, 3, 74, 46],
  [15, 43, 19, 2, 44, 20],
  [3, 45, 15, 13, 46, 16],
  // 17
  [1, 135, 107, 5, 136, 108],
  [10, 74, 46, 1, 75, 47],
  [1, 50, 22, 15, 51, 23],
  [2, 42, 14, 17, 43, 15],
  // 18
  [5, 150, 120, 1, 151, 121],
  [9, 69, 43, 4, 70, 44],
  [17, 50, 22, 1, 51, 23],
  [2, 42, 14, 19, 43, 15],
  // 19
  [3, 141, 113, 4, 142, 114],
  [3, 70, 44, 11, 71, 45],
  [17, 47, 21, 4, 48, 22],
  [9, 39, 13, 16, 40, 14],
  // 20
  [3, 135, 107, 5, 136, 108],
  [3, 67, 41, 13, 68, 42],
  [15, 54, 24, 5, 55, 25],
  [15, 43, 15, 10, 44, 16],
  // 21
  [4, 144, 116, 4, 145, 117],
  [17, 68, 42],
  [17, 50, 22, 6, 51, 23],
  [19, 46, 16, 6, 47, 17],
  // 22
  [2, 139, 111, 7, 140, 112],
  [17, 74, 46],
  [7, 54, 24, 16, 55, 25],
  [34, 37, 13],
  // 23
  [4, 151, 121, 5, 152, 122],
  [4, 75, 47, 14, 76, 48],
  [11, 54, 24, 14, 55, 25],
  [16, 45, 15, 14, 46, 16],
  // 24
  [6, 147, 117, 4, 148, 118],
  [6, 73, 45, 14, 74, 46],
  [11, 54, 24, 16, 55, 25],
  [30, 46, 16, 2, 47, 17],
  // 25
  [8, 132, 106, 4, 133, 107],
  [8, 75, 47, 13, 76, 48],
  [7, 54, 24, 22, 55, 25],
  [22, 45, 15, 13, 46, 16],
  // 26
  [10, 142, 114, 2, 143, 115],
  [19, 74, 46, 4, 75, 47],
  [28, 50, 22, 6, 51, 23],
  [33, 46, 16, 4, 47, 17],
  // 27
  [8, 152, 122, 4, 153, 123],
  [22, 73, 45, 3, 74, 46],
  [8, 53, 23, 26, 54, 24],
  [12, 45, 15, 28, 46, 16],
  // 28
  [3, 147, 117, 10, 148, 118],
  [3, 73, 45, 23, 74, 46],
  [4, 54, 24, 31, 55, 25],
  [11, 45, 15, 31, 46, 16],
  // 29
  [7, 146, 116, 7, 147, 117],
  [21, 73, 45, 7, 74, 46],
  [1, 53, 23, 37, 54, 24],
  [19, 45, 15, 26, 46, 16],
  // 30
  [5, 145, 115, 10, 146, 116],
  [19, 75, 47, 10, 76, 48],
  [15, 54, 24, 25, 55, 25],
  [23, 45, 15, 25, 46, 16],
  // 31
  [13, 145, 115, 3, 146, 116],
  [2, 74, 46, 29, 75, 47],
  [42, 54, 24, 1, 55, 25],
  [23, 45, 15, 28, 46, 16],
  // 32
  [17, 145, 115],
  [10, 74, 46, 23, 75, 47],
  [10, 54, 24, 35, 55, 25],
  [19, 45, 15, 35, 46, 16],
  // 33
  [17, 145, 115, 1, 146, 116],
  [14, 74, 46, 21, 75, 47],
  [29, 54, 24, 19, 55, 25],
  [11, 45, 15, 46, 46, 16],
  // 34
  [13, 145, 115, 6, 146, 116],
  [14, 74, 46, 23, 75, 47],
  [44, 54, 24, 7, 55, 25],
  [59, 46, 16, 1, 47, 17],
  // 35
  [12, 151, 121, 7, 152, 122],
  [12, 75, 47, 26, 76, 48],
  [39, 54, 24, 14, 55, 25],
  [22, 45, 15, 41, 46, 16],
  // 36
  [6, 151, 121, 14, 152, 122],
  [6, 75, 47, 34, 76, 48],
  [46, 54, 24, 10, 55, 25],
  [2, 45, 15, 64, 46, 16],
  // 37
  [17, 152, 122, 4, 153, 123],
  [29, 74, 46, 14, 75, 47],
  [49, 54, 24, 10, 55, 25],
  [24, 45, 15, 46, 46, 16],
  // 38
  [4, 152, 122, 18, 153, 123],
  [13, 74, 46, 32, 75, 47],
  [48, 54, 24, 14, 55, 25],
  [42, 45, 15, 32, 46, 16],
  // 39
  [20, 147, 117, 4, 148, 118],
  [40, 75, 47, 7, 76, 48],
  [43, 54, 24, 22, 55, 25],
  [10, 45, 15, 67, 46, 16],
  // 40
  [19, 148, 118, 6, 149, 119],
  [18, 75, 47, 31, 76, 48],
  [34, 54, 24, 34, 55, 25],
  [20, 45, 15, 61, 46, 16]
];
function createRSBlock(totalCount, dataCount) {
  return { totalCount, dataCount };
}
function getRsBlockTable(typeNumber, errorCorrectionLevel) {
  switch (errorCorrectionLevel) {
    case QRErrorCorrectionLevel.L:
      return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
    case QRErrorCorrectionLevel.M:
      return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
    case QRErrorCorrectionLevel.Q:
      return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
    case QRErrorCorrectionLevel.H:
      return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
    default:
      return void 0;
  }
}
function getRSBlocks(typeNumber, errorCorrectionLevel) {
  const rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);
  if (typeof rsBlock === "undefined") {
    throw new Error(
      `bad rs block @ typeNumber:${typeNumber}/errorCorrectionLevel:${errorCorrectionLevel}`
    );
  }
  const length = rsBlock.length / 3;
  const list = [];
  for (let i = 0; i < length; i += 1) {
    const count = rsBlock[i * 3 + 0];
    const totalCount = rsBlock[i * 3 + 1];
    const dataCount = rsBlock[i * 3 + 2];
    for (let j = 0; j < count; j += 1) {
      list.push(createRSBlock(totalCount, dataCount));
    }
  }
  return list;
}

// src/modules/qr-spec/bch.ts
var _log35 = createLogger("SPEC");
var G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0;
var G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0;
var G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1;
function getBCHDigit(data) {
  let digit = 0;
  let d = data;
  while (d !== 0) {
    digit += 1;
    d >>>= 1;
  }
  return digit;
}
function getBCHTypeInfo(data) {
  let d = data << 10;
  while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
    d ^= G15 << getBCHDigit(d) - getBCHDigit(G15);
  }
  return (data << 10 | d) ^ G15_MASK;
}
function getBCHTypeNumber(data) {
  let d = data << 12;
  while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
    d ^= G18 << getBCHDigit(d) - getBCHDigit(G18);
  }
  return data << 12 | d;
}

// src/modules/qr-spec/constants.ts
var _log36 = createLogger("SPEC");
var ALIGNMENT_POSITIONS = [
  [],
  // Version 1 - no alignment
  [6, 18],
  // Version 2
  [6, 22],
  // Version 3
  [6, 26],
  // Version 4
  [6, 30],
  // Version 5
  [6, 34],
  // Version 6
  [6, 22, 38],
  // Version 7
  [6, 24, 42],
  // Version 8
  [6, 26, 46],
  // Version 9
  [6, 28, 50],
  // Version 10
  [6, 30, 54],
  // Version 11
  [6, 32, 58],
  // Version 12
  [6, 34, 62],
  // Version 13
  [6, 26, 46, 66],
  // Version 14
  [6, 26, 48, 70],
  // Version 15
  [6, 26, 50, 74],
  // Version 16
  [6, 30, 54, 78],
  // Version 17
  [6, 30, 56, 82],
  // Version 18
  [6, 30, 58, 86],
  // Version 19
  [6, 34, 62, 90],
  // Version 20
  [6, 28, 50, 72, 94],
  // Version 21
  [6, 26, 50, 74, 98],
  // Version 22
  [6, 30, 54, 78, 102],
  // Version 23
  [6, 28, 54, 80, 106],
  // Version 24
  [6, 32, 58, 84, 110],
  // Version 25
  [6, 30, 58, 86, 114],
  // Version 26
  [6, 34, 62, 90, 118],
  // Version 27
  [6, 26, 50, 74, 98, 122],
  // Version 28
  [6, 30, 54, 78, 102, 126],
  // Version 29
  [6, 26, 52, 78, 104, 130],
  // Version 30
  [6, 30, 56, 82, 108, 134],
  // Version 31
  [6, 34, 60, 86, 112, 138],
  // Version 32
  [6, 30, 58, 86, 114, 142],
  // Version 33
  [6, 34, 62, 90, 118, 146],
  // Version 34
  [6, 30, 54, 78, 102, 126, 150],
  // Version 35
  [6, 24, 50, 76, 102, 128, 154],
  // Version 36
  [6, 28, 54, 80, 106, 132, 158],
  // Version 37
  [6, 32, 58, 84, 110, 136, 162],
  // Version 38
  [6, 26, 54, 82, 110, 138, 166],
  // Version 39
  [6, 30, 58, 86, 114, 142, 170]
  // Version 40
];
function getAlignmentPositions(version) {
  if (version < 1 || version > 40) return [];
  return ALIGNMENT_POSITIONS[version - 1] || [];
}

// src/modules/qr-spec/types.ts
var _log37 = createLogger("SPEC");
var QRMode2 = {
  MODE_NUMBER: 1 << 0,
  // 0001 - Numeric
  MODE_ALPHA_NUM: 1 << 1,
  // 0010 - Alphanumeric
  MODE_8BIT_BYTE: 1 << 2,
  // 0100 - Byte
  MODE_KANJI: 1 << 3
  // 1000 - Kanji
};
var QRMaskPattern = {
  PATTERN000: 0,
  PATTERN001: 1,
  PATTERN010: 2,
  PATTERN011: 3,
  PATTERN100: 4,
  PATTERN101: 5,
  PATTERN110: 6,
  PATTERN111: 7
};

// src/modules/qr-spec/masks.ts
var _log38 = createLogger("SPEC");
function getMaskFunction(maskPattern) {
  switch (maskPattern) {
    case QRMaskPattern.PATTERN000:
    case 0:
      return (i, j) => (i + j) % 2 === 0;
    case QRMaskPattern.PATTERN001:
    case 1:
      return (i) => i % 2 === 0;
    case QRMaskPattern.PATTERN010:
    case 2:
      return (_i, j) => j % 3 === 0;
    case QRMaskPattern.PATTERN011:
    case 3:
      return (i, j) => (i + j) % 3 === 0;
    case QRMaskPattern.PATTERN100:
    case 4:
      return (i, j) => (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
    case QRMaskPattern.PATTERN101:
    case 5:
      return (i, j) => i * j % 2 + i * j % 3 === 0;
    case QRMaskPattern.PATTERN110:
    case 6:
      return (i, j) => (i * j % 2 + i * j % 3) % 2 === 0;
    case QRMaskPattern.PATTERN111:
    case 7:
      return (i, j) => (i * j % 3 + (i + j) % 2) % 2 === 0;
    default:
      throw new Error(`Invalid mask pattern: ${maskPattern}`);
  }
}

// src/modules/qr-spec/qr-patterns.ts
var _log39 = createLogger("SPEC");
function isFinderPattern(row, col, moduleCount) {
  if (row < 7 && col < 7) return true;
  if (row < 7 && col >= moduleCount - 7) return true;
  if (row >= moduleCount - 7 && col < 7) return true;
  return false;
}
function isTimingPattern(row, col, moduleCount) {
  if (row === 6 && col >= 8 && col < moduleCount - 8) return true;
  if (col === 6 && row >= 8 && row < moduleCount - 8) return true;
  return false;
}
function getAlignmentPatternCenters(version, moduleCount) {
  if (version < 2) return [];
  const positions = ALIGNMENT_POSITIONS[version - 1] || [];
  const centers = [];
  for (const row of positions) {
    for (const col of positions) {
      if (isFinderPattern(row, col, moduleCount)) continue;
      let overlapsWithFinder = false;
      for (let dr = -2; dr <= 2 && !overlapsWithFinder; dr++) {
        for (let dc = -2; dc <= 2 && !overlapsWithFinder; dc++) {
          if (isFinderPattern(row + dr, col + dc, moduleCount)) {
            overlapsWithFinder = true;
          }
        }
      }
      if (!overlapsWithFinder) {
        centers.push({ row, col });
      }
    }
  }
  return centers;
}
function isAlignmentPattern(row, col, moduleCount, version) {
  if (version < 2) return false;
  const centers = getAlignmentPatternCenters(version, moduleCount);
  for (const center of centers) {
    if (Math.abs(row - center.row) <= 2 && Math.abs(col - center.col) <= 2) {
      return true;
    }
  }
  return false;
}
function isFormatInfo(row, col, moduleCount) {
  if (row === 8) {
    if (col <= 5) return true;
    if (col === 7 || col === 8) return true;
    if (col >= moduleCount - 8) return true;
  }
  if (col === 8) {
    if (row <= 5) return true;
    if (row === 7 || row === 8) return true;
    if (row >= moduleCount - 7) return true;
  }
  return false;
}
function isVersionInfo(row, col, moduleCount, version) {
  if (version < 7) return false;
  if (row < 6 && col >= moduleCount - 11 && col < moduleCount - 8) return true;
  if (col < 6 && row >= moduleCount - 11 && row < moduleCount - 8) return true;
  return false;
}

// src/modules/qr-spec/verify.ts
var _log40 = createLogger("SPEC");
function isFinderCoreCorrect(isDark2, baseRow, baseCol) {
  for (let r = 0; r < 7; r++) {
    for (let c = 0; c < 7; c++) {
      const rr = baseRow + r;
      const cc = baseCol + c;
      const expectedDark = r === 0 || r === 6 || c === 0 || c === 6 || r >= 2 && r <= 4 && c >= 2 && c <= 4;
      if (isDark2(rr, cc) !== expectedDark) return false;
    }
  }
  return true;
}
function isAlternatingLine(isDark2, row, colStart, colEnd) {
  let prev = isDark2(row, colStart);
  for (let c = colStart + 1; c <= colEnd; c++) {
    const cur = isDark2(row, c);
    if (cur === prev) return false;
    prev = cur;
  }
  return true;
}
function isAlternatingCol(isDark2, col, rowStart, rowEnd) {
  let prev = isDark2(rowStart, col);
  for (let r = rowStart + 1; r <= rowEnd; r++) {
    const cur = isDark2(r, col);
    if (cur === prev) return false;
    prev = cur;
  }
  return true;
}
function verifyQRStructure(qr, explicitVersion) {
  const issues = [];
  const moduleCount = qr.getModuleCount();
  const rawV = (moduleCount - 17) / 4;
  const version = explicitVersion ?? Math.floor(rawV);
  if (!Number.isFinite(rawV) || rawV < 1 || rawV > 40 || Math.floor(rawV) !== rawV) {
    issues.push(`moduleCount ${moduleCount} does not map to an integer QR version`);
  }
  if (version < 1 || version > 40) {
    issues.push(`version ${version} out of range`);
  }
  const isDark2 = (r, c) => qr.isDark(r, c);
  const tl = isFinderCoreCorrect(isDark2, 0, 0);
  const tr = isFinderCoreCorrect(isDark2, 0, moduleCount - 7);
  const bl = isFinderCoreCorrect(isDark2, moduleCount - 7, 0);
  if (!tl) issues.push("top-left finder core mismatch");
  if (!tr) issues.push("top-right finder core mismatch");
  if (!bl) issues.push("bottom-left finder core mismatch");
  if (moduleCount >= 21) {
    const timingRowOk = isAlternatingLine(isDark2, 6, 8, moduleCount - 9);
    const timingColOk = isAlternatingCol(isDark2, 6, 8, moduleCount - 9);
    if (!timingRowOk) issues.push("timing row does not alternate");
    if (!timingColOk) issues.push("timing col does not alternate");
  }
  const dmRow = moduleCount - 8;
  const dmCol = 8;
  if (dmRow >= 0 && dmRow < moduleCount && dmCol >= 0 && dmCol < moduleCount) {
    if (!isDark2(dmRow, dmCol)) issues.push("fixed dark module is not dark");
  }
  return { ok: issues.length === 0, version, issues };
}

// src/modules/qr-spec/index.ts
var _log41 = createLogger("SPEC");

// src/modules/qr-encoder/utils.ts
var _log42 = createLogger("ENCODER");
var getBCHTypeInfo2 = getBCHTypeInfo;
var getBCHTypeNumber2 = getBCHTypeNumber;
var getMaskFunction2 = getMaskFunction;
function getPatternPosition(typeNumber) {
  return getAlignmentPositions(typeNumber);
}
function getErrorCorrectPolynomial(errorCorrectLength) {
  let a = qrPolynomial([1], 0);
  for (let i = 0; i < errorCorrectLength; i += 1) {
    a = a.multiply(qrPolynomial([1, gexp(i)], 0));
  }
  return a;
}
function getLengthInBits(mode, type) {
  if (1 <= type && type < 10) {
    switch (mode) {
      case QRMode.MODE_NUMBER:
        return 10;
      case QRMode.MODE_ALPHA_NUM:
        return 9;
      case QRMode.MODE_8BIT_BYTE:
        return 8;
      case QRMode.MODE_KANJI:
        return 8;
      default:
        throw new Error(`mode:${mode}`);
    }
  } else if (type < 27) {
    switch (mode) {
      case QRMode.MODE_NUMBER:
        return 12;
      case QRMode.MODE_ALPHA_NUM:
        return 11;
      case QRMode.MODE_8BIT_BYTE:
        return 16;
      case QRMode.MODE_KANJI:
        return 10;
      default:
        throw new Error(`mode:${mode}`);
    }
  } else if (type < 41) {
    switch (mode) {
      case QRMode.MODE_NUMBER:
        return 14;
      case QRMode.MODE_ALPHA_NUM:
        return 13;
      case QRMode.MODE_8BIT_BYTE:
        return 16;
      case QRMode.MODE_KANJI:
        return 12;
      default:
        throw new Error(`mode:${mode}`);
    }
  } else {
    throw new Error(`type:${type}`);
  }
}
function getLostPoint(qrcode2) {
  const moduleCount = qrcode2.getModuleCount();
  let lostPoint = 0;
  for (let row = 0; row < moduleCount; row += 1) {
    for (let col = 0; col < moduleCount; col += 1) {
      let sameCount = 0;
      const dark = qrcode2.isDark(row, col);
      for (let r = -1; r <= 1; r += 1) {
        if (row + r < 0 || moduleCount <= row + r) continue;
        for (let c = -1; c <= 1; c += 1) {
          if (col + c < 0 || moduleCount <= col + c) continue;
          if (r === 0 && c === 0) continue;
          if (dark === qrcode2.isDark(row + r, col + c)) {
            sameCount += 1;
          }
        }
      }
      if (sameCount > 5) {
        lostPoint += 3 + sameCount - 5;
      }
    }
  }
  for (let row = 0; row < moduleCount - 1; row += 1) {
    for (let col = 0; col < moduleCount - 1; col += 1) {
      let count = 0;
      if (qrcode2.isDark(row, col)) count += 1;
      if (qrcode2.isDark(row + 1, col)) count += 1;
      if (qrcode2.isDark(row, col + 1)) count += 1;
      if (qrcode2.isDark(row + 1, col + 1)) count += 1;
      if (count === 0 || count === 4) {
        lostPoint += 3;
      }
    }
  }
  for (let row = 0; row < moduleCount; row += 1) {
    for (let col = 0; col < moduleCount - 6; col += 1) {
      if (qrcode2.isDark(row, col) && !qrcode2.isDark(row, col + 1) && qrcode2.isDark(row, col + 2) && qrcode2.isDark(row, col + 3) && qrcode2.isDark(row, col + 4) && !qrcode2.isDark(row, col + 5) && qrcode2.isDark(row, col + 6)) {
        lostPoint += 40;
      }
    }
  }
  for (let col = 0; col < moduleCount; col += 1) {
    for (let row = 0; row < moduleCount - 6; row += 1) {
      if (qrcode2.isDark(row, col) && !qrcode2.isDark(row + 1, col) && qrcode2.isDark(row + 2, col) && qrcode2.isDark(row + 3, col) && qrcode2.isDark(row + 4, col) && !qrcode2.isDark(row + 5, col) && qrcode2.isDark(row + 6, col)) {
        lostPoint += 40;
      }
    }
  }
  let darkCount = 0;
  for (let col = 0; col < moduleCount; col += 1) {
    for (let row = 0; row < moduleCount; row += 1) {
      if (qrcode2.isDark(row, col)) {
        darkCount += 1;
      }
    }
  }
  const ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
  lostPoint += ratio * 10;
  return lostPoint;
}

// src/modules/qr-encoder/encoder.ts
var _log43 = createLogger("ENCODER");
var PAD0 = 236;
var PAD1 = 17;
function qrcode(typeNumber, errorCorrectionLevel) {
  let _typeNumber = typeNumber;
  const _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
  let _modules = null;
  let _moduleCount = 0;
  let _dataCache = null;
  const _dataList = [];
  const makeImpl = (test, maskPattern) => {
    _moduleCount = _typeNumber * 4 + 17;
    _modules = (() => {
      const modules = new Array(_moduleCount);
      for (let row = 0; row < _moduleCount; row += 1) {
        modules[row] = new Array(_moduleCount);
        for (let col = 0; col < _moduleCount; col += 1) {
          modules[row][col] = null;
        }
      }
      return modules;
    })();
    setupPositionProbePattern(0, 0);
    setupPositionProbePattern(_moduleCount - 7, 0);
    setupPositionProbePattern(0, _moduleCount - 7);
    setupPositionAdjustPattern();
    setupTimingPattern();
    setupTypeInfo(test, maskPattern);
    if (_typeNumber >= 7) {
      setupTypeNumber(test);
    }
    if (_dataCache == null) {
      _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
    }
    mapData(_dataCache, maskPattern);
  };
  const setupPositionProbePattern = (row, col) => {
    for (let r = -1; r <= 7; r += 1) {
      if (row + r <= -1 || _moduleCount <= row + r) continue;
      for (let c = -1; c <= 7; c += 1) {
        if (col + c <= -1 || _moduleCount <= col + c) continue;
        if (0 <= r && r <= 6 && (c === 0 || c === 6) || 0 <= c && c <= 6 && (r === 0 || r === 6) || 2 <= r && r <= 4 && 2 <= c && c <= 4) {
          _modules[row + r][col + c] = true;
        } else {
          _modules[row + r][col + c] = false;
        }
      }
    }
  };
  const getBestMaskPattern = () => {
    let minLostPoint = 0;
    let pattern = 0;
    for (let i = 0; i < 8; i += 1) {
      makeImpl(true, i);
      const lostPoint = getLostPoint(_this);
      if (i === 0 || minLostPoint > lostPoint) {
        minLostPoint = lostPoint;
        pattern = i;
      }
    }
    return pattern;
  };
  const setupTimingPattern = () => {
    for (let r = 8; r < _moduleCount - 8; r += 1) {
      if (_modules[r][6] != null) continue;
      _modules[r][6] = r % 2 === 0;
    }
    for (let c = 8; c < _moduleCount - 8; c += 1) {
      if (_modules[6][c] != null) continue;
      _modules[6][c] = c % 2 === 0;
    }
  };
  const setupPositionAdjustPattern = () => {
    const pos = getPatternPosition(_typeNumber);
    for (let i = 0; i < pos.length; i += 1) {
      for (let j = 0; j < pos.length; j += 1) {
        const row = pos[i];
        const col = pos[j];
        if (_modules[row][col] != null) continue;
        for (let r = -2; r <= 2; r += 1) {
          for (let c = -2; c <= 2; c += 1) {
            if (r === -2 || r === 2 || c === -2 || c === 2 || r === 0 && c === 0) {
              _modules[row + r][col + c] = true;
            } else {
              _modules[row + r][col + c] = false;
            }
          }
        }
      }
    }
  };
  const setupTypeNumber = (test) => {
    const bits = getBCHTypeNumber2(_typeNumber);
    for (let i = 0; i < 18; i += 1) {
      const mod = !test && (bits >> i & 1) === 1;
      _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
    }
    for (let i = 0; i < 18; i += 1) {
      const mod = !test && (bits >> i & 1) === 1;
      _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
    }
  };
  const setupTypeInfo = (test, maskPattern) => {
    const data = _errorCorrectionLevel << 3 | maskPattern;
    const bits = getBCHTypeInfo2(data);
    for (let i = 0; i < 15; i += 1) {
      const mod = !test && (bits >> i & 1) === 1;
      if (i < 6) {
        _modules[i][8] = mod;
      } else if (i < 8) {
        _modules[i + 1][8] = mod;
      } else {
        _modules[_moduleCount - 15 + i][8] = mod;
      }
    }
    for (let i = 0; i < 15; i += 1) {
      const mod = !test && (bits >> i & 1) === 1;
      if (i < 8) {
        _modules[8][_moduleCount - i - 1] = mod;
      } else if (i < 9) {
        _modules[8][15 - i - 1 + 1] = mod;
      } else {
        _modules[8][15 - i - 1] = mod;
      }
    }
    _modules[_moduleCount - 8][8] = !test;
  };
  const mapData = (data, maskPattern) => {
    let inc = -1;
    let row = _moduleCount - 1;
    let bitIndex = 7;
    let byteIndex = 0;
    const maskFunc = getMaskFunction2(maskPattern);
    for (let col = _moduleCount - 1; col > 0; col -= 2) {
      if (col === 6) col -= 1;
      while (true) {
        for (let c = 0; c < 2; c += 1) {
          if (_modules[row][col - c] == null) {
            let dark = false;
            if (byteIndex < data.length) {
              dark = (data[byteIndex] >>> bitIndex & 1) === 1;
            }
            const mask = maskFunc(row, col - c);
            if (mask) {
              dark = !dark;
            }
            _modules[row][col - c] = dark;
            bitIndex -= 1;
            if (bitIndex === -1) {
              byteIndex += 1;
              bitIndex = 7;
            }
          }
        }
        row += inc;
        if (row < 0 || _moduleCount <= row) {
          row -= inc;
          inc = -inc;
          break;
        }
      }
    }
  };
  const createBytes = (buffer, rsBlocks) => {
    let offset = 0;
    let maxDcCount = 0;
    let maxEcCount = 0;
    const dcdata = new Array(rsBlocks.length);
    const ecdata = new Array(rsBlocks.length);
    for (let r = 0; r < rsBlocks.length; r += 1) {
      const dcCount = rsBlocks[r].dataCount;
      const ecCount = rsBlocks[r].totalCount - dcCount;
      maxDcCount = Math.max(maxDcCount, dcCount);
      maxEcCount = Math.max(maxEcCount, ecCount);
      dcdata[r] = new Array(dcCount);
      for (let i = 0; i < dcdata[r].length; i += 1) {
        dcdata[r][i] = 255 & buffer.getBuffer()[i + offset];
      }
      offset += dcCount;
      const rsPoly = getErrorCorrectPolynomial(ecCount);
      const rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);
      const modPoly = rawPoly.mod(rsPoly);
      ecdata[r] = new Array(rsPoly.getLength() - 1);
      for (let i = 0; i < ecdata[r].length; i += 1) {
        const modIndex = i + modPoly.getLength() - ecdata[r].length;
        ecdata[r][i] = modIndex >= 0 ? modPoly.getAt(modIndex) : 0;
      }
    }
    let totalCodeCount = 0;
    for (let i = 0; i < rsBlocks.length; i += 1) {
      totalCodeCount += rsBlocks[i].totalCount;
    }
    const data = new Array(totalCodeCount);
    let index = 0;
    for (let i = 0; i < maxDcCount; i += 1) {
      for (let r = 0; r < rsBlocks.length; r += 1) {
        if (i < dcdata[r].length) {
          data[index] = dcdata[r][i];
          index += 1;
        }
      }
    }
    for (let i = 0; i < maxEcCount; i += 1) {
      for (let r = 0; r < rsBlocks.length; r += 1) {
        if (i < ecdata[r].length) {
          data[index] = ecdata[r][i];
          index += 1;
        }
      }
    }
    return data;
  };
  const createData = (typeNumber2, errorCorrectionLevel2, dataList) => {
    const rsBlocks = getRSBlocks(typeNumber2, errorCorrectionLevel2);
    const buffer = qrBitBuffer();
    for (let i = 0; i < dataList.length; i += 1) {
      const data = dataList[i];
      buffer.put(data.getMode(), 4);
      buffer.put(data.getLength(), getLengthInBits(data.getMode(), typeNumber2));
      data.write(buffer);
    }
    let totalDataCount = 0;
    for (let i = 0; i < rsBlocks.length; i += 1) {
      totalDataCount += rsBlocks[i].dataCount;
    }
    if (buffer.getLengthInBits() > totalDataCount * 8) {
      throw new Error(`code length overflow. (${buffer.getLengthInBits()}>${totalDataCount * 8})`);
    }
    if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
      buffer.put(0, 4);
    }
    while (buffer.getLengthInBits() % 8 !== 0) {
      buffer.putBit(false);
    }
    while (true) {
      if (buffer.getLengthInBits() >= totalDataCount * 8) {
        break;
      }
      buffer.put(PAD0, 8);
      if (buffer.getLengthInBits() >= totalDataCount * 8) {
        break;
      }
      buffer.put(PAD1, 8);
    }
    return createBytes(buffer, rsBlocks);
  };
  const escapeXml = (s) => {
    let escaped = "";
    for (let i = 0; i < s.length; i += 1) {
      const c = s.charAt(i);
      switch (c) {
        case "<":
          escaped += "&lt;";
          break;
        case ">":
          escaped += "&gt;";
          break;
        case "&":
          escaped += "&amp;";
          break;
        case '"':
          escaped += "&quot;";
          break;
        default:
          escaped += c;
          break;
      }
    }
    return escaped;
  };
  const _createHalfASCII = (margin) => {
    const cellSize = 1;
    const marginVal = typeof margin === "undefined" ? cellSize * 2 : margin;
    const size = _moduleCount * cellSize + marginVal * 2;
    const min = marginVal;
    const max = size - marginVal;
    const blocks = {
      "\u2588\u2588": "\u2588",
      "\u2588 ": "\u2580",
      " \u2588": "\u2584",
      "  ": " "
    };
    const blocksLastLineNoMargin = {
      "\u2588\u2588": "\u2580",
      "\u2588 ": "\u2580",
      " \u2588": " ",
      "  ": " "
    };
    let ascii = "";
    for (let y = 0; y < size; y += 2) {
      const r1 = Math.floor((y - min) / cellSize);
      const r2 = Math.floor((y + 1 - min) / cellSize);
      for (let x = 0; x < size; x += 1) {
        let p = "\u2588";
        if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
          p = " ";
        }
        if (min <= x && x < max && min <= y + 1 && y + 1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
          p += " ";
        } else {
          p += "\u2588";
        }
        ascii += marginVal < 1 && y + 1 >= max ? blocksLastLineNoMargin[p] : blocks[p];
      }
      ascii += "\n";
    }
    if (size % 2 && marginVal > 0) {
      return ascii.substring(0, ascii.length - size - 1) + Array(size + 1).join("\u2580");
    }
    return ascii.substring(0, ascii.length - 1);
  };
  const _this = {
    addData: (data, mode) => {
      const modeVal = mode || "Byte";
      let newData = null;
      switch (modeVal) {
        case "Numeric":
          newData = qrNumber(data);
          break;
        case "Alphanumeric":
          newData = qrAlphaNum(data);
          break;
        case "Byte":
          newData = qr8BitByte(data);
          break;
        case "Kanji":
          newData = qrKanji(data);
          break;
        default:
          throw new Error(`mode:${modeVal}`);
      }
      _dataList.push(newData);
      _dataCache = null;
    },
    isDark: (row, col) => {
      if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
        throw new Error(`${row},${col}`);
      }
      return _modules[row][col] === true;
    },
    getModuleCount: () => _moduleCount,
    make: (maskPattern) => {
      if (_typeNumber < 1) {
        let typeNum = 1;
        for (; typeNum < 40; typeNum++) {
          const rsBlocks = getRSBlocks(typeNum, _errorCorrectionLevel);
          const buffer = qrBitBuffer();
          for (let i = 0; i < _dataList.length; i++) {
            const data = _dataList[i];
            buffer.put(data.getMode(), 4);
            buffer.put(data.getLength(), getLengthInBits(data.getMode(), typeNum));
            data.write(buffer);
          }
          let totalDataCount = 0;
          for (let i = 0; i < rsBlocks.length; i++) {
            totalDataCount += rsBlocks[i].dataCount;
          }
          if (buffer.getLengthInBits() <= totalDataCount * 8) {
            break;
          }
        }
        _typeNumber = typeNum;
      }
      const finalMaskPattern = typeof maskPattern === "number" && maskPattern >= 0 && maskPattern <= 7 ? maskPattern : getBestMaskPattern();
      makeImpl(false, finalMaskPattern);
    },
    createTableTag: (cellSize, margin) => {
      const cellSizeVal = cellSize || 2;
      const marginVal = typeof margin === "undefined" ? cellSizeVal * 4 : margin;
      let qrHtml = "";
      qrHtml += '<table style="';
      qrHtml += " border-width: 0px; border-style: none;";
      qrHtml += " border-collapse: collapse;";
      qrHtml += ` padding: 0px; margin: ${marginVal}px;`;
      qrHtml += '">';
      qrHtml += "<tbody>";
      for (let r = 0; r < _this.getModuleCount(); r += 1) {
        qrHtml += "<tr>";
        for (let c = 0; c < _this.getModuleCount(); c += 1) {
          qrHtml += '<td style="';
          qrHtml += " border-width: 0px; border-style: none;";
          qrHtml += " border-collapse: collapse;";
          qrHtml += " padding: 0px; margin: 0px;";
          qrHtml += ` width: ${cellSizeVal}px;`;
          qrHtml += ` height: ${cellSizeVal}px;`;
          qrHtml += " background-color: ";
          qrHtml += _this.isDark(r, c) ? "#000000" : "#ffffff";
          qrHtml += ";";
          qrHtml += '"/>';
        }
        qrHtml += "</tr>";
      }
      qrHtml += "</tbody>";
      qrHtml += "</table>";
      return qrHtml;
    },
    createSvgTag: (cellSize, margin, alt, title) => {
      let opts = {};
      if (typeof cellSize === "object") {
        opts = cellSize;
        cellSize = opts.cellSize;
        margin = opts.margin;
        alt = opts.alt;
        title = opts.title;
      }
      const cellSizeVal = cellSize || 2;
      const marginVal = typeof margin === "undefined" ? cellSizeVal * 4 : margin;
      let altObj = { text: null, id: null };
      if (typeof alt === "string") {
        altObj = { text: alt, id: alt ? "qrcode-description" : null };
      } else if (alt && typeof alt === "object") {
        altObj = alt;
      }
      altObj.text = altObj.text || null;
      altObj.id = altObj.text ? altObj.id || "qrcode-description" : null;
      let titleObj = { text: null, id: null };
      if (typeof title === "string") {
        titleObj = { text: title, id: title ? "qrcode-title" : null };
      } else if (title && typeof title === "object") {
        titleObj = title;
      }
      titleObj.text = titleObj.text || null;
      titleObj.id = titleObj.text ? titleObj.id || "qrcode-title" : null;
      const size = _this.getModuleCount() * cellSizeVal + marginVal * 2;
      const rect = `l${cellSizeVal},0 0,${cellSizeVal} -${cellSizeVal},0 0,-${cellSizeVal}z `;
      let qrSvg = "";
      qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
      qrSvg += !opts.scalable ? ` width="${size}px" height="${size}px"` : "";
      qrSvg += ` viewBox="0 0 ${size} ${size}" `;
      qrSvg += ' preserveAspectRatio="xMinYMin meet"';
      qrSvg += titleObj.text || altObj.text ? ` role="img" aria-labelledby="${escapeXml([titleObj.id, altObj.id].join(" ").trim())}"` : "";
      qrSvg += ">";
      qrSvg += titleObj.text ? `<title id="${escapeXml(titleObj.id || "")}">${escapeXml(titleObj.text)}</title>` : "";
      qrSvg += altObj.text ? `<description id="${escapeXml(altObj.id || "")}">${escapeXml(altObj.text)}</description>` : "";
      qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
      qrSvg += '<path d="';
      for (let r = 0; r < _this.getModuleCount(); r += 1) {
        const mr = r * cellSizeVal + marginVal;
        for (let c = 0; c < _this.getModuleCount(); c += 1) {
          if (_this.isDark(r, c)) {
            const mc = c * cellSizeVal + marginVal;
            qrSvg += `M${mc},${mr}${rect}`;
          }
        }
      }
      qrSvg += '" stroke="transparent" fill="black"/>';
      qrSvg += "</svg>";
      return qrSvg;
    },
    createDataURL: (cellSize, margin) => {
      const cellSizeVal = cellSize || 2;
      const marginVal = typeof margin === "undefined" ? cellSizeVal * 4 : margin;
      const size = _this.getModuleCount() * cellSizeVal + marginVal * 2;
      const min = marginVal;
      const max = size - marginVal;
      return createDataURL(size, size, (x, y) => {
        if (min <= x && x < max && min <= y && y < max) {
          const c = Math.floor((x - min) / cellSizeVal);
          const r = Math.floor((y - min) / cellSizeVal);
          return _this.isDark(r, c) ? 0 : 1;
        } else {
          return 1;
        }
      });
    },
    createImgTag: (cellSize, margin, alt) => {
      const cellSizeVal = cellSize || 2;
      const marginVal = typeof margin === "undefined" ? cellSizeVal * 4 : margin;
      const size = _this.getModuleCount() * cellSizeVal + marginVal * 2;
      let img = "";
      img += "<img";
      img += ' src="';
      img += _this.createDataURL(cellSizeVal, marginVal);
      img += '"';
      img += ' width="';
      img += size;
      img += '"';
      img += ' height="';
      img += size;
      img += '"';
      if (alt) {
        img += ' alt="';
        img += escapeXml(alt);
        img += '"';
      }
      img += "/>";
      return img;
    },
    createASCII: (cellSize, margin) => {
      const cellSizeVal = cellSize || 1;
      if (cellSizeVal < 2) {
        return _createHalfASCII(margin);
      }
      const cs = cellSizeVal - 1;
      const marginVal = typeof margin === "undefined" ? cs * 2 : margin;
      const size = _moduleCount * cs + marginVal * 2;
      const min = marginVal;
      const max = size - marginVal;
      const white = Array(cs + 1).join("\u2588\u2588");
      const black = Array(cs + 1).join("  ");
      let ascii = "";
      for (let y = 0; y < size; y += 1) {
        const r = Math.floor((y - min) / cs);
        let line = "";
        for (let x = 0; x < size; x += 1) {
          let p = 1;
          if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cs))) {
            p = 0;
          }
          line += p ? white : black;
        }
        for (let i = 0; i < cs; i += 1) {
          ascii += `${line}
`;
        }
      }
      return ascii.substring(0, ascii.length - 1);
    },
    renderTo2dContext: (context, cellSize) => {
      const cellSizeVal = cellSize || 2;
      const length = _this.getModuleCount();
      for (let row = 0; row < length; row++) {
        for (let col = 0; col < length; col++) {
          context.fillStyle = _this.isDark(row, col) ? "black" : "white";
          context.fillRect(col * cellSizeVal, row * cellSizeVal, cellSizeVal, cellSizeVal);
        }
      }
    },
    // Debug/test helper to access interleaved data bytes
    getDataCache: () => {
      if (_typeNumber < 1) {
        throw new Error("QR code not initialized: call make() before getDataCache()");
      }
      if (_dataCache == null) {
        _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
      }
      return _dataCache;
    }
  };
  return _this;
}

// src/modules/qr-encoder/encoder-api.ts
var _log44 = createLogger("ENCODER");
function isNumeric(char) {
  return /^[0-9]$/.test(char);
}
function isAlphanumeric(char) {
  return /^[0-9A-Z $%*+\-./:]$/.test(char);
}
function optimizeSegments(text) {
  if (!text || text.length === 0) {
    return [];
  }
  const segments = [];
  let i = 0;
  while (i < text.length) {
    const numericStart = i;
    while (i < text.length && isNumeric(text[i])) {
      i++;
    }
    const numericLen = i - numericStart;
    if (numericLen >= 4) {
      segments.push({ data: text.slice(numericStart, i), mode: "numeric" });
      continue;
    }
    i = numericStart;
    const alphaStart = i;
    const upperText = text.toUpperCase();
    while (i < text.length && isAlphanumeric(upperText[i]) && text[i] === upperText[i]) {
      i++;
    }
    const alphaLen = i - alphaStart;
    if (alphaLen >= 6) {
      segments.push({ data: text.slice(alphaStart, i), mode: "alphanumeric" });
      continue;
    }
    i = alphaStart;
    const byteStart = i;
    while (i < text.length) {
      let numAhead = 0;
      let j = i;
      while (j < text.length && isNumeric(text[j])) {
        numAhead++;
        j++;
      }
      if (numAhead >= 4) break;
      let alphaAhead = 0;
      j = i;
      while (j < text.length && isAlphanumeric(upperText[j]) && text[j] === upperText[j]) {
        alphaAhead++;
        j++;
      }
      if (alphaAhead >= 6) break;
      i++;
    }
    if (i > byteStart) {
      segments.push({ data: text.slice(byteStart, i), mode: "byte" });
    }
  }
  const merged = [];
  for (const seg of segments) {
    if (merged.length > 0 && merged[merged.length - 1].mode === seg.mode) {
      merged[merged.length - 1].data += seg.data;
    } else {
      merged.push({ ...seg });
    }
  }
  return merged;
}
function toEncoderModeToken(mode, content) {
  if (mode === "numeric") return "Numeric";
  if (mode === "alphanumeric") return "Alphanumeric";
  if (mode === "kanji") return "Kanji";
  if (mode === "byte") return "Byte";
  const compatible = getCompatibleMode(content, mode);
  switch (compatible) {
    case "numeric":
      return "Numeric";
    case "alphanumeric":
      return "Alphanumeric";
    case "kanji":
      return "Kanji";
    default:
      return "Byte";
  }
}
function createQRInstanceWithSegments(segments, errorCorrectionLevel = "M", version = 0, options = {}) {
  const typeNumber = version === 0 ? 0 : version;
  const qr = qrcode(
    typeNumber,
    errorCorrectionLevel
  );
  for (const segment of segments) {
    const modeToken = toEncoderModeToken(segment.mode, segment.data);
    qr.addData(segment.data, modeToken);
  }
  const mask = options.maskPattern;
  const maskPattern = typeof mask === "number" && mask >= 0 && mask <= 7 ? mask : void 0;
  qr.make(maskPattern);
  return qr;
}
function createQRInstance(data, errorCorrectionLevel = "M", version = 0, options = {}) {
  if (options.mode === "mixed" || options.mode === "auto") {
    const segments = optimizeSegments(data);
    if (segments.length > 1 || segments.length === 1 && segments[0].mode !== "byte") {
      return createQRInstanceWithSegments(segments, errorCorrectionLevel, version, options);
    }
  }
  const typeNumber = version === 0 ? 0 : version;
  const qr = qrcode(
    typeNumber,
    errorCorrectionLevel
  );
  const modeToken = options.mode && options.mode !== "mixed" ? toEncoderModeToken(options.mode, data) : void 0;
  qr.addData(data, modeToken);
  const mask = options.maskPattern;
  const maskPattern = typeof mask === "number" && mask >= 0 && mask <= 7 ? mask : void 0;
  qr.make(maskPattern);
  return qr;
}
function getCompatibleMode(content, requestedMode) {
  if (requestedMode === "auto") {
    if (/^[0-9]+$/.test(content)) return "numeric";
    if (/^[0-9A-Z $%*+\-./:']+$/.test(content)) return "alphanumeric";
    return "byte";
  }
  switch (requestedMode) {
    case "numeric":
      if (/^[0-9]+$/.test(content)) return "numeric";
      break;
    case "alphanumeric":
      if (/^[0-9A-Z $%*+\-./:']+$/.test(content)) return "alphanumeric";
      break;
    case "kanji":
      return "kanji";
    case "byte":
      return "byte";
  }
  return "byte";
}
function calculateOptimalVersion(data, errorCorrectionLevel = "M") {
  for (let v = 1; v <= 40; v++) {
    try {
      createQRInstance(data, errorCorrectionLevel, v);
      return v;
    } catch {
    }
  }
  return 40;
}

// src/modules/qr-generator/cache.ts
var _log45 = createLogger("GENERATE");
var MemoCache = class {
  cache;
  maxSize;
  constructor(maxSize = 100) {
    this.cache = /* @__PURE__ */ new Map();
    this.maxSize = maxSize;
  }
  get(key) {
    if (this.cache.has(key)) {
      const value = this.cache.get(key);
      this.cache.delete(key);
      this.cache.set(key, value);
      return value;
    }
    return void 0;
  }
  set(key, value) {
    if (this.cache.has(key)) {
      this.cache.delete(key);
    }
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      if (firstKey !== void 0) {
        this.cache.delete(firstKey);
      }
    }
    this.cache.set(key, value);
  }
  clear() {
    this.cache.clear();
  }
};
var alignmentCache = new MemoCache(50);
var overlayDataCache = new MemoCache(20);
var qrMatrixCache = new MemoCache(30);
var canvasHashCache = /* @__PURE__ */ new WeakMap();

// src/modules/qr-generator/canvas-factory.ts
var _log46 = createLogger("GENERATE");
var defaultBrowserCanvasFactory = {
  createCanvas: (width, height) => {
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    return Promise.resolve(canvas);
  },
  loadImage: (src) => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error(`Failed to load image: ${src}`));
      img.src = src;
    });
  }
};

// src/modules/qr-generator/utils.ts
var log2 = createLogger("GENERATE");
function validateColor(color, fallback) {
  if (typeof color !== "string" || !color) {
    return fallback;
  }
  const trimmed = color.trim();
  if (trimmed.length < 4) {
    return fallback;
  }
  if (trimmed.startsWith("#")) {
    const hex = trimmed.slice(1);
    if (!/^[0-9a-fA-F]{3,8}$/.test(hex)) {
      return fallback;
    }
    return trimmed;
  }
  if (trimmed.startsWith("rgb")) {
    return trimmed;
  }
  if (trimmed.startsWith("hsl")) {
    return trimmed;
  }
  if (/^[a-zA-Z]+$/.test(trimmed)) {
    return trimmed;
  }
  return fallback;
}
var getContrastRatio2 = getContrastRatio;
async function hashCanvasContent(canvas, createCanvasFn) {
  const cachedHash = canvas instanceof HTMLCanvasElement ? canvasHashCache.get(canvas) : void 0;
  if (cachedHash !== void 0) {
    return cachedHash;
  }
  try {
    const hashSize = 32;
    const hashCanvas = typeof document !== "undefined" ? (() => {
      const c = document.createElement("canvas");
      c.width = hashSize;
      c.height = hashSize;
      return c;
    })() : await createCanvasFn(hashSize, hashSize);
    const hashCtx = hashCanvas.getContext("2d");
    if (!hashCtx) {
      return `${canvas.width}x${canvas.height}`;
    }
    hashCtx.drawImage(canvas, 0, 0, hashSize, hashSize);
    const imageData = hashCtx.getImageData(0, 0, hashSize, hashSize);
    const data = imageData.data;
    let hash = 5381;
    for (let i = 0; i < data.length; i += 4) {
      hash = (hash << 5) + hash + data[i];
      hash = (hash << 5) + hash + data[i + 1];
      hash = (hash << 5) + hash + data[i + 2];
      hash = hash >>> 0;
    }
    const hashStr = hash.toString(16);
    if (canvas instanceof HTMLCanvasElement) {
      canvasHashCache.set(canvas, hashStr);
    }
    return hashStr;
  } catch (error) {
    log2.warn("Canvas hashing failed", { error });
    return `${canvas.width}x${canvas.height}`;
  }
}

// src/modules/qr-generator/color.ts
var log3 = createLogger("GENERATE");
function applyPerModuleColor(mode, baseColor, overlayData, row, col, moduleCount, config) {
  const brightness2 = overlayData[row]?.[col] ?? 0.5;
  const overlayColor = overlayData.colors?.[row]?.[col];
  const intensity = (config.overlayIntensity || 100) / 100;
  switch (mode) {
    case "by_brightness": {
      const parsed = parseColor(baseColor);
      if (!parsed) return baseColor;
      const factor = 0.5 + brightness2 * 0.5;
      return `rgb(${Math.round(parsed.r * factor)},${Math.round(parsed.g * factor)},${Math.round(parsed.b * factor)})`;
    }
    case "by_position": {
      const parsed = parseColor(baseColor);
      if (!parsed) return baseColor;
      const xFactor = col / moduleCount;
      const yFactor = row / moduleCount;
      const r = Math.round(parsed.r * (0.5 + xFactor * 0.5));
      const g = Math.round(parsed.g * (0.5 + yFactor * 0.5));
      const b = Math.round(parsed.b * (0.5 + (1 - xFactor) * 0.5));
      return `rgb(${r},${g},${b})`;
    }
    case "by_overlay": {
      if (overlayColor) {
        const colorStr = `rgb(${overlayColor.r},${overlayColor.g},${overlayColor.b})`;
        return blendColors(baseColor, colorStr, intensity);
      }
      return baseColor;
    }
    case "by_cluster": {
      const blockSize = 3;
      const blockRow = Math.floor(row / blockSize);
      const blockCol = Math.floor(col / blockSize);
      const seed = blockRow * 100 + blockCol;
      const hueShift = seed * 37 % 360;
      const parsed = parseColor(baseColor);
      if (!parsed) return baseColor;
      const angle = hueShift * Math.PI / 180;
      const cos = Math.cos(angle);
      const sin = Math.sin(angle);
      const r = Math.max(
        0,
        Math.min(
          255,
          parsed.r * (0.213 + cos * 0.787 - sin * 0.213) + parsed.g * (0.715 - cos * 0.715 - sin * 0.715) + parsed.b * (0.072 - cos * 0.072 + sin * 0.928)
        )
      );
      const g = Math.max(
        0,
        Math.min(
          255,
          parsed.r * (0.213 - cos * 0.213 + sin * 0.143) + parsed.g * (0.715 + cos * 0.285 + sin * 0.14) + parsed.b * (0.072 - cos * 0.072 - sin * 0.283)
        )
      );
      const b = Math.max(
        0,
        Math.min(
          255,
          parsed.r * (0.213 - cos * 0.213 - sin * 0.787) + parsed.g * (0.715 - cos * 0.715 + sin * 0.715) + parsed.b * (0.072 + cos * 0.928 + sin * 0.072)
        )
      );
      return `rgb(${Math.round(r)},${Math.round(g)},${Math.round(b)})`;
    }
    default:
      return baseColor;
  }
}
function ensureContrast(moduleColor, bgColor, minRatio) {
  try {
    const ratio = getContrastRatio2(moduleColor, bgColor);
    if (ratio >= minRatio) {
      return moduleColor;
    }
    const parsed = parseColor(moduleColor);
    if (!parsed) return moduleColor;
    const bgLuminance = getRelativeLuminance(bgColor);
    const bgIsDark = bgLuminance < 0.179;
    let newColor = moduleColor;
    if (bgIsDark) {
      let factor = 0.1;
      for (let i = 0; i < 10; i++) {
        const r = Math.round(parsed.r + (255 - parsed.r) * factor);
        const g = Math.round(parsed.g + (255 - parsed.g) * factor);
        const b = Math.round(parsed.b + (255 - parsed.b) * factor);
        newColor = `rgb(${r},${g},${b})`;
        const newRatio = getContrastRatio2(newColor, bgColor);
        if (newRatio >= minRatio) {
          return newColor;
        }
        factor = Math.min(1, factor + 0.1);
      }
      return "#ffffff";
    } else {
      let factor = 0.9;
      for (let i = 0; i < 10; i++) {
        const r = Math.round(parsed.r * factor);
        const g = Math.round(parsed.g * factor);
        const b = Math.round(parsed.b * factor);
        newColor = `rgb(${r},${g},${b})`;
        const newRatio = getContrastRatio2(newColor, bgColor);
        if (newRatio >= minRatio) {
          return newColor;
        }
        factor *= 0.85;
      }
      return "#000000";
    }
  } catch (error) {
    log3.warn("Contrast check failed", { error });
    return moduleColor;
  }
}
function applyPaletteColor(row, col, moduleCount, brightness2, palette, config) {
  if (!palette || palette.length === 0) return config.fgColor;
  const paletteMode = config.paletteMode || "position";
  switch (paletteMode) {
    case "brightness": {
      const idx = Math.floor((1 - brightness2) * (palette.length - 0.01));
      return palette[Math.max(0, Math.min(palette.length - 1, idx))];
    }
    case "diagonal": {
      const diag = (row + col) / (moduleCount * 2);
      const idx = Math.floor(diag * palette.length) % palette.length;
      return palette[idx];
    }
    case "radial": {
      const cx = moduleCount / 2;
      const cy = moduleCount / 2;
      const dist = Math.hypot(row - cy, col - cx);
      const maxDist = Math.hypot(cx, cy);
      const idx = Math.floor(dist / maxDist * palette.length) % palette.length;
      return palette[idx];
    }
    case "random": {
      const hash = (row * 31 + col) * 17 % palette.length;
      return palette[hash];
    }
    case "row": {
      const idx = Math.floor(row / moduleCount * palette.length) % palette.length;
      return palette[idx];
    }
    case "column": {
      const idx = Math.floor(col / moduleCount * palette.length) % palette.length;
      return palette[idx];
    }
    default: {
      const linearPos = row * moduleCount + col;
      const idx = linearPos % palette.length;
      return palette[idx];
    }
  }
}

// src/modules/qr-generator/dithering-advanced.ts
var _log47 = createLogger("GENERATE");

// src/modules/qr-generator/dithering-error.ts
var _log48 = createLogger("GENERATE");
function distributeError(errors, x, y, error, kernel, width, height) {
  for (const offset of kernel.offsets) {
    const nx = x + offset.dx;
    const ny = y + offset.dy;
    if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
      if (!errors[ny]) errors[ny] = [];
      errors[ny][nx] = (errors[ny][nx] || 0) + error * offset.weight / kernel.divisor;
    }
  }
}

// src/modules/qr-generator/dithering-kernels.ts
var _log49 = createLogger("GENERATE");
function getDiffusionKernel(name) {
  const kernels = {
    floyd_steinberg: {
      offsets: [
        { dx: 1, dy: 0, weight: 7 },
        { dx: -1, dy: 1, weight: 3 },
        { dx: 0, dy: 1, weight: 5 },
        { dx: 1, dy: 1, weight: 1 }
      ],
      divisor: 16
    },
    jarvis_judice_ninke: {
      offsets: [
        { dx: 1, dy: 0, weight: 7 },
        { dx: 2, dy: 0, weight: 5 },
        { dx: -2, dy: 1, weight: 3 },
        { dx: -1, dy: 1, weight: 5 },
        { dx: 0, dy: 1, weight: 7 },
        { dx: 1, dy: 1, weight: 5 },
        { dx: 2, dy: 1, weight: 3 },
        { dx: -2, dy: 2, weight: 1 },
        { dx: -1, dy: 2, weight: 3 },
        { dx: 0, dy: 2, weight: 5 },
        { dx: 1, dy: 2, weight: 3 },
        { dx: 2, dy: 2, weight: 1 }
      ],
      divisor: 48
    },
    stucki: {
      offsets: [
        { dx: 1, dy: 0, weight: 8 },
        { dx: 2, dy: 0, weight: 4 },
        { dx: -2, dy: 1, weight: 2 },
        { dx: -1, dy: 1, weight: 4 },
        { dx: 0, dy: 1, weight: 8 },
        { dx: 1, dy: 1, weight: 4 },
        { dx: 2, dy: 1, weight: 2 },
        { dx: -2, dy: 2, weight: 1 },
        { dx: -1, dy: 2, weight: 2 },
        { dx: 0, dy: 2, weight: 4 },
        { dx: 1, dy: 2, weight: 2 },
        { dx: 2, dy: 2, weight: 1 }
      ],
      divisor: 42
    },
    atkinson: {
      offsets: [
        { dx: 1, dy: 0, weight: 1 },
        { dx: 2, dy: 0, weight: 1 },
        { dx: -1, dy: 1, weight: 1 },
        { dx: 0, dy: 1, weight: 1 },
        { dx: 1, dy: 1, weight: 1 },
        { dx: 0, dy: 2, weight: 1 }
      ],
      divisor: 8
    },
    burkes: {
      offsets: [
        { dx: 1, dy: 0, weight: 8 },
        { dx: 2, dy: 0, weight: 4 },
        { dx: -2, dy: 1, weight: 2 },
        { dx: -1, dy: 1, weight: 4 },
        { dx: 0, dy: 1, weight: 8 },
        { dx: 1, dy: 1, weight: 4 },
        { dx: 2, dy: 1, weight: 2 }
      ],
      divisor: 32
    },
    sierra: {
      offsets: [
        { dx: 1, dy: 0, weight: 5 },
        { dx: 2, dy: 0, weight: 3 },
        { dx: -2, dy: 1, weight: 2 },
        { dx: -1, dy: 1, weight: 4 },
        { dx: 0, dy: 1, weight: 5 },
        { dx: 1, dy: 1, weight: 4 },
        { dx: 2, dy: 1, weight: 2 },
        { dx: -1, dy: 2, weight: 2 },
        { dx: 0, dy: 2, weight: 3 },
        { dx: 1, dy: 2, weight: 2 }
      ],
      divisor: 32
    },
    sierra_two_row: {
      offsets: [
        { dx: 1, dy: 0, weight: 4 },
        { dx: 2, dy: 0, weight: 3 },
        { dx: -2, dy: 1, weight: 1 },
        { dx: -1, dy: 1, weight: 2 },
        { dx: 0, dy: 1, weight: 3 },
        { dx: 1, dy: 1, weight: 2 },
        { dx: 2, dy: 1, weight: 1 }
      ],
      divisor: 16
    },
    sierra_lite: {
      offsets: [
        { dx: 1, dy: 0, weight: 2 },
        { dx: -1, dy: 1, weight: 1 },
        { dx: 0, dy: 1, weight: 1 }
      ],
      divisor: 4
    }
  };
  return kernels[name] || kernels.floyd_steinberg;
}

// src/modules/qr-generator/dithering-constants.ts
var HISTOGRAM_BUCKETS = 32;
var BUCKET_SHIFT = 3;
var DARK_REGION_END = 8;
var LIGHT_REGION_START = 24;
var MIN_PEAK_RATIO = 0.12;
var MAX_VALLEY_RATIO = 0.2;
var MIN_PEAK_SEPARATION = 16;
var DARK_DESIRE_MIN = 0.55;
var DARK_DESIRE_MAX = 0.95;
var LIGHT_DESIRE_MIN = 0.05;
var LIGHT_DESIRE_MAX = 0.45;

// src/modules/qr-generator/dithering-matrix.ts
var log4 = createLogger("GENERATE");
function detectBWFromOverlayData(overlayData, moduleCount) {
  const histogram = new Int32Array(HISTOGRAM_BUCKETS);
  let totalPixels = 0;
  for (let row = 0; row < moduleCount; row++) {
    for (let col = 0; col < moduleCount; col++) {
      const brightness2 = overlayData[row]?.[col] ?? 0.5;
      const gray = Math.floor(brightness2 * 255);
      const bucket = Math.min(HISTOGRAM_BUCKETS - 1, gray >> BUCKET_SHIFT);
      histogram[bucket]++;
      totalPixels++;
    }
  }
  if (totalPixels === 0) return false;
  let darkPeakBucket = 0, lightPeakBucket = 0;
  let darkPeak = 0, lightPeak = 0;
  for (let i = 0; i < DARK_REGION_END; i++) {
    if (histogram[i] > darkPeak) {
      darkPeak = histogram[i];
      darkPeakBucket = i;
    }
  }
  for (let i = LIGHT_REGION_START; i < HISTOGRAM_BUCKETS; i++) {
    if (histogram[i] > lightPeak) {
      lightPeak = histogram[i];
      lightPeakBucket = i;
    }
  }
  if (lightPeakBucket - darkPeakBucket < MIN_PEAK_SEPARATION) return false;
  let darkCount = 0, lightCount = 0, valleyCount = 0;
  for (let i = 0; i < DARK_REGION_END; i++) darkCount += histogram[i];
  for (let i = LIGHT_REGION_START; i < HISTOGRAM_BUCKETS; i++) lightCount += histogram[i];
  for (let i = DARK_REGION_END; i < LIGHT_REGION_START; i++) valleyCount += histogram[i];
  return darkCount / totalPixels >= MIN_PEAK_RATIO && lightCount / totalPixels >= MIN_PEAK_RATIO && valleyCount / totalPixels < MAX_VALLEY_RATIO;
}
function isStructuralModule2(row, col, moduleCount, version) {
  if (row === moduleCount - 8 && col === 8) return true;
  return isFinderPattern(row, col, moduleCount) || isTimingPattern(row, col, moduleCount) || isAlignmentPattern(row, col, moduleCount, version) || isFormatInfo(row, col, moduleCount) || isVersionInfo(row, col, moduleCount, version);
}
function isQuietZoneSeparator(row, col, moduleCount) {
  if (row === 7 && col <= 7 || col === 7 && row <= 7) return true;
  if (row === 7 && col >= moduleCount - 8 || col === moduleCount - 8 && row <= 7) return true;
  if (row === moduleCount - 8 && col <= 7 || col === 7 && row >= moduleCount - 8) return true;
  return false;
}
function applyDitherToMatrix(qr, moduleCount, overlayData, config) {
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  if (detectBWFromOverlayData(overlayData, moduleCount)) {
    log4.debug("Detected high-contrast B&W overlay in dither mode - using QR-first (no dithering)");
    const result2 = [];
    for (let row = 0; row < moduleCount; row++) {
      result2[row] = [];
      for (let col = 0; col < moduleCount; col++) {
        result2[row][col] = qr.isDark(row, col);
      }
    }
    return result2;
  }
  const kernel = getDiffusionKernel(config.ditherKind || "floyd_steinberg");
  const strength = (config.ditherStrength ?? 50) / 100;
  const intensity = (config.overlayIntensity ?? 100) / 100;
  const result = [];
  for (let row = 0; row < moduleCount; row++) {
    result[row] = [];
    for (let col = 0; col < moduleCount; col++) {
      result[row][col] = qr.isDark(row, col);
    }
  }
  const errors = [];
  for (let row = 0; row < moduleCount; row++) {
    errors[row] = new Array(moduleCount).fill(0);
  }
  for (let row = 0; row < moduleCount; row++) {
    for (let col = 0; col < moduleCount; col++) {
      const qrIsDark = qr.isDark(row, col);
      if (isStructuralModule2(row, col, moduleCount, version) || isQuietZoneSeparator(row, col, moduleCount)) {
        result[row][col] = qrIsDark;
        continue;
      }
      const brightness2 = overlayData[row]?.[col] ?? 0.5;
      const originalValue = qrIsDark ? 1 : 0;
      const error = errors[row][col] || 0;
      const overlayDark = 1 - brightness2;
      const mix = intensity * strength;
      let targetValue = originalValue * (1 - mix) + overlayDark * mix;
      if (qrIsDark) {
        targetValue = DARK_DESIRE_MIN + targetValue * (DARK_DESIRE_MAX - DARK_DESIRE_MIN);
      } else {
        targetValue = LIGHT_DESIRE_MIN + targetValue * (LIGHT_DESIRE_MAX - LIGHT_DESIRE_MIN);
      }
      const adjustedValue = targetValue + error;
      const threshold2 = qrIsDark ? 0.4 : 0.6;
      const newValue = adjustedValue >= threshold2;
      result[row][col] = newValue;
      const quantError = adjustedValue - (newValue ? 1 : 0);
      distributeError(errors, col, row, quantError, kernel, moduleCount, moduleCount);
    }
  }
  enforceModuleConstraints(qr, result, moduleCount, version);
  log4.debug("dither-matrix applied with QR protection", {
    moduleCount,
    strength,
    intensity,
    version
  });
  return result;
}
function enforceModuleConstraints(qr, matrix, moduleCount, version) {
  for (let row = 0; row < moduleCount; row++) {
    for (let col = 0; col < moduleCount; col++) {
      const qrIsDark = qr.isDark(row, col);
      if (isStructuralModule2(row, col, moduleCount, version) || isQuietZoneSeparator(row, col, moduleCount)) {
        matrix[row][col] = qrIsDark;
      }
    }
  }
}

// src/modules/qr-generator/dithering-true.ts
var _log50 = createLogger("GENERATE");

// src/modules/qr-generator/dithering.ts
var _log51 = createLogger("GENERATE");

// src/modules/qr-encoder/shift-jis.ts
var _log52 = createLogger("ENCODER");
var HIRAGANA_START = 12353;
var HIRAGANA_END = 12438;
var KATAKANA_START = 12449;
var KATAKANA_END = 12534;
var HW_KATAKANA_START = 65377;
var HW_KATAKANA_END = 65439;
var HW_KATAKANA_SJIS_START = 161;
var FULLWIDTH_ASCII_START = 65281;
var FULLWIDTH_ASCII_END = 65374;
var FULLWIDTH_MAP = {
  // Full-width space
  12288: 33088,
  // Full-width punctuation
  12289: 33089,
  // 、
  12290: 33090,
  // 。
  65292: 33091,
  // ，
  65294: 33092,
  // ．
  12539: 33093,
  // ・
  65306: 33094,
  // ：
  65307: 33095,
  // ；
  65311: 33096,
  // ？
  65281: 33097,
  // ！
  12443: 33098,
  // ゛
  12444: 33099,
  // ゜
  180: 33100,
  // ´
  65344: 33101,
  // ｀
  168: 33102,
  // ¨
  65342: 33103,
  // ＾
  65507: 33104,
  // ￣
  65343: 33105,
  // ＿
  // Brackets
  12308: 33131,
  // 〔
  12309: 33132,
  // 〕
  12304: 33133,
  // 【
  12305: 33134,
  // 】
  12298: 33137,
  // 《
  12299: 33138,
  // 》
  12300: 33141,
  // 「
  12301: 33142,
  // 」
  12302: 33143,
  // 『
  12303: 33144,
  // 』
  65288: 33129,
  // （
  65289: 33130,
  // ）
  65339: 33135,
  // ［
  65341: 33136,
  // ］
  65371: 33135,
  // ｛
  65373: 33136,
  // ｝
  // Symbols
  12291: 33110,
  // 〃
  20189: 33111,
  // 仝
  12293: 33112,
  // 々
  12294: 33113,
  // 〆
  12295: 33114,
  // 〇
  12540: 33115,
  // ー (prolonged sound mark)
  8213: 33116,
  // ―
  8208: 33117,
  // ‐
  65295: 33118,
  // ／
  65340: 33119,
  // ＼
  12316: 33120,
  // 〜
  8214: 33121,
  // ‖
  65372: 33122,
  // ｜
  8230: 33123,
  // …
  8229: 33124,
  // ‥
  8216: 33125,
  // '
  8217: 33126,
  // '
  8220: 33127,
  // "
  8221: 33128,
  // "
  // Math symbols
  65291: 33147,
  // ＋
  65293: 33148,
  // －
  177: 33149,
  // ±
  215: 33150,
  // ×
  247: 33152,
  // ÷
  65309: 33153,
  // ＝
  8800: 33154,
  // ≠
  65308: 33155,
  // ＜
  65310: 33156,
  // ＞
  8806: 33157,
  // ≦
  8807: 33158,
  // ≧
  8734: 33159,
  // ∞
  8756: 33160,
  // ∴
  // Currency and special
  65509: 33167,
  // ￥
  65284: 33168,
  // ＄
  65504: 33169,
  // ￠
  65505: 33170,
  // ￡
  65285: 33171,
  // ％
  65283: 33172,
  // ＃
  65286: 33173,
  // ＆
  65290: 33174,
  // ＊
  65312: 33175,
  // ＠
  // Arrows
  8592: 33193,
  // ←
  8593: 33194,
  // ↑
  8594: 33192,
  // →
  8595: 33195,
  // ↓
  // Greek letters (common)
  913: 33695,
  // Α
  914: 33696,
  // Β
  915: 33697,
  // Γ
  916: 33698,
  // Δ
  917: 33699,
  // Ε
  918: 33700,
  // Ζ
  919: 33701,
  // Η
  920: 33702,
  // Θ
  921: 33703,
  // Ι
  922: 33704,
  // Κ
  923: 33705,
  // Λ
  924: 33706,
  // Μ
  925: 33707,
  // Ν
  926: 33708,
  // Ξ
  927: 33709,
  // Ο
  928: 33710,
  // Π
  929: 33711,
  // Ρ
  931: 33712,
  // Σ
  932: 33713,
  // Τ
  933: 33714,
  // Υ
  934: 33715,
  // Φ
  935: 33716,
  // Χ
  936: 33717,
  // Ψ
  937: 33718,
  // Ω
  945: 33727,
  // α
  946: 33728,
  // β
  947: 33729,
  // γ
  948: 33730,
  // δ
  949: 33731,
  // ε
  950: 33732,
  // ζ
  951: 33733,
  // η
  952: 33734,
  // θ
  953: 33735,
  // ι
  954: 33736,
  // κ
  955: 33737,
  // λ
  956: 33738,
  // μ
  957: 33739,
  // ν
  958: 33740,
  // ξ
  959: 33741,
  // ο
  960: 33742,
  // π
  961: 33743,
  // ρ
  963: 33744,
  // σ
  964: 33745,
  // τ
  965: 33746,
  // υ
  966: 33747,
  // φ
  967: 33748,
  // χ
  968: 33749,
  // ψ
  969: 33750
  // ω
};
var KANJI_MAP = {
  // Numbers
  19968: 35050,
  // 一
  20108: 37873,
  // 二
  19977: 36431,
  // 三
  22235: 36460,
  // 四
  20116: 36060,
  // 五
  20845: 39002,
  // 六
  19971: 36533,
  // 七
  20843: 38058,
  // 八
  20061: 35811,
  // 九
  21313: 36700,
  // 十
  30334: 38227,
  // 百
  21315: 37095,
  // 千
  19975: 38556,
  // 万
  20740: 35245,
  // 億
  // Time/Calendar
  26085: 37882,
  // 日
  26376: 35982,
  // 月
  28779: 35278,
  // 火
  27700: 36997,
  // 水
  26408: 38616,
  // 木
  37329: 35808,
  // 金
  22303: 37753,
  // 土
  24180: 37966,
  // 年
  26178: 36510,
  // 時
  20998: 38314,
  // 分
  31186: 38242,
  // 秒
  20170: 36257,
  // 今
  26152: 36346,
  // 昨
  26126: 38590,
  // 明
  // People/Body
  20154: 36972,
  // 人
  30007: 37482,
  // 男
  22899: 36759,
  // 女
  23376: 36465,
  // 子
  27597: 38378,
  // 母
  29238: 38275,
  // 父
  21451: 38726,
  // 友
  25163: 36584,
  // 手
  36275: 37291,
  // 足
  30446: 38618,
  // 目
  32819: 36520,
  // 耳
  21475: 36091,
  // 口
  40763: 38208,
  // 鼻
  24515: 36947,
  // 心
  // Nature
  23665: 36434,
  // 山
  24029: 37100,
  // 川
  28023: 35395,
  // 海
  31354: 35827,
  // 空
  38632: 35137,
  // 雨
  39080: 38295,
  // 風
  38634: 37089,
  // 雪
  33457: 35284,
  // 花
  33609: 37264,
  // 草
  27193: 36599,
  // 樹
  26519: 38865,
  // 林
  26862: 36952,
  // 森
  // Actions
  35211: 36009,
  // 見
  32862: 38327,
  // 聞
  35328: 36030,
  // 言
  35501: 37831,
  // 読
  26360: 36753,
  // 書
  35441: 39010,
  // 話
  39135: 36936,
  // 食
  39154: 35065,
  // 飲
  36208: 37270,
  // 走
  27497: 38368,
  // 歩
  31435: 38823,
  // 立
  24231: 36288,
  // 座
  23517: 36945,
  // 寝
  36215: 35662,
  // 起
  20316: 36332,
  // 作
  20351: 36455,
  // 使
  25345: 36509,
  // 持
  21462: 36582,
  // 取
  20986: 36719,
  // 出
  20837: 37884,
  // 入
  34892: 36211,
  // 行
  26469: 38792,
  // 来
  24112: 35649,
  // 帰
  24453: 37330,
  // 待
  20250: 35311,
  // 会
  30693: 37485,
  // 知
  24605: 36470,
  // 思
  32771: 36204,
  // 考
  20449: 36941,
  // 信
  24859: 34980,
  // 愛
  // Places/Buildings
  23478: 35270,
  // 家
  24215: 37720,
  // 店
  39365: 35191,
  // 駅
  23398: 35447,
  // 学
  26657: 36186,
  // 校
  31038: 36560,
  // 社
  22269: 36241,
  // 国
  24066: 36467,
  // 市
  30010: 37548,
  // 町
  26449: 37306,
  // 村
  36947: 37817,
  // 道
  27211: 35764,
  // 橋
  // Objects
  36554: 36429,
  // 車
  38651: 37732,
  // 電
  26412: 38523,
  // 本
  26032: 36950,
  // 新
  32025: 36486,
  // 紙
  31558: 38221,
  // 筆
  37549: 37534,
  // 銭
  37347: 37347,
  // 釣
  // Adjectives
  22823: 37349,
  // 大
  23567: 36751,
  // 小
  39640: 36226,
  // 高
  20302: 37601,
  // 低
  38263: 37559,
  // 長
  30701: 37466,
  // 短
  33391: 38855,
  // 良
  24746: 34987,
  // 悪
  21476: 36035,
  // 古
  22810: 37309,
  // 多
  23569: 36781,
  // 少
  24375: 35757,
  // 強
  24369: 36579,
  // 弱
  26263: 35011,
  // 暗
  28201: 35255,
  // 温
  23506: 35494,
  // 寒
  29105: 37965,
  // 熱
  20919: 38882,
  // 冷
  // Colors
  36196: 37076,
  // 赤
  38738: 37058,
  // 青
  30333: 38034,
  // 白
  40658: 36245,
  // 黒
  32209: 38862,
  // 緑
  40644: 35241,
  // 黄
  // Position/Direction
  20013: 37510,
  // 中
  22806: 35407,
  // 外
  19978: 36835,
  // 上
  19979: 35258,
  // 下
  24038: 36278,
  // 左
  21491: 35141,
  // 右
  21069: 37199,
  // 前
  24460: 36067,
  // 後
  21271: 38523,
  // 北
  21335: 37868,
  // 南
  26481: 37772,
  // 東
  35199: 37052,
  // 西
  20869: 37856,
  // 内
  // Common abstract concepts
  29289: 38312,
  // 物
  20107: 36502,
  // 事
  32773: 36562,
  // 者
  25152: 36746,
  // 所
  26041: 38395,
  // 方
  27671: 35651,
  // 気
  21147: 38861,
  // 力
  21517: 38588,
  // 名
  27425: 36511,
  // 次
  21021: 36745,
  // 初
  26368: 36293,
  // 最
  26411: 38550,
  // 末
  20808: 37094,
  // 先
  27096: 38808,
  // 様
  24335: 36526,
  // 式
  24615: 37035,
  // 性
  21270: 35259,
  // 化
  29992: 38768,
  // 用
  24471: 37822,
  // 得
  22833: 36536,
  // 失
  21487: 35266,
  // 可
  19981: 38259,
  // 不
  28961: 38579,
  // 無
  26377: 38732,
  // 有
  20840: 37203,
  // 全
  37096: 38292,
  // 部
  21322: 38076,
  // 半
  27491: 37043,
  // 正
  35492: 36064,
  // 誤
  30495: 36958,
  // 真
  20605: 35669,
  // 偽
  22987: 36462,
  // 始
  32066: 36681,
  // 終
  32154: 37297,
  // 続
  27490: 36478,
  // 止
  21205: 37806,
  // 動
  38745: 37059,
  // 静
  22793: 38351,
  // 変
  21516: 37807,
  // 同
  21029: 38346,
  // 別
  29305: 37825,
  // 特
  26222: 38273,
  // 普
  36890: 37578,
  // 通
  20849: 35748,
  // 共
  31169: 36484,
  // 私
  20844: 36086,
  // 公
  20491: 36034,
  // 個
  22243: 37475,
  // 団
  20307: 37324,
  // 体
  32676: 35921,
  // 群
  38598: 36695,
  // 集
  21512: 36231,
  // 合
  35299: 35312,
  // 解
  32080: 35979,
  // 結
  38283: 35402,
  // 開
  38281: 38338,
  // 閉
  29983: 37046,
  // 生
  27515: 36480,
  // 死
  20581: 35986,
  // 健
  24247: 36174,
  // 康
  30149: 38241,
  // 病
  21307: 35043,
  // 医
  34220: 38642,
  // 薬
  // Question words
  20309: 35261,
  // 何
  35504: 37454
  // 誰
};
function hiraganaToShiftJIS(codePoint) {
  if (codePoint < HIRAGANA_START || codePoint > HIRAGANA_END) {
    return [63];
  }
  const offset = codePoint - HIRAGANA_START;
  let sjis = 33439 + offset;
  const lowByte = sjis & 255;
  if (lowByte >= 127) {
    sjis += 1;
  }
  return [sjis >> 8 & 255, sjis & 255];
}
function katakanaToShiftJIS(codePoint) {
  if (codePoint < KATAKANA_START || codePoint > KATAKANA_END) {
    return [63];
  }
  const offset = codePoint - KATAKANA_START;
  let sjis = 33600 + offset;
  let lowByte = sjis & 255;
  if (lowByte >= 127) {
    sjis += 1;
    lowByte = sjis & 255;
  }
  if ((sjis & 65280) === 33536 && lowByte > 158) {
    const extraOffset = lowByte - 158 - 1;
    sjis = 33856 + extraOffset;
  }
  return [sjis >> 8 & 255, sjis & 255];
}
function unicodeToShiftJIS(codePoint) {
  if (codePoint < 128) {
    return [codePoint];
  }
  if (codePoint >= HW_KATAKANA_START && codePoint <= HW_KATAKANA_END) {
    return [HW_KATAKANA_SJIS_START + (codePoint - HW_KATAKANA_START)];
  }
  if (codePoint >= HIRAGANA_START && codePoint <= HIRAGANA_END) {
    return hiraganaToShiftJIS(codePoint);
  }
  if (codePoint >= KATAKANA_START && codePoint <= KATAKANA_END) {
    return katakanaToShiftJIS(codePoint);
  }
  if (FULLWIDTH_MAP[codePoint] !== void 0) {
    const sjis = FULLWIDTH_MAP[codePoint];
    return [sjis >> 8 & 255, sjis & 255];
  }
  if (codePoint >= FULLWIDTH_ASCII_START && codePoint <= FULLWIDTH_ASCII_END) {
    const offset = codePoint - FULLWIDTH_ASCII_START;
    if (offset === 0) return [129, 73];
    if (offset >= 15 && offset <= 24) {
      return [130, 79 + (offset - 15)];
    }
    if (offset >= 32 && offset <= 57) {
      const charOffset = offset - 32;
      let lowByte = 96 + charOffset;
      if (lowByte >= 127) lowByte += 1;
      return [130, lowByte];
    }
    if (offset >= 64 && offset <= 89) {
      const charOffset = offset - 64;
      const lowByte = 129 + charOffset;
      return [130, lowByte];
    }
  }
  if (KANJI_MAP[codePoint] !== void 0) {
    const sjis = KANJI_MAP[codePoint];
    return [sjis >> 8 & 255, sjis & 255];
  }
  return [63];
}
function createShiftJISEncoder() {
  return (s) => {
    const bytes = [];
    for (let i = 0; i < s.length; i++) {
      const codePoint = s.codePointAt(i);
      if (codePoint === void 0) continue;
      if (codePoint > 65535) {
        i++;
        bytes.push(63);
        continue;
      }
      const sjisBytes = unicodeToShiftJIS(codePoint);
      bytes.push(...sjisBytes);
    }
    return bytes;
  };
}

// src/modules/qr-encoder/index.ts
var _log53 = createLogger("ENCODER");

// src/modules/qr-generator/dithering-blue.ts
var _log54 = createLogger("GENERATE");
var BLUE_NOISE_TILE_SIZE = 64;
var BLUE_NOISE_64 = generateBlueNoiseTile(BLUE_NOISE_TILE_SIZE, 0);

// src/modules/qr-generator/drawing-primitives.ts
var _log55 = createLogger("GENERATE");
function roundRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  ctx.fill();
}
function drawModule(ctx, x, y, size, style = "square", options = {}) {
  const { cornerRadius = 0, rotation = 0 } = options;
  ctx.save();
  if (rotation !== 0) {
    const centerX = x + size / 2;
    const centerY = y + size / 2;
    ctx.translate(centerX, centerY);
    ctx.rotate(rotation * Math.PI / 180);
    ctx.translate(-centerX, -centerY);
  }
  switch (style) {
    case "rounded": {
      const radius = cornerRadius / 100 * (size / 2);
      roundRect(ctx, x, y, size, size, radius);
      break;
    }
    case "dots": {
      const radius = size * 0.4;
      ctx.beginPath();
      ctx.arc(x + size / 2, y + size / 2, radius, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "diamond": {
      const half = size / 2;
      ctx.beginPath();
      ctx.moveTo(x + half, y);
      ctx.lineTo(x + size, y + half);
      ctx.lineTo(x + half, y + size);
      ctx.lineTo(x, y + half);
      ctx.closePath();
      ctx.fill();
      break;
    }
    case "star": {
      const cx = x + size / 2;
      const cy = y + size / 2;
      const outerRadius = size * 0.45;
      const innerRadius = size * 0.2;
      const points = 5;
      ctx.beginPath();
      for (let i = 0; i < points * 2; i++) {
        const radius = i % 2 === 0 ? outerRadius : innerRadius;
        const angle = i * Math.PI / points - Math.PI / 2;
        const px = cx + radius * Math.cos(angle);
        const py = cy + radius * Math.sin(angle);
        if (i === 0) {
          ctx.moveTo(px, py);
        } else {
          ctx.lineTo(px, py);
        }
      }
      ctx.closePath();
      ctx.fill();
      break;
    }
    case "heart": {
      const cx = x + size / 2;
      const cy = y + size / 2;
      const s = size * 0.3;
      ctx.beginPath();
      ctx.moveTo(cx, cy + s * 0.8);
      ctx.bezierCurveTo(cx - s * 1.5, cy - s * 0.5, cx - s * 0.5, cy - s * 1.5, cx, cy - s * 0.5);
      ctx.bezierCurveTo(cx + s * 0.5, cy - s * 1.5, cx + s * 1.5, cy - s * 0.5, cx, cy + s * 0.8);
      ctx.fill();
      break;
    }
    default:
      ctx.fillRect(x, y, size, size);
      break;
  }
  ctx.restore();
}

// src/modules/qr-generator/drawing-frames.ts
var _log56 = createLogger("GENERATE");
function drawFrameBackground(ctx, size, _moduleSize, _margin, config) {
  if (!config.frameStyle || config.frameStyle === "none") return;
  const frameColor = config.frameColor || config.bgColor;
  const borderRadius = config.frameBorderRadius ?? 0;
  ctx.fillStyle = frameColor;
  if (borderRadius > 0) {
    const radius = borderRadius / 100 * (size / 4);
    roundRect(ctx, 0, 0, size, size, radius);
  } else {
    ctx.fillRect(0, 0, size, size);
  }
}
function drawFrame(ctx, size, moduleSize, _margin, config) {
  if (!config.frameStyle || config.frameStyle === "none") return;
  if (!config.frameText) return;
  const textColor = config.frameTextColor || config.fgColor;
  const frameHeight = moduleSize * 4;
  const textY = size - frameHeight / 2;
  ctx.fillStyle = textColor;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const fontSize = Math.max(12, frameHeight * 0.5);
  ctx.font = `${fontSize}px sans-serif`;
  ctx.fillText(config.frameText, size / 2, textY);
}
function drawCenterLogo(ctx, logoCanvas, canvasSize, logoSizePercent = 20) {
  const logoSize = canvasSize * logoSizePercent / 100;
  const logoX = (canvasSize - logoSize) / 2;
  const logoY = (canvasSize - logoSize) / 2;
  ctx.drawImage(logoCanvas, logoX, logoY, logoSize, logoSize);
}

// src/modules/qr-generator/drawing-gradients.ts
var _log57 = createLogger("GENERATE");
function createGradientFill(ctx, config, size) {
  if (!config.gradient || config.gradient.type === "none") {
    return null;
  }
  const { type, angle = 0, stops = [] } = config.gradient;
  if (stops.length === 0) {
    return null;
  }
  let gradient;
  switch (type) {
    case "linear": {
      const rad = angle * Math.PI / 180;
      const x1 = size / 2 - Math.cos(rad) * size / 2;
      const y1 = size / 2 - Math.sin(rad) * size / 2;
      const x2 = size / 2 + Math.cos(rad) * size / 2;
      const y2 = size / 2 + Math.sin(rad) * size / 2;
      gradient = ctx.createLinearGradient(x1, y1, x2, y2);
      break;
    }
    case "radial": {
      const centerX = size / 2;
      const centerY = size / 2;
      const radius = size / 2;
      gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
      break;
    }
    case "conic": {
      const centerX = size / 2;
      const centerY = size / 2;
      const radius = size / 2;
      gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
      break;
    }
    default:
      return null;
  }
  for (const stop of stops) {
    gradient.addColorStop(stop.pos, stop.color);
  }
  return gradient;
}

// src/modules/qr-generator/drawing-halftone.ts
var _log58 = createLogger("GENERATE");
function parseHalftoneCell(cellConfig) {
  if (cellConfig === void 0 || cellConfig === "per_module") return 1;
  if (typeof cellConfig === "number") return Math.max(1, Math.round(cellConfig));
  const match = String(cellConfig).match(/^(\d+)[x×](\d+)$/i);
  if (match) {
    return Math.max(1, parseInt(match[1], 10));
  }
  return 1;
}
function drawHalftoneDot(ctx, cx, cy, dotSize, shape, row, col) {
  const halfSize = dotSize / 2;
  switch (shape) {
    case "square":
      ctx.fillRect(cx - halfSize, cy - halfSize, dotSize, dotSize);
      break;
    case "line": {
      ctx.save();
      ctx.translate(cx, cy);
      const angle = (row + col) % 2 === 0 ? Math.PI / 4 : -Math.PI / 4;
      ctx.rotate(angle);
      const lineWidth = dotSize * 0.35;
      const lineLength = dotSize * 1.2;
      ctx.fillRect(-lineLength / 2, -lineWidth / 2, lineLength, lineWidth);
      ctx.restore();
      break;
    }
    default:
      ctx.beginPath();
      ctx.arc(cx, cy, halfSize, 0, Math.PI * 2);
      ctx.fill();
      break;
  }
}
function drawHalftoneModule(ctx, x, y, size, brightness2, config, moduleRow = 0, moduleCol = 0) {
  const htDot = config.htDot ?? 0.8;
  const htCurve = config.htCurve ?? 1;
  const gridSize = parseHalftoneCell(config.halftoneCell ?? config.htCell);
  const dotShape = config.halftoneDotShape || "circle";
  const adjustedBrightness = (1 - brightness2) ** htCurve;
  if (gridSize <= 1) {
    const minSize = size * 0.1;
    const maxSize = size * htDot;
    const dotSize = minSize + adjustedBrightness * (maxSize - minSize);
    const cx = x + size / 2;
    const cy = y + size / 2;
    drawHalftoneDot(ctx, cx, cy, dotSize, dotShape, moduleRow, moduleCol);
  } else {
    const cellSize = size / gridSize;
    const maxDotSize = cellSize * htDot;
    const minDotSize = cellSize * 0.1;
    const dotSize = minDotSize + adjustedBrightness * (maxDotSize - minDotSize);
    for (let row = 0; row < gridSize; row++) {
      for (let col = 0; col < gridSize; col++) {
        const cx = x + (col + 0.5) * cellSize;
        const cy = y + (row + 0.5) * cellSize;
        drawHalftoneDot(
          ctx,
          cx,
          cy,
          dotSize,
          dotShape,
          moduleRow * gridSize + row,
          moduleCol * gridSize + col
        );
      }
    }
  }
}

// src/modules/qr-generator/drawing-patterns.ts
var _log59 = createLogger("GENERATE");
function drawFinderPatternComplete(ctx, x, y, moduleSize, config) {
  const outerStyle = config.eyeOuterStyle || config.finderStyle || "square";
  const innerStyle = config.eyeInnerStyle || config.finderStyle || "square";
  const eyeScale = (config.eyeScale ?? 100) / 100;
  const fgColor = validateColor(config.fgColor, "#000000");
  const bgColor = validateColor(config.bgColor, "#ffffff");
  const outerSize = 7 * moduleSize;
  const middleSize = 5 * moduleSize;
  const innerSize = 3 * moduleSize;
  const scaledOuterSize = outerSize * eyeScale;
  const scaledMiddleSize = middleSize * eyeScale;
  const scaledInnerSize = innerSize * eyeScale;
  const outerOffset = (outerSize - scaledOuterSize) / 2;
  const _middleOffset = moduleSize + (outerSize - scaledOuterSize) / 2;
  const _innerOffset = 2 * moduleSize + (outerSize - scaledOuterSize) / 2;
  ctx.fillStyle = fgColor;
  drawFinderRing(ctx, x + outerOffset, y + outerOffset, scaledOuterSize, outerStyle);
  ctx.fillStyle = bgColor;
  const middleRingSize = scaledMiddleSize;
  const middleRingOffset = (scaledOuterSize - middleRingSize) / 2;
  drawFinderRing(
    ctx,
    x + outerOffset + middleRingOffset,
    y + outerOffset + middleRingOffset,
    middleRingSize,
    outerStyle
  );
  ctx.fillStyle = fgColor;
  const innerDotSize = scaledInnerSize;
  const innerDotOffset = (scaledOuterSize - innerDotSize) / 2;
  drawFinderRing(
    ctx,
    x + outerOffset + innerDotOffset,
    y + outerOffset + innerDotOffset,
    innerDotSize,
    innerStyle
  );
}
function drawFinderRing(ctx, x, y, size, style) {
  switch (style) {
    case "rounded": {
      const radius = size * 0.2;
      roundRect(ctx, x, y, size, size, radius);
      break;
    }
    case "circle": {
      ctx.beginPath();
      ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    default:
      ctx.fillRect(x, y, size, size);
      break;
  }
}
function drawAlignmentPattern(ctx, centerX, centerY, moduleSize, style, config) {
  const fgColor = validateColor(config.fgColor, "#000000");
  const bgColor = validateColor(config.bgColor, "#ffffff");
  const outerSize = 5 * moduleSize;
  const middleSize = 3 * moduleSize;
  const innerSize = 1 * moduleSize;
  const effectiveStyle = style === "match_finder" ? config.finderStyle || "square" : style;
  ctx.fillStyle = fgColor;
  drawAlignmentRing(
    ctx,
    centerX - outerSize / 2,
    centerY - outerSize / 2,
    outerSize,
    effectiveStyle
  );
  ctx.fillStyle = bgColor;
  drawAlignmentRing(
    ctx,
    centerX - middleSize / 2,
    centerY - middleSize / 2,
    middleSize,
    effectiveStyle
  );
  ctx.fillStyle = fgColor;
  drawAlignmentRing(
    ctx,
    centerX - innerSize / 2,
    centerY - innerSize / 2,
    innerSize,
    effectiveStyle
  );
}
function drawAlignmentRing(ctx, x, y, size, style) {
  switch (style) {
    case "rounded": {
      const radius = size * 0.15;
      roundRect(ctx, x, y, size, size, radius);
      break;
    }
    case "circle": {
      ctx.beginPath();
      ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    default:
      ctx.fillRect(x, y, size, size);
      break;
  }
}
function drawTimingModule(ctx, x, y, size, style, config) {
  if (style === "match_module") {
    drawModule(ctx, x, y, size, config.moduleStyle || "square", {
      cornerRadius: config.cornerRadius || 0
    });
  } else if (style === "dashed") {
    const dashSize = size * 0.7;
    const offset = (size - dashSize) / 2;
    ctx.fillRect(x + offset, y + offset, dashSize, dashSize);
  } else {
    ctx.fillRect(x, y, size, size);
  }
}

// src/modules/qr-generator/drawing.ts
var _log60 = createLogger("GENERATE");

// src/modules/qr-generator/ecc.ts
var _log61 = createLogger("GENERATE");

// src/modules/overlay/crop-handler.ts
var _log62 = createLogger("OVERLAY");

// src/modules/overlay/overlay-filters.ts
var log5 = createLogger("OVERLAY");
function copyImageData(imageData) {
  return new ImageData(new Uint8ClampedArray(imageData.data), imageData.width, imageData.height);
}
function brightness(imageData, amount) {
  const data = imageData.data;
  const factor = amount / 100;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.max(0, Math.min(255, Math.round(data[i] + 255 * factor)));
    data[i + 1] = Math.max(0, Math.min(255, Math.round(data[i + 1] + 255 * factor)));
    data[i + 2] = Math.max(0, Math.min(255, Math.round(data[i + 2] + 255 * factor)));
  }
  return imageData;
}
function contrast(imageData, amount) {
  const data = imageData.data;
  const factor = 259 * (amount + 255) / (255 * (259 - amount));
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.max(0, Math.min(255, Math.round(factor * (data[i] - 128) + 128)));
    data[i + 1] = Math.max(0, Math.min(255, Math.round(factor * (data[i + 1] - 128) + 128)));
    data[i + 2] = Math.max(0, Math.min(255, Math.round(factor * (data[i + 2] - 128) + 128)));
  }
  return imageData;
}
function saturation(imageData, amount) {
  const data = imageData.data;
  const factor = amount / 100;
  for (let i = 0; i < data.length; i += 4) {
    const gray = rgbToGray(data[i], data[i + 1], data[i + 2]);
    data[i] = Math.max(0, Math.min(255, Math.round(gray + factor * (data[i] - gray))));
    data[i + 1] = Math.max(0, Math.min(255, Math.round(gray + factor * (data[i + 1] - gray))));
    data[i + 2] = Math.max(0, Math.min(255, Math.round(gray + factor * (data[i + 2] - gray))));
  }
  return imageData;
}
function hueRotate(imageData, degrees) {
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const hsl = rgbToHsl(data[i], data[i + 1], data[i + 2]);
    hsl.h = (hsl.h + degrees) % 360;
    if (hsl.h < 0) hsl.h += 360;
    const rgb = hslToRgb(hsl.h, hsl.s, hsl.l);
    data[i] = rgb.r;
    data[i + 1] = rgb.g;
    data[i + 2] = rgb.b;
  }
  return imageData;
}
function gamma(imageData, value) {
  const data = imageData.data;
  const invGamma = 1 / value;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.round(255 * (data[i] / 255) ** invGamma);
    data[i + 1] = Math.round(255 * (data[i + 1] / 255) ** invGamma);
    data[i + 2] = Math.round(255 * (data[i + 2] / 255) ** invGamma);
  }
  return imageData;
}
function invert(imageData) {
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = 255 - data[i];
    data[i + 1] = 255 - data[i + 1];
    data[i + 2] = 255 - data[i + 2];
  }
  return imageData;
}
function grayscale(imageData) {
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const gray = Math.round(rgbToGray(data[i], data[i + 1], data[i + 2]));
    data[i] = gray;
    data[i + 1] = gray;
    data[i + 2] = gray;
  }
  return imageData;
}
function threshold(imageData, level) {
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const gray = rgbToGray(data[i], data[i + 1], data[i + 2]);
    const value = gray > level ? 255 : 0;
    data[i] = value;
    data[i + 1] = value;
    data[i + 2] = value;
  }
  return imageData;
}
function posterize(imageData, levels) {
  const data = imageData.data;
  const step = 255 / (levels - 1);
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.round(Math.round(data[i] / step) * step);
    data[i + 1] = Math.round(Math.round(data[i + 1] / step) * step);
    data[i + 2] = Math.round(Math.round(data[i + 2] / step) * step);
  }
  return imageData;
}
function duotone(imageData, lightColor, darkColor) {
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const gray = rgbToGray(data[i], data[i + 1], data[i + 2]) / 255;
    data[i] = Math.round(darkColor.r * (1 - gray) + lightColor.r * gray);
    data[i + 1] = Math.round(darkColor.g * (1 - gray) + lightColor.g * gray);
    data[i + 2] = Math.round(darkColor.b * (1 - gray) + lightColor.b * gray);
  }
  return imageData;
}
function convolve(imageData, kernel, divisor) {
  const data = imageData.data;
  const width = imageData.width;
  const height = imageData.height;
  const result = new Uint8ClampedArray(data);
  const kSize = kernel.length;
  const kHalf = Math.floor(kSize / 2);
  const div = divisor ?? (kernel.flat().reduce((a, b) => a + b, 0) || 1);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let r = 0, g = 0, b = 0;
      for (let ky = 0; ky < kSize; ky++) {
        for (let kx = 0; kx < kSize; kx++) {
          const px = Math.max(0, Math.min(width - 1, x + kx - kHalf));
          const py = Math.max(0, Math.min(height - 1, y + ky - kHalf));
          const idx2 = (py * width + px) * 4;
          const weight = kernel[ky][kx];
          r += data[idx2] * weight;
          g += data[idx2 + 1] * weight;
          b += data[idx2 + 2] * weight;
        }
      }
      const idx = (y * width + x) * 4;
      result[idx] = Math.max(0, Math.min(255, Math.round(r / div)));
      result[idx + 1] = Math.max(0, Math.min(255, Math.round(g / div)));
      result[idx + 2] = Math.max(0, Math.min(255, Math.round(b / div)));
    }
  }
  imageData.data.set(result);
  return imageData;
}
function sharpen(imageData, amount = 1) {
  const kernel = [
    [0, -amount, 0],
    [-amount, 1 + 4 * amount, -amount],
    [0, -amount, 0]
  ];
  return convolve(imageData, kernel, 1);
}
function blur(imageData, radius = 1) {
  const size = 2 * radius + 1;
  const kernel = Array(size).fill(null).map(() => Array(size).fill(1));
  return convolve(imageData, kernel);
}
function sobelEdge(imageData) {
  const data = imageData.data;
  const width = imageData.width;
  const height = imageData.height;
  const result = new Uint8ClampedArray(data.length);
  const sobelX = [
    [-1, 0, 1],
    [-2, 0, 2],
    [-1, 0, 1]
  ];
  const sobelY = [
    [-1, -2, -1],
    [0, 0, 0],
    [1, 2, 1]
  ];
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      let gx = 0, gy = 0;
      for (let ky = -1; ky <= 1; ky++) {
        for (let kx = -1; kx <= 1; kx++) {
          const idx2 = ((y + ky) * width + (x + kx)) * 4;
          const gray = rgbToGray(data[idx2], data[idx2 + 1], data[idx2 + 2]);
          gx += gray * sobelX[ky + 1][kx + 1];
          gy += gray * sobelY[ky + 1][kx + 1];
        }
      }
      const magnitude = Math.min(255, Math.sqrt(gx * gx + gy * gy));
      const idx = (y * width + x) * 4;
      result[idx] = magnitude;
      result[idx + 1] = magnitude;
      result[idx + 2] = magnitude;
      result[idx + 3] = data[idx + 3];
    }
  }
  imageData.data.set(result);
  return imageData;
}
function cannyEdge(imageData, lowThreshold = 50, highThreshold = 150) {
  const sobelResult = sobelEdge(copyImageData(imageData));
  const data = sobelResult.data;
  for (let i = 0; i < data.length; i += 4) {
    const magnitude = data[i];
    const value = magnitude > highThreshold ? 255 : magnitude > lowThreshold ? 128 : 0;
    data[i] = value;
    data[i + 1] = value;
    data[i + 2] = value;
  }
  imageData.data.set(data);
  return imageData;
}
function applyColorMode(imageData, mode) {
  if (mode === "color") return imageData;
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const gray = Math.round(rgbToGray(data[i], data[i + 1], data[i + 2]));
    if (mode === "bw") {
      const value = gray > 128 ? 255 : 0;
      data[i] = value;
      data[i + 1] = value;
      data[i + 2] = value;
    } else {
      data[i] = gray;
      data[i + 1] = gray;
      data[i + 2] = gray;
    }
  }
  return imageData;
}
function applyFilters(imageData, options) {
  let result = copyImageData(imageData);
  log5.debug("applyFilters called", {
    brightness: options.brightness,
    contrast: options.contrast,
    saturation: options.saturation,
    hue: options.hue,
    gamma: options.gamma,
    invert: options.invert,
    grayscale: options.grayscale,
    threshold: options.threshold,
    posterize: options.posterize,
    sharpen: options.sharpen,
    blur: options.blur,
    colorMode: options.colorMode,
    hasDuotone: !!options.duotone
  });
  if (options.brightness !== void 0 && options.brightness !== 0) {
    log5.debug("Applying brightness", { value: options.brightness });
    result = brightness(result, options.brightness);
  }
  if (options.contrast !== void 0 && options.contrast !== 0) {
    log5.debug("Applying contrast", { value: options.contrast });
    result = contrast(result, options.contrast);
  }
  if (options.saturation !== void 0 && options.saturation !== 100) {
    log5.debug("Applying saturation", { value: options.saturation });
    result = saturation(result, options.saturation);
  }
  if (options.hue !== void 0 && options.hue !== 0) {
    log5.debug("Applying hue rotation", { value: options.hue });
    result = hueRotate(result, options.hue);
  }
  if (options.gamma !== void 0 && options.gamma !== 1) {
    log5.debug("Applying gamma", { value: options.gamma });
    result = gamma(result, options.gamma);
  }
  if (options.invert) {
    log5.debug("Applying INVERT - this will flip perceived brightness");
    result = invert(result);
  }
  if (options.grayscale) {
    log5.debug("Applying grayscale");
    result = grayscale(result);
  }
  if (options.threshold !== void 0) {
    log5.debug("Applying threshold", { value: options.threshold });
    result = threshold(result, options.threshold);
  }
  if (options.posterize !== void 0 && options.posterize > 0) {
    log5.debug("Applying posterize", { value: options.posterize });
    result = posterize(result, options.posterize);
  }
  if (options.sharpen !== void 0 && options.sharpen > 0) {
    log5.debug("Applying sharpen", { value: options.sharpen });
    result = sharpen(result, options.sharpen);
  }
  if (options.blur !== void 0 && options.blur > 0) {
    log5.debug("Applying blur", { value: options.blur });
    result = blur(result, options.blur);
  }
  if (options.duotone) {
    log5.debug("Applying duotone");
    result = duotone(result, options.duotone.light, options.duotone.dark);
  }
  if (options.colorMode) {
    log5.debug("Applying colorMode", { mode: options.colorMode });
    result = applyColorMode(result, options.colorMode);
  }
  log5.debug("Filter pipeline complete");
  return result;
}

// src/modules/overlay/processor.ts
var _log63 = createLogger("OVERLAY");

// src/modules/overlay/watermark.ts
var _log64 = createLogger("WATERMARK");

// src/modules/overlay/index.ts
var _log65 = createLogger("OVERLAY");

// src/modules/qr-generator/filters-edge.ts
var _log66 = createLogger("GENERATE");

// src/modules/qr-generator/filters-preprocess.ts
var log6 = createLogger("GENERATE");
function detectBimodalBW(imageData) {
  const data = imageData.data;
  const totalPixels = data.length / 4;
  const histogram = new Int32Array(HISTOGRAM_BUCKETS);
  for (let i = 0; i < data.length; i += 4) {
    const gray = rgbToGray(data[i], data[i + 1], data[i + 2]);
    const bucket = Math.min(HISTOGRAM_BUCKETS - 1, gray >> BUCKET_SHIFT);
    histogram[bucket]++;
  }
  let darkPeak = 0;
  let darkPeakBucket = 0;
  for (let i = 0; i < DARK_REGION_END; i++) {
    if (histogram[i] > darkPeak) {
      darkPeak = histogram[i];
      darkPeakBucket = i;
    }
  }
  let lightPeak = 0;
  let lightPeakBucket = 0;
  for (let i = LIGHT_REGION_START; i < HISTOGRAM_BUCKETS; i++) {
    if (histogram[i] > lightPeak) {
      lightPeak = histogram[i];
      lightPeakBucket = i;
    }
  }
  if (lightPeakBucket - darkPeakBucket < MIN_PEAK_SEPARATION) {
    return false;
  }
  let darkRegionCount = 0;
  for (let i = 0; i < DARK_REGION_END; i++) {
    darkRegionCount += histogram[i];
  }
  let lightRegionCount = 0;
  for (let i = LIGHT_REGION_START; i < HISTOGRAM_BUCKETS; i++) {
    lightRegionCount += histogram[i];
  }
  let valleyCount = 0;
  for (let i = DARK_REGION_END; i < LIGHT_REGION_START; i++) {
    valleyCount += histogram[i];
  }
  const darkRatio = darkRegionCount / totalPixels;
  const lightRatio = lightRegionCount / totalPixels;
  const valleyRatio = valleyCount / totalPixels;
  const isBimodal = darkRatio >= MIN_PEAK_RATIO && lightRatio >= MIN_PEAK_RATIO && valleyRatio < MAX_VALLEY_RATIO;
  if (isBimodal) {
    log6.debug("Detected bimodal B&W image", {
      darkRatio: darkRatio.toFixed(3),
      lightRatio: lightRatio.toFixed(3),
      valleyRatio: valleyRatio.toFixed(3),
      darkPeakBucket,
      lightPeakBucket
    });
  }
  return isBimodal;
}
function preprocessImageData(imageData, config, debug = false) {
  const filterOptions = {};
  if (config.filterBrightness !== void 0 && config.filterBrightness !== 0) {
    filterOptions.brightness = config.filterBrightness;
  }
  if (config.filterContrast !== void 0 && config.filterContrast !== 0) {
    filterOptions.contrast = config.filterContrast;
  }
  if (config.filterSaturation !== void 0 && config.filterSaturation !== 0) {
    filterOptions.saturation = config.filterSaturation + 100;
  }
  if (config.filterHue !== void 0 && config.filterHue !== 0) {
    filterOptions.hue = config.filterHue;
  }
  if (config.filterGamma !== void 0 && config.filterGamma !== 1) {
    filterOptions.gamma = config.filterGamma;
  }
  if (config.filterInvert) {
    filterOptions.invert = true;
  }
  if (config.filterGrayscale) {
    filterOptions.grayscale = true;
  }
  if (config.filterThreshold !== void 0 && config.filterThreshold > 0) {
    filterOptions.threshold = config.filterThreshold;
  }
  if (config.filterBlur !== void 0 && config.filterBlur > 0) {
    filterOptions.blur = config.filterBlur;
  }
  if (config.filterSharpen !== void 0 && config.filterSharpen > 0) {
    filterOptions.sharpen = config.filterSharpen;
  }
  if (config.filterPosterize !== void 0 && config.filterPosterize > 0) {
    filterOptions.posterize = config.filterPosterize;
  }
  if (config.filterDuotone1 && config.filterDuotone2 && config.colorMode !== "color") {
    const lightRgb = parseColor(config.filterDuotone1);
    const darkRgb = parseColor(config.filterDuotone2);
    if (lightRgb && darkRgb) {
      filterOptions.duotone = { light: lightRgb, dark: darkRgb };
    }
  }
  if (config.colorMode) {
    if (config.colorMode === "color") {
      filterOptions.grayscale = false;
    } else {
      filterOptions.colorMode = config.colorMode;
      filterOptions.grayscale = false;
    }
  }
  if (debug) {
    log6.debug("preprocessImageData - filter options", {
      brightness: filterOptions.brightness,
      contrast: filterOptions.contrast,
      saturation: filterOptions.saturation,
      hue: filterOptions.hue,
      gamma: filterOptions.gamma,
      invert: filterOptions.invert,
      grayscale: filterOptions.grayscale,
      threshold: filterOptions.threshold,
      blur: filterOptions.blur,
      sharpen: filterOptions.sharpen,
      posterize: filterOptions.posterize,
      colorMode: filterOptions.colorMode,
      hasDuotone: !!filterOptions.duotone,
      configColorMode: config.colorMode
    });
  }
  const workingData = copyImageData(imageData);
  if (!config.disableAutoSoften) {
    if (detectBimodalBW(workingData)) {
      if (debug) {
        log6.debug(
          "preprocessImageData - detected high-contrast B&W, skipping softening (QR-first mode will handle)"
        );
      }
    }
  }
  if (Object.keys(filterOptions).length === 0) {
    if (debug) {
      log6.debug("preprocessImageData - no additional filters to apply");
    }
    return workingData;
  }
  if (debug) {
    log6.debug("preprocessImageData - applying filters");
  }
  let out = applyFilters(workingData, filterOptions);
  if (config.filterEdgeDetect) {
    const mode = (config.filterEdgeMode || "sobel").toLowerCase();
    if (debug) {
      log6.debug("preprocessImageData - applying edge detection", { mode });
    }
    out = mode === "canny" ? cannyEdge(out) : sobelEdge(out);
  }
  if (debug) {
    log6.debug("preprocessImageData - complete");
  }
  return out;
}

// src/modules/qr-generator/filters.ts
var _log67 = createLogger("GENERATE");

// src/modules/qr-generator/overlay-data.ts
var _log68 = createLogger("GENERATE");
async function getOverlayData(overlayCanvas, moduleCount, config, createCanvasFn) {
  if (!overlayCanvas) {
    return {};
  }
  const canvasHash = await hashCanvasContent(overlayCanvas, createCanvasFn);
  const cacheKey = `${canvasHash}:${moduleCount}:${config.overlayIntensity}:${config.colorMode}`;
  const cached = overlayDataCache.get(cacheKey);
  if (cached) {
    return cached;
  }
  const scaledCanvas = await createCanvasFn(moduleCount, moduleCount);
  const ctx = scaledCanvas.getContext("2d");
  if (!ctx) {
    return {};
  }
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(overlayCanvas, 0, 0, moduleCount, moduleCount);
  const imageData = ctx.getImageData(0, 0, moduleCount, moduleCount);
  const data = imageData.data;
  const result = {};
  const includeColors = config.colorMode !== "bw";
  if (includeColors) {
    result.colors = {};
  }
  for (let row = 0; row < moduleCount; row++) {
    result[row] = {};
    if (includeColors) {
      if (!result.colors) result.colors = {};
      result.colors[row] = {};
    }
    for (let col = 0; col < moduleCount; col++) {
      const idx = (row * moduleCount + col) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const brightness2 = rgbToGray(r, g, b) / 255;
      result[row][col] = brightness2;
      if (includeColors && result.colors) {
        result.colors[row][col] = { r, g, b };
      }
    }
  }
  overlayDataCache.set(cacheKey, result);
  return result;
}

// src/modules/qr-generator/overlay-subpixel.ts
var log7 = createLogger("GENERATE");
function parseGridSize(gridSize) {
  if (!gridSize) return 3;
  const match = gridSize.match(/^(\d+)x\d+$/);
  if (match) {
    return parseInt(match[1], 10);
  }
  return 3;
}
function parseHexColor(hex) {
  if (!hex) return null;
  const match = hex.match(/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i);
  if (match) {
    return {
      r: parseInt(match[1], 16),
      g: parseInt(match[2], 16),
      b: parseInt(match[3], 16)
    };
  }
  return null;
}
function isStructuralModule3(row, col, moduleCount, version) {
  return isFinderPattern(row, col, moduleCount) || isTimingPattern(row, col, moduleCount) || isAlignmentPattern(row, col, moduleCount, version) || isFormatInfo(row, col, moduleCount) || isVersionInfo(row, col, moduleCount, version);
}
async function getSubpixelOverlayData(overlayCanvas, moduleCount, scale, _config, createCanvasFn) {
  const scaledSize = moduleCount * scale;
  const scaledCanvas = await createCanvasFn(scaledSize, scaledSize);
  const ctx = scaledCanvas.getContext("2d");
  if (!ctx) {
    return { brightness: [], colors: [] };
  }
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(overlayCanvas, 0, 0, scaledSize, scaledSize);
  const imageData = ctx.getImageData(0, 0, scaledSize, scaledSize);
  const data = imageData.data;
  const brightness2 = [];
  const colors = [];
  for (let y = 0; y < scaledSize; y++) {
    brightness2[y] = [];
    colors[y] = [];
    for (let x = 0; x < scaledSize; x++) {
      const idx = (y * scaledSize + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      brightness2[y][x] = rgbToGray(r, g, b) / 255;
      colors[y][x] = { r, g, b };
    }
  }
  return { brightness: brightness2, colors };
}
async function generateSubpixelMatrix(qr, config, overlayCanvas, moduleCount, scale, useHalftoneCenter, createCanvasFn) {
  const gridScale = parseGridSize(config.subpixelGridSize) || scale;
  const actualScale = gridScale;
  const scaledSize = moduleCount * actualScale;
  const intensity = (config.overlayIntensity ?? 100) / 100;
  const { brightness: brightness2, colors } = await getSubpixelOverlayData(
    overlayCanvas,
    moduleCount,
    actualScale,
    config,
    createCanvasFn
  );
  const matrix = [];
  const colorMatrix = [];
  const centerIdx = Math.floor(actualScale / 2);
  const neutralColor = parseHexColor(config.subpixelNeutralColor);
  const centerRule = config.subpixelCenterRule || "strict";
  const useHalftone = centerRule === "halftone_center" || useHalftoneCenter;
  const finderOverride = config.subpixelFinderOverride || "solid";
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  log7.debug("Subpixel matrix generation", {
    gridScale,
    actualScale,
    scaledSize,
    intensity,
    centerRule,
    finderOverride,
    hasNeutralColor: !!neutralColor
  });
  for (let y = 0; y < scaledSize; y++) {
    matrix[y] = [];
    colorMatrix[y] = [];
    for (let x = 0; x < scaledSize; x++) {
      const moduleRow = Math.floor(y / actualScale);
      const moduleCol = Math.floor(x / actualScale);
      const subX = x % actualScale;
      const subY = y % actualScale;
      const isCenter = subX === centerIdx && subY === centerIdx;
      const qrValue = qr.isDark(moduleRow, moduleCol);
      const overlayBrightness = brightness2[y]?.[x] ?? 0.5;
      const overlayColor = colors[y]?.[x];
      const isStructural = isStructuralModule3(moduleRow, moduleCol, moduleCount, version);
      if (isStructural && finderOverride === "solid") {
        matrix[y][x] = qrValue;
        colorMatrix[y][x] = null;
        continue;
      }
      if (isCenter) {
        matrix[y][x] = qrValue;
        if (useHalftone && qrValue) {
          colorMatrix[y][x] = overlayColor ? {
            ...overlayColor,
            halftone: true,
            sizeRatio: 0.5 + overlayBrightness * 0.5
          } : neutralColor ? { ...neutralColor, halftone: true, sizeRatio: 0.5 + overlayBrightness * 0.5 } : null;
        } else {
          colorMatrix[y][x] = overlayColor ? { ...overlayColor } : neutralColor ? { ...neutralColor } : null;
        }
      } else {
        const threshold2 = 0.5 - intensity * 0.3;
        matrix[y][x] = overlayBrightness < threshold2;
        colorMatrix[y][x] = overlayColor ? { ...overlayColor } : neutralColor ? { ...neutralColor } : null;
      }
    }
  }
  return {
    matrix,
    colors: colorMatrix,
    scale: actualScale,
    overlayData: null,
    effectiveIntensity: intensity * 100
    // Return as percentage (0-100) for consistency
  };
}

// src/modules/qr-generator/overlay-transforms.ts
var log8 = createLogger("GENERATE");
function hasPreprocessingOptions(config) {
  return config.filterBrightness !== void 0 && config.filterBrightness !== 0 || config.filterContrast !== void 0 && config.filterContrast !== 0 || config.filterSaturation !== void 0 && config.filterSaturation !== 0 || config.filterHue !== void 0 && config.filterHue !== 0 || config.filterGamma !== void 0 && config.filterGamma !== 1 || !!config.filterInvert || !!config.filterGrayscale || config.filterThreshold !== void 0 && config.filterThreshold > 0 || config.filterBlur !== void 0 && config.filterBlur > 0 || config.filterSharpen !== void 0 && config.filterSharpen > 0 || config.filterPosterize !== void 0 && config.filterPosterize > 0 || !!config.filterDuotone1 && !!config.filterDuotone2 || !!config.filterEdgeDetect || // colorMode 'grayscale' or 'bw' requires preprocessing
  config.colorMode !== void 0 && config.colorMode !== "color";
}
function hasGeometricTransforms(_config) {
  return false;
}
async function applyGeometricTransforms(canvas, config, createCanvasFn) {
  if (!hasGeometricTransforms(config)) {
    return canvas;
  }
  const result = await createCanvasFn(canvas.width, canvas.height);
  const ctx = result.getContext("2d");
  if (!ctx) return canvas;
  ctx.drawImage(canvas, 0, 0);
  return result;
}
async function preprocessOverlay(canvas, config, createCanvasFn) {
  const debug = config.debugOverlayDither === true;
  if (!hasPreprocessingOptions(config)) {
    if (debug) {
      log8.debug("preprocessOverlay - no preprocessing needed, returning original canvas");
    }
    return canvas;
  }
  if (debug) {
    log8.debug("preprocessOverlay - starting preprocessing", {
      canvasSize: { width: canvas.width, height: canvas.height },
      colorMode: config.colorMode,
      filterGrayscale: config.filterGrayscale,
      filterBrightness: config.filterBrightness,
      filterContrast: config.filterContrast
    });
  }
  const ctx = canvas.getContext("2d", {
    willReadFrequently: true
  });
  if (!ctx) return canvas;
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const processed = preprocessImageData(imageData, config, debug);
  const result = await createCanvasFn(canvas.width, canvas.height);
  const resultCtx = result.getContext("2d");
  if (!resultCtx) return canvas;
  resultCtx.putImageData(processed, 0, 0);
  if (debug) {
    log8.debug("preprocessOverlay - complete", {
      resultSize: { width: result.width, height: result.height }
    });
  }
  return result;
}

// src/modules/qr-generator/overlay.ts
var _log69 = createLogger("GENERATE");

// src/modules/qr-generator/pattern-helpers.ts
var isFormatInfo2 = isFormatInfo;
var isVersionInfo2 = isVersionInfo;
function getAlignmentPositionsCached(version, moduleCount) {
  if (version < 2) return [];
  const cacheKey = `${version}-${moduleCount}`;
  const cached = alignmentCache.get(cacheKey);
  if (cached !== void 0) {
    return cached;
  }
  const positions = getAlignmentPatternCenters(version, moduleCount);
  alignmentCache.set(cacheKey, positions);
  return positions;
}

// src/modules/qr-generator/pixel-matrix-dither.ts
var _log70 = createLogger("GENERATE");
function normalizeColors(colors, moduleCount) {
  const result = [];
  for (let row = 0; row < moduleCount; row++) {
    result[row] = [];
    for (let col = 0; col < moduleCount; col++) {
      const color = colors?.[row]?.[col];
      if (color) {
        result[row][col] = {
          r: color.r,
          g: color.g,
          b: color.b
        };
      } else {
        result[row][col] = null;
      }
    }
  }
  return result;
}
async function generateDitherModeMatrix(qr, _config, overlayCanvas, moduleCount, effectiveIntensity, effectiveConfig, _overlayMode, createCanvasFn) {
  const overlayData = await getOverlayData(
    overlayCanvas,
    moduleCount,
    effectiveConfig,
    createCanvasFn
  );
  const matrix = applyDitherToMatrix(qr, moduleCount, overlayData, effectiveConfig);
  const colors = normalizeColors(overlayData.colors, moduleCount);
  return {
    matrix,
    colors,
    scale: 1,
    overlayData,
    effectiveIntensity
  };
}

// src/modules/qr-generator/pixel-matrix-dithered.ts
var log9 = createLogger("DITHER");
var COLOR_PRESERVE_RATIO = 0.7;
function detectBWFromCanvas(ctx, width, height) {
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;
  const totalPixels = data.length / 4;
  const histogram = new Int32Array(HISTOGRAM_BUCKETS);
  for (let i = 0; i < data.length; i += 4) {
    const gray = rgbToGray(data[i], data[i + 1], data[i + 2]);
    const bucket = Math.min(HISTOGRAM_BUCKETS - 1, gray >> BUCKET_SHIFT);
    histogram[bucket]++;
  }
  let darkPeak = 0, darkPeakBucket = 0;
  for (let i = 0; i < DARK_REGION_END; i++) {
    if (histogram[i] > darkPeak) {
      darkPeak = histogram[i];
      darkPeakBucket = i;
    }
  }
  let lightPeak = 0, lightPeakBucket = 0;
  for (let i = LIGHT_REGION_START; i < HISTOGRAM_BUCKETS; i++) {
    if (histogram[i] > lightPeak) {
      lightPeak = histogram[i];
      lightPeakBucket = i;
    }
  }
  if (lightPeakBucket - darkPeakBucket < MIN_PEAK_SEPARATION) {
    return false;
  }
  let darkCount = 0, lightCount = 0, valleyCount = 0;
  for (let i = 0; i < DARK_REGION_END; i++) darkCount += histogram[i];
  for (let i = LIGHT_REGION_START; i < HISTOGRAM_BUCKETS; i++) lightCount += histogram[i];
  for (let i = DARK_REGION_END; i < LIGHT_REGION_START; i++) valleyCount += histogram[i];
  const darkRatio = darkCount / totalPixels;
  const lightRatio = lightCount / totalPixels;
  const valleyRatio = valleyCount / totalPixels;
  return darkRatio >= MIN_PEAK_RATIO && lightRatio >= MIN_PEAK_RATIO && valleyRatio < MAX_VALLEY_RATIO;
}
async function generateBWFirstMatrix(qr, config, overlayCanvas, moduleCount, scale, effectiveIntensity, createCanvasFn) {
  const scaledSize = moduleCount * scale;
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  const scaledCanvas = await createCanvasFn(scaledSize, scaledSize);
  const ctx = scaledCanvas.getContext("2d");
  if (!ctx) return createEmptyMatrix(scaledSize, scale, effectiveIntensity);
  ctx.drawImage(overlayCanvas, 0, 0, scaledSize, scaledSize);
  const imageData = ctx.getImageData(0, 0, scaledSize, scaledSize);
  const data = imageData.data;
  const matrix = [];
  const colors = [];
  const textureAmount = Math.min(1, effectiveIntensity);
  const seed = config.blueNoiseSeed ?? 1337;
  const tileSize = config.blueNoiseTileSize ?? 64;
  const blueNoiseTile = generateBlueNoiseTile(tileSize, seed);
  const contrastPower = 1.5;
  for (let y = 0; y < scaledSize; y++) {
    matrix[y] = [];
    colors[y] = [];
    for (let x = 0; x < scaledSize; x++) {
      const idx = (y * scaledSize + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const moduleRow = Math.floor(y / scale);
      const moduleCol = Math.floor(x / scale);
      const qrIsDark = qr.isDark(moduleRow, moduleCol);
      matrix[y][x] = qrIsDark;
      let overlayBrightness = rgbToGray(r, g, b) / 255;
      overlayBrightness = overlayBrightness ** contrastPower;
      const noise = sampleBlueNoise(x, y, blueNoiseTile, tileSize);
      const noiseVariation = (noise - 0.5) * 0.3;
      let shade;
      if (qrIsDark) {
        const darkMin = 0;
        const darkMax = 100;
        const darkRange = darkMax - darkMin;
        let normalizedShade = (1 - overlayBrightness) * textureAmount;
        normalizedShade = clamp013(normalizedShade + noiseVariation * textureAmount);
        shade = darkMin + Math.floor((1 - normalizedShade) * darkRange);
      } else {
        const lightMin = 155;
        const lightMax = 255;
        const lightRange = lightMax - lightMin;
        let normalizedShade = overlayBrightness * textureAmount;
        normalizedShade = clamp013(normalizedShade + noiseVariation * textureAmount);
        shade = lightMin + Math.floor(normalizedShade * lightRange);
        if (textureAmount === 0) shade = 255;
      }
      if (shouldLockModule(moduleRow, moduleCol, moduleCount, version, config)) {
        shade = qrIsDark ? 0 : 255;
      }
      colors[y][x] = config.colorMode !== "bw" ? { r: shade, g: shade, b: shade } : null;
    }
  }
  log9.debug("QR-first B&W matrix generated", {
    scaledSize,
    moduleCount,
    scale,
    textureAmount,
    contrastPower,
    mode: "bw-first"
  });
  return { matrix, colors, scale, overlayData: null, effectiveIntensity };
}
function luma01(r, g, b) {
  return rgbToGray(r, g, b) / 255;
}
function clamp013(x) {
  return x < 0 ? 0 : x > 1 ? 1 : x;
}
function lerp2(a, b, t) {
  return a + (b - a) * t;
}
function distributeError2(errors, x, y, error, kernel, scaledSize, leftToRight) {
  const { matrix, divisor, offset } = kernel;
  for (let ky = 0; ky < matrix.length; ky++) {
    for (let kx = 0; kx < matrix[ky].length; kx++) {
      const weight = matrix[ky][kx];
      if (weight === 0) continue;
      let offsetX = kx - offset;
      if (!leftToRight) offsetX = -offsetX;
      const nx = x + offsetX;
      const ny = y + ky;
      if (nx >= 0 && nx < scaledSize && ny < scaledSize) {
        errors[ny][nx] += error * weight / divisor;
      }
    }
  }
}
function distributeColorError(errorsR, errorsG, errorsB, x, y, errorR, errorG, errorB, kernel, scaledSize, leftToRight) {
  const { matrix, divisor, offset } = kernel;
  for (let ky = 0; ky < matrix.length; ky++) {
    for (let kx = 0; kx < matrix[ky].length; kx++) {
      const weight = matrix[ky][kx];
      if (weight === 0) continue;
      let offsetX = kx - offset;
      if (!leftToRight) offsetX = -offsetX;
      const nx = x + offsetX;
      const ny = y + ky;
      if (nx >= 0 && nx < scaledSize && ny < scaledSize) {
        const factor = weight / divisor;
        errorsR[ny][nx] += errorR * factor;
        errorsG[ny][nx] += errorG * factor;
        errorsB[ny][nx] += errorB * factor;
      }
    }
  }
}
function createEmptyMatrix(size, scale, effectiveIntensity) {
  const matrix = [];
  const colors = [];
  for (let y = 0; y < size; y++) {
    matrix[y] = [];
    colors[y] = [];
    for (let x = 0; x < size; x++) {
      matrix[y][x] = false;
      colors[y][x] = null;
    }
  }
  return { matrix, colors, scale, overlayData: null, effectiveIntensity };
}
function shouldLockModule(row, col, moduleCount, version, config) {
  if (row === moduleCount - 8 && col === 8) return true;
  if (isFinderPattern(row, col, moduleCount)) {
    return config.preserveFinders !== false;
  }
  if (isTimingPattern(row, col, moduleCount)) {
    return config.preserveTiming === true;
  }
  if (isAlignmentPattern(row, col, moduleCount, version)) {
    return config.preserveAlignment === true;
  }
  if (isFormatInfo(row, col, moduleCount)) {
    return config.protectFormatInfo === true;
  }
  if (isVersionInfo(row, col, moduleCount, version)) {
    return config.protectVersionInfo === true;
  }
  if (row === 7 && col <= 7 || col === 7 && row <= 7) {
    return config.preserveFinders !== false;
  }
  if (row === 7 && col >= moduleCount - 8 || col === moduleCount - 8 && row <= 7) {
    return config.preserveFinders !== false;
  }
  if (row === moduleCount - 8 && col <= 7 || col === 7 && row >= moduleCount - 8) {
    return config.preserveFinders !== false;
  }
  return false;
}
function enforceModuleConstraints2(qr, matrix, desire, moduleCount, scale, version, config) {
  const DARK_MIN = 0.75;
  const DARK_MAX = 0.97;
  const LIGHT_MAX = 0.25;
  const half = Math.floor(scale / 2);
  for (let mr = 0; mr < moduleCount; mr++) {
    for (let mc = 0; mc < moduleCount; mc++) {
      if (shouldLockModule(mr, mc, moduleCount, version, config)) continue;
      const qrIsDark = qr.isDark(mr, mc);
      const y0 = mr * scale;
      const x0 = mc * scale;
      const cy = y0 + half;
      const cx = x0 + half;
      if (matrix[cy] && typeof matrix[cy][cx] === "boolean") {
        matrix[cy][cx] = qrIsDark;
      }
      let darkCount = 0;
      const total = scale * scale;
      for (let y = 0; y < scale; y++) {
        for (let x = 0; x < scale; x++) {
          if (matrix[y0 + y][x0 + x]) darkCount++;
        }
      }
      const ratio = darkCount / total;
      if (qrIsDark) {
        if (ratio < DARK_MIN) {
          const need = Math.ceil(DARK_MIN * total - darkCount);
          if (need > 0) {
            const candidates = [];
            for (let y = 0; y < scale; y++) {
              for (let x = 0; x < scale; x++) {
                const yy = y0 + y;
                const xx = x0 + x;
                if (!matrix[yy][xx]) candidates.push({ y: yy, x: xx, score: desire[yy][xx] });
              }
            }
            candidates.sort((a, b) => b.score - a.score);
            for (let i = 0; i < need && i < candidates.length; i++) {
              matrix[candidates[i].y][candidates[i].x] = true;
            }
          }
        }
        if (ratio > DARK_MAX) {
          const excess = Math.ceil(darkCount - DARK_MAX * total);
          if (excess > 0) {
            const candidates = [];
            for (let y = 0; y < scale; y++) {
              for (let x = 0; x < scale; x++) {
                const yy = y0 + y;
                const xx = x0 + x;
                if (matrix[yy][xx]) candidates.push({ y: yy, x: xx, score: desire[yy][xx] });
              }
            }
            candidates.sort((a, b) => a.score - b.score);
            for (let i = 0; i < excess && i < candidates.length; i++) {
              if (candidates[i].y === cy && candidates[i].x === cx) continue;
              matrix[candidates[i].y][candidates[i].x] = false;
            }
          }
        }
      } else {
        if (ratio > LIGHT_MAX) {
          const excess = Math.ceil(darkCount - LIGHT_MAX * total);
          if (excess > 0) {
            const candidates = [];
            for (let y = 0; y < scale; y++) {
              for (let x = 0; x < scale; x++) {
                const yy = y0 + y;
                const xx = x0 + x;
                if (matrix[yy][xx]) candidates.push({ y: yy, x: xx, score: desire[yy][xx] });
              }
            }
            candidates.sort((a, b) => a.score - b.score);
            for (let i = 0; i < excess && i < candidates.length; i++) {
              if (candidates[i].y === cy && candidates[i].x === cx) continue;
              matrix[candidates[i].y][candidates[i].x] = false;
            }
          }
        }
      }
    }
  }
}
async function generateDitheredMatrix(qr, config, overlayCanvas, moduleCount, scale, effectiveIntensity, _effectiveConfig, createCanvasFn) {
  const scaledSize = moduleCount * scale;
  if (config.qrFirstMode) {
    log9.debug("QR-first mode enabled via config - using QR-first matrix");
    return generateBWFirstMatrix(
      qr,
      config,
      overlayCanvas,
      moduleCount,
      scale,
      effectiveIntensity,
      createCanvasFn
    );
  }
  const detectCanvas = await createCanvasFn(Math.min(scaledSize, 256), Math.min(scaledSize, 256));
  const detectCtx = detectCanvas.getContext("2d");
  if (detectCtx) {
    detectCtx.drawImage(overlayCanvas, 0, 0, detectCanvas.width, detectCanvas.height);
    const isBW = detectBWFromCanvas(detectCtx, detectCanvas.width, detectCanvas.height);
    if (isBW) {
      log9.debug("Detected high-contrast B&W overlay - using QR-first mode");
      return generateBWFirstMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        scale,
        effectiveIntensity,
        createCanvasFn
      );
    }
  }
  const intensity = effectiveIntensity;
  const ditherStrength = (config.ditherStrength ?? 50) / 100;
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  const serpentine = config.ditherSerpentine ?? false;
  const colorDitherMode = config.colorDither ?? "none";
  const useColorDither = colorDitherMode !== "none";
  const kernelName = config.diffusionKernel ?? "floyd_steinberg";
  const kernel = DIFFUSION_KERNELS[kernelName] ?? DIFFUSION_KERNELS.floyd_steinberg;
  const scaledCanvas = await createCanvasFn(scaledSize, scaledSize);
  const ctx = scaledCanvas.getContext("2d");
  if (!ctx) return createEmptyMatrix(scaledSize, scale, effectiveIntensity);
  ctx.drawImage(overlayCanvas, 0, 0, scaledSize, scaledSize);
  const imageData = ctx.getImageData(0, 0, scaledSize, scaledSize);
  const data = imageData.data;
  const matrix = [];
  const colors = [];
  const desire = [];
  const errorsR = [];
  const errorsG = [];
  const errorsB = [];
  const errors = [];
  for (let y = 0; y < scaledSize; y++) {
    matrix[y] = [];
    colors[y] = [];
    desire[y] = new Array(scaledSize).fill(0.5);
    if (useColorDither) {
      errorsR[y] = new Array(scaledSize).fill(0);
      errorsG[y] = new Array(scaledSize).fill(0);
      errorsB[y] = new Array(scaledSize).fill(0);
    } else {
      errors[y] = new Array(scaledSize).fill(0);
    }
  }
  const mix = clamp013(intensity * ditherStrength);
  for (let y = 0; y < scaledSize; y++) {
    const leftToRight = serpentine ? y % 2 === 0 : true;
    const startX = leftToRight ? 0 : scaledSize - 1;
    const endX = leftToRight ? scaledSize : -1;
    const deltaX = leftToRight ? 1 : -1;
    for (let x = startX; leftToRight ? x < endX : x > endX; x += deltaX) {
      const idx = (y * scaledSize + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const moduleRow = Math.floor(y / scale);
      const moduleCol = Math.floor(x / scale);
      const qrIsDark = qr.isDark(moduleRow, moduleCol);
      if (shouldLockModule(moduleRow, moduleCol, moduleCount, version, config)) {
        matrix[y][x] = qrIsDark;
        colors[y][x] = config.colorMode !== "bw" ? { r, g, b } : null;
        desire[y][x] = qrIsDark ? 1 : 0;
        continue;
      }
      if (useColorDither) {
        const rNorm = r / 255;
        const gNorm = g / 255;
        const bNorm = b / 255;
        const rAdjusted = clamp013(rNorm + errorsR[y][x]);
        const gAdjusted = clamp013(gNorm + errorsG[y][x]);
        const bAdjusted = clamp013(bNorm + errorsB[y][x]);
        const rNew = rAdjusted > 0.5 ? 1 : 0;
        const gNew = gAdjusted > 0.5 ? 1 : 0;
        const bNew = bAdjusted > 0.5 ? 1 : 0;
        const errR = (rAdjusted - rNew) * mix;
        const errG = (gAdjusted - gNew) * mix;
        const errB = (bAdjusted - bNew) * mix;
        const ditheredLuma = luma01(rNew * 255, gNew * 255, bNew * 255);
        let d = lerp2(qrIsDark ? 1 : 0, 1 - ditheredLuma, mix);
        if (qrIsDark) {
          d = clamp013(lerp2(DARK_DESIRE_MIN, DARK_DESIRE_MAX, d));
        } else {
          d = clamp013(lerp2(LIGHT_DESIRE_MIN, LIGHT_DESIRE_MAX, d));
        }
        desire[y][x] = d;
        const isDark2 = d >= 0.5;
        matrix[y][x] = isDark2;
        colors[y][x] = config.colorMode !== "bw" ? {
          r: Math.round(r * COLOR_PRESERVE_RATIO + rNew * 255 * (1 - COLOR_PRESERVE_RATIO)),
          g: Math.round(g * COLOR_PRESERVE_RATIO + gNew * 255 * (1 - COLOR_PRESERVE_RATIO)),
          b: Math.round(b * COLOR_PRESERVE_RATIO + bNew * 255 * (1 - COLOR_PRESERVE_RATIO))
        } : null;
        distributeColorError(
          errorsR,
          errorsG,
          errorsB,
          x,
          y,
          errR,
          errG,
          errB,
          kernel,
          scaledSize,
          leftToRight
        );
      } else {
        const overlayDark = 1 - luma01(r, g, b);
        let d = lerp2(qrIsDark ? 1 : 0, overlayDark, mix);
        if (qrIsDark) {
          d = clamp013(lerp2(DARK_DESIRE_MIN, DARK_DESIRE_MAX, d));
        } else {
          d = clamp013(lerp2(LIGHT_DESIRE_MIN, LIGHT_DESIRE_MAX, d));
        }
        desire[y][x] = d;
        const adjusted = d + errors[y][x];
        const isDark2 = adjusted >= 0.5;
        matrix[y][x] = isDark2;
        colors[y][x] = config.colorMode !== "bw" ? { r, g, b } : null;
        const err = adjusted - (isDark2 ? 1 : 0);
        distributeError2(errors, x, y, err, kernel, scaledSize, leftToRight);
      }
    }
  }
  enforceModuleConstraints2(qr, matrix, desire, moduleCount, scale, version, config);
  const center = Math.floor(scale / 2);
  const sampleMr = Math.min(10, moduleCount - 1);
  const sampleMc = Math.min(10, moduleCount - 1);
  const sy = sampleMr * scale + center;
  const sx = sampleMc * scale + center;
  log9.debug("dithered-matrix generated", {
    scaledSize,
    moduleCount,
    scale,
    mix,
    serpentine,
    colorDitherMode,
    kernelName,
    sample: {
      module: { row: sampleMr, col: sampleMc, qrIsDark: qr.isDark(sampleMr, sampleMc) },
      centerPixel: { y: sy, x: sx, isDark: matrix[sy]?.[sx], desire: desire[sy]?.[sx] }
    }
  });
  return { matrix, colors, scale, overlayData: null, effectiveIntensity };
}
async function generateBlueNoiseMatrix(qr, config, overlayCanvas, moduleCount, scale, effectiveIntensity, _canvasFactory, createCanvasFn) {
  const scaledSize = moduleCount * scale;
  if (config.qrFirstMode) {
    log9.debug("QR-first mode enabled via config in blue-noise mode - using QR-first matrix");
    return generateBWFirstMatrix(
      qr,
      config,
      overlayCanvas,
      moduleCount,
      scale,
      effectiveIntensity,
      createCanvasFn
    );
  }
  const detectCanvas = await createCanvasFn(Math.min(scaledSize, 256), Math.min(scaledSize, 256));
  const detectCtx = detectCanvas.getContext("2d");
  if (detectCtx) {
    detectCtx.drawImage(overlayCanvas, 0, 0, detectCanvas.width, detectCanvas.height);
    const isBW = detectBWFromCanvas(detectCtx, detectCanvas.width, detectCanvas.height);
    if (isBW) {
      log9.debug("Detected high-contrast B&W overlay in blue-noise mode - using QR-first mode");
      return generateBWFirstMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        scale,
        effectiveIntensity,
        createCanvasFn
      );
    }
  }
  const intensity = effectiveIntensity;
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  const scaledCanvas = await createCanvasFn(scaledSize, scaledSize);
  const ctx = scaledCanvas.getContext("2d");
  if (!ctx) return createEmptyMatrix(scaledSize, scale, effectiveIntensity);
  ctx.drawImage(overlayCanvas, 0, 0, scaledSize, scaledSize);
  const imageData = ctx.getImageData(0, 0, scaledSize, scaledSize);
  const data = imageData.data;
  const matrix = [];
  const colors = [];
  const desire = [];
  for (let y = 0; y < scaledSize; y++) {
    matrix[y] = [];
    colors[y] = [];
    desire[y] = new Array(scaledSize).fill(0.5);
  }
  const seed = config.blueNoiseSeed ?? 1337;
  const tileSize = config.blueNoiseTileSize ?? 64;
  const tile = generateBlueNoiseTile(tileSize, seed);
  for (let y = 0; y < scaledSize; y++) {
    for (let x = 0; x < scaledSize; x++) {
      const idx = (y * scaledSize + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const moduleRow = Math.floor(y / scale);
      const moduleCol = Math.floor(x / scale);
      const qrIsDark = qr.isDark(moduleRow, moduleCol);
      if (shouldLockModule(moduleRow, moduleCol, moduleCount, version, config)) {
        matrix[y][x] = qrIsDark;
        colors[y][x] = config.colorMode !== "bw" ? { r, g, b } : null;
        desire[y][x] = qrIsDark ? 1 : 0;
        continue;
      }
      const overlayDark = 1 - luma01(r, g, b);
      let d = lerp2(qrIsDark ? 1 : 0, overlayDark, intensity);
      if (qrIsDark) {
        d = clamp013(lerp2(DARK_DESIRE_MIN, DARK_DESIRE_MAX, d));
      } else {
        d = clamp013(lerp2(LIGHT_DESIRE_MIN, LIGHT_DESIRE_MAX, d));
      }
      desire[y][x] = d;
      const n = sampleBlueNoise(x, y, tile, tileSize);
      const isDark2 = n < d;
      matrix[y][x] = isDark2;
      colors[y][x] = config.colorMode !== "bw" ? { r, g, b } : null;
    }
  }
  enforceModuleConstraints2(qr, matrix, desire, moduleCount, scale, version, config);
  log9.debug("blue-noise-matrix generated", {
    scaledSize,
    moduleCount,
    scale,
    tileSize,
    seed
  });
  return { matrix, colors, scale, overlayData: null, effectiveIntensity };
}

// src/modules/qr-generator/pixel-matrix-standard.ts
var _log71 = createLogger("GENERATE");
async function generateStandardMatrix(qr, _config, overlayCanvas, moduleCount, effectiveIntensity, effectiveConfig, createCanvasFn) {
  const overlayData = await getOverlayData(
    overlayCanvas,
    moduleCount,
    effectiveConfig,
    createCanvasFn
  );
  const matrix = [];
  for (let row = 0; row < moduleCount; row++) {
    matrix[row] = [];
    for (let col = 0; col < moduleCount; col++) {
      matrix[row][col] = qr.isDark(row, col);
    }
  }
  const colors = normalizeColors(overlayData.colors, moduleCount);
  return {
    matrix,
    colors,
    scale: 1,
    overlayData,
    effectiveIntensity
  };
}

// src/modules/qr-generator/pixel-matrix-utils.ts
var _log72 = createLogger("GENERATE");
function getScaleFactor(overlayMode, config) {
  switch (overlayMode) {
    case "dithered":
      return 4;
    case "blue-noise":
    case "blue_noise":
      return 4;
    case "subpixel":
    case "subpixel-size":
      return config.subpixelGrid ?? 3;
    default:
      return 1;
  }
}
var DEFAULT_ECC_LIMITS = {
  L: 30,
  M: 50,
  Q: 70,
  H: 85
};
function getEffectiveIntensity(config) {
  const intensity = (config.overlayIntensity ?? 100) / 100;
  const eccLimits = config.maxOverlayIntensityByEcc ?? DEFAULT_ECC_LIMITS;
  const maxIntensityPct = eccLimits[config.errorCorrection] ?? 50;
  const maxIntensity = maxIntensityPct / 100;
  const effectiveIntensity = Math.min(intensity, maxIntensity);
  return {
    effectiveIntensity,
    effectiveConfig: { ...config, overlayIntensity: effectiveIntensity * 100 }
  };
}
function generateBaseMatrix(qr, scaledSize, scale) {
  const _moduleCount = scaledSize / scale;
  const matrix = [];
  const colors = [];
  for (let y = 0; y < scaledSize; y++) {
    matrix[y] = [];
    colors[y] = [];
    for (let x = 0; x < scaledSize; x++) {
      const moduleRow = Math.floor(y / scale);
      const moduleCol = Math.floor(x / scale);
      matrix[y][x] = qr.isDark(moduleRow, moduleCol);
      colors[y][x] = null;
    }
  }
  return { matrix, colors };
}

// src/modules/qr-generator/pixel-matrix-overlay.ts
var _log73 = createLogger("GENERATE");
async function prepareUnifiedOverlayData(qr, config, overlayCanvas, moduleCount, createCanvasFn) {
  if (!overlayCanvas) {
    return {
      ditherPattern: null,
      overlayData: null,
      effectiveIntensity: 0
    };
  }
  const { effectiveIntensity, effectiveConfig } = getEffectiveIntensity(config);
  const overlayData = await getOverlayData(
    overlayCanvas,
    moduleCount,
    effectiveConfig,
    createCanvasFn
  );
  let ditherPattern = null;
  const overlayMode = config.overlayMode || "blend";
  if (overlayMode === "dither" || overlayMode === "extreme") {
    ditherPattern = applyDitherToMatrix(qr, moduleCount, overlayData, effectiveConfig);
  }
  return {
    ditherPattern,
    overlayData,
    effectiveIntensity
  };
}

// src/modules/qr-generator/pixel-matrix.ts
var log10 = createLogger("GENERATE");
async function generatePixelDecisionMatrix(qr, config, overlayCanvas, moduleCount, createCanvasFn, canvasFactory) {
  const overlayMode = config.overlayMode;
  const scale = getScaleFactor(overlayMode, config);
  const scaledSize = moduleCount * scale;
  const { effectiveIntensity, effectiveConfig } = getEffectiveIntensity(config);
  if (config.debugOverlayDither) {
    log10.debug("pixel-matrix", {
      overlayMode,
      scale,
      scaledSize,
      hasOverlay: !!overlayCanvas,
      effectiveIntensity,
      colorMode: config.colorMode
    });
  }
  if (overlayCanvas === null || overlayCanvas === void 0) {
    const { matrix, colors } = generateBaseMatrix(qr, scaledSize, scale);
    return { matrix, colors, scale, overlayData: null, effectiveIntensity };
  }
  switch (overlayMode) {
    case "dithered":
      return generateDitheredMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        scale,
        effectiveIntensity,
        effectiveConfig,
        createCanvasFn
      );
    case "blue-noise":
    case "blue_noise":
      return generateBlueNoiseMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        scale,
        effectiveIntensity,
        canvasFactory,
        createCanvasFn
      );
    case "subpixel":
    case "subpixel-size": {
      const useHalftoneCenter = overlayMode === "subpixel-size";
      return await generateSubpixelMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        scale,
        useHalftoneCenter,
        createCanvasFn
      );
    }
    case "dither":
    case "extreme":
      return generateDitherModeMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        effectiveIntensity,
        effectiveConfig,
        overlayMode,
        createCanvasFn
      );
    default:
      return generateStandardMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        effectiveIntensity,
        effectiveConfig,
        createCanvasFn
      );
  }
}

// src/modules/qr-generator/render-modes.ts
var _log74 = createLogger("GENERATE");
function computeDarkFactor(intensity, minFactor = 0.55) {
  const i = Math.max(0, Math.min(1, intensity));
  return 1 - (1 - minFactor) * i;
}
function computeLightBlend(intensity, maxBlend = 0.4) {
  const i = Math.max(0, Math.min(1, intensity));
  return maxBlend * i;
}
var DUOTONE_MAX_LIGHTEN = 0.5;
function applyQROverlayMode(overlayMode, isDark2, brightness2, overlayData, row, col, moduleCount, effectiveIntensity, config) {
  const result = {
    moduleColor: isDark2 ? config.fgColor : config.bgColor,
    moduleSizeModifier: 1,
    moduleOpacity: 1,
    waveOffsetX: 0,
    waveOffsetY: 0,
    drawOutlineOnly: false,
    useHalftoneRendering: false,
    halftoneBrightness: 0.5,
    shouldDrawCell: isDark2
  };
  const overlayWithColors = overlayData;
  switch (overlayMode) {
    case "halftone":
      if (isDark2) {
        if (config.halftoneCell || config.halftoneDotShape || config.brightnessCurve) {
          result.useHalftoneRendering = true;
          let transformedBrightness = brightness2;
          const curve = config.brightnessCurve;
          if (curve === "s-curve" || curve === "s_curve") {
            transformedBrightness = brightness2 * brightness2 * (3 - 2 * brightness2);
          } else if (curve === "gamma") {
            transformedBrightness = brightness2 ** 0.7;
          }
          result.halftoneBrightness = 0.5 + (transformedBrightness - 0.5) * effectiveIntensity;
        } else {
          const intensity = effectiveIntensity;
          const minSize = 0.15 + 0.1 * (1 - intensity);
          const maxSize = 1;
          const sizeRange = maxSize - minSize;
          const darknessInfluence = (1 - brightness2) * intensity;
          const baseSize = minSize + sizeRange * (1 - intensity) * 0.5;
          result.moduleSizeModifier = baseSize + darknessInfluence * (maxSize - baseSize);
        }
      }
      break;
    case "blend":
      if (isDark2) {
        const blendColor = overlayWithColors.colors?.[row]?.[col];
        if (blendColor) {
          const blendAmount = effectiveIntensity;
          const darkFactor = computeDarkFactor(blendAmount, 0.75);
          const darkR = Math.round(blendColor.r * darkFactor);
          const darkG = Math.round(blendColor.g * darkFactor);
          const darkB = Math.round(blendColor.b * darkFactor);
          result.moduleColor = blendColors(
            config.fgColor,
            `rgb(${darkR},${darkG},${darkB})`,
            blendAmount
          );
        }
      }
      break;
    case "brightness":
      if (isDark2) {
        const threshold2 = 1 - effectiveIntensity;
        if (brightness2 > threshold2) {
          result.moduleOpacity = 0;
        }
      }
      break;
    case "gapfill":
      if (isDark2) {
        result.moduleColor = config.fgColor;
      } else {
        const gapColor = overlayWithColors.colors?.[row]?.[col];
        if (gapColor) {
          const fadeAmount = computeLightBlend(effectiveIntensity, 0.75);
          const colorStr = `rgb(${gapColor.r},${gapColor.g},${gapColor.b})`;
          result.moduleColor = blendColors(config.bgColor, colorStr, fadeAmount);
          result.shouldDrawCell = true;
        }
      }
      break;
    case "pixelate":
      if (isDark2) {
        const blockSize = 3;
        const blockRow = Math.floor(row / blockSize) * blockSize;
        const blockCol = Math.floor(col / blockSize) * blockSize;
        let avgR = 0, avgG = 0, avgB = 0, pixCount = 0;
        for (let br = 0; br < blockSize && blockRow + br < moduleCount; br++) {
          for (let bc = 0; bc < blockSize && blockCol + bc < moduleCount; bc++) {
            const c = overlayWithColors.colors?.[blockRow + br]?.[blockCol + bc];
            if (c) {
              avgR += c.r;
              avgG += c.g;
              avgB += c.b;
              pixCount++;
            }
          }
        }
        if (pixCount > 0) {
          avgR = Math.round(avgR / pixCount);
          avgG = Math.round(avgG / pixCount);
          avgB = Math.round(avgB / pixCount);
          const pixIntensity = effectiveIntensity;
          const darkFactor = computeDarkFactor(pixIntensity, 0.7);
          const darkR = Math.round(avgR * darkFactor);
          const darkG = Math.round(avgG * darkFactor);
          const darkB = Math.round(avgB * darkFactor);
          const blockColor = `rgb(${darkR},${darkG},${darkB})`;
          result.moduleColor = blendColors(config.fgColor, blockColor, pixIntensity);
        }
      }
      break;
    case "duotone":
      if (isDark2) {
        const duotoneArr = config.duotoneColors || [];
        const shadowColor = duotoneArr[0] || config.fgColor;
        const highlightColor = duotoneArr[1] || null;
        const duoIntensity = effectiveIntensity;
        if (highlightColor) {
          const shadowParsed = parseColor(shadowColor) ?? { r: 0, g: 0, b: 0, a: 1 };
          const highlightParsed = parseColor(highlightColor) ?? { r: 0, g: 0, b: 0, a: 1 };
          const duoR = Math.round(
            shadowParsed.r + (highlightParsed.r - shadowParsed.r) * brightness2
          );
          const duoG = Math.round(
            shadowParsed.g + (highlightParsed.g - shadowParsed.g) * brightness2
          );
          const duoB = Math.round(
            shadowParsed.b + (highlightParsed.b - shadowParsed.b) * brightness2
          );
          const duoColor = `rgb(${duoR},${duoG},${duoB})`;
          result.moduleColor = blendColors(config.fgColor, duoColor, duoIntensity);
        } else if (brightness2 > 0.5) {
          const shadowParsed = parseColor(shadowColor) ?? { r: 0, g: 0, b: 0, a: 1 };
          const lightenAmt = (brightness2 - 0.5) * 2 * duoIntensity;
          const lightR = Math.min(
            255,
            Math.round(shadowParsed.r + (255 - shadowParsed.r) * lightenAmt * DUOTONE_MAX_LIGHTEN)
          );
          const lightG = Math.min(
            255,
            Math.round(shadowParsed.g + (255 - shadowParsed.g) * lightenAmt * DUOTONE_MAX_LIGHTEN)
          );
          const lightB = Math.min(
            255,
            Math.round(shadowParsed.b + (255 - shadowParsed.b) * lightenAmt * DUOTONE_MAX_LIGHTEN)
          );
          result.moduleColor = `rgb(${lightR},${lightG},${lightB})`;
        } else {
          result.moduleColor = blendColors(
            config.fgColor,
            shadowColor,
            duoIntensity * (0.5 - brightness2) * 2
          );
        }
      }
      break;
    case "outline":
      if (isDark2) {
        result.drawOutlineOnly = true;
        const outlineColor = overlayWithColors.colors?.[row]?.[col];
        if (outlineColor) {
          const outlineBlend = effectiveIntensity;
          const darkFactor = computeDarkFactor(outlineBlend, 0.75);
          const darkR = Math.round(outlineColor.r * darkFactor);
          const darkG = Math.round(outlineColor.g * darkFactor);
          const darkB = Math.round(outlineColor.b * darkFactor);
          const colorStr = `rgb(${darkR},${darkG},${darkB})`;
          result.moduleColor = blendColors(config.fgColor, colorStr, outlineBlend);
        }
      }
      break;
    case "wave":
      if (isDark2) {
        const waveIntensity = effectiveIntensity;
        const waveStrength = (1 - brightness2) * waveIntensity * 4;
        result.waveOffsetX = Math.sin(row * 0.5 + col * 0.15) * waveStrength;
        result.waveOffsetY = Math.cos(col * 0.5 + row * 0.15) * waveStrength;
        const waveColor = overlayWithColors.colors?.[row]?.[col];
        if (waveColor && waveIntensity > 0) {
          const darkFactor = computeDarkFactor(waveIntensity, 0.7);
          const colorStr = `rgb(${Math.round(waveColor.r * darkFactor)},${Math.round(waveColor.g * darkFactor)},${Math.round(waveColor.b * darkFactor)})`;
          result.moduleColor = blendColors(config.fgColor, colorStr, waveIntensity);
        }
      }
      break;
    case "mosaic": {
      result.shouldDrawCell = true;
      const mosaicColor = overlayWithColors.colors?.[row]?.[col];
      if (mosaicColor) {
        const mosaicIntensity = effectiveIntensity;
        if (isDark2) {
          const darkFactor = computeDarkFactor(mosaicIntensity, 0.8);
          result.moduleColor = `rgb(${Math.round(mosaicColor.r * darkFactor)},${Math.round(mosaicColor.g * darkFactor)},${Math.round(mosaicColor.b * darkFactor)})`;
        } else {
          const blendToWhite = 0.4 + computeLightBlend(mosaicIntensity, 0.3);
          const lightR = Math.round(mosaicColor.r + (255 - mosaicColor.r) * blendToWhite);
          const lightG = Math.round(mosaicColor.g + (255 - mosaicColor.g) * blendToWhite);
          const lightB = Math.round(mosaicColor.b + (255 - mosaicColor.b) * blendToWhite);
          result.moduleColor = `rgb(${lightR},${lightG},${lightB})`;
        }
      }
      break;
    }
    case "artwork": {
      result.shouldDrawCell = isDark2;
      result.moduleColor = isDark2 ? config.fgColor : config.bgColor;
      result.moduleSizeModifier = 1;
      break;
    }
  }
  return result;
}

// src/modules/qr-generator/render-loop.ts
function renderModules(ctx, qr, config, moduleCount, moduleSize, margin, overlayData, ditherPattern, effectiveIntensity, drawnFinderPatterns, drawnAlignmentPatterns, version, gradientFill, useGradient) {
  const cornerRadius = config.cornerRadius || 0;
  const dotRotation = config.dotRotationDeg || 0;
  const timingStyle = config.timingStyle || "match_module";
  for (let row = 0; row < moduleCount; row++) {
    for (let col = 0; col < moduleCount; col++) {
      if (drawnFinderPatterns.has(`${row},${col}`)) continue;
      if (drawnAlignmentPatterns.has(`${row},${col}`)) continue;
      const isDark2 = ditherPattern ? ditherPattern[row][col] : qr.isDark(row, col);
      const x = (col + margin) * moduleSize;
      const y = (row + margin) * moduleSize;
      const isFinder = isFinderPattern(row, col, moduleCount);
      const isTiming = isTimingPattern(row, col, moduleCount);
      const isFormat = isFormatInfo2(row, col, moduleCount);
      const isVersion = isVersionInfo2(row, col, moduleCount, version);
      const isInAlignmentSet = drawnAlignmentPatterns.has(`${row},${col}`);
      const protectFormat = config.protectFormatInfo;
      const protectVersion = config.protectVersionInfo;
      const applyOverlay = overlayData && !(config.preserveFinders && isFinder) && !(config.preserveTiming && isTiming) && !(config.preserveAlignment && isInAlignmentSet) && !(protectFormat && isFormat) && !(protectVersion && isVersion);
      const effectiveBgColor = validateColor(config.bgColor, "#ffffff");
      const effectiveFgColor = validateColor(config.fgColor, "#000000");
      let moduleColor = isDark2 ? effectiveFgColor : effectiveBgColor;
      const needsExplicitLightModules = config.transparentBg === true;
      let moduleSizeModifier = 1;
      let moduleOpacity = 1;
      let waveOffsetX = 0;
      let waveOffsetY = 0;
      let drawOutlineOnly = false;
      let useHalftoneRendering = false;
      let halftoneBrightness = 0.5;
      let shouldDrawCell = isDark2 || needsExplicitLightModules;
      if (applyOverlay) {
        const brightness2 = overlayData[row][col];
        const modeResult = applyQROverlayMode(
          config.overlayMode,
          isDark2,
          brightness2,
          overlayData,
          row,
          col,
          moduleCount,
          effectiveIntensity,
          config
        );
        moduleColor = modeResult.moduleColor;
        moduleSizeModifier = modeResult.moduleSizeModifier;
        moduleOpacity = modeResult.moduleOpacity;
        waveOffsetX = modeResult.waveOffsetX;
        waveOffsetY = modeResult.waveOffsetY;
        drawOutlineOnly = modeResult.drawOutlineOnly;
        useHalftoneRendering = modeResult.useHalftoneRendering;
        halftoneBrightness = modeResult.halftoneBrightness;
        shouldDrawCell = modeResult.shouldDrawCell || needsExplicitLightModules;
      }
      if (shouldDrawCell && moduleOpacity > 0) {
        ctx.save();
        ctx.globalAlpha = moduleOpacity;
        let finalModuleColor = moduleColor;
        if (isDark2 && config.perModuleColorMode && config.perModuleColorMode !== "solid" && overlayData) {
          finalModuleColor = applyPerModuleColor(
            config.perModuleColorMode,
            moduleColor,
            overlayData,
            row,
            col,
            moduleCount,
            config
          );
        }
        const paletteBrightness = overlayData?.[row]?.[col] ?? 0.5;
        if (isDark2 && config.palette && config.palette.length > 0) {
          finalModuleColor = applyPaletteColor(
            row,
            col,
            moduleCount,
            paletteBrightness,
            config.palette,
            config
          );
        }
        if (isDark2 && config.contrastGuard && config.minContrastRatio) {
          finalModuleColor = ensureContrast(
            finalModuleColor,
            config.bgColor,
            config.minContrastRatio
          );
        }
        if (isDark2 && useGradient && gradientFill) {
          ctx.fillStyle = gradientFill;
        } else {
          ctx.fillStyle = finalModuleColor;
        }
        let gap = config.moduleGap ? moduleSize * config.moduleGap / 100 : 0;
        const gapMode = config.gapMode || "none";
        let strokeWidth = 0;
        if (gapMode === "inset") {
          gap = Math.max(gap, moduleSize * 0.1);
        } else if (gapMode === "stroke") {
          strokeWidth = Math.max(1, moduleSize * 0.15);
          gap = strokeWidth;
        } else if (gapMode === "negative_space") {
          gap = Math.max(gap, moduleSize * 0.2);
        }
        const adjustedSize = (moduleSize - gap) * moduleSizeModifier;
        const offset = (moduleSize - adjustedSize) / 2;
        let drawX = x + offset + waveOffsetX;
        let drawY = y + offset + waveOffsetY;
        if (config.moduleJitterPx && config.moduleJitterPx > 0) {
          const jitterSeed = (row * 31 + col * 17 + (config.frameIndex || 0) * 13) % 1e3;
          const jitterX = (jitterSeed % 100 / 100 - 0.5) * 2 * config.moduleJitterPx;
          const jitterY = (jitterSeed * 7 % 100 / 100 - 0.5) * 2 * config.moduleJitterPx;
          drawX += jitterX;
          drawY += jitterY;
        }
        const pixelSnap = config.pixelSnap || "floor";
        if (pixelSnap === "floor") {
          drawX = Math.floor(drawX);
          drawY = Math.floor(drawY);
        } else if (pixelSnap === "round") {
          drawX = Math.round(drawX);
          drawY = Math.round(drawY);
        } else if (pixelSnap === "ceil") {
          drawX = Math.ceil(drawX);
          drawY = Math.ceil(drawY);
        }
        if (drawOutlineOnly || gapMode === "stroke" && isDark2) {
          ctx.strokeStyle = finalModuleColor;
          ctx.lineWidth = strokeWidth || 1;
          ctx.strokeRect(
            drawX + ctx.lineWidth / 2,
            drawY + ctx.lineWidth / 2,
            adjustedSize - ctx.lineWidth,
            adjustedSize - ctx.lineWidth
          );
        } else if (useHalftoneRendering && isDark2) {
          drawHalftoneModule(
            ctx,
            drawX,
            drawY,
            adjustedSize,
            halftoneBrightness,
            config,
            row,
            col
          );
        } else if (isTiming) {
          drawTimingModule(
            ctx,
            drawX,
            drawY,
            adjustedSize,
            timingStyle,
            config
          );
        } else {
          drawModule(
            ctx,
            drawX,
            drawY,
            adjustedSize,
            config.moduleStyle,
            {
              cornerRadius,
              rotation: dotRotation
            }
          );
        }
        ctx.restore();
      }
    }
  }
}

// src/modules/qr-generator/scaled-render.ts
var log11 = createLogger("GENERATE");
async function generateScaledQR(qr, config, overlayCanvas, moduleCount, scale, createCanvasFn, canvasFactory, storeMatrixFn) {
  const pixelData = await generatePixelDecisionMatrix(
    qr,
    config,
    overlayCanvas,
    moduleCount,
    createCanvasFn,
    canvasFactory
  );
  const { matrix, colors } = pixelData;
  const scaledSize = matrix.length;
  const quietZoneMin = config.quietZoneMinEnforce === false ? 0 : 4;
  const marginModules = Math.max(quietZoneMin, config.margin);
  const subPixelSize = Math.max(1, Math.round(config.moduleSize / scale));
  const effectiveModuleSize = subPixelSize * scale;
  const frameExtra = config.frameStyle && config.frameStyle !== "none" && config.frameText ? effectiveModuleSize * 4 : 0;
  const marginPx = marginModules * effectiveModuleSize;
  const size = scaledSize * subPixelSize + marginPx * 2 + frameExtra;
  const canvas = await createCanvasFn(size, size);
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = false;
  const effectiveBgColor = validateColor(config.bgColor, "#ffffff");
  const effectiveFgColor = validateColor(config.fgColor, "#000000");
  const needsExplicitLightModules = config.transparentBg === true;
  if (!config.transparentBg) {
    ctx.fillStyle = effectiveBgColor;
    ctx.fillRect(0, 0, size, size);
  }
  drawFrameBackground(ctx, size, effectiveModuleSize, marginModules, config);
  const gradientFill = createGradientFill(ctx, config, size);
  const useGradient = config.gradient && config.gradient.type !== "none";
  const useColorRendering = overlayCanvas && config.colorMode !== "bw";
  const isDitheredMode = config.overlayMode === "dithered" || config.overlayMode === "blue_noise" || config.overlayMode === "blue-noise";
  const isSubpixelMode = config.overlayMode === "subpixel" || config.overlayMode === "subpixel-size";
  const needsBothDarkAndLightColors = isDitheredMode || isSubpixelMode;
  const debug = config.debugOverlayDither === true;
  if (debug) {
    log11.debug("ScaledRender start", {
      moduleCount,
      scale,
      scaledSize,
      overlayMode: config.overlayMode,
      colorMode: config.colorMode,
      useColorRendering,
      needsBothDarkAndLightColors,
      protectFormatInfo: config.protectFormatInfo,
      protectVersionInfo: config.protectVersionInfo,
      preserveFinders: config.preserveFinders,
      preserveTiming: config.preserveTiming,
      preserveAlignment: config.preserveAlignment,
      hasColors: !!(colors?.length && colors[0]?.length),
      sampleColor: colors?.[5]?.[5]
    });
  }
  const overlayDkFactor = computeDarkFactor(pixelData.effectiveIntensity, 0.6);
  const overlayLtBlend = computeLightBlend(pixelData.effectiveIntensity, 0.4);
  for (let y = 0; y < scaledSize; y++) {
    for (let x = 0; x < scaledSize; x++) {
      const isDark2 = matrix[y]?.[x];
      const color = colors[y]?.[x];
      const shouldDrawLightPixel = needsExplicitLightModules || needsBothDarkAndLightColors && useColorRendering;
      if (debug && y === Math.floor(scaledSize / 2) && (x === Math.floor(scaledSize / 2) || x === Math.floor(scaledSize / 2) + 4)) {
        log11.debug("ScaledRender samplePixel", {
          y,
          x,
          isDark: isDark2,
          color
        });
      }
      if (!(isDark2 || shouldDrawLightPixel)) continue;
      const dx = marginPx + x * subPixelSize;
      const dy = marginPx + y * subPixelSize;
      if (isDark2) {
        if (useColorRendering && color) {
          if (color.halftone) {
            ctx.fillStyle = effectiveBgColor;
            ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
            ctx.fillStyle = useGradient && gradientFill ? gradientFill : effectiveFgColor;
            const dotSize = subPixelSize * (color.sizeRatio || 1);
            const offset = (subPixelSize - dotSize) / 2;
            ctx.fillRect(dx + offset, dy + offset, dotSize, dotSize);
          } else if (isDitheredMode) {
            const darkR = Math.round(color.r * overlayDkFactor);
            const darkG = Math.round(color.g * overlayDkFactor);
            const darkB = Math.round(color.b * overlayDkFactor);
            ctx.fillStyle = `rgb(${darkR},${darkG},${darkB})`;
            ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
          } else {
            ctx.fillStyle = `rgb(${color.r},${color.g},${color.b})`;
            ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
          }
        } else {
          ctx.fillStyle = useGradient && gradientFill ? gradientFill : effectiveFgColor;
          ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
        }
      } else {
        if (needsBothDarkAndLightColors && useColorRendering && color) {
          if (isDitheredMode) {
            const lightR = Math.round(color.r + (255 - color.r) * overlayLtBlend);
            const lightG = Math.round(color.g + (255 - color.g) * overlayLtBlend);
            const lightB = Math.round(color.b + (255 - color.b) * overlayLtBlend);
            ctx.fillStyle = `rgb(${lightR},${lightG},${lightB})`;
            ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
          } else {
            ctx.fillStyle = `rgb(${color.r},${color.g},${color.b})`;
            ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
          }
        } else {
          ctx.fillStyle = effectiveBgColor;
          ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
        }
      }
    }
  }
  const shouldDrawFindersFirst = config.preserveFinders !== false || !overlayCanvas;
  const finderPositions = [
    { row: 0, col: 0 },
    // Top-left
    { row: 0, col: moduleCount - 7 },
    // Top-right
    { row: moduleCount - 7, col: 0 }
    // Bottom-left
  ];
  if (shouldDrawFindersFirst) {
    for (const pos of finderPositions) {
      const x = marginPx + pos.col * effectiveModuleSize;
      const y = marginPx + pos.row * effectiveModuleSize;
      drawFinderPatternComplete(ctx, x, y, effectiveModuleSize, config);
    }
  }
  const shouldDrawAlignmentFirst = config.preserveAlignment !== false || !overlayCanvas;
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  if (version >= 2 && shouldDrawAlignmentFirst) {
    const alignPositions = getAlignmentPositionsCached(version, moduleCount);
    const alignmentStyle = config.alignmentStyle || "match_finder";
    for (const pos of alignPositions) {
      const centerX = marginPx + (pos.col + 0.5) * effectiveModuleSize;
      const centerY = marginPx + (pos.row + 0.5) * effectiveModuleSize;
      drawAlignmentPattern(ctx, centerX, centerY, effectiveModuleSize, alignmentStyle, config);
    }
  }
  const shouldPreserveTiming = config.preserveTiming === true;
  if (shouldPreserveTiming) {
    const timingStyle = config.timingStyle || "match_module";
    const timingRow = 6;
    for (let col = 8; col < moduleCount - 8; col++) {
      const isDark2 = qr.isDark(timingRow, col);
      const x = marginPx + col * effectiveModuleSize;
      const y = marginPx + timingRow * effectiveModuleSize;
      if (isDark2) {
        ctx.fillStyle = useGradient && gradientFill ? gradientFill : effectiveFgColor;
        drawTimingModule(ctx, x, y, effectiveModuleSize, timingStyle, config);
      } else {
        ctx.fillStyle = effectiveBgColor;
        ctx.fillRect(x, y, effectiveModuleSize, effectiveModuleSize);
      }
    }
    const timingCol = 6;
    for (let row = 8; row < moduleCount - 8; row++) {
      const isDark2 = qr.isDark(row, timingCol);
      const x = marginPx + timingCol * effectiveModuleSize;
      const y = marginPx + row * effectiveModuleSize;
      if (isDark2) {
        ctx.fillStyle = useGradient && gradientFill ? gradientFill : effectiveFgColor;
        drawTimingModule(ctx, x, y, effectiveModuleSize, timingStyle, config);
      } else {
        ctx.fillStyle = effectiveBgColor;
        ctx.fillRect(x, y, effectiveModuleSize, effectiveModuleSize);
      }
    }
  }
  const protectFormat = config.protectFormatInfo === true;
  const protectVersion = config.protectVersionInfo === true;
  if (protectFormat || protectVersion) {
    let formatCount = 0;
    let versionCount = 0;
    for (let row = 0; row < moduleCount; row++) {
      for (let col = 0; col < moduleCount; col++) {
        const isFormat = protectFormat && isFormatInfo(row, col, moduleCount);
        const isVersion = protectVersion && isVersionInfo(row, col, moduleCount, version);
        if (!(isFormat || isVersion)) continue;
        const isDark2 = qr.isDark(row, col);
        const x = marginPx + col * effectiveModuleSize;
        const y = marginPx + row * effectiveModuleSize;
        if (isDark2) {
          ctx.fillStyle = useGradient && gradientFill ? gradientFill : effectiveFgColor;
        } else {
          ctx.fillStyle = effectiveBgColor;
        }
        ctx.fillRect(x, y, effectiveModuleSize, effectiveModuleSize);
        if (isFormat) formatCount++;
        if (isVersion) versionCount++;
      }
    }
    const dmRow = moduleCount - 8;
    const dmCol = 8;
    if (dmRow >= 0 && dmRow < moduleCount && dmCol >= 0 && dmCol < moduleCount) {
      const x = marginPx + dmCol * effectiveModuleSize;
      const y = marginPx + dmRow * effectiveModuleSize;
      ctx.fillStyle = useGradient && gradientFill ? gradientFill : effectiveFgColor;
      ctx.fillRect(x, y, effectiveModuleSize, effectiveModuleSize);
    }
    if (debug) {
      log11.debug("ScaledRender preserved", {
        protectFormat,
        protectVersion,
        formatCount,
        versionCount,
        preservedTiming: shouldPreserveTiming
      });
    }
  }
  drawFrame(ctx, size, effectiveModuleSize, marginModules, config);
  storeMatrixFn(qr, moduleCount);
  return canvas;
}

// src/modules/qr-generator/qr-generator-class.ts
var log12 = createLogger("GENERATE");
var MatrixWrapper = class {
  matrix;
  moduleCount;
  constructor(matrix) {
    this.matrix = matrix;
    this.moduleCount = matrix.length;
  }
  // Required by QRCodeInstance interface but not used for rendering
  addData(_data, _mode) {
  }
  // Required by QRCodeInstance interface but not used for rendering
  make(_maskPattern) {
  }
  getModuleCount() {
    return this.moduleCount;
  }
  isDark(row, col) {
    return this.matrix[row]?.[col] ?? false;
  }
};
var QRGenerator = class {
  qrcode;
  canvasFactory;
  _lastMatrix = null;
  _lastModuleCount = 0;
  /**
   * Create a QR generator instance
   * @param canvasFactory - Optional canvas factory for non-browser environments
   */
  constructor(canvasFactory = null) {
    this.qrcode = qrcode;
    this.canvasFactory = canvasFactory || defaultBrowserCanvasFactory;
  }
  /**
   * Get the QR matrix from the last generate() call
   * Returns a 2D boolean array where true = dark module, false = light module
   */
  getLastMatrix() {
    if (!this._lastMatrix) return null;
    return {
      matrix: this._lastMatrix,
      moduleCount: this._lastModuleCount
    };
  }
  /**
   * Store the QR matrix for vector SVG export
   * Reusable helper to avoid code duplication across render methods
   */
  storeMatrix(qr, moduleCount) {
    const matrix = [];
    for (let row = 0; row < moduleCount; row++) {
      matrix[row] = [];
      for (let col = 0; col < moduleCount; col++) {
        matrix[row][col] = qr.isDark(row, col);
      }
    }
    this._lastMatrix = matrix;
    this._lastModuleCount = moduleCount;
  }
  /**
   * Store a pre-computed matrix directly (without iterating through QRCodeInstance)
   */
  storeMatrixDirect(matrix, moduleCount) {
    this._lastMatrix = matrix;
    this._lastModuleCount = moduleCount;
  }
  /**
   * Create a canvas using the configured factory
   */
  async createCanvas(width, height) {
    return this.canvasFactory.createCanvas(width, height);
  }
  async loadLibrary() {
  }
  /**
   * Build QR matrix with caching
   */
  buildQRMatrix(config, typeNumber, encodingMode, maskPatternConfig, characterEncodingConfig) {
    const qrCacheKey = `${config.content}:${config.errorCorrection}:${typeNumber}:${encodingMode}:${maskPatternConfig}:${characterEncodingConfig}`;
    const cachedQr = qrMatrixCache.get(qrCacheKey);
    if (cachedQr) {
      return { qr: cachedQr.qr, moduleCount: cachedQr.moduleCount };
    }
    const qr = this.qrcode(typeNumber, config.errorCorrection);
    if (characterEncodingConfig === "utf8") {
      setStringToBytes((s) => {
        const encoder = new TextEncoder();
        return Array.from(encoder.encode(s));
      });
    } else if (characterEncodingConfig === "shift-jis") {
      setStringToBytes(createShiftJISEncoder());
    } else {
      resetStringToBytes();
    }
    const modeMap = {
      numeric: "Numeric",
      alphanumeric: "Alphanumeric",
      byte: "Byte",
      kanji: "Kanji",
      auto: void 0
    };
    const libraryMode = modeMap[encodingMode] || void 0;
    qr.addData(config.content, libraryMode);
    const maskPattern = typeof maskPatternConfig === "number" && maskPatternConfig >= 0 && maskPatternConfig <= 7 ? maskPatternConfig : void 0;
    qr.make(maskPattern);
    const moduleCount = qr.getModuleCount();
    resetStringToBytes();
    qrMatrixCache.set(qrCacheKey, { qr, moduleCount });
    return { qr, moduleCount };
  }
  /**
   * Draw finder and alignment patterns
   */
  drawStructuralPatterns(ctx, config, moduleCount, moduleSize, margin, overlayData, version) {
    const drawnFinderPatterns = /* @__PURE__ */ new Set();
    const drawnAlignmentPatterns = /* @__PURE__ */ new Set();
    const shouldDrawFindersFirst = config.preserveFinders !== false || !overlayData;
    const finderPositions = [
      { row: 0, col: 0 },
      { row: 0, col: moduleCount - 7 },
      { row: moduleCount - 7, col: 0 }
    ];
    if (shouldDrawFindersFirst) {
      for (const pos of finderPositions) {
        const x = (pos.col + margin) * moduleSize;
        const y = (pos.row + margin) * moduleSize;
        drawFinderPatternComplete(ctx, x, y, moduleSize, config);
        for (let r = pos.row; r < pos.row + 7; r++) {
          for (let c = pos.col; c < pos.col + 7; c++) {
            drawnFinderPatterns.add(`${r},${c}`);
          }
        }
      }
    }
    const shouldDrawAlignmentFirst = config.preserveAlignment !== false || !overlayData;
    const alignmentStyle = config.alignmentStyle || "match_finder";
    if (version >= 2 && shouldDrawAlignmentFirst) {
      const alignPositions = getAlignmentPositionsCached(version, moduleCount);
      for (const pos of alignPositions) {
        const centerX = (pos.col + margin) * moduleSize + moduleSize / 2;
        const centerY = (pos.row + margin) * moduleSize + moduleSize / 2;
        drawAlignmentPattern(
          ctx,
          centerX,
          centerY,
          moduleSize,
          alignmentStyle,
          config
        );
        for (let r = pos.row - 2; r <= pos.row + 2; r++) {
          for (let c = pos.col - 2; c <= pos.col + 2; c++) {
            drawnAlignmentPatterns.add(`${r},${c}`);
          }
        }
      }
    }
    return { drawnFinderPatterns, drawnAlignmentPatterns };
  }
  async generate(config, overlayCanvas = null) {
    if (!this.qrcode) {
      await this.loadLibrary();
    }
    let encodingMode = config.encodingMode || "auto";
    const content = config.content || "";
    encodingMode = getCompatibleMode(content, encodingMode);
    let typeNumber = config.typeNumber;
    if (typeNumber === 0) {
      typeNumber = calculateOptimalVersion(
        config.content,
        config.errorCorrection
      );
    }
    let processedOverlayCanvas = overlayCanvas;
    if (overlayCanvas && hasGeometricTransforms(config)) {
      processedOverlayCanvas = await applyGeometricTransforms(
        overlayCanvas,
        config,
        this.createCanvas.bind(this)
      );
    }
    const needsPreprocessing = hasPreprocessingOptions(config);
    log12.debug("Preprocessing check", {
      hasOverlay: !!processedOverlayCanvas,
      needsPreprocessing,
      overlayMode: config.overlayMode,
      colorMode: config.colorMode,
      filterGrayscale: config.filterGrayscale,
      filterBrightness: config.filterBrightness,
      filterContrast: config.filterContrast
    });
    if (processedOverlayCanvas && needsPreprocessing) {
      log12.debug("Preprocessing overlay", {
        overlayMode: config.overlayMode,
        colorMode: config.colorMode,
        filterBrightness: config.filterBrightness,
        filterContrast: config.filterContrast,
        filterGamma: config.filterGamma,
        filterSaturation: config.filterSaturation,
        filterHue: config.filterHue,
        filterBlur: config.filterBlur,
        filterSharpen: config.filterSharpen,
        filterPosterize: config.filterPosterize,
        filterThreshold: config.filterThreshold,
        filterEdgeDetect: config.filterEdgeDetect,
        filterInvert: config.filterInvert,
        filterGrayscale: config.filterGrayscale
      });
      processedOverlayCanvas = await preprocessOverlay(
        processedOverlayCanvas,
        config,
        this.createCanvas.bind(this)
      );
      log12.debug("Preprocessing complete", {
        width: processedOverlayCanvas.width,
        height: processedOverlayCanvas.height
      });
    } else if (processedOverlayCanvas) {
      log12.debug("Skipping preprocessing - no filters to apply");
    }
    const maskPatternConfig = typeof config.maskPattern === "number" ? config.maskPattern : void 0;
    const characterEncodingConfig = config.characterEncoding || "default";
    const { qr, moduleCount } = this.buildQRMatrix(
      config,
      typeNumber,
      encodingMode,
      maskPatternConfig,
      characterEncodingConfig
    );
    const vr = verifyQRStructure(qr, typeNumber || void 0);
    if (!vr.ok) {
      log12.warn("QR structural check failed", {
        moduleCount,
        version: vr.version,
        issues: vr.issues
      });
    }
    const effectiveOverlayMode = processedOverlayCanvas && !config.overlayMode ? "dithered" : config.overlayMode;
    const effectiveConfig = {
      ...config,
      typeNumber,
      overlayMode: effectiveOverlayMode
    };
    const scale = getScaleFactor(effectiveOverlayMode, effectiveConfig);
    log12.debug("Overlay mode resolution", {
      hasOverlay: !!processedOverlayCanvas,
      configOverlayMode: config.overlayMode,
      effectiveOverlayMode,
      scale,
      willUseScaledPath: scale > 1 && !!processedOverlayCanvas,
      colorMode: config.colorMode,
      overlayIntensity: config.overlayIntensity
    });
    if (scale > 1 && processedOverlayCanvas) {
      return await generateScaledQR(
        qr,
        effectiveConfig,
        // Use effectiveConfig with corrected overlayMode
        processedOverlayCanvas,
        moduleCount,
        scale,
        this.createCanvas.bind(this),
        this.canvasFactory,
        this.storeMatrix.bind(this)
      );
    }
    let ditherPattern = null;
    let overlayData = null;
    let effectiveIntensity = 0;
    if (effectiveConfig.overlayMode !== "center") {
      const overlayResult = await prepareUnifiedOverlayData(
        qr,
        effectiveConfig,
        processedOverlayCanvas,
        moduleCount,
        this.createCanvas.bind(this)
      );
      ditherPattern = overlayResult.ditherPattern;
      overlayData = overlayResult.overlayData;
      effectiveIntensity = overlayResult.effectiveIntensity;
    }
    const moduleSize = config.moduleSize;
    const quietZoneMin = config.quietZoneMinEnforce === false ? 0 : 4;
    const margin = Math.max(config.margin, quietZoneMin);
    const frameExtra = config.frameStyle && config.frameStyle !== "none" && config.frameText ? moduleSize * 4 : 0;
    const size = moduleCount * moduleSize + margin * 2 * moduleSize + frameExtra;
    const canvas = await this.createCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    const effectiveBgColor = validateColor(config.bgColor, "#ffffff");
    if (!config.transparentBg) {
      ctx.fillStyle = effectiveBgColor;
      ctx.fillRect(0, 0, size, size);
    }
    drawFrameBackground(ctx, size, moduleSize, margin, config);
    const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
    const gradientFill = createGradientFill(ctx, config, size);
    const useGradient = config.gradient && config.gradient.type !== "none";
    const { drawnFinderPatterns, drawnAlignmentPatterns } = this.drawStructuralPatterns(
      ctx,
      config,
      moduleCount,
      moduleSize,
      margin,
      overlayData,
      version
    );
    renderModules(
      ctx,
      qr,
      effectiveConfig,
      // Use effectiveConfig with corrected overlayMode
      moduleCount,
      moduleSize,
      margin,
      overlayData,
      ditherPattern,
      effectiveIntensity,
      drawnFinderPatterns,
      drawnAlignmentPatterns,
      version,
      gradientFill,
      useGradient ?? false
    );
    if (processedOverlayCanvas && config.overlayMode === "center") {
      log12.debug("Drawing center logo", {
        canvasSize: size,
        logoSize: config.logoSize,
        overlayWidth: processedOverlayCanvas.width,
        overlayHeight: processedOverlayCanvas.height,
        colorMode: config.colorMode
      });
      drawCenterLogo(ctx, processedOverlayCanvas, size, config.logoSize);
    }
    drawFrame(ctx, size, moduleSize, margin, config);
    this.storeMatrix(qr, moduleCount);
    return canvas;
  }
  /**
   * Render a pre-computed boolean matrix with full styling.
   * Used by QR-Art to render matrices that were modified via RS basis manipulation.
   *
   * This method bypasses the encoding stage and directly renders the provided matrix
   * using the same styling pipeline as generate() (structural patterns, module styles,
   * gradients, frames, etc.).
   *
   * @param matrix - Pre-computed boolean matrix (true = dark module)
   * @param config - Rendering configuration (same as generate())
   * @returns Rendered canvas with proper styling
   */
  async renderFromMatrix(matrix, config) {
    const moduleCount = matrix.length;
    if (moduleCount === 0) {
      throw new Error("Empty matrix provided to renderFromMatrix");
    }
    const qr = new MatrixWrapper(matrix);
    const version = Math.ceil((moduleCount - 17) / 4);
    const rawMatrixRender = config.rawMatrixRender === true;
    const effectiveConfig = rawMatrixRender ? {
      ...config,
      typeNumber: version,
      overlayMode: void 0,
      moduleStyle: "square",
      moduleGap: 0,
      gapMode: "none",
      cornerRadius: 0,
      finderStyle: "square",
      eyeOuterStyle: "square",
      eyeInnerStyle: "square",
      alignmentStyle: "square",
      timingStyle: "square",
      preserveFinders: true,
      preserveTiming: true,
      preserveAlignment: true,
      gradient: { type: "none" },
      frameStyle: "none",
      frameText: void 0,
      frameColor: void 0,
      frameTextColor: void 0,
      fgColor: "#000000",
      bgColor: "#ffffff",
      transparentBg: false
    } : {
      ...config,
      typeNumber: version,
      // Disable overlay processing - the matrix already represents the final QR
      overlayMode: void 0
    };
    const moduleSize = config.moduleSize || 10;
    const quietZoneMin = config.quietZoneMinEnforce === false ? 0 : 4;
    const margin = Math.max(config.margin || 4, quietZoneMin);
    const frameExtra = config.frameStyle && config.frameStyle !== "none" && config.frameText ? moduleSize * 4 : 0;
    const size = moduleCount * moduleSize + margin * 2 * moduleSize + frameExtra;
    const canvas = await this.createCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    const effectiveBgColor = validateColor(config.bgColor, "#ffffff");
    if (!config.transparentBg) {
      ctx.fillStyle = effectiveBgColor;
      ctx.fillRect(0, 0, size, size);
    }
    drawFrameBackground(ctx, size, moduleSize, margin, effectiveConfig);
    const gradientFill = createGradientFill(ctx, effectiveConfig, size);
    const useGradient = config.gradient && config.gradient.type !== "none";
    const { drawnFinderPatterns, drawnAlignmentPatterns } = this.drawStructuralPatterns(
      ctx,
      effectiveConfig,
      moduleCount,
      moduleSize,
      margin,
      null,
      // No overlay data
      version
    );
    renderModules(
      ctx,
      qr,
      effectiveConfig,
      moduleCount,
      moduleSize,
      margin,
      null,
      // No overlay data
      null,
      // No dither pattern - use qr.isDark() which reads from our matrix
      0,
      // No effective intensity
      drawnFinderPatterns,
      drawnAlignmentPatterns,
      version,
      gradientFill,
      useGradient ?? false
    );
    drawFrame(ctx, size, moduleSize, margin, effectiveConfig);
    this.storeMatrixDirect(matrix, moduleCount);
    log12.debug("renderFromMatrix complete", {
      moduleCount,
      version,
      canvasSize: size,
      moduleSize,
      margin
    });
    return canvas;
  }
};

// src/modules/qr-generator/index.ts
var _log75 = createLogger("GENERATE");

// netlify/functions/qr.ts
Sentry2.init({
  dsn: "https://6935e811c47169e037e31209f2d46fbd@o4510808522489856.ingest.us.sentry.io/4510808547917824",
  sendDefaultPii: true,
  tracesSampleRate: 0.1,
  // 10% of transactions for performance monitoring
  environment: "production"
});
var { GIFEncoder, quantize, applyPalette } = gifenc;
var MAX_SERVER_IMAGE_SIZE = 2048;
var MAX_DATA_LENGTH = 4096;
var MAX_OVERLAY_BYTES = 5 * 1024 * 1024;
var MAX_OVERLAY_PIXELS = 10 * 1024 * 1024;
var MAX_GIF_FRAMES = 60;
var MAX_GIF_DURATION_MS = 1e4;
var FETCH_TIMEOUT_MS = 1e4;
var DEFAULT_SERVER_DITHER = "ordered_bayer";
var DEFAULT_OUTPUT_FORMAT = "gif";
function isPrivateOrReservedIP(ip) {
  if (ip === "localhost" || ip === "127.0.0.1" || ip === "::1") {
    return true;
  }
  const ipv4Match = ip.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (ipv4Match) {
    const [, a, b, c, _d] = ipv4Match.map(Number);
    if (a === 10) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 169 && b === 254) return true;
    if (a === 127) return true;
    if (a === 0) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    if (a === 192 && b === 0 && c === 0) return true;
    if (a === 192 && b === 0 && c === 2) return true;
    if (a === 198 && b === 51 && c === 100) return true;
    if (a === 203 && b === 0 && c === 113) return true;
    if (a >= 224 && a <= 239) return true;
    if (a >= 240) return true;
  }
  if (ip.startsWith("fe80:") || // link-local
  ip.startsWith("fc") || ip.startsWith("fd") || // unique local
  ip === "::1" || ip.startsWith("::ffff:")) {
    return true;
  }
  return false;
}
var nodeCanvasFactory = {
  createCanvas: async (width, height) => {
    return createCanvas(width, height);
  },
  loadImage: async (src) => {
    return loadImage(src);
  }
};
function createTextWatermark(text, fontSize = 14, fontFamily = "sans-serif", color = "#000000") {
  const measureCanvas = createCanvas(1, 1);
  const measureCtx = measureCanvas.getContext("2d");
  measureCtx.font = `${fontSize}px ${fontFamily}`;
  const metrics = measureCtx.measureText(text);
  const textHeight = fontSize * 1.2;
  const canvas = createCanvas(Math.ceil(metrics.width) + 10, Math.ceil(textHeight) + 10);
  const ctx = canvas.getContext("2d");
  ctx.font = `${fontSize}px ${fontFamily}`;
  ctx.fillStyle = color;
  ctx.textBaseline = "middle";
  ctx.fillText(text, 5, canvas.height / 2);
  return canvas;
}
function getWatermarkPositions(position, canvasWidth, canvasHeight, watermarkWidth, watermarkHeight, margin = 10) {
  const positions = [];
  switch (position) {
    case "center":
      positions.push({
        x: (canvasWidth - watermarkWidth) / 2,
        y: (canvasHeight - watermarkHeight) / 2
      });
      break;
    case "corners":
      positions.push(
        { x: margin, y: margin },
        { x: canvasWidth - watermarkWidth - margin, y: margin },
        { x: margin, y: canvasHeight - watermarkHeight - margin },
        { x: canvasWidth - watermarkWidth - margin, y: canvasHeight - watermarkHeight - margin }
      );
      break;
    case "edges":
      positions.push(
        { x: (canvasWidth - watermarkWidth) / 2, y: margin },
        { x: (canvasWidth - watermarkWidth) / 2, y: canvasHeight - watermarkHeight - margin },
        { x: margin, y: (canvasHeight - watermarkHeight) / 2 },
        { x: canvasWidth - watermarkWidth - margin, y: (canvasHeight - watermarkHeight) / 2 }
      );
      break;
    case "quiet_zone":
      positions.push({ x: margin / 2, y: canvasHeight - watermarkHeight - margin / 2 });
      break;
  }
  return positions;
}
function applyBlendMode(ctx, blend) {
  switch (blend) {
    case "multiply":
      ctx.globalCompositeOperation = "multiply";
      break;
    case "screen":
      ctx.globalCompositeOperation = "screen";
      break;
    case "overlay":
      ctx.globalCompositeOperation = "overlay";
      break;
    default:
      ctx.globalCompositeOperation = "source-over";
      break;
  }
}
function applyWatermarkServer(source, options) {
  if (!options.enabled || options.kind === "text" && !options.text) {
    return source;
  }
  const result = createCanvas(source.width, source.height);
  const ctx = result.getContext("2d");
  if (options.position === "behind") {
    drawWatermarkLayerServer(ctx, options, source.width, source.height);
    ctx.drawImage(source, 0, 0);
  } else {
    ctx.drawImage(source, 0, 0);
    drawWatermarkLayerServer(ctx, options, source.width, source.height);
  }
  return result;
}
function drawWatermarkLayerServer(ctx, options, canvasWidth, canvasHeight) {
  let watermarkCanvas = null;
  if (options.kind === "text" && options.text) {
    watermarkCanvas = createTextWatermark(options.text, 14, "sans-serif", "#000000");
  } else if ((options.kind === "image" || options.kind === "pattern") && options.imageCanvas) {
    watermarkCanvas = options.imageCanvas;
  }
  if (!watermarkCanvas) return;
  ctx.save();
  applyBlendMode(ctx, options.blend);
  ctx.globalAlpha = options.opacity / 100;
  const positions = getWatermarkPositions(
    options.position,
    canvasWidth,
    canvasHeight,
    watermarkCanvas.width,
    watermarkCanvas.height,
    10
  );
  for (const pos of positions) {
    ctx.drawImage(watermarkCanvas, pos.x, pos.y);
  }
  ctx.restore();
}
function calculateCrc32(data) {
  let crc = 4294967295;
  const table = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    table[n] = c;
  }
  for (const byte of data) {
    crc = table[(crc ^ byte) & 255] ^ crc >>> 8;
  }
  return (crc ^ 4294967295) >>> 0;
}
function createPngTextChunk(keyword, text) {
  const keywordBytes = new TextEncoder().encode(keyword);
  const textBytes = new TextEncoder().encode(text);
  const chunkData = new Uint8Array(keywordBytes.length + 1 + textBytes.length);
  chunkData.set(keywordBytes, 0);
  chunkData.set([0], keywordBytes.length);
  chunkData.set(textBytes, keywordBytes.length + 1);
  const chunkType = new TextEncoder().encode("tEXt");
  const chunk = new Uint8Array(4 + 4 + chunkData.length + 4);
  const dataView = new DataView(chunk.buffer);
  dataView.setUint32(0, chunkData.length, false);
  chunk.set(chunkType, 4);
  chunk.set(chunkData, 8);
  const crcData = new Uint8Array(4 + chunkData.length);
  crcData.set(chunkType, 0);
  crcData.set(chunkData, 4);
  const crc = calculateCrc32(crcData);
  dataView.setUint32(8 + chunkData.length, crc, false);
  return chunk;
}
function createPngPhysChunk(dpi) {
  const pixelsPerMeter = Math.round(dpi / 0.0254);
  const chunkData = new Uint8Array(9);
  const chunkDataView = new DataView(chunkData.buffer);
  chunkDataView.setUint32(0, pixelsPerMeter, false);
  chunkDataView.setUint32(4, pixelsPerMeter, false);
  chunkData[8] = 1;
  const chunkType = new TextEncoder().encode("pHYs");
  const chunk = new Uint8Array(4 + 4 + 9 + 4);
  const chunkView = new DataView(chunk.buffer);
  chunkView.setUint32(0, 9, false);
  chunk.set(chunkType, 4);
  chunk.set(chunkData, 8);
  const crcData = new Uint8Array(4 + 9);
  crcData.set(chunkType, 0);
  crcData.set(chunkData, 4);
  const crc = calculateCrc32(crcData);
  chunkView.setUint32(17, crc, false);
  return chunk;
}
function embedPngMetadataAndDpi(pngBuffer, metadata, dpi) {
  const data = new Uint8Array(pngBuffer);
  const pngSignature = [137, 80, 78, 71, 13, 10, 26, 10];
  for (let i = 0; i < 8; i++) {
    if (data[i] !== pngSignature[i]) {
      return pngBuffer;
    }
  }
  const chunks = [];
  if (dpi && dpi > 0 && dpi !== 72) {
    chunks.push(createPngPhysChunk(dpi));
  }
  if (metadata) {
    const keywordMap = {
      title: "Title",
      author: "Author",
      description: "Description",
      copyright: "Copyright",
      creationTime: "Creation Time",
      software: "Software"
    };
    for (const [key, value] of Object.entries(metadata)) {
      if (value && typeof value === "string") {
        const keyword = keywordMap[key] || key;
        chunks.push(createPngTextChunk(keyword, value));
      }
    }
  }
  if (chunks.length === 0) {
    return pngBuffer;
  }
  const ihdrEnd = 33;
  const totalChunksSize = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
  const newPng = new Uint8Array(data.length + totalChunksSize);
  newPng.set(data.slice(0, ihdrEnd), 0);
  let offset = ihdrEnd;
  for (const chunk of chunks) {
    newPng.set(chunk, offset);
    offset += chunk.length;
  }
  newPng.set(data.slice(ihdrEnd), offset);
  return Buffer.from(newPng);
}
function encodeGif(canvas, colors = 256, disposal = 2) {
  const width = canvas.width;
  const height = canvas.height;
  const ctx = canvas.getContext("2d");
  const imageData = ctx.getImageData(0, 0, width, height);
  const { data } = imageData;
  const gif = GIFEncoder();
  const palette = quantize(data, Math.min(256, Math.max(2, colors)));
  const index = applyPalette(data, palette);
  gif.writeFrame(index, width, height, {
    palette,
    delay: 100,
    repeat: 0,
    disposal
  });
  gif.finish();
  return Buffer.from(gif.bytes());
}
function encodeAnimatedGif(frames, frameDelayMs = 100, colors = 256, disposal = 2) {
  if (frames.length === 0) {
    throw new Error("No frames to encode");
  }
  const width = frames[0].width;
  const height = frames[0].height;
  const gif = GIFEncoder();
  const paletteSize = Math.min(256, Math.max(2, colors));
  const delayCentiseconds = Math.max(2, Math.round(frameDelayMs / 10));
  for (let i = 0; i < frames.length; i++) {
    const frame = frames[i];
    const ctx = frame.getContext("2d");
    const imageData = ctx.getImageData(0, 0, width, height);
    const { data } = imageData;
    const palette = quantize(data, paletteSize);
    const index = applyPalette(data, palette);
    const frameOptions = {
      palette,
      delay: delayCentiseconds,
      disposal
    };
    if (i === 0) {
      frameOptions.repeat = 0;
    }
    gif.writeFrame(index, width, height, frameOptions);
  }
  gif.finish();
  return Buffer.from(gif.bytes());
}
function generatePatternFramesServer(sourceCanvas, pattern, frameCount = 24, seed = 0, easing = "linear") {
  if (pattern === "none") {
    return [sourceCanvas];
  }
  const frames = [];
  const width = sourceCanvas.width;
  const height = sourceCanvas.height;
  const sourceCtx = sourceCanvas.getContext("2d");
  const sourceData = sourceCtx.getImageData(0, 0, width, height);
  for (let i = 0; i < frameCount; i++) {
    const linearProgress = i / frameCount;
    const progress = applyAnimationEasing(linearProgress, easing);
    const frame = createCanvas(width, height);
    const ctx = frame.getContext("2d");
    const frameData = ctx.createImageData(width, height);
    frameData.data.set(sourceData.data);
    switch (pattern) {
      case "pulse":
        applyAnimationPulse(frameData.data, progress, seed);
        break;
      case "wave":
        applyAnimationWave(frameData.data, progress, width, height, seed);
        break;
      case "scanline":
        applyAnimationScanline(frameData.data, progress, width, height, seed);
        break;
      case "shimmer":
        applyAnimationShimmer(frameData.data, progress, width, height, seed);
        break;
      case "drift":
        applyAnimationDrift(frameData.data, progress, width, height, seed);
        break;
      case "color_cycle":
        applyAnimationColorCycle(frameData.data, progress, seed);
        break;
    }
    ctx.putImageData(frameData, 0, 0);
    frames.push(frame);
  }
  return frames;
}
function cropOverlayServer(source, centerX, centerY, sizeFraction) {
  const minDim = Math.min(source.width, source.height);
  const cropSize = Math.round(minDim * Math.max(0.1, Math.min(1, sizeFraction)));
  let cropX = Math.round(source.width * centerX - cropSize / 2);
  let cropY = Math.round(source.height * centerY - cropSize / 2);
  cropX = Math.max(0, Math.min(source.width - cropSize, cropX));
  cropY = Math.max(0, Math.min(source.height - cropSize, cropY));
  const result = createCanvas(cropSize, cropSize);
  const ctx = result.getContext("2d");
  ctx.drawImage(source, cropX, cropY, cropSize, cropSize, 0, 0, cropSize, cropSize);
  return result;
}
function rgbToGrayServer(r, g, b) {
  return 0.299 * r + 0.587 * g + 0.114 * b;
}
function convolveServer(data, width, height, kernel, divisor) {
  const result = new Uint8ClampedArray(data);
  const kSize = kernel.length;
  const kHalf = Math.floor(kSize / 2);
  const div = divisor ?? (kernel.flat().reduce((a, b) => a + b, 0) || 1);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let r = 0, g = 0, b = 0;
      for (let ky = 0; ky < kSize; ky++) {
        for (let kx = 0; kx < kSize; kx++) {
          const px = Math.max(0, Math.min(width - 1, x + kx - kHalf));
          const py = Math.max(0, Math.min(height - 1, y + ky - kHalf));
          const idx2 = (py * width + px) * 4;
          const weight = kernel[ky][kx];
          r += data[idx2] * weight;
          g += data[idx2 + 1] * weight;
          b += data[idx2 + 2] * weight;
        }
      }
      const idx = (y * width + x) * 4;
      result[idx] = Math.max(0, Math.min(255, Math.round(r / div)));
      result[idx + 1] = Math.max(0, Math.min(255, Math.round(g / div)));
      result[idx + 2] = Math.max(0, Math.min(255, Math.round(b / div)));
    }
  }
  return result;
}
function blurServer(data, width, height, radius) {
  if (radius <= 0) return data;
  const size = 2 * Math.min(radius, 10) + 1;
  const kernel = Array(size).fill(null).map(() => Array(size).fill(1));
  return convolveServer(data, width, height, kernel);
}
function sharpenServer(data, width, height, amount) {
  if (amount <= 0) return data;
  const strength = amount / 100;
  const kernel = [
    [0, -strength, 0],
    [-strength, 1 + 4 * strength, -strength],
    [0, -strength, 0]
  ];
  return convolveServer(data, width, height, kernel, 1);
}
function posterizeServer(data, levels) {
  if (levels <= 1) return data;
  const result = new Uint8ClampedArray(data);
  const step = 255 / (levels - 1);
  for (let i = 0; i < result.length; i += 4) {
    result[i] = Math.round(Math.round(result[i] / step) * step);
    result[i + 1] = Math.round(Math.round(result[i + 1] / step) * step);
    result[i + 2] = Math.round(Math.round(result[i + 2] / step) * step);
  }
  return result;
}
function thresholdServer(data, level) {
  const result = new Uint8ClampedArray(data);
  for (let i = 0; i < result.length; i += 4) {
    const gray = rgbToGrayServer(result[i], result[i + 1], result[i + 2]);
    const value = gray > level ? 255 : 0;
    result[i] = value;
    result[i + 1] = value;
    result[i + 2] = value;
  }
  return result;
}
function sobelEdgeServer(data, width, height) {
  const result = new Uint8ClampedArray(data.length);
  const sobelX = [
    [-1, 0, 1],
    [-2, 0, 2],
    [-1, 0, 1]
  ];
  const sobelY = [
    [-1, -2, -1],
    [0, 0, 0],
    [1, 2, 1]
  ];
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      let gx = 0, gy = 0;
      for (let ky = -1; ky <= 1; ky++) {
        for (let kx = -1; kx <= 1; kx++) {
          const idx2 = ((y + ky) * width + (x + kx)) * 4;
          const gray = rgbToGrayServer(data[idx2], data[idx2 + 1], data[idx2 + 2]);
          gx += gray * sobelX[ky + 1][kx + 1];
          gy += gray * sobelY[ky + 1][kx + 1];
        }
      }
      const magnitude = Math.min(255, Math.sqrt(gx * gx + gy * gy));
      const idx = (y * width + x) * 4;
      result[idx] = magnitude;
      result[idx + 1] = magnitude;
      result[idx + 2] = magnitude;
      result[idx + 3] = data[idx + 3];
    }
  }
  return result;
}
function cannyEdgeServer(data, width, height, lowThreshold = 50, highThreshold = 150) {
  const sobelResult = sobelEdgeServer(data, width, height);
  const result = new Uint8ClampedArray(sobelResult);
  for (let i = 0; i < result.length; i += 4) {
    const magnitude = result[i];
    const value = magnitude > highThreshold ? 255 : magnitude > lowThreshold ? 128 : 0;
    result[i] = value;
    result[i + 1] = value;
    result[i + 2] = value;
  }
  return result;
}
function applyOverlayFiltersServer(source, options) {
  const result = createCanvas(source.width, source.height);
  const resultCtx = result.getContext("2d");
  resultCtx.drawImage(source, 0, 0);
  const imageData = resultCtx.getImageData(0, 0, result.width, result.height);
  const data = imageData.data;
  const brightness2 = (options.brightness ?? 0) / 100;
  const contrast2 = (options.contrast ?? 0) / 100;
  const gamma2 = options.gamma ?? 1;
  const saturation2 = (options.saturation ?? 0) / 100;
  const hue = (options.hue ?? 0) * (Math.PI / 180);
  const invert2 = options.invert ?? false;
  const blurRadius = options.blur ?? 0;
  const sharpenAmount = options.sharpen ?? 0;
  const posterizeLevels = options.posterize ?? 0;
  const thresholdLevel = options.threshold;
  const edgeMode = options.edge ?? "off";
  const contrastFactor = (1 + contrast2) / (1 - contrast2 * 0.5);
  for (let i = 0; i < data.length; i += 4) {
    let r = data[i] / 255;
    let g = data[i + 1] / 255;
    let b = data[i + 2] / 255;
    if (invert2) {
      r = 1 - r;
      g = 1 - g;
      b = 1 - b;
    }
    r += brightness2;
    g += brightness2;
    b += brightness2;
    r = (r - 0.5) * contrastFactor + 0.5;
    g = (g - 0.5) * contrastFactor + 0.5;
    b = (b - 0.5) * contrastFactor + 0.5;
    if (gamma2 !== 1) {
      r = Math.max(0, r) ** (1 / gamma2);
      g = Math.max(0, g) ** (1 / gamma2);
      b = Math.max(0, b) ** (1 / gamma2);
    }
    if (saturation2 !== 0 || hue !== 0) {
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      let h = 0;
      let s = 0;
      const l = (max + min) / 2;
      if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r:
            h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
            break;
          case g:
            h = ((b - r) / d + 2) / 6;
            break;
          case b:
            h = ((r - g) / d + 4) / 6;
            break;
        }
      }
      h += hue / (2 * Math.PI);
      if (h > 1) h -= 1;
      if (h < 0) h += 1;
      s = Math.max(0, Math.min(1, s * (1 + saturation2)));
      if (s === 0) {
        r = g = b = l;
      } else {
        const hue2rgb = (p2, q2, t) => {
          if (t < 0) t += 1;
          if (t > 1) t -= 1;
          if (t < 1 / 6) return p2 + (q2 - p2) * 6 * t;
          if (t < 1 / 2) return q2;
          if (t < 2 / 3) return p2 + (q2 - p2) * (2 / 3 - t) * 6;
          return p2;
        };
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r = hue2rgb(p, q, h + 1 / 3);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1 / 3);
      }
    }
    data[i] = Math.round(Math.max(0, Math.min(1, r)) * 255);
    data[i + 1] = Math.round(Math.max(0, Math.min(1, g)) * 255);
    data[i + 2] = Math.round(Math.max(0, Math.min(1, b)) * 255);
  }
  if (blurRadius > 0) {
    const blurred = blurServer(data, result.width, result.height, blurRadius);
    data.set(blurred);
  }
  if (sharpenAmount > 0) {
    const sharpened = sharpenServer(data, result.width, result.height, sharpenAmount);
    data.set(sharpened);
  }
  if (posterizeLevels > 1) {
    const posterized = posterizeServer(data, posterizeLevels);
    data.set(posterized);
  }
  if (thresholdLevel !== void 0) {
    const thresholded = thresholdServer(data, thresholdLevel);
    data.set(thresholded);
  }
  if (edgeMode === "sobel") {
    const edges = sobelEdgeServer(data, result.width, result.height);
    data.set(edges);
  } else if (edgeMode === "canny") {
    const edges = cannyEdgeServer(data, result.width, result.height);
    data.set(edges);
  }
  resultCtx.putImageData(imageData, 0, 0);
  return result;
}
function flipOverlayServer(source, horizontal, vertical) {
  if (!(horizontal || vertical)) return source;
  const result = createCanvas(source.width, source.height);
  const ctx = result.getContext("2d");
  ctx.translate(horizontal ? source.width : 0, vertical ? source.height : 0);
  ctx.scale(horizontal ? -1 : 1, vertical ? -1 : 1);
  ctx.drawImage(source, 0, 0);
  return result;
}
function rotateOverlayServer(source, degrees) {
  if (degrees === 0) return source;
  const radians = degrees * Math.PI / 180;
  const sin = Math.abs(Math.sin(radians));
  const cos = Math.abs(Math.cos(radians));
  const newWidth = Math.round(source.width * cos + source.height * sin);
  const newHeight = Math.round(source.width * sin + source.height * cos);
  const result = createCanvas(newWidth, newHeight);
  const ctx = result.getContext("2d");
  ctx.translate(newWidth / 2, newHeight / 2);
  ctx.rotate(radians);
  ctx.drawImage(source, -source.width / 2, -source.height / 2);
  return result;
}
function isGifBuffer(buffer) {
  const view = new DataView(buffer);
  if (view.byteLength < 6) return false;
  const sig = String.fromCodePoint(view.getUint8(0), view.getUint8(1), view.getUint8(2));
  return sig === "GIF";
}
function parseGifFramesServer(arrayBuffer) {
  const gif = parseGIF3(arrayBuffer);
  const frames = decompressFrames3(gif, true);
  if (frames.length === 0) {
    throw new Error("No frames found in GIF");
  }
  const framesToProcess = frames.slice(0, MAX_GIF_FRAMES);
  if (frames.length > MAX_GIF_FRAMES) {
  }
  const totalDuration = framesToProcess.reduce((sum, f) => sum + f.delay * 10, 0);
  if (totalDuration > MAX_GIF_DURATION_MS) {
  }
  const { width, height } = gif.lsd;
  const compositeCanvas = createCanvas(width, height);
  const compositeCtx = compositeCanvas.getContext("2d");
  const animationFrames = [];
  for (const frame of framesToProcess) {
    const { dims, patch, disposalType, delay } = frame;
    const imageData = compositeCtx.createImageData(dims.width, dims.height);
    imageData.data.set(new Uint8ClampedArray(patch));
    const patchCanvas = createCanvas(dims.width, dims.height);
    const patchCtx = patchCanvas.getContext("2d");
    patchCtx.putImageData(imageData, 0, 0);
    compositeCtx.drawImage(patchCanvas, dims.left, dims.top);
    const outputCanvas = createCanvas(width, height);
    const outputCtx = outputCanvas.getContext("2d");
    outputCtx.drawImage(compositeCanvas, 0, 0);
    animationFrames.push({
      canvas: outputCanvas,
      delay: delay * 10,
      // GIF delay is in centiseconds, convert to ms
      disposalType
    });
    if (disposalType === 2) {
      compositeCtx.clearRect(dims.left, dims.top, dims.width, dims.height);
    }
  }
  return animationFrames;
}
function decimateFramesToMaxFps(frames, targetFps) {
  if (frames.length <= 1 || targetFps <= 0) {
    return frames;
  }
  const totalDelay = frames.reduce((sum, f) => sum + (f.delay || 100), 0);
  const avgDelay = totalDelay / frames.length;
  const sourceFps = avgDelay > 0 ? 1e3 / avgDelay : 0;
  if (!sourceFps || sourceFps <= targetFps) {
    return frames;
  }
  const ratio = sourceFps / targetFps;
  const keepIndices = [];
  let accumulator = 0;
  for (let i = 0; i < frames.length; i++) {
    accumulator += 1;
    if (accumulator >= ratio) {
      keepIndices.push(i);
      accumulator -= ratio;
    }
  }
  if (keepIndices.length > 0 && keepIndices[0] !== 0) {
    keepIndices.unshift(0);
  }
  if (keepIndices.length > 0 && keepIndices[keepIndices.length - 1] !== frames.length - 1) {
    keepIndices.push(frames.length - 1);
  }
  return keepIndices.map((idx) => frames[idx]).filter(Boolean);
}
function encodeAnimatedGifWithDelays(frames, colors = 256, disposal = 2) {
  if (frames.length === 0) {
    throw new Error("No frames to encode");
  }
  const width = frames[0].canvas.width;
  const height = frames[0].canvas.height;
  const gif = GIFEncoder();
  const paletteSize = Math.min(256, Math.max(2, colors));
  for (let i = 0; i < frames.length; i++) {
    const frame = frames[i];
    const ctx = frame.canvas.getContext("2d");
    const imageData = ctx.getImageData(0, 0, width, height);
    const { data } = imageData;
    const palette = quantize(data, paletteSize);
    const index = applyPalette(data, palette);
    const delayCentiseconds = Math.max(2, Math.round(frame.delay / 10));
    const frameOptions = {
      palette,
      delay: delayCentiseconds,
      disposal
    };
    if (i === 0) {
      frameOptions.repeat = 0;
    }
    gif.writeFrame(index, width, height, frameOptions);
  }
  gif.finish();
  return Buffer.from(gif.bytes());
}
function parseGradientStops(stopsParam) {
  const parts = stopsParam.split(",");
  const stops = [];
  for (let i = 0; i < parts.length - 1; i += 2) {
    const color = `#${parts[i]}`;
    const pos = Number.parseFloat(parts[i + 1]);
    if (!Number.isNaN(pos)) {
      stops.push({ color, pos });
    }
  }
  return stops.length > 0 ? stops : [
    { color: "#000000", pos: 0 },
    { color: "#000000", pos: 1 }
  ];
}
async function fetchImageWithBuffer(url) {
  try {
    let parsedUrl;
    try {
      parsedUrl = new URL(url);
      if (!["http:", "https:"].includes(parsedUrl.protocol)) {
        return null;
      }
      if (isPrivateOrReservedIP(parsedUrl.hostname)) {
        return null;
      }
    } catch {
      return null;
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    const response = await fetch(url, {
      headers: {
        "User-Agent": "ANQR-QR-Generator/1.0"
      },
      signal: controller.signal,
      redirect: "follow"
      // Follows up to 20 redirects by default; MAX_REDIRECTS is for documentation
    });
    clearTimeout(timeoutId);
    if (!response.ok) {
      return null;
    }
    const contentType = response.headers.get("Content-Type") || "";
    const validImageTypes = [
      "image/png",
      "image/jpeg",
      "image/gif",
      "image/webp",
      "image/svg+xml",
      "image/bmp"
    ];
    const isImage = validImageTypes.some((type) => contentType.toLowerCase().startsWith(type));
    if (!isImage && contentType && !contentType.startsWith("application/octet-stream")) {
      return null;
    }
    const reader = response.body?.getReader();
    if (!reader) {
      return null;
    }
    const chunks = [];
    let totalBytes = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        totalBytes += value.byteLength;
        if (totalBytes > MAX_OVERLAY_BYTES) {
          reader.cancel();
          return null;
        }
        chunks.push(value);
      }
    } catch (_streamError) {
      return null;
    }
    const arrayBuffer = new Uint8Array(totalBytes);
    let offset = 0;
    for (const chunk of chunks) {
      arrayBuffer.set(chunk, offset);
      offset += chunk.byteLength;
    }
    const buffer = Buffer.from(arrayBuffer);
    let isAnimatedGif = false;
    if (isGifBuffer(arrayBuffer)) {
      try {
        const gif = parseGIF3(arrayBuffer);
        const frames = decompressFrames3(gif, true);
        isAnimatedGif = frames.length > 1;
      } catch (_e) {
      }
    }
    const img = await loadImage(buffer);
    if (!(img.width && img.height) || img.width <= 0 || img.height <= 0) {
      return null;
    }
    const pixelCount = img.width * img.height;
    if (pixelCount > MAX_OVERLAY_PIXELS) {
      return null;
    }
    const canvas = createCanvas(img.width, img.height);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);
    return {
      canvas,
      arrayBuffer,
      isAnimatedGif
    };
  } catch (_error) {
    return null;
  }
}
async function fetchImageAsCanvas(url) {
  const result = await fetchImageWithBuffer(url);
  return result?.canvas ?? null;
}
async function handler(request) {
  const url = new URL(request.url);
  const params = url.searchParams;
  const data = params.get("data");
  if (!data) {
    return new Response('Missing required "data" parameter', {
      status: 400,
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  }
  if (data.length > MAX_DATA_LENGTH) {
    return new Response(`Data too long: ${data.length} characters (max: ${MAX_DATA_LENGTH})`, {
      status: 400,
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  }
  const lang = params.get("lang") || void 0;
  void lang;
  const sizeParam = Number.parseInt(params.get("size") || "400", 10);
  const modulePxParam = params.get("modulePx") ? Number.parseInt(params.get("modulePx"), 10) : null;
  const widthParam = params.get("w") ? Number.parseInt(params.get("w"), 10) : null;
  const heightParam = params.get("h") ? Number.parseInt(params.get("h"), 10) : null;
  const outputWidth = Math.min(MAX_SERVER_IMAGE_SIZE, Math.max(50, widthParam ?? sizeParam));
  const outputHeight = Math.min(MAX_SERVER_IMAGE_SIZE, Math.max(50, heightParam ?? sizeParam));
  const size = Math.max(outputWidth, outputHeight);
  const fg = params.get("fg") || "000000";
  const bg = params.get("bg") || "ffffff";
  const ec = params.get("ec")?.toUpperCase() || "H";
  const margin = Math.min(20, Math.max(0, Number.parseInt(params.get("margin") || "4", 10)));
  const transparent = params.get("transparent") === "1";
  const encodingMode = params.get("enc") || "auto";
  const version = params.get("v") ? Number.parseInt(params.get("v"), 10) : 0;
  const maskPatternParam = params.get("mask");
  const parsedMask = maskPatternParam ? Number.parseInt(maskPatternParam, 10) : NaN;
  const maskPattern = maskPatternParam === "auto" || !maskPatternParam || Number.isNaN(parsedMask) ? "auto" : Math.min(7, Math.max(0, parsedMask));
  const charsetParam = params.get("charset") || "default";
  const characterEncoding = ["default", "utf8", "shift-jis"].includes(charsetParam) ? charsetParam : "default";
  const borderModulesExtra = Math.min(
    10,
    Math.max(0, Number.parseInt(params.get("border") || "0", 10))
  );
  const quietZoneMinEnforce = params.has("qzEnforce") ? params.get("qzEnforce") !== "0" : void 0;
  const crispEdges = params.get("crisp") !== "0";
  const pixelSnap = params.get("snap") || "floor";
  const perModuleColorMode = params.get("modColor") || "solid";
  const contrastGuard = params.get("cGuard") === "1";
  const minContrastRatio = Number.parseFloat(params.get("minContrast") || "4.5");
  const renderSeed = params.get("seed") ? Number.parseInt(params.get("seed") || "0", 10) : void 0;
  const moduleStyle = params.get("style") || "square";
  const finderStyle = params.get("finder") || "square";
  const eyeOuterStyle = params.get("eyeOuter") || finderStyle;
  const eyeInnerStyle = params.get("eyeInner") || finderStyle;
  const eyeScale = Math.min(
    150,
    Math.max(50, Number.parseInt(params.get("eyeScale") || "100", 10))
  );
  const cornerRadius = Math.min(100, Math.max(0, Number.parseInt(params.get("radius") || "0", 10)));
  const moduleGap = Math.min(50, Math.max(0, Number.parseInt(params.get("gap") || "0", 10)));
  const gapMode = params.get("gapMode") || "none";
  const dotRotationDeg = Number.parseInt(params.get("dotRot") || "0", 10);
  const frameStyle = params.get("frame") || "none";
  const frameText = params.get("frameText") || "";
  const gradientType = params.get("grad") || "none";
  const gradientAngle = Number.parseInt(params.get("gradAngle") || "0", 10);
  const gradientStopsParam = params.get("gradStops");
  const gradientStops = gradientStopsParam ? parseGradientStops(gradientStopsParam) : void 0;
  const alignmentStyle = params.get("align") || "match_finder";
  const timingStyle = params.get("timing") || "match_module";
  const preserveFinders = params.get("keepFinders") !== "0";
  const preserveTiming = params.get("keepTiming") === "1";
  const preserveAlignment = params.get("keepAlign") === "1";
  const protectFormatInfo = params.get("protectFmt") === "1";
  const protectVersionInfo = params.get("protectVer") === "1";
  const eccAwareEnabled = params.get("eccAware") === "1";
  const eccAwareRiskBudget = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("eccRisk") || "50", 10))
  );
  const eccAwareWeightMap = params.get("eccMap") || "distance_to_finders";
  const overlayUrl = params.get("img");
  const legacySubpixel = params.get("subpixel") === "1";
  const overlayMode = params.get("mode") || (legacySubpixel ? "subpixel" : overlayUrl ? "dithered" : void 0);
  const overlayIntensity = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("intensity") || "100", 10))
  );
  const colorMode = params.get("colorMode") || "color";
  const logoSize = Math.min(50, Math.max(5, Number.parseInt(params.get("logoSize") || "25", 10)));
  const overlayBrightness = Math.min(
    100,
    Math.max(-100, Number.parseInt(params.get("brightness") || "0", 10))
  );
  const overlayContrast = Math.min(
    100,
    Math.max(-100, Number.parseInt(params.get("contrast") || "0", 10))
  );
  const overlayGamma = Math.max(0.1, Math.min(3, Number.parseFloat(params.get("gamma") || "1")));
  const overlaySaturation = Math.min(
    100,
    Math.max(-100, Number.parseInt(params.get("saturation") || "0", 10))
  );
  const overlayHueRotate = Number.parseInt(params.get("hue") || "0", 10);
  const overlayInvert = params.get("invert") === "1";
  const overlayBlur = Math.max(0, Number.parseInt(params.get("blur") || "0", 10));
  const overlaySharpen = Math.max(0, Number.parseInt(params.get("sharpen") || "0", 10));
  const overlayPosterize = Math.max(0, Number.parseInt(params.get("posterize") || "0", 10));
  const overlayThresholdParam = params.get("threshold");
  const overlayThreshold = overlayThresholdParam ? Math.min(255, Math.max(0, Number.parseInt(overlayThresholdParam, 10))) : void 0;
  const overlayEdgeDetect = params.get("edge") || "off";
  const overlayFit = params.get("fit") || "cover";
  const overlayRotate = Number.parseInt(params.get("rot") || "0", 10);
  const overlayFlipX = params.get("flipX") === "1";
  const overlayFlipY = params.get("flipY") === "1";
  const ditherKindParam = params.get("ditherKind");
  const ditherKind = ditherKindParam || DEFAULT_SERVER_DITHER;
  const diffusionKernel = params.get("diffusionKernel") || "floyd_steinberg";
  const ditherStrength = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("ditherStrength") || "50", 10))
  );
  const ditherSerpentine = params.get("serpentine") === "1";
  const orderedMatrix = params.get("matrix") || "bayer4";
  const blueNoiseTileSize = Number.parseInt(params.get("bnTile") || "64", 10);
  const blueNoiseSeed = Number.parseInt(params.get("bnSeed") || "0", 10);
  const colorDither = params.get("colorDither") || "none";
  const subpixelGridSize = params.get("spGrid") || "3x3";
  const subpixelGridNum = params.get("spGridNum") ? Number.parseInt(params.get("spGridNum") || "3", 10) : void 0;
  const subpixelCenterRule = params.get("spCenter") || "strict";
  const subpixelNeutralColor = params.get("spNeutral") ? `#${params.get("spNeutral")}` : "#808080";
  const subpixelFinderOverride = params.get("spFinder") || "solid";
  const halftoneCell = params.get("htCell") || "per_module";
  const halftoneDotShape = params.get("htDot") || "circle";
  const brightnessCurve = params.get("htCurve") || "linear";
  const duotoneColor1 = params.get("duo1") ? `#${params.get("duo1")}` : "#000000";
  const duotoneColor2 = params.get("duo2") ? `#${params.get("duo2")}` : "#ffffff";
  const paletteParam = params.get("palette");
  const palette = paletteParam ? paletteParam.split(",").map((c) => c.startsWith("#") ? c : `#${c}`) : void 0;
  const maxOverlayIntensityL = Number.parseInt(
    params.get("maxIntL") || params.get("maxOverlayIntensityL") || "100",
    10
  );
  const maxOverlayIntensityM = Number.parseInt(
    params.get("maxIntM") || params.get("maxOverlayIntensityM") || "100",
    10
  );
  const maxOverlayIntensityQ = Number.parseInt(
    params.get("maxIntQ") || params.get("maxOverlayIntensityQ") || "100",
    10
  );
  const maxOverlayIntensityH = Number.parseInt(
    params.get("maxIntH") || params.get("maxOverlayIntensityH") || "100",
    10
  );
  let outputFormat = params.get("format") || DEFAULT_OUTPUT_FORMAT;
  const outputQuality = Math.max(0, Math.min(1, Number.parseFloat(params.get("quality") || "0.9")));
  const outputDpi = Math.max(1, Math.min(1200, Number.parseInt(params.get("dpi") || "72", 10)));
  const watermarkEnabled = params.get("wmEn") === "1";
  const watermarkKind = params.get("wmKind") || "text";
  const watermarkText = params.get("wmText") || "";
  const watermarkImageUrl = params.get("wmImg") || void 0;
  const watermarkPosition = params.get("wmPos") || "center";
  const watermarkOpacity = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("wmOpacity") || "50", 10))
  );
  const watermarkBlend = params.get("wmBlend") || "normal";
  const animationPattern = params.get("animPattern") || "none";
  const animationLoop = params.get("loop") !== "0";
  const animationBounce = params.get("bounce") === "1";
  const animationReverse = params.get("reverse") === "1";
  const animationColorCycle = params.get("colorCycle") === "1";
  const animationInterpolate = params.get("interp") || "none";
  const animationTemporalDither = params.get("tempDither") || "off";
  const animationStartFrame = Number.parseInt(params.get("startF") || "0", 10);
  const animationMaxFrames = Number.parseInt(params.get("maxF") || "0", 10);
  const animationFrameStep = Number.parseInt(params.get("stepF") || "1", 10);
  const animationModuleJitter = Number.parseFloat(params.get("jitter") || "0");
  const animationFramesRaw = Number.parseInt(params.get("animFrames") || "24", 10);
  const animationFrames = Math.min(
    60,
    Math.max(1, Number.isNaN(animationFramesRaw) ? 24 : animationFramesRaw)
  );
  const animationSpeedRaw = Number.parseInt(
    params.get("animSpeed") || params.get("speed") || "100",
    10
  );
  const animationSpeed = Math.min(
    1e3,
    Math.max(10, Number.isNaN(animationSpeedRaw) ? 100 : animationSpeedRaw)
  );
  const animationSeed = Number.parseInt(params.get("animSeed") || "0", 10);
  const animationEasing = params.get("easing") || "linear";
  const webpQuality = Math.min(100, Math.max(0, Number.parseInt(params.get("webpQ") || "90", 10)));
  const _jpegQuality = Math.min(100, Math.max(0, Number.parseInt(params.get("jpegQ") || "92", 10)));
  const gifPaletteSize = params.get("gifPal");
  const gifColors = Math.min(
    256,
    Math.max(2, Number.parseInt(params.get("gifColors") || gifPaletteSize || "256", 10))
  );
  const gifQuantizer = params.get("gifQuant") || void 0;
  const gifDither = params.get("gifDith") || void 0;
  const gifTransparentColor = params.get("gifTrans") ? `#${params.get("gifTrans")}` : void 0;
  void gifQuantizer;
  void gifDither;
  void gifTransparentColor;
  const metaTitle = params.get("metaTitle") || void 0;
  const metaAuthor = params.get("metaAuthor") || void 0;
  const metaCopyright = params.get("metaCopy") || void 0;
  const metaDescription = params.get("metaDesc") || void 0;
  const metaLicense = params.get("metaLic") || void 0;
  const metaCreationTime = params.get("metaTime") === "1";
  const metaCustomKv = params.get("metaKv") || void 0;
  const cropEnabled = params.get("cropEn") === "1";
  const cropX = Number.parseFloat(params.get("cropX") || "0.5");
  const cropY = Number.parseFloat(params.get("cropY") || "0.5");
  const cropSize = Number.parseFloat(params.get("cropSize") || "1");
  const overlayType = params.get("ovType") || "static";
  const overlayFramePick = params.get("ovFramePick") || "all";
  const gifUseFrameDelays = params.get("gifDelays") !== "0";
  const gifDisposalHandling = params.get("gifDispH") || "respect";
  const gifMaxFps = Number.parseInt(params.get("gifMaxFps") || "0", 10);
  const lockFinders = params.get("lockF") !== "0";
  const lockTiming = params.get("lockT") !== "0";
  const lockAlign = params.get("lockA") !== "0";
  const lockFormat = params.get("lockFmt") !== "0";
  const lockVersion = params.get("lockV") !== "0";
  const safetyMode = params.get("safeMode") || "off";
  const safetyMinModulePx = Number.parseInt(params.get("safeMinPx") || "2", 10);
  const safetyMinQuietZone = Number.parseInt(params.get("safeMinQz") || "4", 10);
  const autoPickVersion = params.get("autoVer") !== "0";
  const autoPickEcc = params.get("autoEcc") === "1";
  const autoReduceIntensity = params.get("autoReduce") === "1";
  const qaContrastCheckClientOnly = params.get("qaContrast") === "1";
  const qaSimulateBlurClientOnly = Number.parseFloat(params.get("qaBlur") || "0");
  const qaSimulateNoiseClientOnly = Number.parseInt(params.get("qaNoise") || "0", 10);
  const qaSimulateRotationClientOnly = Number.parseInt(params.get("qaRot") || "0", 10);
  const qaShowHeatmapClientOnly = params.get("qaHeatmap") === "1";
  if (qaContrastCheckClientOnly || qaSimulateBlurClientOnly || qaSimulateNoiseClientOnly || qaSimulateRotationClientOnly || qaShowHeatmapClientOnly) {
  }
  const bgOverride = params.get("bgOver") ? `#${params.get("bgOver")}` : void 0;
  const formatExtra = params.get("fmtExtra") || "none";
  const filename = params.get("fname") || "anqr-qrcode";
  const includeQuietZone = params.get("inclQz") !== "0";
  const gifDisposal = params.get("gifDisp") || "restore_bg";
  const gifDisposalCode = gifDisposal === "none" ? 0 : gifDisposal === "keep" ? 1 : gifDisposal === "restore_previous" ? 3 : 2;
  const svgTrueVector = params.get("svgVec") === "1";
  const svgShapePrecision = params.get("svgPrec") || "pixel";
  const svgEmbedRasterOverlay = params.get("svgEmbed") !== "0";
  void svgTrueVector;
  const paletteMode = params.get("paletteMode") || "position";
  if (!["L", "M", "Q", "H"].includes(ec)) {
    return new Response('Invalid "ec" parameter. Use L, M, Q, or H', {
      status: 400,
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  }
  const validModuleStyles = ["square", "rounded", "dots", "diamond", "connected"];
  if (!validModuleStyles.includes(moduleStyle)) {
    return new Response(`Invalid "style" parameter. Use one of: ${validModuleStyles.join(", ")}`, {
      status: 400,
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  }
  try {
    const qrGenerator = new QRGenerator(nodeCanvasFactory);
    const estimatedVersion = calculateOptimalVersion(data, ec);
    const estimatedModuleCount = estimatedVersion * 4 + 17;
    const totalMargin = margin + borderModulesExtra;
    const moduleSize = modulePxParam ? Math.max(1, Math.min(50, modulePxParam)) : Math.max(
      1,
      Math.floor((size - totalMargin * 2) / (estimatedModuleCount + totalMargin * 2))
    );
    const config = {
      content: data,
      typeNumber: version,
      // 0 = auto-detect
      errorCorrection: ec,
      encodingMode,
      maskPattern,
      characterEncoding,
      seed: renderSeed,
      moduleSize,
      margin: margin + borderModulesExtra,
      quietZoneMinEnforce,
      crispEdges,
      pixelSnap,
      fgColor: `#${fg}`,
      bgColor: `#${bg}`,
      transparentBg: transparent,
      moduleStyle,
      finderStyle,
      alignmentStyle,
      timingStyle,
      eyeOuterStyle,
      eyeInnerStyle,
      eyeScale,
      cornerRadius,
      moduleGap,
      gapMode,
      dotRotationDeg,
      frameStyle,
      frameText,
      perModuleColorMode,
      contrastGuard,
      minContrastRatio,
      overlayMode,
      overlayIntensity,
      colorMode,
      logoSize,
      preserveFinders,
      preserveTiming,
      preserveAlignment,
      protectFormatInfo,
      protectVersionInfo,
      eccAwareEnabled,
      eccAwareRiskBudget,
      eccAwareWeightMap,
      overlayBrightness,
      overlayContrast,
      overlayGamma,
      overlaySaturation,
      overlayHueRotate,
      invertImage: overlayInvert,
      overlayBlur,
      overlaySharpen,
      overlayPosterize,
      overlayThreshold,
      overlayEdgeDetect,
      overlayFit,
      overlayRotate,
      overlayFlipX,
      overlayFlipY,
      // Dither options
      ditherKind,
      diffusionKernel,
      ditherStrength,
      ditherSerpentine,
      orderedMatrix,
      blueNoiseTileSize,
      blueNoiseSeed,
      colorDither,
      // Subpixel options
      subpixelGridSize,
      subpixelGrid: subpixelGridNum,
      subpixelCenterRule,
      subpixelNeutralColor,
      subpixelFinderOverride,
      // Halftone options
      halftoneCell,
      halftoneDotShape,
      brightnessCurve,
      duotoneColors: [duotoneColor1, duotoneColor2],
      // Palette
      palette,
      gradient: gradientType === "none" ? void 0 : {
        type: gradientType,
        angle: gradientAngle,
        stops: gradientStops
      },
      // Per-ECC intensity limits
      maxOverlayIntensityByEcc: {
        L: maxOverlayIntensityL,
        M: maxOverlayIntensityM,
        Q: maxOverlayIntensityQ,
        H: maxOverlayIntensityH
      },
      // Animation settings (pattern-based animation is supported server-side)
      animationPattern,
      animationFrames,
      animationSpeed,
      animationSeed,
      animationLoop,
      animationBounce,
      animationReverse,
      animationInterpolate,
      animationTemporalDither,
      animationStartFrame,
      animationMaxFrames,
      animationFrameStep,
      moduleJitterPx: animationModuleJitter,
      // Limited server-side support
      colorCycle: animationColorCycle,
      // Supported via color cycle pattern
      // Crop settings
      cropEnabled,
      cropX,
      cropY,
      cropSize,
      // Overlay type
      overlayType,
      overlayFramePick,
      // GIF overlay
      gifUseFrameDelays,
      gifDisposalHandling,
      // Safety locks
      lockFinders,
      lockTiming,
      lockAlign,
      lockFormat,
      lockVersion,
      safetyMode,
      safetyMinModulePx,
      safetyMinQuietZone,
      // Auto-tuning hints
      autoPickVersion,
      autoPickEcc,
      autoReduceIntensity,
      // Output extras
      bgOverride,
      formatExtra,
      filename,
      includeQuietZone,
      svgShapePrecision,
      svgEmbedRasterOverlay,
      // Palette
      paletteMode
    };
    let overlayCanvas = null;
    let overlayFrames = [];
    let hasAnimatedOverlay = false;
    if (overlayUrl && overlayMode) {
      const fetchedImage = await fetchImageWithBuffer(overlayUrl);
      if (fetchedImage) {
        const hasFilters = overlayBrightness !== 0 || overlayContrast !== 0 || overlayGamma !== 1 || overlaySaturation !== 0 || overlayHueRotate !== 0 || overlayInvert || overlayBlur > 0 || overlaySharpen > 0 || overlayPosterize > 1 || overlayEdgeDetect !== "off";
        const filterOptions = {
          brightness: overlayBrightness,
          contrast: overlayContrast,
          gamma: overlayGamma,
          saturation: overlaySaturation,
          hue: overlayHueRotate,
          invert: overlayInvert,
          blur: overlayBlur,
          sharpen: overlaySharpen,
          posterize: overlayPosterize,
          threshold: overlayThreshold,
          // Only applied if explicitly specified via URL param
          edge: overlayEdgeDetect
        };
        const preprocessCanvas = (canvas2) => {
          let processed = canvas2;
          if (cropEnabled && cropSize < 1) {
            processed = cropOverlayServer(processed, cropX, cropY, cropSize);
          }
          if (overlayRotate !== 0) {
            processed = rotateOverlayServer(processed, overlayRotate);
          }
          if (overlayFlipX || overlayFlipY) {
            processed = flipOverlayServer(processed, overlayFlipX, overlayFlipY);
          }
          if (hasFilters) {
            processed = applyOverlayFiltersServer(processed, filterOptions);
          }
          return processed;
        };
        if (fetchedImage.isAnimatedGif) {
          outputFormat = "gif";
          hasAnimatedOverlay = true;
          const rawFrames = parseGifFramesServer(fetchedImage.arrayBuffer);
          overlayFrames = rawFrames.map((frame) => ({
            ...frame,
            canvas: preprocessCanvas(frame.canvas)
          }));
          if (gifMaxFps > 0 && overlayFrames.length > 1 && !Number.isNaN(gifMaxFps)) {
            overlayFrames = decimateFramesToMaxFps(overlayFrames, gifMaxFps);
          }
          overlayCanvas = overlayFrames[0]?.canvas ?? preprocessCanvas(fetchedImage.canvas);
        } else {
          overlayCanvas = preprocessCanvas(fetchedImage.canvas);
        }
      }
    }
    let canvas = await qrGenerator.generate(config, overlayCanvas);
    let watermarkImageCanvas = null;
    if (watermarkEnabled && (watermarkKind === "image" || watermarkKind === "pattern") && watermarkImageUrl) {
      watermarkImageCanvas = await fetchImageAsCanvas(watermarkImageUrl);
    }
    if (watermarkEnabled) {
      canvas = applyWatermarkServer(canvas, {
        enabled: watermarkEnabled,
        kind: watermarkKind,
        text: watermarkText,
        imageCanvas: watermarkImageCanvas,
        position: watermarkPosition,
        opacity: watermarkOpacity,
        blend: watermarkBlend
      });
    }
    let outputCanvas = canvas;
    if (canvas.width !== outputWidth || canvas.height !== outputHeight) {
      outputCanvas = createCanvas(outputWidth, outputHeight);
      const ctx = outputCanvas.getContext("2d");
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(canvas, 0, 0, outputWidth, outputHeight);
    }
    const metadata = metaTitle || metaAuthor || metaCopyright || metaDescription || metaLicense || metaCreationTime || metaCustomKv ? {
      title: metaTitle,
      author: metaAuthor,
      copyright: metaCopyright,
      description: metaDescription,
      creationTime: metaCreationTime ? (/* @__PURE__ */ new Date()).toISOString() : void 0,
      software: "ANQR - anqr.link",
      // Custom key-value pairs are stored in description if provided
      // Format: key1=value1;key2=value2
      ...metaCustomKv && !metaDescription ? { description: metaCustomKv } : {}
    } : void 0;
    let animationFrameCanvases = [];
    const animatedOverlayFrames = [];
    if (outputFormat === "gif") {
      if (hasAnimatedOverlay && overlayFrames.length > 1) {
        for (const overlayFrame of overlayFrames) {
          const frameCanvas = await qrGenerator.generate(config, overlayFrame.canvas);
          let scaledFrame = frameCanvas;
          if (frameCanvas.width !== outputWidth || frameCanvas.height !== outputHeight) {
            scaledFrame = createCanvas(outputWidth, outputHeight);
            const ctx = scaledFrame.getContext("2d");
            ctx.imageSmoothingEnabled = false;
            ctx.drawImage(frameCanvas, 0, 0, outputWidth, outputHeight);
          }
          if (watermarkEnabled) {
            scaledFrame = applyWatermarkServer(scaledFrame, {
              enabled: watermarkEnabled,
              kind: watermarkKind,
              text: watermarkText,
              imageCanvas: watermarkImageCanvas,
              position: watermarkPosition,
              opacity: watermarkOpacity,
              blend: watermarkBlend
            });
          }
          animatedOverlayFrames.push({
            canvas: scaledFrame,
            delay: overlayFrame.delay,
            disposalType: overlayFrame.disposalType
          });
        }
      } else if (animationPattern !== "none") {
        animationFrameCanvases = generatePatternFramesServer(
          outputCanvas,
          animationPattern,
          animationFrames,
          animationSeed,
          animationEasing
        );
      }
    }
    let outputBuffer;
    let contentType;
    switch (outputFormat) {
      case "gif":
        if (animatedOverlayFrames.length > 1) {
          outputBuffer = encodeAnimatedGifWithDelays(
            animatedOverlayFrames,
            gifColors,
            gifDisposalCode
          );
        } else if (animationFrameCanvases.length > 1) {
          outputBuffer = encodeAnimatedGif(
            animationFrameCanvases,
            animationSpeed,
            gifColors,
            gifDisposalCode
          );
        } else {
          outputBuffer = encodeGif(outputCanvas, gifColors, gifDisposalCode);
        }
        contentType = "image/gif";
        break;
      case "webp": {
        const finalWebpQuality = webpQuality !== 90 ? webpQuality : Math.round(outputQuality * 100);
        outputBuffer = outputCanvas.toBuffer("image/webp", finalWebpQuality);
        contentType = "image/webp";
        break;
      }
      default:
        outputBuffer = outputCanvas.toBuffer("image/png");
        if (metadata || outputDpi !== 72) {
          outputBuffer = embedPngMetadataAndDpi(outputBuffer, metadata, outputDpi);
        }
        contentType = "image/png";
        break;
    }
    const etag = `"${createHash("md5").update(outputBuffer).digest("hex")}"`;
    return new Response(new Uint8Array(outputBuffer), {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "public, max-age=31536000, immutable",
        ETag: etag,
        Vary: "Accept-Encoding",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    Sentry2.captureException(error);
    return new Response(`Error generating QR code: ${message}`, {
      status: 500,
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  }
}
var qr_default = handler;
export {
  qr_default as default
};
