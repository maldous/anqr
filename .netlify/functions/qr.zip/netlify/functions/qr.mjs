
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/qr.ts
import { createCanvas, loadImage } from "@napi-rs/canvas";
import gifenc from "gifenc";
import { decompressFrames, parseGIF } from "gifuct-js";

// src/modules/qrcode.mjs
var qrcode = (typeNumber, errorCorrectionLevel) => {
  const PAD0 = 236;
  const PAD1 = 17;
  let _typeNumber = typeNumber;
  const _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
  let _modules = null;
  let _moduleCount = 0;
  let _dataCache = null;
  const _dataList = [];
  const _this = {};
  const makeImpl = (test, maskPattern) => {
    _moduleCount = _typeNumber * 4 + 17;
    _modules = ((moduleCount2) => {
      const modules = new Array(moduleCount2);
      for (let row2 = 0; row2 < moduleCount2; row2 += 1) {
        modules[row2] = new Array(moduleCount2);
        for (let col2 = 0; col2 < moduleCount2; col2 += 1) {
          modules[row2][col2] = null;
        }
      }
      return modules;
    })(_moduleCount);
    setupPositionProbePattern(0, 0);
    setupPositionProbePattern(_moduleCount - 7, 0);
    setupPositionProbePattern(0, _moduleCount - 7);
    setupPositionAdjustPattern();
    setupTimingPattern();
    setupTypeInfo(test, maskPattern);
    if (_typeNumber >= 7) {
      setupTypeNumber(test);
    }
    if (_dataCache == null) {
      _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
    }
    mapData(_dataCache, maskPattern);
  };
  const setupPositionProbePattern = (row2, col2) => {
    for (let r = -1; r <= 7; r += 1) {
      if (row2 + r <= -1 || _moduleCount <= row2 + r) continue;
      for (let c = -1; c <= 7; c += 1) {
        if (col2 + c <= -1 || _moduleCount <= col2 + c) continue;
        if (0 <= r && r <= 6 && (c === 0 || c === 6) || 0 <= c && c <= 6 && (r === 0 || r === 6) || 2 <= r && r <= 4 && 2 <= c && c <= 4) {
          _modules[row2 + r][col2 + c] = true;
        } else {
          _modules[row2 + r][col2 + c] = false;
        }
      }
    }
  };
  const getBestMaskPattern = () => {
    let minLostPoint = 0;
    let pattern = 0;
    for (let i2 = 0; i2 < 8; i2 += 1) {
      makeImpl(true, i2);
      const lostPoint = QRUtil.getLostPoint(_this);
      if (i2 === 0 || minLostPoint > lostPoint) {
        minLostPoint = lostPoint;
        pattern = i2;
      }
    }
    return pattern;
  };
  const setupTimingPattern = () => {
    for (let r = 8; r < _moduleCount - 8; r += 1) {
      if (_modules[r][6] != null) {
        continue;
      }
      _modules[r][6] = r % 2 === 0;
    }
    for (let c = 8; c < _moduleCount - 8; c += 1) {
      if (_modules[6][c] != null) {
        continue;
      }
      _modules[6][c] = c % 2 === 0;
    }
  };
  const setupPositionAdjustPattern = () => {
    const pos = QRUtil.getPatternPosition(_typeNumber);
    for (let i2 = 0; i2 < pos.length; i2 += 1) {
      for (let j = 0; j < pos.length; j += 1) {
        const row2 = pos[i2];
        const col2 = pos[j];
        if (_modules[row2][col2] != null) {
          continue;
        }
        for (let r = -2; r <= 2; r += 1) {
          for (let c = -2; c <= 2; c += 1) {
            if (r === -2 || r === 2 || c === -2 || c === 2 || r === 0 && c === 0) {
              _modules[row2 + r][col2 + c] = true;
            } else {
              _modules[row2 + r][col2 + c] = false;
            }
          }
        }
      }
    }
  };
  const setupTypeNumber = (test) => {
    const bits = QRUtil.getBCHTypeNumber(_typeNumber);
    for (let i2 = 0; i2 < 18; i2 += 1) {
      const mod = !test && (bits >> i2 & 1) === 1;
      _modules[Math.floor(i2 / 3)][i2 % 3 + _moduleCount - 8 - 3] = mod;
    }
    for (let i2 = 0; i2 < 18; i2 += 1) {
      const mod = !test && (bits >> i2 & 1) === 1;
      _modules[i2 % 3 + _moduleCount - 8 - 3][Math.floor(i2 / 3)] = mod;
    }
  };
  const setupTypeInfo = (test, maskPattern) => {
    const data = _errorCorrectionLevel << 3 | maskPattern;
    const bits = QRUtil.getBCHTypeInfo(data);
    for (let i2 = 0; i2 < 15; i2 += 1) {
      const mod = !test && (bits >> i2 & 1) === 1;
      if (i2 < 6) {
        _modules[i2][8] = mod;
      } else if (i2 < 8) {
        _modules[i2 + 1][8] = mod;
      } else {
        _modules[_moduleCount - 15 + i2][8] = mod;
      }
    }
    for (let i2 = 0; i2 < 15; i2 += 1) {
      const mod = !test && (bits >> i2 & 1) === 1;
      if (i2 < 8) {
        _modules[8][_moduleCount - i2 - 1] = mod;
      } else if (i2 < 9) {
        _modules[8][15 - i2 - 1 + 1] = mod;
      } else {
        _modules[8][15 - i2 - 1] = mod;
      }
    }
    _modules[_moduleCount - 8][8] = !test;
  };
  const mapData = (data, maskPattern) => {
    let inc = -1;
    let row2 = _moduleCount - 1;
    let bitIndex = 7;
    let byteIndex = 0;
    const maskFunc = QRUtil.getMaskFunction(maskPattern);
    for (let col2 = _moduleCount - 1; col2 > 0; col2 -= 2) {
      if (col2 === 6) col2 -= 1;
      while (true) {
        for (let c = 0; c < 2; c += 1) {
          if (_modules[row2][col2 - c] == null) {
            let dark = false;
            if (byteIndex < data.length) {
              dark = (data[byteIndex] >>> bitIndex & 1) === 1;
            }
            const mask = maskFunc(row2, col2 - c);
            if (mask) {
              dark = !dark;
            }
            _modules[row2][col2 - c] = dark;
            bitIndex -= 1;
            if (bitIndex === -1) {
              byteIndex += 1;
              bitIndex = 7;
            }
          }
        }
        row2 += inc;
        if (row2 < 0 || _moduleCount <= row2) {
          row2 -= inc;
          inc = -inc;
          break;
        }
      }
    }
  };
  const createBytes = (buffer, rsBlocks) => {
    let offset = 0;
    let maxDcCount = 0;
    let maxEcCount = 0;
    const dcdata = new Array(rsBlocks.length);
    const ecdata = new Array(rsBlocks.length);
    for (let r = 0; r < rsBlocks.length; r += 1) {
      const dcCount = rsBlocks[r].dataCount;
      const ecCount = rsBlocks[r].totalCount - dcCount;
      maxDcCount = Math.max(maxDcCount, dcCount);
      maxEcCount = Math.max(maxEcCount, ecCount);
      dcdata[r] = new Array(dcCount);
      for (let i2 = 0; i2 < dcdata[r].length; i2 += 1) {
        dcdata[r][i2] = 255 & buffer.getBuffer()[i2 + offset];
      }
      offset += dcCount;
      const rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
      const rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);
      const modPoly = rawPoly.mod(rsPoly);
      ecdata[r] = new Array(rsPoly.getLength() - 1);
      for (let i2 = 0; i2 < ecdata[r].length; i2 += 1) {
        const modIndex = i2 + modPoly.getLength() - ecdata[r].length;
        ecdata[r][i2] = modIndex >= 0 ? modPoly.getAt(modIndex) : 0;
      }
    }
    let totalCodeCount = 0;
    for (let i2 = 0; i2 < rsBlocks.length; i2 += 1) {
      totalCodeCount += rsBlocks[i2].totalCount;
    }
    const data = new Array(totalCodeCount);
    let index = 0;
    for (let i2 = 0; i2 < maxDcCount; i2 += 1) {
      for (let r = 0; r < rsBlocks.length; r += 1) {
        if (i2 < dcdata[r].length) {
          data[index] = dcdata[r][i2];
          index += 1;
        }
      }
    }
    for (let i2 = 0; i2 < maxEcCount; i2 += 1) {
      for (let r = 0; r < rsBlocks.length; r += 1) {
        if (i2 < ecdata[r].length) {
          data[index] = ecdata[r][i2];
          index += 1;
        }
      }
    }
    return data;
  };
  const createData = (typeNumber2, errorCorrectionLevel2, dataList) => {
    const rsBlocks = QRRSBlock.getRSBlocks(typeNumber2, errorCorrectionLevel2);
    const buffer = qrBitBuffer();
    for (let i2 = 0; i2 < dataList.length; i2 += 1) {
      const data = dataList[i2];
      buffer.put(data.getMode(), 4);
      buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber2));
      data.write(buffer);
    }
    let totalDataCount = 0;
    for (let i2 = 0; i2 < rsBlocks.length; i2 += 1) {
      totalDataCount += rsBlocks[i2].dataCount;
    }
    if (buffer.getLengthInBits() > totalDataCount * 8) {
      throw `code length overflow. (${buffer.getLengthInBits()}>${totalDataCount * 8})`;
    }
    if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
      buffer.put(0, 4);
    }
    while (buffer.getLengthInBits() % 8 !== 0) {
      buffer.putBit(false);
    }
    while (true) {
      if (buffer.getLengthInBits() >= totalDataCount * 8) {
        break;
      }
      buffer.put(PAD0, 8);
      if (buffer.getLengthInBits() >= totalDataCount * 8) {
        break;
      }
      buffer.put(PAD1, 8);
    }
    return createBytes(buffer, rsBlocks);
  };
  _this.addData = (data, mode) => {
    mode = mode || "Byte";
    let newData = null;
    switch (mode) {
      case "Numeric":
        newData = qrNumber(data);
        break;
      case "Alphanumeric":
        newData = qrAlphaNum(data);
        break;
      case "Byte":
        newData = qr8BitByte(data);
        break;
      case "Kanji":
        newData = qrKanji(data);
        break;
      default:
        throw `mode:${mode}`;
    }
    _dataList.push(newData);
    _dataCache = null;
  };
  _this.isDark = (row2, col2) => {
    if (row2 < 0 || _moduleCount <= row2 || col2 < 0 || _moduleCount <= col2) {
      throw `${row2},${col2}`;
    }
    return _modules[row2][col2];
  };
  _this.getModuleCount = () => _moduleCount;
  _this.make = (maskPattern) => {
    if (_typeNumber < 1) {
      let typeNumber2 = 1;
      for (; typeNumber2 < 40; typeNumber2++) {
        const rsBlocks = QRRSBlock.getRSBlocks(typeNumber2, _errorCorrectionLevel);
        const buffer = qrBitBuffer();
        for (let i2 = 0; i2 < _dataList.length; i2++) {
          const data = _dataList[i2];
          buffer.put(data.getMode(), 4);
          buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber2));
          data.write(buffer);
        }
        let totalDataCount = 0;
        for (let i2 = 0; i2 < rsBlocks.length; i2++) {
          totalDataCount += rsBlocks[i2].dataCount;
        }
        if (buffer.getLengthInBits() <= totalDataCount * 8) {
          break;
        }
      }
      _typeNumber = typeNumber2;
    }
    const finalMaskPattern = typeof maskPattern === "number" && maskPattern >= 0 && maskPattern <= 7 ? maskPattern : getBestMaskPattern();
    makeImpl(false, finalMaskPattern);
  };
  _this.createTableTag = (cellSize, margin) => {
    cellSize = cellSize || 2;
    margin = typeof margin === "undefined" ? cellSize * 4 : margin;
    let qrHtml = "";
    qrHtml += '<table style="';
    qrHtml += " border-width: 0px; border-style: none;";
    qrHtml += " border-collapse: collapse;";
    qrHtml += ` padding: 0px; margin: ${margin}px;`;
    qrHtml += '">';
    qrHtml += "<tbody>";
    for (let r = 0; r < _this.getModuleCount(); r += 1) {
      qrHtml += "<tr>";
      for (let c = 0; c < _this.getModuleCount(); c += 1) {
        qrHtml += '<td style="';
        qrHtml += " border-width: 0px; border-style: none;";
        qrHtml += " border-collapse: collapse;";
        qrHtml += " padding: 0px; margin: 0px;";
        qrHtml += ` width: ${cellSize}px;`;
        qrHtml += ` height: ${cellSize}px;`;
        qrHtml += " background-color: ";
        qrHtml += _this.isDark(r, c) ? "#000000" : "#ffffff";
        qrHtml += ";";
        qrHtml += '"/>';
      }
      qrHtml += "</tr>";
    }
    qrHtml += "</tbody>";
    qrHtml += "</table>";
    return qrHtml;
  };
  _this.createSvgTag = function(cellSize, margin, alt, title) {
    let opts = {};
    if (typeof arguments[0] === "object") {
      opts = arguments[0];
      cellSize = opts.cellSize;
      margin = opts.margin;
      alt = opts.alt;
      title = opts.title;
    }
    cellSize = cellSize || 2;
    margin = typeof margin === "undefined" ? cellSize * 4 : margin;
    alt = typeof alt === "string" ? { text: alt } : alt || {};
    alt.text = alt.text || null;
    alt.id = alt.text ? alt.id || "qrcode-description" : null;
    title = typeof title === "string" ? { text: title } : title || {};
    title.text = title.text || null;
    title.id = title.text ? title.id || "qrcode-title" : null;
    const size = _this.getModuleCount() * cellSize + margin * 2;
    let c, mc, r, mr, qrSvg = "", rect;
    rect = `l${cellSize},0 0,${cellSize} -${cellSize},0 0,-${cellSize}z `;
    qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
    qrSvg += !opts.scalable ? ` width="${size}px" height="${size}px"` : "";
    qrSvg += ` viewBox="0 0 ${size} ${size}" `;
    qrSvg += ' preserveAspectRatio="xMinYMin meet"';
    qrSvg += title.text || alt.text ? ` role="img" aria-labelledby="${escapeXml([title.id, alt.id].join(" ").trim())}"` : "";
    qrSvg += ">";
    qrSvg += title.text ? `<title id="${escapeXml(title.id)}">${escapeXml(title.text)}</title>` : "";
    qrSvg += alt.text ? `<description id="${escapeXml(alt.id)}">${escapeXml(alt.text)}</description>` : "";
    qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
    qrSvg += '<path d="';
    for (r = 0; r < _this.getModuleCount(); r += 1) {
      mr = r * cellSize + margin;
      for (c = 0; c < _this.getModuleCount(); c += 1) {
        if (_this.isDark(r, c)) {
          mc = c * cellSize + margin;
          qrSvg += `M${mc},${mr}${rect}`;
        }
      }
    }
    qrSvg += '" stroke="transparent" fill="black"/>';
    qrSvg += "</svg>";
    return qrSvg;
  };
  _this.createDataURL = (cellSize, margin) => {
    cellSize = cellSize || 2;
    margin = typeof margin === "undefined" ? cellSize * 4 : margin;
    const size = _this.getModuleCount() * cellSize + margin * 2;
    const min = margin;
    const max = size - margin;
    return createDataURL(size, size, (x, y) => {
      if (min <= x && x < max && min <= y && y < max) {
        const c = Math.floor((x - min) / cellSize);
        const r = Math.floor((y - min) / cellSize);
        return _this.isDark(r, c) ? 0 : 1;
      } else {
        return 1;
      }
    });
  };
  _this.createImgTag = (cellSize, margin, alt) => {
    cellSize = cellSize || 2;
    margin = typeof margin === "undefined" ? cellSize * 4 : margin;
    const size = _this.getModuleCount() * cellSize + margin * 2;
    let img = "";
    img += "<img";
    img += ' src="';
    img += _this.createDataURL(cellSize, margin);
    img += '"';
    img += ' width="';
    img += size;
    img += '"';
    img += ' height="';
    img += size;
    img += '"';
    if (alt) {
      img += ' alt="';
      img += escapeXml(alt);
      img += '"';
    }
    img += "/>";
    return img;
  };
  const escapeXml = (s) => {
    let escaped = "";
    for (let i2 = 0; i2 < s.length; i2 += 1) {
      const c = s.charAt(i2);
      switch (c) {
        case "<":
          escaped += "&lt;";
          break;
        case ">":
          escaped += "&gt;";
          break;
        case "&":
          escaped += "&amp;";
          break;
        case '"':
          escaped += "&quot;";
          break;
        default:
          escaped += c;
          break;
      }
    }
    return escaped;
  };
  const _createHalfASCII = (margin) => {
    const cellSize = 1;
    margin = typeof margin === "undefined" ? cellSize * 2 : margin;
    const size = _this.getModuleCount() * cellSize + margin * 2;
    const min = margin;
    const max = size - margin;
    let y, x, r1, r2, p;
    const blocks = {
      "\u2588\u2588": "\u2588",
      "\u2588 ": "\u2580",
      " \u2588": "\u2584",
      "  ": " "
    };
    const blocksLastLineNoMargin = {
      "\u2588\u2588": "\u2580",
      "\u2588 ": "\u2580",
      " \u2588": " ",
      "  ": " "
    };
    let ascii = "";
    for (y = 0; y < size; y += 2) {
      r1 = Math.floor((y - min) / cellSize);
      r2 = Math.floor((y + 1 - min) / cellSize);
      for (x = 0; x < size; x += 1) {
        p = "\u2588";
        if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
          p = " ";
        }
        if (min <= x && x < max && min <= y + 1 && y + 1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
          p += " ";
        } else {
          p += "\u2588";
        }
        ascii += margin < 1 && y + 1 >= max ? blocksLastLineNoMargin[p] : blocks[p];
      }
      ascii += "\n";
    }
    if (size % 2 && margin > 0) {
      return ascii.substring(0, ascii.length - size - 1) + Array(size + 1).join("\u2580");
    }
    return ascii.substring(0, ascii.length - 1);
  };
  _this.createASCII = (cellSize, margin) => {
    cellSize = cellSize || 1;
    if (cellSize < 2) {
      return _createHalfASCII(margin);
    }
    cellSize -= 1;
    margin = typeof margin === "undefined" ? cellSize * 2 : margin;
    const size = _this.getModuleCount() * cellSize + margin * 2;
    const min = margin;
    const max = size - margin;
    let y, x, r, p;
    const white = Array(cellSize + 1).join("\u2588\u2588");
    const black = Array(cellSize + 1).join("  ");
    let ascii = "";
    let line = "";
    for (y = 0; y < size; y += 1) {
      r = Math.floor((y - min) / cellSize);
      line = "";
      for (x = 0; x < size; x += 1) {
        p = 1;
        if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
          p = 0;
        }
        line += p ? white : black;
      }
      for (r = 0; r < cellSize; r += 1) {
        ascii += `${line}
`;
      }
    }
    return ascii.substring(0, ascii.length - 1);
  };
  _this.renderTo2dContext = (context, cellSize) => {
    cellSize = cellSize || 2;
    const length = _this.getModuleCount();
    for (let row2 = 0; row2 < length; row2++) {
      for (let col2 = 0; col2 < length; col2++) {
        context.fillStyle = _this.isDark(row2, col2) ? "black" : "white";
        context.fillRect(col2 * cellSize, row2 * cellSize, cellSize, cellSize);
      }
    }
  };
  return _this;
};
qrcode.stringToBytes = (s) => {
  const bytes = [];
  for (let i2 = 0; i2 < s.length; i2 += 1) {
    const c = s.charCodeAt(i2);
    bytes.push(c & 255);
  }
  return bytes;
};
qrcode.createStringToBytes = (unicodeData, numChars) => {
  const unicodeMap = (() => {
    const bin = base64DecodeInputStream(unicodeData);
    const read = () => {
      const b = bin.read();
      if (b === -1) throw "eof";
      return b;
    };
    let count = 0;
    const unicodeMap2 = {};
    while (true) {
      const b0 = bin.read();
      if (b0 === -1) break;
      const b1 = read();
      const b2 = read();
      const b3 = read();
      const k = String.fromCharCode(b0 << 8 | b1);
      const v = b2 << 8 | b3;
      unicodeMap2[k] = v;
      count += 1;
    }
    if (count !== numChars) {
      throw `${count} != ${numChars}`;
    }
    return unicodeMap2;
  })();
  const unknownChar = "?".charCodeAt(0);
  return (s) => {
    const bytes = [];
    for (let i2 = 0; i2 < s.length; i2 += 1) {
      const c = s.charCodeAt(i2);
      if (c < 128) {
        bytes.push(c);
      } else {
        const b = unicodeMap[s.charAt(i2)];
        if (typeof b === "number") {
          if ((b & 255) === b) {
            bytes.push(b);
          } else {
            bytes.push(b >>> 8);
            bytes.push(b & 255);
          }
        } else {
          bytes.push(unknownChar);
        }
      }
    }
    return bytes;
  };
};
var QRMode = {
  MODE_NUMBER: 1 << 0,
  MODE_ALPHA_NUM: 1 << 1,
  MODE_8BIT_BYTE: 1 << 2,
  MODE_KANJI: 1 << 3
};
var QRErrorCorrectionLevel = {
  L: 1,
  M: 0,
  Q: 3,
  H: 2
};
var QRMaskPattern = {
  PATTERN000: 0,
  PATTERN001: 1,
  PATTERN010: 2,
  PATTERN011: 3,
  PATTERN100: 4,
  PATTERN101: 5,
  PATTERN110: 6,
  PATTERN111: 7
};
var QRUtil = (() => {
  const PATTERN_POSITION_TABLE = [
    [],
    [6, 18],
    [6, 22],
    [6, 26],
    [6, 30],
    [6, 34],
    [6, 22, 38],
    [6, 24, 42],
    [6, 26, 46],
    [6, 28, 50],
    [6, 30, 54],
    [6, 32, 58],
    [6, 34, 62],
    [6, 26, 46, 66],
    [6, 26, 48, 70],
    [6, 26, 50, 74],
    [6, 30, 54, 78],
    [6, 30, 56, 82],
    [6, 30, 58, 86],
    [6, 34, 62, 90],
    [6, 28, 50, 72, 94],
    [6, 26, 50, 74, 98],
    [6, 30, 54, 78, 102],
    [6, 28, 54, 80, 106],
    [6, 32, 58, 84, 110],
    [6, 30, 58, 86, 114],
    [6, 34, 62, 90, 118],
    [6, 26, 50, 74, 98, 122],
    [6, 30, 54, 78, 102, 126],
    [6, 26, 52, 78, 104, 130],
    [6, 30, 56, 82, 108, 134],
    [6, 34, 60, 86, 112, 138],
    [6, 30, 58, 86, 114, 142],
    [6, 34, 62, 90, 118, 146],
    [6, 30, 54, 78, 102, 126, 150],
    [6, 24, 50, 76, 102, 128, 154],
    [6, 28, 54, 80, 106, 132, 158],
    [6, 32, 58, 84, 110, 136, 162],
    [6, 26, 54, 82, 110, 138, 166],
    [6, 30, 58, 86, 114, 142, 170]
  ];
  const G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0;
  const G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0;
  const G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1;
  const _this = {};
  const getBCHDigit = (data) => {
    let digit = 0;
    while (data !== 0) {
      digit += 1;
      data >>>= 1;
    }
    return digit;
  };
  _this.getBCHTypeInfo = (data) => {
    let d = data << 10;
    while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
      d ^= G15 << getBCHDigit(d) - getBCHDigit(G15);
    }
    return (data << 10 | d) ^ G15_MASK;
  };
  _this.getBCHTypeNumber = (data) => {
    let d = data << 12;
    while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
      d ^= G18 << getBCHDigit(d) - getBCHDigit(G18);
    }
    return data << 12 | d;
  };
  _this.getPatternPosition = (typeNumber) => PATTERN_POSITION_TABLE[typeNumber - 1];
  _this.getMaskFunction = (maskPattern) => {
    switch (maskPattern) {
      case QRMaskPattern.PATTERN000:
        return (i2, j) => (i2 + j) % 2 === 0;
      case QRMaskPattern.PATTERN001:
        return (i2, _j) => i2 % 2 === 0;
      case QRMaskPattern.PATTERN010:
        return (_i, j) => j % 3 === 0;
      case QRMaskPattern.PATTERN011:
        return (i2, j) => (i2 + j) % 3 === 0;
      case QRMaskPattern.PATTERN100:
        return (i2, j) => (Math.floor(i2 / 2) + Math.floor(j / 3)) % 2 === 0;
      case QRMaskPattern.PATTERN101:
        return (i2, j) => i2 * j % 2 + i2 * j % 3 === 0;
      case QRMaskPattern.PATTERN110:
        return (i2, j) => (i2 * j % 2 + i2 * j % 3) % 2 === 0;
      case QRMaskPattern.PATTERN111:
        return (i2, j) => (i2 * j % 3 + (i2 + j) % 2) % 2 === 0;
      default:
        throw `bad maskPattern:${maskPattern}`;
    }
  };
  _this.getErrorCorrectPolynomial = (errorCorrectLength) => {
    let a = qrPolynomial([1], 0);
    for (let i2 = 0; i2 < errorCorrectLength; i2 += 1) {
      a = a.multiply(qrPolynomial([1, QRMath.gexp(i2)], 0));
    }
    return a;
  };
  _this.getLengthInBits = (mode, type) => {
    if (1 <= type && type < 10) {
      switch (mode) {
        case QRMode.MODE_NUMBER:
          return 10;
        case QRMode.MODE_ALPHA_NUM:
          return 9;
        case QRMode.MODE_8BIT_BYTE:
          return 8;
        case QRMode.MODE_KANJI:
          return 8;
        default:
          throw `mode:${mode}`;
      }
    } else if (type < 27) {
      switch (mode) {
        case QRMode.MODE_NUMBER:
          return 12;
        case QRMode.MODE_ALPHA_NUM:
          return 11;
        case QRMode.MODE_8BIT_BYTE:
          return 16;
        case QRMode.MODE_KANJI:
          return 10;
        default:
          throw `mode:${mode}`;
      }
    } else if (type < 41) {
      switch (mode) {
        case QRMode.MODE_NUMBER:
          return 14;
        case QRMode.MODE_ALPHA_NUM:
          return 13;
        case QRMode.MODE_8BIT_BYTE:
          return 16;
        case QRMode.MODE_KANJI:
          return 12;
        default:
          throw `mode:${mode}`;
      }
    } else {
      throw `type:${type}`;
    }
  };
  _this.getLostPoint = (qrcode2) => {
    const moduleCount2 = qrcode2.getModuleCount();
    let lostPoint = 0;
    for (let row2 = 0; row2 < moduleCount2; row2 += 1) {
      for (let col2 = 0; col2 < moduleCount2; col2 += 1) {
        let sameCount = 0;
        const dark = qrcode2.isDark(row2, col2);
        for (let r = -1; r <= 1; r += 1) {
          if (row2 + r < 0 || moduleCount2 <= row2 + r) {
            continue;
          }
          for (let c = -1; c <= 1; c += 1) {
            if (col2 + c < 0 || moduleCount2 <= col2 + c) {
              continue;
            }
            if (r === 0 && c === 0) {
              continue;
            }
            if (dark === qrcode2.isDark(row2 + r, col2 + c)) {
              sameCount += 1;
            }
          }
        }
        if (sameCount > 5) {
          lostPoint += 3 + sameCount - 5;
        }
      }
    }
    for (let row2 = 0; row2 < moduleCount2 - 1; row2 += 1) {
      for (let col2 = 0; col2 < moduleCount2 - 1; col2 += 1) {
        let count = 0;
        if (qrcode2.isDark(row2, col2)) count += 1;
        if (qrcode2.isDark(row2 + 1, col2)) count += 1;
        if (qrcode2.isDark(row2, col2 + 1)) count += 1;
        if (qrcode2.isDark(row2 + 1, col2 + 1)) count += 1;
        if (count === 0 || count === 4) {
          lostPoint += 3;
        }
      }
    }
    for (let row2 = 0; row2 < moduleCount2; row2 += 1) {
      for (let col2 = 0; col2 < moduleCount2 - 6; col2 += 1) {
        if (qrcode2.isDark(row2, col2) && !qrcode2.isDark(row2, col2 + 1) && qrcode2.isDark(row2, col2 + 2) && qrcode2.isDark(row2, col2 + 3) && qrcode2.isDark(row2, col2 + 4) && !qrcode2.isDark(row2, col2 + 5) && qrcode2.isDark(row2, col2 + 6)) {
          lostPoint += 40;
        }
      }
    }
    for (let col2 = 0; col2 < moduleCount2; col2 += 1) {
      for (let row2 = 0; row2 < moduleCount2 - 6; row2 += 1) {
        if (qrcode2.isDark(row2, col2) && !qrcode2.isDark(row2 + 1, col2) && qrcode2.isDark(row2 + 2, col2) && qrcode2.isDark(row2 + 3, col2) && qrcode2.isDark(row2 + 4, col2) && !qrcode2.isDark(row2 + 5, col2) && qrcode2.isDark(row2 + 6, col2)) {
          lostPoint += 40;
        }
      }
    }
    let darkCount = 0;
    for (let col2 = 0; col2 < moduleCount2; col2 += 1) {
      for (let row2 = 0; row2 < moduleCount2; row2 += 1) {
        if (qrcode2.isDark(row2, col2)) {
          darkCount += 1;
        }
      }
    }
    const ratio = Math.abs(100 * darkCount / moduleCount2 / moduleCount2 - 50) / 5;
    lostPoint += ratio * 10;
    return lostPoint;
  };
  return _this;
})();
var QRMath = (() => {
  const EXP_TABLE = new Array(256);
  const LOG_TABLE = new Array(256);
  for (let i2 = 0; i2 < 8; i2 += 1) {
    EXP_TABLE[i2] = 1 << i2;
  }
  for (let i2 = 8; i2 < 256; i2 += 1) {
    EXP_TABLE[i2] = EXP_TABLE[i2 - 4] ^ EXP_TABLE[i2 - 5] ^ EXP_TABLE[i2 - 6] ^ EXP_TABLE[i2 - 8];
  }
  for (let i2 = 0; i2 < 255; i2 += 1) {
    LOG_TABLE[EXP_TABLE[i2]] = i2;
  }
  const _this = {};
  _this.glog = (n) => {
    if (n < 1) {
      throw `glog(${n})`;
    }
    return LOG_TABLE[n];
  };
  _this.gexp = (n) => {
    while (n < 0) {
      n += 255;
    }
    while (n >= 256) {
      n -= 255;
    }
    return EXP_TABLE[n];
  };
  return _this;
})();
var qrPolynomial = (num, shift) => {
  if (typeof num.length === "undefined") {
    throw `${num.length}/${shift}`;
  }
  const _num = (() => {
    let offset = 0;
    while (offset < num.length && num[offset] === 0) {
      offset += 1;
    }
    const _num2 = new Array(num.length - offset + shift);
    for (let i2 = 0; i2 < num.length - offset; i2 += 1) {
      _num2[i2] = num[i2 + offset];
    }
    return _num2;
  })();
  const _this = {};
  _this.getAt = (index) => _num[index];
  _this.getLength = () => _num.length;
  _this.multiply = (e) => {
    const num2 = new Array(_this.getLength() + e.getLength() - 1);
    for (let i2 = 0; i2 < _this.getLength(); i2 += 1) {
      for (let j = 0; j < e.getLength(); j += 1) {
        num2[i2 + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i2)) + QRMath.glog(e.getAt(j)));
      }
    }
    return qrPolynomial(num2, 0);
  };
  _this.mod = (e) => {
    if (_this.getLength() - e.getLength() < 0) {
      return _this;
    }
    const ratio = QRMath.glog(_this.getAt(0)) - QRMath.glog(e.getAt(0));
    const num2 = new Array(_this.getLength());
    for (let i2 = 0; i2 < _this.getLength(); i2 += 1) {
      num2[i2] = _this.getAt(i2);
    }
    for (let i2 = 0; i2 < e.getLength(); i2 += 1) {
      num2[i2] ^= QRMath.gexp(QRMath.glog(e.getAt(i2)) + ratio);
    }
    return qrPolynomial(num2, 0).mod(e);
  };
  return _this;
};
var QRRSBlock = (() => {
  const RS_BLOCK_TABLE = [
    // L
    // M
    // Q
    // H
    // 1
    [1, 26, 19],
    [1, 26, 16],
    [1, 26, 13],
    [1, 26, 9],
    // 2
    [1, 44, 34],
    [1, 44, 28],
    [1, 44, 22],
    [1, 44, 16],
    // 3
    [1, 70, 55],
    [1, 70, 44],
    [2, 35, 17],
    [2, 35, 13],
    // 4
    [1, 100, 80],
    [2, 50, 32],
    [2, 50, 24],
    [4, 25, 9],
    // 5
    [1, 134, 108],
    [2, 67, 43],
    [2, 33, 15, 2, 34, 16],
    [2, 33, 11, 2, 34, 12],
    // 6
    [2, 86, 68],
    [4, 43, 27],
    [4, 43, 19],
    [4, 43, 15],
    // 7
    [2, 98, 78],
    [4, 49, 31],
    [2, 32, 14, 4, 33, 15],
    [4, 39, 13, 1, 40, 14],
    // 8
    [2, 121, 97],
    [2, 60, 38, 2, 61, 39],
    [4, 40, 18, 2, 41, 19],
    [4, 40, 14, 2, 41, 15],
    // 9
    [2, 146, 116],
    [3, 58, 36, 2, 59, 37],
    [4, 36, 16, 4, 37, 17],
    [4, 36, 12, 4, 37, 13],
    // 10
    [2, 86, 68, 2, 87, 69],
    [4, 69, 43, 1, 70, 44],
    [6, 43, 19, 2, 44, 20],
    [6, 43, 15, 2, 44, 16],
    // 11
    [4, 101, 81],
    [1, 80, 50, 4, 81, 51],
    [4, 50, 22, 4, 51, 23],
    [3, 36, 12, 8, 37, 13],
    // 12
    [2, 116, 92, 2, 117, 93],
    [6, 58, 36, 2, 59, 37],
    [4, 46, 20, 6, 47, 21],
    [7, 42, 14, 4, 43, 15],
    // 13
    [4, 133, 107],
    [8, 59, 37, 1, 60, 38],
    [8, 44, 20, 4, 45, 21],
    [12, 33, 11, 4, 34, 12],
    // 14
    [3, 145, 115, 1, 146, 116],
    [4, 64, 40, 5, 65, 41],
    [11, 36, 16, 5, 37, 17],
    [11, 36, 12, 5, 37, 13],
    // 15
    [5, 109, 87, 1, 110, 88],
    [5, 65, 41, 5, 66, 42],
    [5, 54, 24, 7, 55, 25],
    [11, 36, 12, 7, 37, 13],
    // 16
    [5, 122, 98, 1, 123, 99],
    [7, 73, 45, 3, 74, 46],
    [15, 43, 19, 2, 44, 20],
    [3, 45, 15, 13, 46, 16],
    // 17
    [1, 135, 107, 5, 136, 108],
    [10, 74, 46, 1, 75, 47],
    [1, 50, 22, 15, 51, 23],
    [2, 42, 14, 17, 43, 15],
    // 18
    [5, 150, 120, 1, 151, 121],
    [9, 69, 43, 4, 70, 44],
    [17, 50, 22, 1, 51, 23],
    [2, 42, 14, 19, 43, 15],
    // 19
    [3, 141, 113, 4, 142, 114],
    [3, 70, 44, 11, 71, 45],
    [17, 47, 21, 4, 48, 22],
    [9, 39, 13, 16, 40, 14],
    // 20
    [3, 135, 107, 5, 136, 108],
    [3, 67, 41, 13, 68, 42],
    [15, 54, 24, 5, 55, 25],
    [15, 43, 15, 10, 44, 16],
    // 21
    [4, 144, 116, 4, 145, 117],
    [17, 68, 42],
    [17, 50, 22, 6, 51, 23],
    [19, 46, 16, 6, 47, 17],
    // 22
    [2, 139, 111, 7, 140, 112],
    [17, 74, 46],
    [7, 54, 24, 16, 55, 25],
    [34, 37, 13],
    // 23
    [4, 151, 121, 5, 152, 122],
    [4, 75, 47, 14, 76, 48],
    [11, 54, 24, 14, 55, 25],
    [16, 45, 15, 14, 46, 16],
    // 24
    [6, 147, 117, 4, 148, 118],
    [6, 73, 45, 14, 74, 46],
    [11, 54, 24, 16, 55, 25],
    [30, 46, 16, 2, 47, 17],
    // 25
    [8, 132, 106, 4, 133, 107],
    [8, 75, 47, 13, 76, 48],
    [7, 54, 24, 22, 55, 25],
    [22, 45, 15, 13, 46, 16],
    // 26
    [10, 142, 114, 2, 143, 115],
    [19, 74, 46, 4, 75, 47],
    [28, 50, 22, 6, 51, 23],
    [33, 46, 16, 4, 47, 17],
    // 27
    [8, 152, 122, 4, 153, 123],
    [22, 73, 45, 3, 74, 46],
    [8, 53, 23, 26, 54, 24],
    [12, 45, 15, 28, 46, 16],
    // 28
    [3, 147, 117, 10, 148, 118],
    [3, 73, 45, 23, 74, 46],
    [4, 54, 24, 31, 55, 25],
    [11, 45, 15, 31, 46, 16],
    // 29
    [7, 146, 116, 7, 147, 117],
    [21, 73, 45, 7, 74, 46],
    [1, 53, 23, 37, 54, 24],
    [19, 45, 15, 26, 46, 16],
    // 30
    [5, 145, 115, 10, 146, 116],
    [19, 75, 47, 10, 76, 48],
    [15, 54, 24, 25, 55, 25],
    [23, 45, 15, 25, 46, 16],
    // 31
    [13, 145, 115, 3, 146, 116],
    [2, 74, 46, 29, 75, 47],
    [42, 54, 24, 1, 55, 25],
    [23, 45, 15, 28, 46, 16],
    // 32
    [17, 145, 115],
    [10, 74, 46, 23, 75, 47],
    [10, 54, 24, 35, 55, 25],
    [19, 45, 15, 35, 46, 16],
    // 33
    [17, 145, 115, 1, 146, 116],
    [14, 74, 46, 21, 75, 47],
    [29, 54, 24, 19, 55, 25],
    [11, 45, 15, 46, 46, 16],
    // 34
    [13, 145, 115, 6, 146, 116],
    [14, 74, 46, 23, 75, 47],
    [44, 54, 24, 7, 55, 25],
    [59, 46, 16, 1, 47, 17],
    // 35
    [12, 151, 121, 7, 152, 122],
    [12, 75, 47, 26, 76, 48],
    [39, 54, 24, 14, 55, 25],
    [22, 45, 15, 41, 46, 16],
    // 36
    [6, 151, 121, 14, 152, 122],
    [6, 75, 47, 34, 76, 48],
    [46, 54, 24, 10, 55, 25],
    [2, 45, 15, 64, 46, 16],
    // 37
    [17, 152, 122, 4, 153, 123],
    [29, 74, 46, 14, 75, 47],
    [49, 54, 24, 10, 55, 25],
    [24, 45, 15, 46, 46, 16],
    // 38
    [4, 152, 122, 18, 153, 123],
    [13, 74, 46, 32, 75, 47],
    [48, 54, 24, 14, 55, 25],
    [42, 45, 15, 32, 46, 16],
    // 39
    [20, 147, 117, 4, 148, 118],
    [40, 75, 47, 7, 76, 48],
    [43, 54, 24, 22, 55, 25],
    [10, 45, 15, 67, 46, 16],
    // 40
    [19, 148, 118, 6, 149, 119],
    [18, 75, 47, 31, 76, 48],
    [34, 54, 24, 34, 55, 25],
    [20, 45, 15, 61, 46, 16]
  ];
  const qrRSBlock = (totalCount, dataCount) => {
    const _this2 = {};
    _this2.totalCount = totalCount;
    _this2.dataCount = dataCount;
    return _this2;
  };
  const _this = {};
  const getRsBlockTable = (typeNumber, errorCorrectionLevel) => {
    switch (errorCorrectionLevel) {
      case QRErrorCorrectionLevel.L:
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
      case QRErrorCorrectionLevel.M:
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
      case QRErrorCorrectionLevel.Q:
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
      case QRErrorCorrectionLevel.H:
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
      default:
        return void 0;
    }
  };
  _this.getRSBlocks = (typeNumber, errorCorrectionLevel) => {
    const rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);
    if (typeof rsBlock === "undefined") {
      throw `bad rs block @ typeNumber:${typeNumber}/errorCorrectionLevel:${errorCorrectionLevel}`;
    }
    const length = rsBlock.length / 3;
    const list = [];
    for (let i2 = 0; i2 < length; i2 += 1) {
      const count = rsBlock[i2 * 3 + 0];
      const totalCount = rsBlock[i2 * 3 + 1];
      const dataCount = rsBlock[i2 * 3 + 2];
      for (let j = 0; j < count; j += 1) {
        list.push(qrRSBlock(totalCount, dataCount));
      }
    }
    return list;
  };
  return _this;
})();
var qrBitBuffer = () => {
  const _buffer = [];
  let _length = 0;
  const _this = {};
  _this.getBuffer = () => _buffer;
  _this.getAt = (index) => {
    const bufIndex = Math.floor(index / 8);
    return (_buffer[bufIndex] >>> 7 - index % 8 & 1) === 1;
  };
  _this.put = (num, length) => {
    for (let i2 = 0; i2 < length; i2 += 1) {
      _this.putBit((num >>> length - i2 - 1 & 1) === 1);
    }
  };
  _this.getLengthInBits = () => _length;
  _this.putBit = (bit) => {
    const bufIndex = Math.floor(_length / 8);
    if (_buffer.length <= bufIndex) {
      _buffer.push(0);
    }
    if (bit) {
      _buffer[bufIndex] |= 128 >>> _length % 8;
    }
    _length += 1;
  };
  return _this;
};
var qrNumber = (data) => {
  const _mode = QRMode.MODE_NUMBER;
  const _data = data;
  const _this = {};
  _this.getMode = () => _mode;
  _this.getLength = (_buffer) => _data.length;
  _this.write = (buffer) => {
    const data2 = _data;
    let i2 = 0;
    while (i2 + 2 < data2.length) {
      buffer.put(strToNum(data2.substring(i2, i2 + 3)), 10);
      i2 += 3;
    }
    if (i2 < data2.length) {
      if (data2.length - i2 === 1) {
        buffer.put(strToNum(data2.substring(i2, i2 + 1)), 4);
      } else if (data2.length - i2 === 2) {
        buffer.put(strToNum(data2.substring(i2, i2 + 2)), 7);
      }
    }
  };
  const strToNum = (s) => {
    let num = 0;
    for (let i2 = 0; i2 < s.length; i2 += 1) {
      num = num * 10 + chatToNum(s.charAt(i2));
    }
    return num;
  };
  const chatToNum = (c) => {
    if ("0" <= c && c <= "9") {
      return c.charCodeAt(0) - "0".charCodeAt(0);
    }
    throw `illegal char :${c}`;
  };
  return _this;
};
var qrAlphaNum = (data) => {
  const _mode = QRMode.MODE_ALPHA_NUM;
  const _data = data;
  const _this = {};
  _this.getMode = () => _mode;
  _this.getLength = (_buffer) => _data.length;
  _this.write = (buffer) => {
    const s = _data;
    let i2 = 0;
    while (i2 + 1 < s.length) {
      buffer.put(getCode(s.charAt(i2)) * 45 + getCode(s.charAt(i2 + 1)), 11);
      i2 += 2;
    }
    if (i2 < s.length) {
      buffer.put(getCode(s.charAt(i2)), 6);
    }
  };
  const getCode = (c) => {
    if ("0" <= c && c <= "9") {
      return c.charCodeAt(0) - "0".charCodeAt(0);
    } else if ("A" <= c && c <= "Z") {
      return c.charCodeAt(0) - "A".charCodeAt(0) + 10;
    } else {
      switch (c) {
        case " ":
          return 36;
        case "$":
          return 37;
        case "%":
          return 38;
        case "*":
          return 39;
        case "+":
          return 40;
        case "-":
          return 41;
        case ".":
          return 42;
        case "/":
          return 43;
        case ":":
          return 44;
        default:
          throw `illegal char :${c}`;
      }
    }
  };
  return _this;
};
var qr8BitByte = (data) => {
  const _mode = QRMode.MODE_8BIT_BYTE;
  const _data = data;
  const _bytes = qrcode.stringToBytes(data);
  const _this = {};
  _this.getMode = () => _mode;
  _this.getLength = (_buffer) => _bytes.length;
  _this.write = (buffer) => {
    for (let i2 = 0; i2 < _bytes.length; i2 += 1) {
      buffer.put(_bytes[i2], 8);
    }
  };
  return _this;
};
var qrKanji = (data) => {
  const _mode = QRMode.MODE_KANJI;
  const _data = data;
  const stringToBytes2 = qrcode.stringToBytes;
  !((c, code) => {
    const test = stringToBytes2(c);
    if (test.length !== 2 || (test[0] << 8 | test[1]) !== code) {
      throw "sjis not supported.";
    }
  })("\u53CB", 38726);
  const _bytes = stringToBytes2(data);
  const _this = {};
  _this.getMode = () => _mode;
  _this.getLength = (_buffer) => ~~(_bytes.length / 2);
  _this.write = (buffer) => {
    const data2 = _bytes;
    let i2 = 0;
    while (i2 + 1 < data2.length) {
      let c = (255 & data2[i2]) << 8 | 255 & data2[i2 + 1];
      if (33088 <= c && c <= 40956) {
        c -= 33088;
      } else if (57408 <= c && c <= 60351) {
        c -= 49472;
      } else {
        throw `illegal char at ${i2 + 1}/${c}`;
      }
      c = (c >>> 8 & 255) * 192 + (c & 255);
      buffer.put(c, 13);
      i2 += 2;
    }
    if (i2 < data2.length) {
      throw `illegal char at ${i2 + 1}`;
    }
  };
  return _this;
};
var byteArrayOutputStream = () => {
  const _bytes = [];
  const _this = {};
  _this.writeByte = (b) => {
    _bytes.push(b & 255);
  };
  _this.writeShort = (i2) => {
    _this.writeByte(i2);
    _this.writeByte(i2 >>> 8);
  };
  _this.writeBytes = (b, off, len) => {
    off = off || 0;
    len = len || b.length;
    for (let i2 = 0; i2 < len; i2 += 1) {
      _this.writeByte(b[i2 + off]);
    }
  };
  _this.writeString = (s) => {
    for (let i2 = 0; i2 < s.length; i2 += 1) {
      _this.writeByte(s.charCodeAt(i2));
    }
  };
  _this.toByteArray = () => _bytes;
  _this.toString = () => {
    let s = "";
    s += "[";
    for (let i2 = 0; i2 < _bytes.length; i2 += 1) {
      if (i2 > 0) {
        s += ",";
      }
      s += _bytes[i2];
    }
    s += "]";
    return s;
  };
  return _this;
};
var base64EncodeOutputStream = () => {
  let _buffer = 0;
  let _buflen = 0;
  let _length = 0;
  let _base64 = "";
  const _this = {};
  const writeEncoded = (b) => {
    _base64 += String.fromCharCode(encode(b & 63));
  };
  const encode = (n) => {
    if (n < 0) {
      throw `n:${n}`;
    } else if (n < 26) {
      return 65 + n;
    } else if (n < 52) {
      return 97 + (n - 26);
    } else if (n < 62) {
      return 48 + (n - 52);
    } else if (n === 62) {
      return 43;
    } else if (n === 63) {
      return 47;
    } else {
      throw `n:${n}`;
    }
  };
  _this.writeByte = (n) => {
    _buffer = _buffer << 8 | n & 255;
    _buflen += 8;
    _length += 1;
    while (_buflen >= 6) {
      writeEncoded(_buffer >>> _buflen - 6);
      _buflen -= 6;
    }
  };
  _this.flush = () => {
    if (_buflen > 0) {
      writeEncoded(_buffer << 6 - _buflen);
      _buffer = 0;
      _buflen = 0;
    }
    if (_length % 3 !== 0) {
      const padlen = 3 - _length % 3;
      for (let i2 = 0; i2 < padlen; i2 += 1) {
        _base64 += "=";
      }
    }
  };
  _this.toString = () => _base64;
  return _this;
};
var base64DecodeInputStream = (str) => {
  const _str = str;
  let _pos = 0;
  let _buffer = 0;
  let _buflen = 0;
  const _this = {};
  _this.read = () => {
    while (_buflen < 8) {
      if (_pos >= _str.length) {
        if (_buflen === 0) {
          return -1;
        }
        throw `unexpected end of file./${_buflen}`;
      }
      const c = _str.charAt(_pos);
      _pos += 1;
      if (c === "=") {
        _buflen = 0;
        return -1;
      } else if (c.match(/^\s$/)) {
        continue;
      }
      _buffer = _buffer << 6 | decode(c.charCodeAt(0));
      _buflen += 6;
    }
    const n = _buffer >>> _buflen - 8 & 255;
    _buflen -= 8;
    return n;
  };
  const decode = (c) => {
    if (65 <= c && c <= 90) {
      return c - 65;
    } else if (97 <= c && c <= 122) {
      return c - 97 + 26;
    } else if (48 <= c && c <= 57) {
      return c - 48 + 52;
    } else if (c === 43) {
      return 62;
    } else if (c === 47) {
      return 63;
    } else {
      throw `c:${c}`;
    }
  };
  return _this;
};
var gifImage = (width, height) => {
  const _width = width;
  const _height = height;
  const _data = new Array(width * height);
  const _this = {};
  _this.setPixel = (x, y, pixel) => {
    _data[y * _width + x] = pixel;
  };
  _this.write = (out) => {
    out.writeString("GIF87a");
    out.writeShort(_width);
    out.writeShort(_height);
    out.writeByte(128);
    out.writeByte(0);
    out.writeByte(0);
    out.writeByte(0);
    out.writeByte(0);
    out.writeByte(0);
    out.writeByte(255);
    out.writeByte(255);
    out.writeByte(255);
    out.writeString(",");
    out.writeShort(0);
    out.writeShort(0);
    out.writeShort(_width);
    out.writeShort(_height);
    out.writeByte(0);
    const lzwMinCodeSize = 2;
    const raster = getLZWRaster(lzwMinCodeSize);
    out.writeByte(lzwMinCodeSize);
    let offset = 0;
    while (raster.length - offset > 255) {
      out.writeByte(255);
      out.writeBytes(raster, offset, 255);
      offset += 255;
    }
    out.writeByte(raster.length - offset);
    out.writeBytes(raster, offset, raster.length - offset);
    out.writeByte(0);
    out.writeString(";");
  };
  const bitOutputStream = (out) => {
    const _out = out;
    let _bitLength = 0;
    let _bitBuffer = 0;
    const _this2 = {};
    _this2.write = (data, length) => {
      if (data >>> length !== 0) {
        throw "length over";
      }
      while (_bitLength + length >= 8) {
        _out.writeByte(255 & (data << _bitLength | _bitBuffer));
        length -= 8 - _bitLength;
        data >>>= 8 - _bitLength;
        _bitBuffer = 0;
        _bitLength = 0;
      }
      _bitBuffer = data << _bitLength | _bitBuffer;
      _bitLength = _bitLength + length;
    };
    _this2.flush = () => {
      if (_bitLength > 0) {
        _out.writeByte(_bitBuffer);
      }
    };
    return _this2;
  };
  const getLZWRaster = (lzwMinCodeSize) => {
    const clearCode = 1 << lzwMinCodeSize;
    const endCode = (1 << lzwMinCodeSize) + 1;
    let bitLength = lzwMinCodeSize + 1;
    const table = lzwTable();
    for (let i2 = 0; i2 < clearCode; i2 += 1) {
      table.add(String.fromCharCode(i2));
    }
    table.add(String.fromCharCode(clearCode));
    table.add(String.fromCharCode(endCode));
    const byteOut = byteArrayOutputStream();
    const bitOut = bitOutputStream(byteOut);
    bitOut.write(clearCode, bitLength);
    let dataIndex = 0;
    let s = String.fromCharCode(_data[dataIndex]);
    dataIndex += 1;
    while (dataIndex < _data.length) {
      const c = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;
      if (table.contains(s + c)) {
        s = s + c;
      } else {
        bitOut.write(table.indexOf(s), bitLength);
        if (table.size() < 4095) {
          if (table.size() === 1 << bitLength) {
            bitLength += 1;
          }
          table.add(s + c);
        }
        s = c;
      }
    }
    bitOut.write(table.indexOf(s), bitLength);
    bitOut.write(endCode, bitLength);
    bitOut.flush();
    return byteOut.toByteArray();
  };
  const lzwTable = () => {
    const _map = {};
    let _size = 0;
    const _this2 = {};
    _this2.add = (key) => {
      if (_this2.contains(key)) {
        throw `dup key:${key}`;
      }
      _map[key] = _size;
      _size += 1;
    };
    _this2.size = () => _size;
    _this2.indexOf = (key) => _map[key];
    _this2.contains = (key) => typeof _map[key] !== "undefined";
    return _this2;
  };
  return _this;
};
var createDataURL = (width, height, getPixel) => {
  const gif = gifImage(width, height);
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      gif.setPixel(x, y, getPixel(x, y));
    }
  }
  const b = byteArrayOutputStream();
  gif.write(b);
  const base64 = base64EncodeOutputStream();
  const bytes = b.toByteArray();
  for (let i2 = 0; i2 < bytes.length; i2 += 1) {
    base64.writeByte(bytes[i2]);
  }
  base64.flush();
  return `data:image/gif;base64,${base64}`;
};
var qrcode_default = qrcode;
var stringToBytes = qrcode.stringToBytes;

// src/modules/blue-noise-dither.ts
var ECC_MAP = {
  L: "L",
  M: "M",
  Q: "Q",
  H: "H",
  low: "L",
  medium: "M",
  quartile: "Q",
  high: "H"
};
var ALIGNMENT_POSITIONS = [
  null,
  [],
  [6, 18],
  [6, 22],
  [6, 26],
  [6, 30],
  [6, 34],
  [6, 22, 38],
  [6, 24, 42],
  [6, 26, 46],
  [6, 28, 50],
  [6, 30, 54],
  [6, 32, 58],
  [6, 34, 62],
  [6, 26, 46, 66],
  [6, 26, 48, 70],
  [6, 26, 50, 74],
  [6, 30, 54, 78],
  [6, 30, 56, 82],
  [6, 30, 58, 86],
  [6, 34, 62, 90],
  [6, 28, 50, 72, 94],
  [6, 26, 50, 74, 98],
  [6, 30, 54, 78, 102],
  [6, 28, 54, 80, 106],
  [6, 32, 58, 84, 110],
  [6, 30, 58, 86, 114],
  [6, 34, 62, 90, 118],
  [6, 26, 50, 74, 98, 122],
  [6, 30, 54, 78, 102, 126],
  [6, 26, 52, 78, 104, 130],
  [6, 30, 56, 82, 108, 134],
  [6, 34, 60, 86, 112, 138],
  [6, 30, 58, 86, 114, 142],
  [6, 34, 62, 90, 118, 146],
  [6, 30, 54, 78, 102, 126, 150],
  [6, 24, 50, 76, 102, 128, 154],
  [6, 28, 54, 80, 106, 132, 158],
  [6, 32, 58, 84, 110, 136, 162],
  [6, 26, 54, 82, 110, 138, 166],
  [6, 30, 58, 86, 114, 142, 170]
];
var BLUE_NOISE_TILE_SIZE = 64;
var BLUE_NOISE_64 = generateBlueNoiseTile();
var defaultBrowserCanvasFactory = {
  createCanvas: (width, height) => {
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    return Promise.resolve(canvas);
  }
};
function generateBlueNoiseTile() {
  const size = BLUE_NOISE_TILE_SIZE;
  const tile = new Array(size * size);
  const phi = 1.618033988749895;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const ign = 52.9829189 * ((0.06711056 * x + 583715e-8 * y) % 1) % 1;
      const offset = (x * phi + y * phi * phi) % 1;
      tile[y * size + x] = (ign + offset * 0.5) % 1;
    }
  }
  return tile;
}
function sampleBlueNoise(x, y) {
  const size = BLUE_NOISE_TILE_SIZE;
  const tx = (x % size + size) % size;
  const ty = (y % size + size) % size;
  return BLUE_NOISE_64[ty * size + tx];
}
function isLocked(moduleCount2, x, y, scale) {
  const l = moduleCount2 / scale;
  const sx = Math.floor(x / scale);
  const sy = Math.floor(y / scale);
  if (sx < 0 || sy < 0 || sx >= l || sy >= l) return true;
  if (sx < 7 && sy < 7) return true;
  if (sx < 7 && sy > l - 8) return true;
  if (sx > l - 8 && sy < 7) return true;
  if (sx === 6 || sy === 6) return true;
  const version = (l - 17) / 4;
  const positions = ALIGNMENT_POSITIONS[version];
  if (positions && positions.length > 0) {
    for (const px of positions) {
      for (const py of positions) {
        if (px < 8 && py < 8) continue;
        if (px < 8 && py > l - 9) continue;
        if (px > l - 9 && py < 8) continue;
        if (Math.abs(sx - px) <= 2 && Math.abs(sy - py) <= 2) {
          return true;
        }
      }
    }
  }
  return false;
}
function isData(x, y, scale) {
  const m = Math.floor(scale / 2);
  const xs = x % scale;
  const ys = y % scale;
  if (xs === m && ys === m) return true;
  if (scale % 2 === 1) return false;
  if (xs === m && ys === m - 1) return true;
  if (xs === m - 1 && ys === m) return true;
  if (xs === m - 1 && ys === m - 1) return true;
  return false;
}
async function loadImageDataRGB(canvas, size, canvasFactory = defaultBrowserCanvasFactory) {
  const tempCanvas = await canvasFactory.createCanvas(size, size);
  const ctx = tempCanvas.getContext("2d");
  if (!ctx) throw new Error("Could not get 2D context");
  ctx.drawImage(canvas, 0, 0, size, size);
  const imgData = ctx.getImageData(0, 0, size, size);
  const output = [];
  for (let y = 0; y < size; y++) {
    const row2 = [];
    for (let x = 0; x < size; x++) {
      const i2 = (y * size + x) * 4;
      row2.push({
        r: imgData.data[i2] / 255,
        g: imgData.data[i2 + 1] / 255,
        b: imgData.data[i2 + 2] / 255
      });
    }
    output.push(row2);
  }
  return output;
}
function rgbToGray(r, g, b) {
  return r * 0.299 + g * 0.587 + b * 0.114;
}
function convertToGrayscale(imageData) {
  for (const row2 of imageData) {
    for (let x = 0; x < row2.length; x++) {
      const { r, g, b } = row2[x];
      const gray = rgbToGray(r, g, b);
      row2[x] = { r: gray, g: gray, b: gray };
    }
  }
}
function blueNoiseDitherFreePoints(imageData, moduleCount2, scale, colorMode) {
  const size = imageData.length;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (isLocked(moduleCount2, x, y, scale)) continue;
      if (isData(x, y, scale)) continue;
      const pixel = imageData[y][x];
      const threshold = sampleBlueNoise(x, y);
      if (colorMode === "bw") {
        const gray = rgbToGray(pixel.r, pixel.g, pixel.b);
        const newVal = gray > threshold ? 1 : 0;
        imageData[y][x] = { r: newVal, g: newVal, b: newVal };
      } else if (colorMode === "grayscale") {
        const gray = rgbToGray(pixel.r, pixel.g, pixel.b);
        const levels = 4;
        const scaled = gray * (levels - 1);
        const low = Math.floor(scaled);
        const high = Math.min(low + 1, levels - 1);
        const frac = scaled - low;
        const newVal = (frac > threshold ? high : low) / (levels - 1);
        imageData[y][x] = { r: newVal, g: newVal, b: newVal };
      } else {
        let quantizeChannel = function(val, noiseOffset) {
          const t = (threshold + noiseOffset) % 1;
          const scaled = val * (levels - 1);
          const low = Math.floor(scaled);
          const high = Math.min(low + 1, levels - 1);
          const frac = scaled - low;
          return (frac > t ? high : low) / (levels - 1);
        };
        const levels = 4;
        imageData[y][x] = {
          r: quantizeChannel(pixel.r, 0),
          g: quantizeChannel(pixel.g, 0.33),
          b: quantizeChannel(pixel.b, 0.67)
        };
      }
    }
  }
}
async function generateBlueNoiseDithered(options) {
  const {
    text,
    ecc,
    version = 0,
    scale,
    overlayCanvas,
    overlayIntensity = 50,
    colorMode = "color",
    canvasFactory = defaultBrowserCanvasFactory
  } = options;
  const eccLevel = ECC_MAP[ecc] || "Q";
  const typeNumber = version || 0;
  const qr = qrcode_default(typeNumber, eccLevel);
  qr.addData(text);
  qr.make();
  const moduleCount2 = qr.getModuleCount();
  const scaledSize = moduleCount2 * scale;
  const matrix = [];
  const colors = [];
  for (let y = 0; y < scaledSize; y++) {
    const matrixRow = [];
    const colorRow = [];
    for (let x = 0; x < scaledSize; x++) {
      const qrX = Math.floor(x / scale);
      const qrY = Math.floor(y / scale);
      const isDark = qr.isDark(qrY, qrX);
      matrixRow.push(isDark);
      colorRow.push(isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 });
    }
    matrix.push(matrixRow);
    colors.push(colorRow);
  }
  if (!overlayCanvas) {
    return { matrix, colors };
  }
  const imageData = await loadImageDataRGB(overlayCanvas, scaledSize, canvasFactory);
  const intensity = overlayIntensity / 100;
  if (colorMode === "grayscale" || colorMode === "bw") {
    convertToGrayscale(imageData);
  }
  blueNoiseDitherFreePoints(imageData, scaledSize, scale, colorMode);
  for (let y = 0; y < scaledSize; y++) {
    for (let x = 0; x < scaledSize; x++) {
      if (isLocked(scaledSize, x, y, scale)) continue;
      if (isData(x, y, scale)) continue;
      const pixel = imageData[y][x];
      const brightness = rgbToGray(pixel.r, pixel.g, pixel.b);
      const useImage = sampleBlueNoise(x + 17, y + 31) < intensity;
      if (useImage) {
        matrix[y][x] = brightness < 0.5;
        colors[y][x] = {
          r: Math.round(Math.max(0, Math.min(1, pixel.r)) * 255),
          g: Math.round(Math.max(0, Math.min(1, pixel.g)) * 255),
          b: Math.round(Math.max(0, Math.min(1, pixel.b)) * 255)
        };
      }
    }
  }
  return { matrix, colors };
}

// src/modules/color-utils.ts
function parseHex(hex) {
  hex = hex.replace("#", "");
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  }
  return {
    r: Number.parseInt(hex.substring(0, 2), 16),
    g: Number.parseInt(hex.substring(2, 4), 16),
    b: Number.parseInt(hex.substring(4, 6), 16)
  };
}
function parseHexAlpha(hex) {
  hex = hex.replace("#", "");
  if (hex.length === 4) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
  }
  const rgb = parseHex(hex.substring(0, 6));
  const a = hex.length >= 8 ? Number.parseInt(hex.substring(6, 8), 16) / 255 : 1;
  return { ...rgb, a };
}
function parseRgbString(str) {
  const rgbRegex = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/;
  const match = rgbRegex.exec(str);
  if (match) {
    return {
      r: Number.parseInt(match[1], 10),
      g: Number.parseInt(match[2], 10),
      b: Number.parseInt(match[3], 10),
      a: match[4] === void 0 ? 1 : Number.parseFloat(match[4])
    };
  }
  return { r: 0, g: 0, b: 0, a: 1 };
}
function parseHslString(str) {
  const hslRegex = /hsla?\((\d+),\s*([\d.]+)%?,\s*([\d.]+)%?(?:,\s*([\d.]+))?\)/;
  const match = hslRegex.exec(str);
  if (match) {
    return {
      h: Number.parseInt(match[1], 10),
      s: Number.parseFloat(match[2]),
      l: Number.parseFloat(match[3]),
      a: match[4] === void 0 ? 1 : Number.parseFloat(match[4])
    };
  }
  return { h: 0, s: 0, l: 0, a: 1 };
}
function parseColor(color) {
  color = color.trim().toLowerCase();
  if (color.startsWith("#")) {
    return parseHexAlpha(color);
  }
  if (color.startsWith("rgb")) {
    return parseRgbString(color);
  }
  if (color.startsWith("hsl")) {
    const hsl = parseHslString(color);
    const rgb = hslToRgb(hsl.h, hsl.s, hsl.l);
    return { ...rgb, a: hsl.a };
  }
  const namedColors = {
    black: "#000000",
    white: "#ffffff",
    red: "#ff0000",
    green: "#00ff00",
    blue: "#0000ff",
    yellow: "#ffff00",
    cyan: "#00ffff",
    magenta: "#ff00ff",
    gray: "#808080",
    grey: "#808080",
    transparent: "#00000000"
  };
  if (namedColors[color]) {
    return parseHexAlpha(namedColors[color]);
  }
  return { r: 0, g: 0, b: 0, a: 1 };
}
function rgbToHex(r, g, b) {
  const toHex = (n) => Math.round(n).toString(16).padStart(2, "0");
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
function rgbaToString(r, g, b, a) {
  return `rgba(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)}, ${a})`;
}
function hslToRgb(h, s, l) {
  h /= 360;
  s /= 100;
  l /= 100;
  let r, g, b;
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p2, q2, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p2 + (q2 - p2) * 6 * t;
      if (t < 1 / 2) return q2;
      if (t < 2 / 3) return p2 + (q2 - p2) * (2 / 3 - t) * 6;
      return p2;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return {
    r: Math.round(r * 255),
    g: Math.round(g * 255),
    b: Math.round(b * 255)
  };
}
function blendColors(color1, color2, ratio) {
  const c1 = parseColor(color1);
  const c2 = parseColor(color2);
  const r = Math.round(c1.r + (c2.r - c1.r) * ratio);
  const g = Math.round(c1.g + (c2.g - c1.g) * ratio);
  const b = Math.round(c1.b + (c2.b - c1.b) * ratio);
  const a = c1.a + (c2.a - c1.a) * ratio;
  if (a < 1) {
    return rgbaToString(r, g, b, a);
  }
  return rgbToHex(r, g, b);
}

// src/modules/dither-algorithms.ts
var BAYER_2 = [
  [0, 2],
  [3, 1]
];
var BAYER_4 = [
  [0, 8, 2, 10],
  [12, 4, 14, 6],
  [3, 11, 1, 9],
  [15, 7, 13, 5]
];
var BAYER_8 = [
  [0, 32, 8, 40, 2, 34, 10, 42],
  [48, 16, 56, 24, 50, 18, 58, 26],
  [12, 44, 4, 36, 14, 46, 6, 38],
  [60, 28, 52, 20, 62, 30, 54, 22],
  [3, 35, 11, 43, 1, 33, 9, 41],
  [51, 19, 59, 27, 49, 17, 57, 25],
  [15, 47, 7, 39, 13, 45, 5, 37],
  [63, 31, 55, 23, 61, 29, 53, 21]
];
var CLUSTERED_DOT = [
  [24, 10, 12, 26, 35, 47, 49, 37],
  [8, 0, 2, 14, 45, 59, 61, 51],
  [22, 6, 4, 16, 43, 57, 63, 53],
  [30, 20, 18, 28, 33, 41, 55, 39],
  [34, 46, 48, 36, 25, 11, 13, 27],
  [44, 58, 60, 50, 9, 1, 3, 15],
  [42, 56, 62, 52, 23, 7, 5, 17],
  [32, 40, 54, 38, 31, 21, 19, 29]
];
var VOID_CLUSTER = [
  [13, 9, 5, 12, 18, 22, 26, 19],
  [6, 1, 0, 8, 25, 30, 31, 23],
  [10, 2, 3, 4, 21, 29, 28, 27],
  [14, 7, 11, 15, 17, 24, 20, 16],
  [18, 22, 26, 19, 13, 9, 5, 12],
  [25, 30, 31, 23, 6, 1, 0, 8],
  [21, 29, 28, 27, 10, 2, 3, 4],
  [17, 24, 20, 16, 14, 7, 11, 15]
];
var DIFFUSION_KERNELS = {
  floyd_steinberg: {
    matrix: [
      [0, 0, 7],
      [3, 5, 1]
    ],
    divisor: 16,
    offset: 1
  },
  jarvis_judice_ninke: {
    matrix: [
      [0, 0, 0, 7, 5],
      [3, 5, 7, 5, 3],
      [1, 3, 5, 3, 1]
    ],
    divisor: 48,
    offset: 2
  },
  stucki: {
    matrix: [
      [0, 0, 0, 8, 4],
      [2, 4, 8, 4, 2],
      [1, 2, 4, 2, 1]
    ],
    divisor: 42,
    offset: 2
  },
  burkes: {
    matrix: [
      [0, 0, 0, 8, 4],
      [2, 4, 8, 4, 2]
    ],
    divisor: 32,
    offset: 2
  },
  sierra: {
    matrix: [
      [0, 0, 0, 5, 3],
      [2, 4, 5, 4, 2],
      [0, 2, 3, 2, 0]
    ],
    divisor: 32,
    offset: 2
  },
  sierra_2: {
    matrix: [
      [0, 0, 0, 4, 3],
      [1, 2, 3, 2, 1]
    ],
    divisor: 16,
    offset: 2
  },
  sierra_lite: {
    matrix: [
      [0, 0, 2],
      [1, 1, 0]
    ],
    divisor: 4,
    offset: 1
  },
  atkinson: {
    matrix: [
      [0, 0, 1, 1],
      [1, 1, 1, 0],
      [0, 1, 0, 0]
    ],
    divisor: 8,
    offset: 1
  }
};
function clamp01(value) {
  return Math.max(0, Math.min(1, value));
}
function rgbToGray2(r, g, b) {
  return r * 0.299 + g * 0.587 + b * 0.114;
}
function createRNG(seed) {
  let state = seed || Date.now();
  return () => {
    state = state * 1103515245 + 12345 & 2147483647;
    return state / 2147483647;
  };
}
function generateBlueNoiseTile2(size, seed) {
  const tile = new Array(size * size);
  const phi = 1.618033988749895;
  const rng = createRNG(seed);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const ign = 52.9829189 * ((0.06711056 * x + 583715e-8 * y) % 1) % 1;
      const offset = (x * phi + y * phi * phi) % 1 + rng() * 0.1;
      tile[y * size + x] = (ign + offset * 0.5) % 1;
    }
  }
  return tile;
}
function sampleBlueNoise2(x, y, tile, tileSize) {
  const tx = (x % tileSize + tileSize) % tileSize;
  const ty = (y % tileSize + tileSize) % tileSize;
  return tile[ty * tileSize + tx];
}
function orderedDither(imageData, width, height, matrix, levels = 2, strength = 100) {
  const matrixSize = matrix.length;
  const maxVal = matrixSize * matrixSize;
  const strengthFactor = strength / 100;
  const resultMatrix = [];
  const resultColors = [];
  for (let y = 0; y < height; y++) {
    const matrixRow = [];
    const colorRow = [];
    for (let x = 0; x < width; x++) {
      const mx = x % matrixSize;
      const my = y % matrixSize;
      const threshold = (matrix[my][mx] + 0.5) / maxVal;
      const idx = x * 3;
      const r = imageData[y][idx];
      const g = imageData[y][idx + 1];
      const b = imageData[y][idx + 2];
      const gray = rgbToGray2(r, g, b);
      const adjustedThreshold = 0.5 + (threshold - 0.5) * strengthFactor;
      const isDark = gray < adjustedThreshold;
      matrixRow.push(isDark);
      const step = 1 / (levels - 1);
      const newR = Math.round(r / step) * step;
      const newG = Math.round(g / step) * step;
      const newB = Math.round(b / step) * step;
      colorRow.push({
        r: Math.round(clamp01(newR) * 255),
        g: Math.round(clamp01(newG) * 255),
        b: Math.round(clamp01(newB) * 255)
      });
    }
    resultMatrix.push(matrixRow);
    resultColors.push(colorRow);
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function bayerDither(imageData, width, height, size = 4, levels = 2, strength = 100) {
  const matrix = (() => {
    if (size === 2) return BAYER_2;
    if (size === 4) return BAYER_4;
    return BAYER_8;
  })();
  return orderedDither(imageData, width, height, matrix, levels, strength);
}
function errorDiffusion(imageData, width, height, options = {}) {
  const kernelName = options.kernelName ?? "floyd_steinberg";
  const serpentine = options.serpentine ?? true;
  const levels = options.levels ?? 2;
  const strength = options.strength ?? 100;
  const colorMode = options.colorMode ?? "bw";
  const kernel = DIFFUSION_KERNELS[kernelName];
  const strengthFactor = strength / 100;
  const step = 1 / (levels - 1);
  const pixels = [];
  for (let y = 0; y < height; y++) {
    const row2 = [];
    for (let x = 0; x < width; x++) {
      const idx = x * 3;
      row2.push({
        r: imageData[y][idx],
        g: imageData[y][idx + 1],
        b: imageData[y][idx + 2]
      });
    }
    pixels.push(row2);
  }
  const resultMatrix = [];
  const resultColors = [];
  for (let y = 0; y < height; y++) {
    resultMatrix.push(new Array(width).fill(false));
    resultColors.push(new Array(width).fill({ r: 255, g: 255, b: 255 }));
  }
  for (let y = 0; y < height; y++) {
    const leftToRight = serpentine ? y % 2 === 0 : true;
    const startX = leftToRight ? 0 : width - 1;
    const endX = leftToRight ? width : -1;
    const deltaX = leftToRight ? 1 : -1;
    for (let x = startX; deltaX > 0 ? x < endX : x > endX; x += deltaX) {
      const pixel = pixels[y][x];
      if (colorMode === "bw") {
        const gray = rgbToGray2(pixel.r, pixel.g, pixel.b);
        const newVal = gray > 0.5 ? 1 : 0;
        const error = (gray - newVal) * strengthFactor;
        resultMatrix[y][x] = newVal === 0;
        resultColors[y][x] = {
          r: newVal * 255,
          g: newVal * 255,
          b: newVal * 255
        };
        distributeErrorWithKernel({
          pixels,
          x,
          y,
          width,
          height,
          errorR: error,
          errorG: error,
          errorB: error,
          kernel,
          leftToRight
        });
      } else if (colorMode === "grayscale") {
        const gray = rgbToGray2(pixel.r, pixel.g, pixel.b);
        const newVal = Math.round(gray / step) * step;
        const error = (gray - newVal) * strengthFactor;
        resultMatrix[y][x] = newVal < 0.5;
        const grayByte = Math.round(clamp01(newVal) * 255);
        resultColors[y][x] = { r: grayByte, g: grayByte, b: grayByte };
        distributeErrorWithKernel({
          pixels,
          x,
          y,
          width,
          height,
          errorR: error,
          errorG: error,
          errorB: error,
          kernel,
          leftToRight
        });
      } else {
        const newR = Math.round(pixel.r / step) * step;
        const newG = Math.round(pixel.g / step) * step;
        const newB = Math.round(pixel.b / step) * step;
        const errR = (pixel.r - newR) * strengthFactor;
        const errG = (pixel.g - newG) * strengthFactor;
        const errB = (pixel.b - newB) * strengthFactor;
        const brightness = rgbToGray2(newR, newG, newB);
        resultMatrix[y][x] = brightness < 0.5;
        resultColors[y][x] = {
          r: Math.round(clamp01(newR) * 255),
          g: Math.round(clamp01(newG) * 255),
          b: Math.round(clamp01(newB) * 255)
        };
        distributeErrorWithKernel({
          pixels,
          x,
          y,
          width,
          height,
          errorR: errR,
          errorG: errG,
          errorB: errB,
          kernel,
          leftToRight
        });
      }
    }
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function distributeErrorWithKernel(opts) {
  const { pixels, x, y, width, height, errorR, errorG, errorB, kernel, leftToRight } = opts;
  for (let ky = 0; ky < kernel.matrix.length; ky++) {
    for (let kx = 0; kx < kernel.matrix[ky].length; kx++) {
      const weight = kernel.matrix[ky][kx];
      if (weight === 0) continue;
      let offsetX = kx - kernel.offset;
      if (!leftToRight) offsetX = -offsetX;
      const nx = x + offsetX;
      const ny = y + ky;
      if (nx >= 0 && nx < width && ny < height) {
        const factor = weight / kernel.divisor;
        pixels[ny][nx].r += errorR * factor;
        pixels[ny][nx].g += errorG * factor;
        pixels[ny][nx].b += errorB * factor;
      }
    }
  }
}
function blueNoiseDither(imageData, width, height, options = {}) {
  const tileSize = options.tileSize ?? 64;
  const seed = options.seed ?? 0;
  const levels = options.levels ?? 2;
  const strength = options.strength ?? 100;
  const colorMode = options.colorMode ?? "bw";
  const tile = generateBlueNoiseTile2(tileSize, seed);
  const strengthFactor = strength / 100;
  const _step = 1 / (levels - 1);
  const resultMatrix = [];
  const resultColors = [];
  for (let y = 0; y < height; y++) {
    const matrixRow = [];
    const colorRow = [];
    for (let x = 0; x < width; x++) {
      const threshold = sampleBlueNoise2(x, y, tile, tileSize);
      const idx = x * 3;
      const r = imageData[y][idx];
      const g = imageData[y][idx + 1];
      const b = imageData[y][idx + 2];
      if (colorMode === "bw") {
        const gray = rgbToGray2(r, g, b);
        const adjustedThreshold = 0.5 + (threshold - 0.5) * strengthFactor;
        const isDark = gray < adjustedThreshold;
        matrixRow.push(isDark);
        colorRow.push(isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 });
      } else if (colorMode === "grayscale") {
        const gray = rgbToGray2(r, g, b);
        const scaled = gray * (levels - 1);
        const low = Math.floor(scaled);
        const high = Math.min(low + 1, levels - 1);
        const frac = scaled - low;
        const t = 0.5 + (threshold - 0.5) * strengthFactor;
        const newVal = (frac > t ? high : low) / (levels - 1);
        matrixRow.push(newVal < 0.5);
        const grayByte = Math.round(newVal * 255);
        colorRow.push({ r: grayByte, g: grayByte, b: grayByte });
      } else {
        const quantize2 = (val, noiseOffset) => {
          const t = (threshold + noiseOffset) % 1;
          const adjustedT = 0.5 + (t - 0.5) * strengthFactor;
          const scaled = val * (levels - 1);
          const low = Math.floor(scaled);
          const high = Math.min(low + 1, levels - 1);
          const frac = scaled - low;
          return (frac > adjustedT ? high : low) / (levels - 1);
        };
        const newR = quantize2(r, 0);
        const newG = quantize2(g, 0.33);
        const newB = quantize2(b, 0.67);
        const brightness = rgbToGray2(newR, newG, newB);
        matrixRow.push(brightness < 0.5);
        colorRow.push({
          r: Math.round(newR * 255),
          g: Math.round(newG * 255),
          b: Math.round(newB * 255)
        });
      }
    }
    resultMatrix.push(matrixRow);
    resultColors.push(colorRow);
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function whiteNoiseDither(imageData, width, height, seed = 0, strength = 100, _colorMode = "bw") {
  const rng = createRNG(seed);
  const strengthFactor = strength / 100;
  const resultMatrix = [];
  const resultColors = [];
  for (let y = 0; y < height; y++) {
    const matrixRow = [];
    const colorRow = [];
    for (let x = 0; x < width; x++) {
      const threshold = rng();
      const idx = x * 3;
      const r = imageData[y][idx];
      const g = imageData[y][idx + 1];
      const b = imageData[y][idx + 2];
      const gray = rgbToGray2(r, g, b);
      const adjustedThreshold = 0.5 + (threshold - 0.5) * strengthFactor;
      const isDark = gray < adjustedThreshold;
      matrixRow.push(isDark);
      colorRow.push(isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 });
    }
    resultMatrix.push(matrixRow);
    resultColors.push(colorRow);
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function gaussianNoiseDither(imageData, width, height, seed = 0, strength = 100, _colorMode = "bw") {
  const rng = createRNG(seed);
  const strengthFactor = strength / 100;
  const gaussianRandom = () => {
    const u1 = rng() || 1e-4;
    const u2 = rng();
    return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2) * 0.2 + 0.5;
  };
  const resultMatrix = [];
  const resultColors = [];
  for (let y = 0; y < height; y++) {
    const matrixRow = [];
    const colorRow = [];
    for (let x = 0; x < width; x++) {
      const threshold = clamp01(gaussianRandom());
      const idx = x * 3;
      const r = imageData[y][idx];
      const g = imageData[y][idx + 1];
      const b = imageData[y][idx + 2];
      const gray = rgbToGray2(r, g, b);
      const adjustedThreshold = 0.5 + (threshold - 0.5) * strengthFactor;
      const isDark = gray < adjustedThreshold;
      matrixRow.push(isDark);
      colorRow.push(isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 });
    }
    resultMatrix.push(matrixRow);
    resultColors.push(colorRow);
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function triangularNoiseDither(imageData, width, height, seed = 0, strength = 100, _colorMode = "bw") {
  const rng = createRNG(seed);
  const strengthFactor = strength / 100;
  const triangularRandom = () => {
    return (rng() + rng()) / 2;
  };
  const resultMatrix = [];
  const resultColors = [];
  for (let y = 0; y < height; y++) {
    const matrixRow = [];
    const colorRow = [];
    for (let x = 0; x < width; x++) {
      const threshold = triangularRandom();
      const idx = x * 3;
      const r = imageData[y][idx];
      const g = imageData[y][idx + 1];
      const b = imageData[y][idx + 2];
      const gray = rgbToGray2(r, g, b);
      const adjustedThreshold = 0.5 + (threshold - 0.5) * strengthFactor;
      const isDark = gray < adjustedThreshold;
      matrixRow.push(isDark);
      colorRow.push(isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 });
    }
    resultMatrix.push(matrixRow);
    resultColors.push(colorRow);
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function blueNoiseErrorDiffusion(imageData, width, height, options = {}) {
  const kernelName = options.kernelName ?? "floyd_steinberg";
  const serpentine = options.serpentine ?? true;
  const levels = options.levels ?? 2;
  const strength = options.strength ?? 100;
  const colorMode = options.colorMode ?? "bw";
  const tileSize = options.tileSize ?? 64;
  const seed = options.seed ?? 0;
  const kernel = DIFFUSION_KERNELS[kernelName];
  const strengthFactor = strength / 100;
  const step = 1 / (levels - 1);
  const tile = generateBlueNoiseTile2(tileSize, seed);
  const pixels = [];
  for (let y = 0; y < height; y++) {
    const row2 = [];
    for (let x = 0; x < width; x++) {
      const idx = x * 3;
      row2.push({
        r: imageData[y][idx],
        g: imageData[y][idx + 1],
        b: imageData[y][idx + 2]
      });
    }
    pixels.push(row2);
  }
  const resultMatrix = [];
  const resultColors = [];
  for (let y = 0; y < height; y++) {
    resultMatrix.push(new Array(width).fill(false));
    resultColors.push(new Array(width).fill({ r: 255, g: 255, b: 255 }));
  }
  for (let y = 0; y < height; y++) {
    const leftToRight = serpentine ? y % 2 === 0 : true;
    const startX = leftToRight ? 0 : width - 1;
    const endX = leftToRight ? width : -1;
    const deltaX = leftToRight ? 1 : -1;
    for (let x = startX; deltaX > 0 ? x < endX : x > endX; x += deltaX) {
      const pixel = pixels[y][x];
      const blueNoiseVal = sampleBlueNoise2(x, y, tile, tileSize);
      const thresholdMod = (blueNoiseVal - 0.5) * 0.3 * strengthFactor;
      if (colorMode === "bw") {
        const gray = rgbToGray2(pixel.r, pixel.g, pixel.b);
        const threshold = 0.5 + thresholdMod;
        const newVal = gray > threshold ? 1 : 0;
        const error = (gray - newVal) * strengthFactor;
        resultMatrix[y][x] = newVal === 0;
        resultColors[y][x] = { r: newVal * 255, g: newVal * 255, b: newVal * 255 };
        distributeErrorWithKernel({
          pixels,
          x,
          y,
          width,
          height,
          errorR: error,
          errorG: error,
          errorB: error,
          kernel,
          leftToRight
        });
      } else {
        const newR = Math.round(pixel.r / step) * step;
        const newG = Math.round(pixel.g / step) * step;
        const newB = Math.round(pixel.b / step) * step;
        const errR = (pixel.r - newR) * strengthFactor;
        const errG = (pixel.g - newG) * strengthFactor;
        const errB = (pixel.b - newB) * strengthFactor;
        const brightness = rgbToGray2(newR, newG, newB);
        resultMatrix[y][x] = brightness < 0.5;
        resultColors[y][x] = {
          r: Math.round(clamp01(newR) * 255),
          g: Math.round(clamp01(newG) * 255),
          b: Math.round(clamp01(newB) * 255)
        };
        distributeErrorWithKernel({
          pixels,
          x,
          y,
          width,
          height,
          errorR: errR,
          errorG: errG,
          errorB: errB,
          kernel,
          leftToRight
        });
      }
    }
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function screenedBlueNoiseDither(imageData, width, height, options = {}) {
  const tileSize = options.tileSize ?? 64;
  const seed = options.seed ?? 0;
  const levels = options.levels ?? 2;
  const strength = options.strength ?? 100;
  const _colorMode = options.colorMode ?? "bw";
  const tile = generateBlueNoiseTile2(tileSize, seed);
  const strengthFactor = strength / 100;
  const _step = 1 / (levels - 1);
  const resultMatrix = [];
  const resultColors = [];
  const screenSize = 4;
  const screenPattern = [
    [0.1, 0.5, 0.2, 0.6],
    [0.7, 0.3, 0.8, 0.4],
    [0.2, 0.6, 0.1, 0.5],
    [0.8, 0.4, 0.7, 0.3]
  ];
  for (let y = 0; y < height; y++) {
    const matrixRow = [];
    const colorRow = [];
    for (let x = 0; x < width; x++) {
      const idx = x * 3;
      const r = imageData[y][idx];
      const g = imageData[y][idx + 1];
      const b = imageData[y][idx + 2];
      const gray = rgbToGray2(r, g, b);
      const screenVal = screenPattern[y % screenSize][x % screenSize];
      const blueNoiseVal = sampleBlueNoise2(x, y, tile, tileSize);
      const combinedThreshold = screenVal * 0.6 + blueNoiseVal * 0.4;
      const adjustedThreshold = 0.5 + (combinedThreshold - 0.5) * strengthFactor;
      const isDark = gray < adjustedThreshold;
      matrixRow.push(isDark);
      colorRow.push(isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 });
    }
    resultMatrix.push(matrixRow);
    resultColors.push(colorRow);
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function perceptualDither(imageData, width, height, options = {}) {
  const kernelName = options.kernelName ?? "floyd_steinberg";
  const serpentine = options.serpentine ?? true;
  const levels = options.levels ?? 2;
  const strength = options.strength ?? 100;
  const colorMode = options.colorMode ?? "bw";
  const kernel = DIFFUSION_KERNELS[kernelName];
  const strengthFactor = strength / 100;
  const step = 1 / (levels - 1);
  const toLinear = (v) => v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  const toSRGB = (v) => v <= 31308e-7 ? v * 12.92 : 1.055 * v ** (1 / 2.4) - 0.055;
  const pixels = [];
  for (let y = 0; y < height; y++) {
    const row2 = [];
    for (let x = 0; x < width; x++) {
      const idx = x * 3;
      row2.push({
        r: toLinear(imageData[y][idx]),
        g: toLinear(imageData[y][idx + 1]),
        b: toLinear(imageData[y][idx + 2])
      });
    }
    pixels.push(row2);
  }
  const resultMatrix = [];
  const resultColors = [];
  for (let y = 0; y < height; y++) {
    resultMatrix.push(new Array(width).fill(false));
    resultColors.push(new Array(width).fill({ r: 255, g: 255, b: 255 }));
  }
  for (let y = 0; y < height; y++) {
    const leftToRight = serpentine ? y % 2 === 0 : true;
    const startX = leftToRight ? 0 : width - 1;
    const endX = leftToRight ? width : -1;
    const deltaX = leftToRight ? 1 : -1;
    for (let x = startX; deltaX > 0 ? x < endX : x > endX; x += deltaX) {
      const pixel = pixels[y][x];
      if (colorMode === "bw") {
        const gray = pixel.r * 0.2126 + pixel.g * 0.7152 + pixel.b * 0.0722;
        const newVal = gray > 0.5 ? 1 : 0;
        const error = (gray - newVal) * strengthFactor;
        resultMatrix[y][x] = newVal === 0;
        const outVal = Math.round(toSRGB(newVal) * 255);
        resultColors[y][x] = { r: outVal, g: outVal, b: outVal };
        distributeErrorWithKernel({
          pixels,
          x,
          y,
          width,
          height,
          errorR: error,
          errorG: error,
          errorB: error,
          kernel,
          leftToRight
        });
      } else {
        const newR = Math.round(pixel.r / step) * step;
        const newG = Math.round(pixel.g / step) * step;
        const newB = Math.round(pixel.b / step) * step;
        const errR = (pixel.r - newR) * strengthFactor;
        const errG = (pixel.g - newG) * strengthFactor;
        const errB = (pixel.b - newB) * strengthFactor;
        const brightness = newR * 0.2126 + newG * 0.7152 + newB * 0.0722;
        resultMatrix[y][x] = brightness < 0.5;
        resultColors[y][x] = {
          r: Math.round(clamp01(toSRGB(newR)) * 255),
          g: Math.round(clamp01(toSRGB(newG)) * 255),
          b: Math.round(clamp01(toSRGB(newB)) * 255)
        };
        distributeErrorWithKernel({
          pixels,
          x,
          y,
          width,
          height,
          errorR: errR,
          errorG: errG,
          errorB: errB,
          kernel,
          leftToRight
        });
      }
    }
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function edgeAwareDither(imageData, width, height, options = {}) {
  const kernelName = options.kernelName ?? "floyd_steinberg";
  const serpentine = options.serpentine ?? true;
  const levels = options.levels ?? 2;
  const strength = options.strength ?? 100;
  const colorMode = options.colorMode ?? "bw";
  const kernel = DIFFUSION_KERNELS[kernelName];
  const strengthFactor = strength / 100;
  const step = 1 / (levels - 1);
  const edgeMap = [];
  for (let y = 0; y < height; y++) {
    edgeMap.push(new Array(width).fill(0));
  }
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const getGray = (px, py) => {
        const idx = px * 3;
        return rgbToGray2(imageData[py][idx], imageData[py][idx + 1], imageData[py][idx + 2]);
      };
      const gx = -getGray(x - 1, y - 1) + getGray(x + 1, y - 1) + -2 * getGray(x - 1, y) + 2 * getGray(x + 1, y) + -getGray(x - 1, y + 1) + getGray(x + 1, y + 1);
      const gy = -getGray(x - 1, y - 1) - 2 * getGray(x, y - 1) - getGray(x + 1, y - 1) + getGray(x - 1, y + 1) + 2 * getGray(x, y + 1) + getGray(x + 1, y + 1);
      edgeMap[y][x] = Math.min(1, Math.hypot(gx, gy));
    }
  }
  const pixels = [];
  for (let y = 0; y < height; y++) {
    const row2 = [];
    for (let x = 0; x < width; x++) {
      const idx = x * 3;
      row2.push({
        r: imageData[y][idx],
        g: imageData[y][idx + 1],
        b: imageData[y][idx + 2]
      });
    }
    pixels.push(row2);
  }
  const resultMatrix = [];
  const resultColors = [];
  for (let y = 0; y < height; y++) {
    resultMatrix.push(new Array(width).fill(false));
    resultColors.push(new Array(width).fill({ r: 255, g: 255, b: 255 }));
  }
  for (let y = 0; y < height; y++) {
    const leftToRight = serpentine ? y % 2 === 0 : true;
    const startX = leftToRight ? 0 : width - 1;
    const endX = leftToRight ? width : -1;
    const deltaX = leftToRight ? 1 : -1;
    for (let x = startX; deltaX > 0 ? x < endX : x > endX; x += deltaX) {
      const pixel = pixels[y][x];
      const edgeFactor = 1 - edgeMap[y][x] * 0.8;
      if (colorMode === "bw") {
        const gray = rgbToGray2(pixel.r, pixel.g, pixel.b);
        const newVal = gray > 0.5 ? 1 : 0;
        const error = (gray - newVal) * strengthFactor * edgeFactor;
        resultMatrix[y][x] = newVal === 0;
        resultColors[y][x] = { r: newVal * 255, g: newVal * 255, b: newVal * 255 };
        distributeErrorWithKernel({
          pixels,
          x,
          y,
          width,
          height,
          errorR: error,
          errorG: error,
          errorB: error,
          kernel,
          leftToRight
        });
      } else {
        const newR = Math.round(pixel.r / step) * step;
        const newG = Math.round(pixel.g / step) * step;
        const newB = Math.round(pixel.b / step) * step;
        const errR = (pixel.r - newR) * strengthFactor * edgeFactor;
        const errG = (pixel.g - newG) * strengthFactor * edgeFactor;
        const errB = (pixel.b - newB) * strengthFactor * edgeFactor;
        const brightness = rgbToGray2(newR, newG, newB);
        resultMatrix[y][x] = brightness < 0.5;
        resultColors[y][x] = {
          r: Math.round(clamp01(newR) * 255),
          g: Math.round(clamp01(newG) * 255),
          b: Math.round(clamp01(newB) * 255)
        };
        distributeErrorWithKernel({
          pixels,
          x,
          y,
          width,
          height,
          errorR: errR,
          errorG: errG,
          errorB: errB,
          kernel,
          leftToRight
        });
      }
    }
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function adaptiveThresholdDither(imageData, width, height, strength = 100, _colorMode = "bw") {
  const strengthFactor = strength / 100;
  const blockSize = 8;
  const resultMatrix = [];
  const resultColors = [];
  const integral = [];
  for (let y = 0; y < height; y++) {
    integral.push(new Array(width).fill(0));
  }
  for (let y = 0; y < height; y++) {
    let rowSum = 0;
    for (let x = 0; x < width; x++) {
      const idx = x * 3;
      const gray = rgbToGray2(imageData[y][idx], imageData[y][idx + 1], imageData[y][idx + 2]);
      rowSum += gray;
      integral[y][x] = rowSum + (y > 0 ? integral[y - 1][x] : 0);
    }
  }
  const getSum = (x1, y1, x2, y2) => {
    x1 = Math.max(0, x1);
    y1 = Math.max(0, y1);
    x2 = Math.min(width - 1, x2);
    y2 = Math.min(height - 1, y2);
    const a = y1 > 0 && x1 > 0 ? integral[y1 - 1][x1 - 1] : 0;
    const b = y1 > 0 ? integral[y1 - 1][x2] : 0;
    const c = x1 > 0 ? integral[y2][x1 - 1] : 0;
    const d = integral[y2][x2];
    return d - b - c + a;
  };
  for (let y = 0; y < height; y++) {
    const matrixRow = [];
    const colorRow = [];
    for (let x = 0; x < width; x++) {
      const idx = x * 3;
      const r = imageData[y][idx];
      const g = imageData[y][idx + 1];
      const b = imageData[y][idx + 2];
      const gray = rgbToGray2(r, g, b);
      const halfBlock = Math.floor(blockSize / 2);
      const x1 = x - halfBlock;
      const y1 = y - halfBlock;
      const x2 = x + halfBlock;
      const y2 = y + halfBlock;
      const area = (Math.min(x2, width - 1) - Math.max(x1, 0) + 1) * (Math.min(y2, height - 1) - Math.max(y1, 0) + 1);
      const localMean = getSum(x1, y1, x2, y2) / area;
      const threshold = localMean * (1 - 0.2 * strengthFactor);
      const isDark = gray < threshold;
      matrixRow.push(isDark);
      colorRow.push(isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 });
    }
    resultMatrix.push(matrixRow);
    resultColors.push(colorRow);
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function temporalBlueNoiseDither(imageData, width, height, frameIndex, tileSize = 64, seed = 0, _colorMode = "bw") {
  const tile = generateBlueNoiseTile2(tileSize, seed);
  const offset = frameIndex * 17 % (tileSize * tileSize);
  const resultMatrix = [];
  const resultColors = [];
  for (let y = 0; y < height; y++) {
    const matrixRow = [];
    const colorRow = [];
    for (let x = 0; x < width; x++) {
      const idx = x * 3;
      const r = imageData[y][idx];
      const g = imageData[y][idx + 1];
      const b = imageData[y][idx + 2];
      const gray = rgbToGray2(r, g, b);
      const nx = x % tileSize;
      const ny = y % tileSize;
      const noiseIdx = (ny * tileSize + nx + offset) % (tileSize * tileSize);
      const threshold = tile[noiseIdx];
      const isDark = gray < threshold;
      matrixRow.push(isDark);
      colorRow.push(isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 });
    }
    resultMatrix.push(matrixRow);
    resultColors.push(colorRow);
  }
  return { matrix: resultMatrix, colors: resultColors };
}
function imageDataToFloat(imageData) {
  const { data, width, height } = imageData;
  const result = [];
  for (let y = 0; y < height; y++) {
    const row2 = new Float32Array(width * 3);
    for (let x = 0; x < width; x++) {
      const srcIdx = (y * width + x) * 4;
      const dstIdx = x * 3;
      row2[dstIdx] = data[srcIdx] / 255;
      row2[dstIdx + 1] = data[srcIdx + 1] / 255;
      row2[dstIdx + 2] = data[srcIdx + 2] / 255;
    }
    result.push(row2);
  }
  return result;
}
function applyDither(imageData, options) {
  const floatData = imageDataToFloat(imageData);
  const { width, height } = imageData;
  switch (options.kind) {
    case "ordered_bayer": {
      const bayerSizeMap = { bayer2: 2, bayer4: 4, bayer8: 8 };
      const bayerSize = bayerSizeMap[options.orderedMatrix] ?? 4;
      return bayerDither(floatData, width, height, bayerSize, options.levels, options.strength);
    }
    case "ordered_clustered":
      return orderedDither(
        floatData,
        width,
        height,
        CLUSTERED_DOT,
        options.levels,
        options.strength
      );
    case "ordered_void_cluster":
      return orderedDither(
        floatData,
        width,
        height,
        VOID_CLUSTER,
        options.levels,
        options.strength
      );
    case "blue_noise":
    case "blue_noise_threshold":
      return blueNoiseDither(floatData, width, height, {
        tileSize: options.blueNoiseTileSize,
        seed: options.blueNoiseSeed,
        levels: options.levels,
        strength: options.strength,
        colorMode: options.colorMode
      });
    case "white_noise":
      return whiteNoiseDither(
        floatData,
        width,
        height,
        options.blueNoiseSeed,
        options.strength,
        options.colorMode
      );
    case "gaussian_noise":
      return gaussianNoiseDither(
        floatData,
        width,
        height,
        options.blueNoiseSeed,
        options.strength,
        options.colorMode
      );
    case "triangular_noise":
      return triangularNoiseDither(
        floatData,
        width,
        height,
        options.blueNoiseSeed,
        options.strength,
        options.colorMode
      );
    case "blue_noise_error_diffusion":
      return blueNoiseErrorDiffusion(floatData, width, height, {
        kernelName: options.diffusionKernel,
        serpentine: options.serpentine,
        levels: options.levels,
        strength: options.strength,
        colorMode: options.colorMode,
        tileSize: options.blueNoiseTileSize,
        seed: options.blueNoiseSeed
      });
    case "screened_blue_noise":
      return screenedBlueNoiseDither(floatData, width, height, {
        tileSize: options.blueNoiseTileSize,
        seed: options.blueNoiseSeed,
        levels: options.levels,
        strength: options.strength,
        colorMode: options.colorMode
      });
    case "perceptual":
      return perceptualDither(floatData, width, height, {
        kernelName: options.diffusionKernel,
        serpentine: options.serpentine,
        levels: options.levels,
        strength: options.strength,
        colorMode: options.colorMode
      });
    case "edge_aware":
      return edgeAwareDither(floatData, width, height, {
        kernelName: options.diffusionKernel,
        serpentine: options.serpentine,
        levels: options.levels,
        strength: options.strength,
        colorMode: options.colorMode
      });
    case "adaptive_threshold":
      return adaptiveThresholdDither(floatData, width, height, options.strength, options.colorMode);
    case "temporal_blue_noise":
      return temporalBlueNoiseDither(
        floatData,
        width,
        height,
        0,
        // frameIndex
        options.blueNoiseTileSize,
        options.blueNoiseSeed,
        options.colorMode
      );
    default:
      return errorDiffusion(floatData, width, height, {
        kernelName: options.diffusionKernel,
        serpentine: options.serpentine,
        levels: options.levels,
        strength: options.strength,
        colorMode: options.colorMode
      });
  }
}

// src/modules/qr-core.ts
var ALIGNMENT_POSITIONS2 = [
  null,
  [],
  [6, 18],
  [6, 22],
  [6, 26],
  [6, 30],
  [6, 34],
  [6, 22, 38],
  [6, 24, 42],
  [6, 26, 46],
  [6, 28, 50],
  [6, 30, 54],
  [6, 32, 58],
  [6, 34, 62],
  [6, 26, 46, 66],
  [6, 26, 48, 70],
  [6, 26, 50, 74],
  [6, 30, 54, 78],
  [6, 30, 56, 82],
  [6, 30, 58, 86],
  [6, 34, 62, 90],
  [6, 28, 50, 72, 94],
  [6, 26, 50, 74, 98],
  [6, 30, 54, 78, 102],
  [6, 28, 54, 80, 106],
  [6, 32, 58, 84, 110],
  [6, 30, 58, 86, 114],
  [6, 34, 62, 90, 118],
  [6, 26, 50, 74, 98, 122],
  [6, 30, 54, 78, 102, 126],
  [6, 26, 52, 78, 104, 130],
  [6, 30, 56, 82, 108, 134],
  [6, 34, 60, 86, 112, 138],
  [6, 30, 58, 86, 114, 142],
  [6, 34, 62, 90, 118, 146],
  [6, 30, 54, 78, 102, 126, 150],
  [6, 24, 50, 76, 102, 128, 154],
  [6, 28, 54, 80, 106, 132, 158],
  [6, 32, 58, 84, 110, 136, 162],
  [6, 26, 54, 82, 110, 138, 166],
  [6, 30, 58, 86, 114, 142, 170]
];
var ECC_CAPACITIES_BYTE = {
  L: [
    17,
    32,
    53,
    78,
    106,
    134,
    154,
    192,
    230,
    271,
    321,
    367,
    425,
    458,
    520,
    586,
    644,
    718,
    792,
    858,
    929,
    1003,
    1091,
    1171,
    1273,
    1367,
    1465,
    1528,
    1628,
    1732,
    1840,
    1952,
    2068,
    2188,
    2303,
    2431,
    2563,
    2699,
    2809,
    2953
  ],
  M: [
    14,
    26,
    42,
    62,
    84,
    106,
    122,
    152,
    180,
    213,
    251,
    287,
    331,
    362,
    412,
    450,
    504,
    560,
    624,
    666,
    711,
    779,
    857,
    911,
    997,
    1059,
    1125,
    1190,
    1264,
    1370,
    1452,
    1538,
    1628,
    1722,
    1809,
    1911,
    1989,
    2099,
    2213,
    2331
  ],
  Q: [
    11,
    20,
    32,
    46,
    60,
    74,
    86,
    108,
    130,
    151,
    177,
    203,
    241,
    258,
    292,
    322,
    364,
    394,
    442,
    482,
    509,
    565,
    611,
    661,
    715,
    751,
    805,
    868,
    908,
    982,
    1030,
    1112,
    1168,
    1228,
    1283,
    1351,
    1423,
    1499,
    1579,
    1663
  ],
  H: [
    7,
    14,
    24,
    34,
    44,
    58,
    64,
    84,
    98,
    119,
    137,
    155,
    177,
    194,
    220,
    250,
    280,
    310,
    338,
    382,
    403,
    439,
    461,
    511,
    535,
    593,
    625,
    658,
    698,
    742,
    790,
    842,
    898,
    958,
    983,
    1051,
    1093,
    1139,
    1219,
    1273
  ]
};
var ECC_CAPACITIES_NUMERIC = {
  L: [
    41,
    77,
    127,
    187,
    255,
    322,
    370,
    461,
    552,
    652,
    772,
    883,
    1022,
    1101,
    1250,
    1408,
    1548,
    1725,
    1903,
    2061,
    2232,
    2409,
    2620,
    2812,
    3057,
    3283,
    3517,
    3669,
    3909,
    4158,
    4417,
    4686,
    4965,
    5253,
    5529,
    5836,
    6153,
    6479,
    6743,
    7089
  ],
  M: [
    34,
    63,
    101,
    149,
    202,
    255,
    293,
    365,
    432,
    513,
    604,
    691,
    796,
    871,
    991,
    1082,
    1212,
    1346,
    1500,
    1600,
    1708,
    1872,
    2059,
    2188,
    2395,
    2544,
    2701,
    2857,
    3035,
    3289,
    3486,
    3693,
    3909,
    4134,
    4343,
    4588,
    4775,
    5039,
    5313,
    5596
  ],
  Q: [
    27,
    48,
    77,
    111,
    144,
    178,
    207,
    259,
    312,
    364,
    427,
    489,
    580,
    621,
    703,
    775,
    876,
    948,
    1063,
    1159,
    1224,
    1358,
    1468,
    1588,
    1718,
    1804,
    1933,
    2085,
    2181,
    2358,
    2473,
    2670,
    2805,
    2949,
    3081,
    3244,
    3417,
    3599,
    3791,
    3993
  ],
  H: [
    17,
    34,
    58,
    82,
    106,
    139,
    154,
    202,
    235,
    288,
    331,
    374,
    427,
    468,
    530,
    602,
    674,
    746,
    813,
    919,
    969,
    1056,
    1108,
    1228,
    1286,
    1425,
    1501,
    1581,
    1677,
    1782,
    1897,
    2022,
    2157,
    2301,
    2361,
    2524,
    2625,
    2735,
    2927,
    3057
  ]
};
var ECC_CAPACITIES_ALPHANUMERIC = {
  L: [
    25,
    47,
    77,
    114,
    154,
    195,
    224,
    279,
    335,
    395,
    468,
    535,
    619,
    667,
    758,
    854,
    938,
    1046,
    1153,
    1249,
    1352,
    1460,
    1588,
    1704,
    1853,
    1990,
    2132,
    2223,
    2369,
    2520,
    2677,
    2840,
    3009,
    3183,
    3351,
    3537,
    3729,
    3927,
    4087,
    4296
  ],
  M: [
    20,
    38,
    61,
    90,
    122,
    154,
    178,
    221,
    262,
    311,
    366,
    419,
    483,
    528,
    600,
    656,
    734,
    816,
    909,
    970,
    1035,
    1134,
    1248,
    1326,
    1451,
    1542,
    1637,
    1732,
    1839,
    1994,
    2113,
    2238,
    2369,
    2506,
    2632,
    2780,
    2894,
    3054,
    3220,
    3391
  ],
  Q: [
    16,
    29,
    47,
    67,
    87,
    108,
    125,
    157,
    189,
    221,
    259,
    296,
    352,
    376,
    426,
    470,
    531,
    574,
    644,
    702,
    742,
    823,
    890,
    963,
    1041,
    1094,
    1172,
    1263,
    1322,
    1429,
    1499,
    1618,
    1700,
    1787,
    1867,
    1966,
    2071,
    2181,
    2298,
    2420
  ],
  H: [
    10,
    20,
    35,
    50,
    64,
    84,
    93,
    122,
    143,
    174,
    200,
    227,
    259,
    283,
    321,
    365,
    408,
    452,
    493,
    557,
    587,
    640,
    672,
    744,
    779,
    864,
    910,
    958,
    1016,
    1080,
    1150,
    1226,
    1307,
    1394,
    1431,
    1530,
    1591,
    1658,
    1774,
    1852
  ]
};
function calculateOptimalVersion(content, ecc, mode = "byte") {
  let effectiveMode = mode;
  if (mode === "auto") {
    effectiveMode = detectOptimalMode(content);
  }
  let caps;
  let len;
  switch (effectiveMode) {
    case "numeric":
      caps = ECC_CAPACITIES_NUMERIC[ecc];
      len = content.length;
      break;
    case "alphanumeric":
      caps = ECC_CAPACITIES_ALPHANUMERIC[ecc];
      len = content.length;
      break;
    case "kanji":
      caps = ECC_CAPACITIES_BYTE[ecc];
      len = content.length * 2;
      break;
    default:
      caps = ECC_CAPACITIES_BYTE[ecc];
      len = getUtf8ByteLength(content);
      break;
  }
  for (let v = 0; v < caps.length; v++) {
    if (caps[v] >= len) {
      return v + 1;
    }
  }
  return 40;
}
function getUtf8ByteLength(str) {
  if (typeof TextEncoder !== "undefined") {
    return new TextEncoder().encode(str).length;
  }
  let bytes = 0;
  for (let i2 = 0; i2 < str.length; i2++) {
    const code = str.charCodeAt(i2);
    if (code < 128) bytes += 1;
    else if (code < 2048) bytes += 2;
    else if (code >= 55296 && code < 56320) {
      bytes += 4;
      i2++;
    } else bytes += 3;
  }
  return bytes;
}
function isValidForMode(content, mode) {
  switch (mode) {
    case "numeric":
      return /^[0-9]*$/.test(content);
    case "alphanumeric":
      return /^[0-9A-Z $%*+\-./:]*$/.test(content);
    case "byte":
      return true;
    // Byte mode can encode anything
    case "kanji":
      return true;
    default:
      return true;
  }
}
function getCompatibleMode(content, requestedMode) {
  if (requestedMode === "auto") {
    return detectOptimalMode(content);
  }
  if (isValidForMode(content, requestedMode)) {
    return requestedMode;
  }
  if (requestedMode === "numeric") {
    if (isValidForMode(content, "alphanumeric")) {
      return "alphanumeric";
    }
    return "byte";
  }
  if (requestedMode === "alphanumeric") {
    return "byte";
  }
  if (requestedMode === "kanji") {
    return "byte";
  }
  return "byte";
}
function detectOptimalMode(content) {
  if (/^[0-9]*$/.test(content)) {
    return "numeric";
  }
  if (/^[0-9A-Z $%*+\-./:]*$/.test(content)) {
    return "alphanumeric";
  }
  return "byte";
}
function getVersionFromModuleCount(moduleCount2) {
  return (moduleCount2 - 17) / 4;
}
function getAlignmentPositions(version) {
  if (version < 2 || version > 40) return [];
  return ALIGNMENT_POSITIONS2[version] || [];
}
function getAlignmentPatternCenters(version, moduleCount2) {
  if (version < 2) return [];
  const coords = getAlignmentPositions(version);
  const positions = [];
  for (const r of coords) {
    for (const c of coords) {
      if (r < 8 && c < 8) continue;
      if (r < 8 && c > moduleCount2 - 9) continue;
      if (r > moduleCount2 - 9 && c < 8) continue;
      positions.push({ row: r, col: c });
    }
  }
  return positions;
}
function isFinderPattern(row2, col2, moduleCount2) {
  if (row2 < 7 && col2 < 7) return true;
  if (row2 < 7 && col2 >= moduleCount2 - 7) return true;
  if (row2 >= moduleCount2 - 7 && col2 < 7) return true;
  return false;
}
function isTimingPattern(row2, col2, moduleCount2) {
  if (moduleCount2 === void 0) {
    return row2 === 6 || col2 === 6;
  }
  if (row2 === 6 && col2 >= 8 && col2 < moduleCount2 - 8) return true;
  if (col2 === 6 && row2 >= 8 && row2 < moduleCount2 - 8) return true;
  return false;
}
function isLocked2(moduleCount2, x, y, scale = 1) {
  const l = moduleCount2 / scale;
  const sx = Math.floor(x / scale);
  const sy = Math.floor(y / scale);
  if (sx < 0 || sy < 0 || sx >= l || sy >= l) return true;
  if (sx < 7 && sy < 7) return true;
  if (sx < 7 && sy > l - 8) return true;
  if (sx > l - 8 && sy < 7) return true;
  if (sx === 6 || sy === 6) return true;
  const version = getVersionFromModuleCount(l);
  const positions = getAlignmentPositions(version);
  if (positions.length > 0) {
    for (const px of positions) {
      for (const py of positions) {
        if (px < 8 && py < 8) continue;
        if (px < 8 && py > l - 9) continue;
        if (px > l - 9 && py < 8) continue;
        if (Math.abs(sx - px) <= 2 && Math.abs(sy - py) <= 2) {
          return true;
        }
      }
    }
  }
  return false;
}
function isData2(x, y, scale) {
  const m = Math.floor(scale / 2);
  const xs = x % scale;
  const ys = y % scale;
  if (xs === m && ys === m) return true;
  if (scale % 2 === 1) return false;
  if (xs === m && ys === m - 1) return true;
  if (xs === m - 1 && ys === m) return true;
  if (xs === m - 1 && ys === m - 1) return true;
  return false;
}
function isStructuralModule(row2, col2, moduleCount2, version) {
  if (row2 < 8 && col2 < 8) return true;
  if (row2 < 8 && col2 >= moduleCount2 - 8) return true;
  if (row2 >= moduleCount2 - 8 && col2 < 8) return true;
  if (row2 === 6 || col2 === 6) return true;
  if (row2 === 8 && col2 < 9) return true;
  if (col2 === 8 && row2 < 9) return true;
  if (row2 === 8 && col2 >= moduleCount2 - 8) return true;
  if (col2 === 8 && row2 >= moduleCount2 - 8) return true;
  if (row2 === moduleCount2 - 8 && col2 === 8) return true;
  if (version >= 7) {
    if (row2 >= moduleCount2 - 11 && row2 < moduleCount2 - 8 && col2 < 6) return true;
    if (col2 >= moduleCount2 - 11 && col2 < moduleCount2 - 8 && row2 < 6) return true;
  }
  if (version >= 2) {
    const positions = getAlignmentPositions(version);
    for (const px of positions) {
      for (const py of positions) {
        if (px < 8 && py < 8) continue;
        if (px < 8 && py > moduleCount2 - 9) continue;
        if (px > moduleCount2 - 9 && py < 8) continue;
        if (Math.abs(row2 - py) <= 2 && Math.abs(col2 - px) <= 2) return true;
      }
    }
  }
  return false;
}
function generateQR(options) {
  const { text, ecc, version = 0, scale = 1 } = options;
  let typeNumber = version;
  if (typeNumber === 0) {
    typeNumber = calculateOptimalVersion(text, ecc);
  }
  const qr = qrcode_default(typeNumber, ecc);
  qr.addData(text);
  qr.make();
  const moduleCount2 = qr.getModuleCount();
  const scaledSize = moduleCount2 * scale;
  const matrix = [];
  for (let y = 0; y < scaledSize; y++) {
    const row2 = [];
    for (let x = 0; x < scaledSize; x++) {
      const qrX = Math.floor(x / scale);
      const qrY = Math.floor(y / scale);
      row2.push(qr.isDark(qrY, qrX));
    }
    matrix.push(row2);
  }
  return {
    matrix,
    moduleCount: scaledSize,
    version: typeNumber
  };
}

// src/modules/shift-jis-encoder.ts
var HIRAGANA_START = 12353;
var HIRAGANA_END = 12438;
var KATAKANA_START = 12449;
var KATAKANA_END = 12534;
var HW_KATAKANA_START = 65377;
var HW_KATAKANA_END = 65439;
var HW_KATAKANA_SJIS_START = 161;
var FULLWIDTH_ASCII_START = 65281;
var FULLWIDTH_ASCII_END = 65374;
var FULLWIDTH_MAP = {
  // Full-width space
  12288: 33088,
  // Full-width punctuation
  12289: 33089,
  // 、
  12290: 33090,
  // 。
  65292: 33091,
  // ，
  65294: 33092,
  // ．
  12539: 33093,
  // ・
  65306: 33094,
  // ：
  65307: 33095,
  // ；
  65311: 33096,
  // ？
  65281: 33097,
  // ！
  12443: 33098,
  // ゛
  12444: 33099,
  // ゜
  180: 33100,
  // ´
  65344: 33101,
  // ｀
  168: 33102,
  // ¨
  65342: 33103,
  // ＾
  65507: 33104,
  // ￣
  65343: 33105,
  // ＿
  // Brackets
  12308: 33131,
  // 〔
  12309: 33132,
  // 〕
  12304: 33133,
  // 【
  12305: 33134,
  // 】
  12298: 33137,
  // 《
  12299: 33138,
  // 》
  12300: 33141,
  // 「
  12301: 33142,
  // 」
  12302: 33143,
  // 『
  12303: 33144,
  // 』
  65288: 33129,
  // （
  65289: 33130,
  // ）
  65339: 33135,
  // ［
  65341: 33136,
  // ］
  65371: 33135,
  // ｛
  65373: 33136,
  // ｝
  // Symbols
  12291: 33110,
  // 〃
  20189: 33111,
  // 仝
  12293: 33112,
  // 々
  12294: 33113,
  // 〆
  12295: 33114,
  // 〇
  12540: 33115,
  // ー (prolonged sound mark)
  8213: 33116,
  // ―
  8208: 33117,
  // ‐
  65295: 33118,
  // ／
  65340: 33119,
  // ＼
  12316: 33120,
  // 〜
  8214: 33121,
  // ‖
  65372: 33122,
  // ｜
  8230: 33123,
  // …
  8229: 33124,
  // ‥
  8216: 33125,
  // '
  8217: 33126,
  // '
  8220: 33127,
  // "
  8221: 33128,
  // "
  // Math symbols
  65291: 33147,
  // ＋
  65293: 33148,
  // －
  177: 33149,
  // ±
  215: 33150,
  // ×
  247: 33152,
  // ÷
  65309: 33153,
  // ＝
  8800: 33154,
  // ≠
  65308: 33155,
  // ＜
  65310: 33156,
  // ＞
  8806: 33157,
  // ≦
  8807: 33158,
  // ≧
  8734: 33159,
  // ∞
  8756: 33160,
  // ∴
  // Currency and special
  65509: 33167,
  // ￥
  65284: 33168,
  // ＄
  65504: 33169,
  // ￠
  65505: 33170,
  // ￡
  65285: 33171,
  // ％
  65283: 33172,
  // ＃
  65286: 33173,
  // ＆
  65290: 33174,
  // ＊
  65312: 33175,
  // ＠
  // Arrows
  8592: 33193,
  // ←
  8593: 33194,
  // ↑
  8594: 33192,
  // →
  8595: 33195,
  // ↓
  // Greek letters (common)
  913: 33695,
  // Α
  914: 33696,
  // Β
  915: 33697,
  // Γ
  916: 33698,
  // Δ
  917: 33699,
  // Ε
  918: 33700,
  // Ζ
  919: 33701,
  // Η
  920: 33702,
  // Θ
  921: 33703,
  // Ι
  922: 33704,
  // Κ
  923: 33705,
  // Λ
  924: 33706,
  // Μ
  925: 33707,
  // Ν
  926: 33708,
  // Ξ
  927: 33709,
  // Ο
  928: 33710,
  // Π
  929: 33711,
  // Ρ
  931: 33712,
  // Σ
  932: 33713,
  // Τ
  933: 33714,
  // Υ
  934: 33715,
  // Φ
  935: 33716,
  // Χ
  936: 33717,
  // Ψ
  937: 33718,
  // Ω
  945: 33727,
  // α
  946: 33728,
  // β
  947: 33729,
  // γ
  948: 33730,
  // δ
  949: 33731,
  // ε
  950: 33732,
  // ζ
  951: 33733,
  // η
  952: 33734,
  // θ
  953: 33735,
  // ι
  954: 33736,
  // κ
  955: 33737,
  // λ
  956: 33738,
  // μ
  957: 33739,
  // ν
  958: 33740,
  // ξ
  959: 33741,
  // ο
  960: 33742,
  // π
  961: 33743,
  // ρ
  963: 33744,
  // σ
  964: 33745,
  // τ
  965: 33746,
  // υ
  966: 33747,
  // φ
  967: 33748,
  // χ
  968: 33749,
  // ψ
  969: 33750
  // ω
};
var KANJI_MAP = {
  // Numbers
  19968: 35050,
  // 一
  20108: 37873,
  // 二
  19977: 36431,
  // 三
  22235: 36460,
  // 四
  20116: 36060,
  // 五
  20845: 39002,
  // 六
  19971: 36533,
  // 七
  20843: 38058,
  // 八
  20061: 35811,
  // 九
  21313: 36700,
  // 十
  30334: 38227,
  // 百
  21315: 37095,
  // 千
  19975: 38556,
  // 万
  20740: 35245,
  // 億
  // Time/Calendar
  26085: 37882,
  // 日
  26376: 35982,
  // 月
  28779: 35278,
  // 火
  27700: 36997,
  // 水
  26408: 38616,
  // 木
  37329: 35808,
  // 金
  22303: 37753,
  // 土
  24180: 37966,
  // 年
  26178: 36510,
  // 時
  20998: 38314,
  // 分
  31186: 38242,
  // 秒
  20170: 36257,
  // 今
  26152: 36346,
  // 昨
  26126: 38590,
  // 明
  // People/Body
  20154: 36972,
  // 人
  30007: 37482,
  // 男
  22899: 36759,
  // 女
  23376: 36465,
  // 子
  27597: 38378,
  // 母
  29238: 38275,
  // 父
  21451: 38726,
  // 友
  25163: 36584,
  // 手
  36275: 37291,
  // 足
  30446: 38618,
  // 目
  32819: 36520,
  // 耳
  21475: 36091,
  // 口
  40763: 38208,
  // 鼻
  24515: 36947,
  // 心
  // Nature
  23665: 36434,
  // 山
  24029: 37100,
  // 川
  28023: 35395,
  // 海
  31354: 35827,
  // 空
  38632: 35137,
  // 雨
  39080: 38295,
  // 風
  38634: 37089,
  // 雪
  33457: 35284,
  // 花
  33609: 37264,
  // 草
  27193: 36599,
  // 樹
  26519: 38865,
  // 林
  26862: 36952,
  // 森
  // Actions
  35211: 36009,
  // 見
  32862: 38327,
  // 聞
  35328: 36030,
  // 言
  35501: 37831,
  // 読
  26360: 36753,
  // 書
  35441: 39010,
  // 話
  39135: 36936,
  // 食
  39154: 35065,
  // 飲
  36208: 37270,
  // 走
  27497: 38368,
  // 歩
  31435: 38823,
  // 立
  24231: 36288,
  // 座
  23517: 36945,
  // 寝
  36215: 35662,
  // 起
  20316: 36332,
  // 作
  20351: 36455,
  // 使
  25345: 36509,
  // 持
  21462: 36582,
  // 取
  20986: 36719,
  // 出
  20837: 37884,
  // 入
  34892: 36211,
  // 行
  26469: 38792,
  // 来
  24112: 35649,
  // 帰
  24453: 37330,
  // 待
  20250: 35311,
  // 会
  30693: 37485,
  // 知
  24605: 36470,
  // 思
  32771: 36204,
  // 考
  20449: 36941,
  // 信
  24859: 34980,
  // 愛
  // Places/Buildings
  23478: 35270,
  // 家
  24215: 37720,
  // 店
  39365: 35191,
  // 駅
  23398: 35447,
  // 学
  26657: 36186,
  // 校
  31038: 36560,
  // 社
  22269: 36241,
  // 国
  24066: 36467,
  // 市
  30010: 37548,
  // 町
  26449: 37306,
  // 村
  36947: 37817,
  // 道
  27211: 35764,
  // 橋
  // Objects
  36554: 36429,
  // 車
  38651: 37732,
  // 電
  26412: 38523,
  // 本
  26032: 36950,
  // 新
  32025: 36486,
  // 紙
  31558: 38221,
  // 筆
  37549: 37534,
  // 銭
  37347: 37347,
  // 釣
  // Adjectives
  22823: 37349,
  // 大
  23567: 36751,
  // 小
  39640: 36226,
  // 高
  20302: 37601,
  // 低
  38263: 37559,
  // 長
  30701: 37466,
  // 短
  33391: 38855,
  // 良
  24746: 34987,
  // 悪
  21476: 36035,
  // 古
  22810: 37309,
  // 多
  23569: 36781,
  // 少
  24375: 35757,
  // 強
  24369: 36579,
  // 弱
  26263: 35011,
  // 暗
  28201: 35255,
  // 温
  23506: 35494,
  // 寒
  29105: 37965,
  // 熱
  20919: 38882,
  // 冷
  // Colors
  36196: 37076,
  // 赤
  38738: 37058,
  // 青
  30333: 38034,
  // 白
  40658: 36245,
  // 黒
  32209: 38862,
  // 緑
  40644: 35241,
  // 黄
  // Position/Direction
  20013: 37510,
  // 中
  22806: 35407,
  // 外
  19978: 36835,
  // 上
  19979: 35258,
  // 下
  24038: 36278,
  // 左
  21491: 35141,
  // 右
  21069: 37199,
  // 前
  24460: 36067,
  // 後
  21271: 38523,
  // 北
  21335: 37868,
  // 南
  26481: 37772,
  // 東
  35199: 37052,
  // 西
  20869: 37856,
  // 内
  // Common abstract concepts
  29289: 38312,
  // 物
  20107: 36502,
  // 事
  32773: 36562,
  // 者
  25152: 36746,
  // 所
  26041: 38395,
  // 方
  27671: 35651,
  // 気
  21147: 38861,
  // 力
  21517: 38588,
  // 名
  27425: 36511,
  // 次
  21021: 36745,
  // 初
  26368: 36293,
  // 最
  26411: 38550,
  // 末
  20808: 37094,
  // 先
  27096: 38808,
  // 様
  24335: 36526,
  // 式
  24615: 37035,
  // 性
  21270: 35259,
  // 化
  29992: 38768,
  // 用
  24471: 37822,
  // 得
  22833: 36536,
  // 失
  21487: 35266,
  // 可
  19981: 38259,
  // 不
  28961: 38579,
  // 無
  26377: 38732,
  // 有
  20840: 37203,
  // 全
  37096: 38292,
  // 部
  21322: 38076,
  // 半
  27491: 37043,
  // 正
  35492: 36064,
  // 誤
  30495: 36958,
  // 真
  20605: 35669,
  // 偽
  22987: 36462,
  // 始
  32066: 36681,
  // 終
  32154: 37297,
  // 続
  27490: 36478,
  // 止
  21205: 37806,
  // 動
  38745: 37059,
  // 静
  22793: 38351,
  // 変
  21516: 37807,
  // 同
  21029: 38346,
  // 別
  29305: 37825,
  // 特
  26222: 38273,
  // 普
  36890: 37578,
  // 通
  20849: 35748,
  // 共
  31169: 36484,
  // 私
  20844: 36086,
  // 公
  20491: 36034,
  // 個
  22243: 37475,
  // 団
  20307: 37324,
  // 体
  32676: 35921,
  // 群
  38598: 36695,
  // 集
  21512: 36231,
  // 合
  35299: 35312,
  // 解
  32080: 35979,
  // 結
  38283: 35402,
  // 開
  38281: 38338,
  // 閉
  29983: 37046,
  // 生
  27515: 36480,
  // 死
  20581: 35986,
  // 健
  24247: 36174,
  // 康
  30149: 38241,
  // 病
  21307: 35043,
  // 医
  34220: 38642,
  // 薬
  // Question words
  20309: 35261,
  // 何
  35504: 37454
  // 誰
};
function hiraganaToShiftJIS(codePoint) {
  if (codePoint < HIRAGANA_START || codePoint > HIRAGANA_END) {
    return [63];
  }
  const offset = codePoint - HIRAGANA_START;
  let sjis = 33439 + offset;
  const lowByte = sjis & 255;
  if (lowByte >= 127) {
    sjis += 1;
  }
  return [sjis >> 8 & 255, sjis & 255];
}
function katakanaToShiftJIS(codePoint) {
  if (codePoint < KATAKANA_START || codePoint > KATAKANA_END) {
    return [63];
  }
  const offset = codePoint - KATAKANA_START;
  let sjis = 33600 + offset;
  let lowByte = sjis & 255;
  if (lowByte >= 127) {
    sjis += 1;
    lowByte = sjis & 255;
  }
  if ((sjis & 65280) === 33536 && lowByte > 158) {
    const extraOffset = lowByte - 158 - 1;
    sjis = 33856 + extraOffset;
  }
  return [sjis >> 8 & 255, sjis & 255];
}
function unicodeToShiftJIS(codePoint) {
  if (codePoint < 128) {
    return [codePoint];
  }
  if (codePoint >= HW_KATAKANA_START && codePoint <= HW_KATAKANA_END) {
    return [HW_KATAKANA_SJIS_START + (codePoint - HW_KATAKANA_START)];
  }
  if (codePoint >= HIRAGANA_START && codePoint <= HIRAGANA_END) {
    return hiraganaToShiftJIS(codePoint);
  }
  if (codePoint >= KATAKANA_START && codePoint <= KATAKANA_END) {
    return katakanaToShiftJIS(codePoint);
  }
  if (FULLWIDTH_MAP[codePoint] !== void 0) {
    const sjis = FULLWIDTH_MAP[codePoint];
    return [sjis >> 8 & 255, sjis & 255];
  }
  if (codePoint >= FULLWIDTH_ASCII_START && codePoint <= FULLWIDTH_ASCII_END) {
    const offset = codePoint - FULLWIDTH_ASCII_START;
    if (offset === 0) return [129, 73];
    if (offset >= 15 && offset <= 24) {
      return [130, 79 + (offset - 15)];
    }
    if (offset >= 32 && offset <= 57) {
      const charOffset = offset - 32;
      let lowByte = 96 + charOffset;
      if (lowByte >= 127) lowByte += 1;
      return [130, lowByte];
    }
    if (offset >= 64 && offset <= 89) {
      const charOffset = offset - 64;
      const lowByte = 129 + charOffset;
      return [130, lowByte];
    }
  }
  if (KANJI_MAP[codePoint] !== void 0) {
    const sjis = KANJI_MAP[codePoint];
    return [sjis >> 8 & 255, sjis & 255];
  }
  return [63];
}
function createShiftJISEncoder() {
  return (s) => {
    const bytes = [];
    for (let i2 = 0; i2 < s.length; i2++) {
      const codePoint = s.codePointAt(i2);
      if (codePoint === void 0) continue;
      if (codePoint > 65535) {
        i2++;
        bytes.push(63);
        continue;
      }
      const sjisBytes = unicodeToShiftJIS(codePoint);
      bytes.push(...sjisBytes);
    }
    return bytes;
  };
}

// src/modules/qr-generator.js
var defaultStringToBytes = (s) => {
  const bytes = [];
  for (let i2 = 0; i2 < s.length; i2 += 1) {
    const c = s.charCodeAt(i2);
    bytes.push(c & 255);
  }
  return bytes;
};
var MemoCache = class {
  constructor(maxSize = 100) {
    this.cache = /* @__PURE__ */ new Map();
    this.maxSize = maxSize;
  }
  get(key) {
    if (this.cache.has(key)) {
      const value = this.cache.get(key);
      this.cache.delete(key);
      this.cache.set(key, value);
      return value;
    }
    return void 0;
  }
  set(key, value) {
    if (this.cache.has(key)) {
      this.cache.delete(key);
    }
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }
    this.cache.set(key, value);
  }
  clear() {
    this.cache.clear();
  }
};
var alignmentCache = new MemoCache(50);
var overlayDataCache = new MemoCache(20);
var qrMatrixCache = new MemoCache(30);
var canvasHashCache = /* @__PURE__ */ new WeakMap();
function getContrastRatio(color1, color2) {
  const getLuminance = (color) => {
    const parsed = parseColor(color);
    const [r, g, b] = [parsed.r, parsed.g, parsed.b].map((c) => {
      c = c / 255;
      return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
    });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  };
  const l1 = getLuminance(color1);
  const l2 = getLuminance(color2);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}
var defaultBrowserCanvasFactory2 = {
  createCanvas: (width, height) => {
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    return Promise.resolve(canvas);
  },
  loadImage: (src) => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = (_e) => reject(new Error(`Failed to load image: ${src}`));
      img.src = src;
    });
  }
};
var QRGenerator = class {
  /**
   * Create a QR generator instance
   * @param {CanvasFactory} [canvasFactory] - Optional canvas factory for non-browser environments
   */
  constructor(canvasFactory = null) {
    this.qrcode = qrcode_default;
    this.canvasFactory = canvasFactory || defaultBrowserCanvasFactory2;
    this._lastMatrix = null;
    this._lastModuleCount = 0;
  }
  /**
   * Get the QR matrix from the last generate() call
   * Returns a 2D boolean array where true = dark module, false = light module
   * @returns {{ matrix: boolean[][], moduleCount: number } | null}
   */
  getLastMatrix() {
    if (!this._lastMatrix) return null;
    return {
      matrix: this._lastMatrix,
      moduleCount: this._lastModuleCount
    };
  }
  /**
   * Store the QR matrix for vector SVG export
   * Reusable helper to avoid code duplication across render methods
   * @param {object} qr - The QR code object with isDark() method
   * @param {number} moduleCount - Number of modules in the QR code
   */
  storeMatrix(qr, moduleCount2) {
    const matrix = [];
    for (let row2 = 0; row2 < moduleCount2; row2++) {
      matrix[row2] = [];
      for (let col2 = 0; col2 < moduleCount2; col2++) {
        matrix[row2][col2] = qr.isDark(row2, col2);
      }
    }
    this._lastMatrix = matrix;
    this._lastModuleCount = moduleCount2;
  }
  /**
   * Create a canvas using the configured factory
   * @param {number} width
   * @param {number} height
   * @returns {Promise<HTMLCanvasElement|object>}
   */
  async createCanvas(width, height) {
    return this.canvasFactory.createCanvas(width, height);
  }
  async loadLibrary() {
  }
  // ============================================
  // UNIFIED PIPELINE HELPERS
  // ============================================
  /**
   * Get the scale factor for a given overlay mode.
   * - Standard modes: scale=1 (module-level rendering)
   * - Dithered/Blue-noise modes: scale=3 (subpixel dithering)
   * - Subpixel modes: scale=2,3,4 (configurable grid)
   * @private
   */
  getScaleFactor(overlayMode, config) {
    switch (overlayMode) {
      case "dithered":
      case "blue-noise":
        return 3;
      // Fixed 3x scale for error diffusion modes
      case "subpixel":
      case "subpixel-size": {
        const gridSizeStr = config?.subpixelGridSize || "3x3";
        return Number.parseInt(gridSizeStr.charAt(0), 10) || 3;
      }
      default:
        return 1;
    }
  }
  /**
   * UNIFIED PIXEL DECISION MATRIX
   * Generates pixel-level decisions for ALL overlay modes.
   * Returns a unified format that the render loop can use consistently.
   *
   * @returns {Object} { matrix: boolean[][], colors: RGB[][], scale: number, overlayData: brightness[][] }
   */
  async generatePixelDecisionMatrix(qr, config, overlayCanvas, moduleCount2) {
    const overlayMode = config.overlayMode;
    const scale = this.getScaleFactor(overlayMode, config);
    const scaledSize = moduleCount2 * scale;
    let effectiveIntensity = config.overlayIntensity ?? 100;
    if (config.maxOverlayIntensityByEcc) {
      const eccLimit = config.maxOverlayIntensityByEcc[config.errorCorrection];
      if (eccLimit !== void 0 && eccLimit < effectiveIntensity) {
        effectiveIntensity = eccLimit;
      }
    }
    const effectiveConfig = { ...config, overlayIntensity: effectiveIntensity };
    if (overlayCanvas === null || overlayCanvas === void 0) {
      const matrix = [];
      const colors = [];
      for (let y = 0; y < scaledSize; y++) {
        matrix[y] = [];
        colors[y] = [];
        for (let x = 0; x < scaledSize; x++) {
          const moduleRow = Math.floor(y / scale);
          const moduleCol = Math.floor(x / scale);
          const isDark = qr.isDark(moduleRow, moduleCol);
          matrix[y][x] = isDark;
          colors[y][x] = isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 };
        }
      }
      return { matrix, colors, scale, overlayData: null, effectiveIntensity };
    }
    switch (overlayMode) {
      case "dithered": {
        const qrResult = generateQR({
          text: config.content,
          ecc: config.errorCorrection,
          version: config.typeNumber || 0,
          scale
        });
        const ditheredResult = await this.applyDitherToMatrix(
          qrResult.matrix,
          qrResult.moduleCount,
          scale,
          overlayCanvas,
          effectiveIntensity,
          config.colorMode || "color",
          config.ditherSerpentine !== false,
          effectiveConfig
        );
        return {
          matrix: ditheredResult.matrix,
          colors: ditheredResult.colors,
          scale,
          overlayData: null,
          effectiveIntensity
        };
      }
      case "blue-noise": {
        let processedOverlay = overlayCanvas;
        if (this.hasPreprocessingOptions(config)) {
          processedOverlay = await this.preprocessOverlay(overlayCanvas, config);
        }
        const blueNoiseResult = await generateBlueNoiseDithered({
          text: config.content,
          ecc: config.errorCorrection,
          version: config.typeNumber || 0,
          scale,
          overlayCanvas: processedOverlay,
          overlayIntensity: effectiveIntensity,
          colorMode: config.colorMode || "color",
          canvasFactory: this.canvasFactory
        });
        return {
          matrix: blueNoiseResult.matrix,
          colors: blueNoiseResult.colors,
          scale,
          overlayData: null,
          effectiveIntensity
        };
      }
      case "subpixel":
      case "subpixel-size": {
        const useHalftoneCenter = overlayMode === "subpixel-size";
        return await this.generateSubpixelMatrix(
          qr,
          config,
          overlayCanvas,
          moduleCount2,
          scale,
          useHalftoneCenter
        );
      }
      case "dither":
      case "extreme": {
        const overlayData = await this.getOverlayData(
          overlayCanvas,
          moduleCount2,
          config.colorMode || "color",
          config.invertImage,
          config.frameIndex || 0,
          effectiveConfig
        );
        let ditherPattern = null;
        let ditherColors = null;
        const useAdvancedDither = config.ditherKind && config.ditherKind !== "true_dither" && config.ditherKind !== "error_diffusion";
        if (useAdvancedDither) {
          try {
            const advResult = await this.applyAdvancedDither(
              overlayCanvas,
              moduleCount2,
              effectiveConfig
            );
            ditherPattern = advResult.matrix;
            ditherColors = advResult.colors;
          } catch (e) {
            console.warn("Advanced dithering failed, falling back to true dither:", e);
            ditherPattern = this.applyTrueDither(
              qr,
              overlayData,
              effectiveConfig,
              overlayMode === "extreme"
            );
          }
        } else {
          ditherPattern = this.applyTrueDither(
            qr,
            overlayData,
            effectiveConfig,
            overlayMode === "extreme"
          );
        }
        const matrix = ditherPattern || [];
        const colors = ditherColors || overlayData.colors || [];
        const normalizedColors = [];
        for (let y = 0; y < moduleCount2; y++) {
          normalizedColors[y] = [];
          for (let x = 0; x < moduleCount2; x++) {
            const c = colors[y]?.[x];
            if (c && typeof c === "object" && "r" in c) {
              normalizedColors[y][x] = c;
            } else if (c && typeof c === "string") {
              const parsed = parseColor(c);
              normalizedColors[y][x] = parsed;
            } else {
              normalizedColors[y][x] = matrix[y]?.[x] ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 };
            }
          }
        }
        return {
          matrix,
          colors: normalizedColors,
          scale: 1,
          overlayData,
          effectiveIntensity
        };
      }
      default: {
        const overlayData = await this.getOverlayData(
          overlayCanvas,
          moduleCount2,
          config.colorMode || "color",
          config.invertImage,
          config.frameIndex || 0,
          effectiveConfig
        );
        const matrix = [];
        const colors = [];
        for (let y = 0; y < moduleCount2; y++) {
          matrix[y] = [];
          colors[y] = [];
          for (let x = 0; x < moduleCount2; x++) {
            const isDark = qr.isDark(y, x);
            matrix[y][x] = isDark;
            const c = overlayData.colors?.[y]?.[x];
            if (c && typeof c === "string") {
              const parsed = parseColor(c);
              colors[y][x] = parsed;
            } else {
              colors[y][x] = isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 };
            }
          }
        }
        return {
          matrix,
          colors,
          scale: 1,
          overlayData,
          effectiveIntensity
        };
      }
    }
  }
  /**
   * UNIFIED OVERLAY PROCESSING
   * Prepares overlay data for ANY overlay mode, returning a unified format
   * that the main render loop can use consistently.
   */
  async prepareUnifiedOverlayData(qr, config, overlayCanvas, moduleCount2) {
    if (!overlayCanvas) {
      return { ditherPattern: null, colors: null, overlayData: null, effectiveIntensity: 100 };
    }
    const overlayMode = config.overlayMode;
    const overlayData = await this.getOverlayData(
      overlayCanvas,
      moduleCount2,
      config.colorMode || "color",
      config.invertImage,
      config.frameIndex || 0,
      config
    );
    let effectiveIntensity = config.overlayIntensity ?? 100;
    if (config.maxOverlayIntensityByEcc) {
      const eccLimit = config.maxOverlayIntensityByEcc[config.errorCorrection];
      if (eccLimit !== void 0 && eccLimit < effectiveIntensity) {
        effectiveIntensity = eccLimit;
      }
    }
    const effectiveConfig = { ...config, overlayIntensity: effectiveIntensity };
    let ditherPattern = null;
    let ditherColors = null;
    if (overlayMode === "dither" || overlayMode === "extreme") {
      const useAdvancedDither = config.ditherKind && config.ditherKind !== "true_dither" && config.ditherKind !== "error_diffusion";
      if (useAdvancedDither) {
        try {
          const advResult = await this.applyAdvancedDither(
            overlayCanvas,
            moduleCount2,
            effectiveConfig
          );
          ditherPattern = advResult.matrix;
          ditherColors = advResult.colors;
        } catch (e) {
          console.warn("Advanced dithering failed, falling back to true dither:", e);
          ditherPattern = this.applyTrueDither(
            qr,
            overlayData,
            effectiveConfig,
            overlayMode === "extreme"
          );
        }
      } else {
        ditherPattern = this.applyTrueDither(
          qr,
          overlayData,
          effectiveConfig,
          overlayMode === "extreme"
        );
      }
    }
    return {
      ditherPattern,
      colors: ditherColors || overlayData.colors,
      overlayData,
      effectiveIntensity
    };
  }
  /**
   * UNIFIED SCALED QR GENERATION
   * Handles ALL scaled overlay modes (dithered, blue-noise, subpixel, subpixel-size)
   * through a single code path with ALL settings applied uniformly.
   */
  async generateScaledQR(qr, config, overlayCanvas, moduleCount2, scale) {
    const pixelData = await this.generatePixelDecisionMatrix(
      qr,
      config,
      overlayCanvas,
      moduleCount2
    );
    const { matrix, colors } = pixelData;
    const scaledSize = matrix.length;
    const quietZoneMin = config.quietZoneMinEnforce === false ? 0 : 4;
    const marginModules = Math.max(quietZoneMin, config.margin);
    const subPixelSize = Math.max(1, Math.round(config.moduleSize / scale));
    const effectiveModuleSize = subPixelSize * scale;
    const frameExtra = config.frameStyle && config.frameStyle !== "none" && config.frameText ? effectiveModuleSize * 4 : 0;
    const marginPx = marginModules * effectiveModuleSize;
    const size = scaledSize * subPixelSize + marginPx * 2 + frameExtra;
    const canvas = await this.createCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    if (!config.transparentBg) {
      ctx.fillStyle = config.bgColor;
      ctx.fillRect(0, 0, size, size);
    }
    this.drawFrameBackground(ctx, size, effectiveModuleSize, marginModules, config);
    const gradientFill = this.createGradientFill(ctx, config, size);
    const useGradient = config.gradient && config.gradient.type !== "none";
    const useColorRendering = overlayCanvas && config.colorMode !== "bw";
    for (let y = 0; y < scaledSize; y++) {
      for (let x = 0; x < scaledSize; x++) {
        const isDark = matrix[y]?.[x];
        const color = colors[y]?.[x];
        if (!(isDark || useColorRendering)) continue;
        const dx = marginPx + x * subPixelSize;
        const dy = marginPx + y * subPixelSize;
        if (useColorRendering && color) {
          if (color.halftone && isDark) {
            ctx.fillStyle = config.bgColor;
            ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
            ctx.fillStyle = useGradient ? gradientFill : config.fgColor;
            const dotSize = subPixelSize * (color.sizeRatio || 1);
            const offset = (subPixelSize - dotSize) / 2;
            ctx.fillRect(dx + offset, dy + offset, dotSize, dotSize);
          } else {
            ctx.fillStyle = `rgb(${color.r},${color.g},${color.b})`;
            ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
          }
        } else if (isDark) {
          ctx.fillStyle = useGradient ? gradientFill : config.fgColor;
          ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
        }
      }
    }
    const shouldDrawFindersFirst = config.preserveFinders !== false || !overlayCanvas;
    const finderPositions = [
      { row: 0, col: 0 },
      // Top-left
      { row: 0, col: moduleCount2 - 7 },
      // Top-right
      { row: moduleCount2 - 7, col: 0 }
      // Bottom-left
    ];
    if (shouldDrawFindersFirst) {
      for (const pos of finderPositions) {
        const x = marginPx + pos.col * effectiveModuleSize;
        const y = marginPx + pos.row * effectiveModuleSize;
        this.drawFinderPatternComplete(ctx, x, y, effectiveModuleSize, config);
      }
    }
    const version = config.typeNumber || Math.ceil((moduleCount2 - 17) / 4);
    if (version >= 2) {
      const alignPositions = this.getAlignmentPositions(version, moduleCount2);
      const alignmentStyle = config.alignmentStyle || "match_finder";
      for (const pos of alignPositions) {
        const centerX = marginPx + (pos.col + 0.5) * effectiveModuleSize;
        const centerY = marginPx + (pos.row + 0.5) * effectiveModuleSize;
        this.drawAlignmentPattern(
          ctx,
          centerX,
          centerY,
          effectiveModuleSize,
          alignmentStyle,
          config
        );
      }
    }
    this.drawFrame(ctx, size, effectiveModuleSize, marginModules, config);
    const syntheticQr = {
      isDark: (row2, col2) => {
        const subRow = row2 * scale + Math.floor(scale / 2);
        const subCol = col2 * scale + Math.floor(scale / 2);
        return matrix[subRow]?.[subCol] ?? false;
      }
    };
    this.storeMatrix(syntheticQr, moduleCount2);
    return canvas;
  }
  /**
   * Generate subpixel matrix for subpixel/subpixel-size modes.
   * Each module becomes NxN pixels where center=QR data, surrounding=image.
   * @private
   */
  async generateSubpixelMatrix(qr, config, overlayCanvas, moduleCount2, scale, useHalftoneCenter = false) {
    const scaledSize = moduleCount2 * scale;
    const matrix = [];
    const colors = [];
    const overlayData = await this.getSubpixelOverlayData(
      overlayCanvas,
      scaledSize,
      config.colorMode || "color",
      config
    );
    const moduleBrightness = await this.getOverlayData(
      overlayCanvas,
      moduleCount2,
      "color",
      false,
      config.frameIndex || 0
    );
    const intensity = (config.overlayIntensity ?? 100) / 100;
    const centerIdx = Math.floor(scale / 2);
    const centerRule = config.subpixelCenterRule || "strict";
    const finderOverride = config.subpixelFinderOverride || "solid";
    const neutralColor = config.subpixelNeutralColor || "#808080";
    const neutralParsed = parseColor(neutralColor);
    for (let moduleRow = 0; moduleRow < moduleCount2; moduleRow++) {
      for (let moduleCol = 0; moduleCol < moduleCount2; moduleCol++) {
        const isDark = qr.isDark(moduleRow, moduleCol);
        const isFinder = isFinderPattern(moduleRow, moduleCol, moduleCount2);
        for (let subRow = 0; subRow < scale; subRow++) {
          for (let subCol = 0; subCol < scale; subCol++) {
            const y = moduleRow * scale + subRow;
            const x = moduleCol * scale + subCol;
            if (!matrix[y]) {
              matrix[y] = [];
              colors[y] = [];
            }
            if (isFinder && finderOverride === "solid") {
              matrix[y][x] = isDark;
              colors[y][x] = isDark ? parseColor(config.fgColor) : parseColor(config.bgColor);
              continue;
            }
            const isCenter = subRow === centerIdx && subCol === centerIdx;
            if (isCenter) {
              const useHalftone = useHalftoneCenter || centerRule === "halftone_center";
              if (useHalftone && isDark) {
                const brightness = moduleBrightness[moduleRow]?.[moduleCol] ?? 0.5;
                const minSize = 0.4;
                const maxSize = 1;
                const sizeRatio = minSize + (1 - brightness) * (maxSize - minSize) * intensity;
                matrix[y][x] = true;
                colors[y][x] = {
                  r: 0,
                  g: 0,
                  b: 0,
                  halftone: true,
                  sizeRatio
                };
              } else {
                matrix[y][x] = isDark;
                colors[y][x] = isDark ? parseColor(config.fgColor) : parseColor(config.bgColor);
              }
            } else {
              const overlayColor = overlayData.colors?.[y]?.[x];
              if (overlayColor && intensity > 0) {
                let parsed;
                if (typeof overlayColor === "string") {
                  parsed = parseColor(overlayColor);
                } else {
                  parsed = overlayColor;
                }
                if (intensity >= 1) {
                  matrix[y][x] = parsed.r * 0.299 + parsed.g * 0.587 + parsed.b * 0.114 < 128;
                  colors[y][x] = parsed;
                } else {
                  const blended = {
                    r: Math.round(neutralParsed.r + (parsed.r - neutralParsed.r) * intensity),
                    g: Math.round(neutralParsed.g + (parsed.g - neutralParsed.g) * intensity),
                    b: Math.round(neutralParsed.b + (parsed.b - neutralParsed.b) * intensity)
                  };
                  matrix[y][x] = blended.r * 0.299 + blended.g * 0.587 + blended.b * 0.114 < 128;
                  colors[y][x] = blended;
                }
              } else if (isDark) {
                const darkened = {
                  r: Math.round(neutralParsed.r * 0.5),
                  g: Math.round(neutralParsed.g * 0.5),
                  b: Math.round(neutralParsed.b * 0.5)
                };
                matrix[y][x] = true;
                colors[y][x] = darkened;
              } else {
                const lightened = {
                  r: Math.round(255 - (255 - neutralParsed.r) * 0.5),
                  g: Math.round(255 - (255 - neutralParsed.g) * 0.5),
                  b: Math.round(255 - (255 - neutralParsed.b) * 0.5)
                };
                matrix[y][x] = false;
                colors[y][x] = lightened;
              }
            }
          }
        }
      }
    }
    return {
      matrix,
      colors,
      scale,
      overlayData: moduleBrightness,
      effectiveIntensity: intensity * 100
    };
  }
  async generate(config, overlayCanvas = null) {
    if (!this.qrcode) {
      await this.loadLibrary();
    }
    let encodingMode = config.encodingMode || "auto";
    const content = config.content || "";
    encodingMode = getCompatibleMode(content, encodingMode);
    let typeNumber = config.typeNumber;
    if (typeNumber === 0) {
      typeNumber = calculateOptimalVersion(config.content, config.errorCorrection, encodingMode);
    }
    let processedOverlayCanvas = overlayCanvas;
    if (overlayCanvas && this.hasGeometricTransforms(config)) {
      processedOverlayCanvas = await this.applyGeometricTransforms(overlayCanvas, config);
    }
    const maskPatternConfig = config.maskPattern;
    const characterEncodingConfig = config.characterEncoding || "default";
    const qrCacheKey = `${config.content}:${config.errorCorrection}:${typeNumber}:${encodingMode}:${maskPatternConfig}:${characterEncodingConfig}`;
    let qr;
    let moduleCount2;
    const cachedQr = qrMatrixCache.get(qrCacheKey);
    if (cachedQr) {
      qr = cachedQr.qr;
      moduleCount2 = cachedQr.moduleCount;
    } else {
      qr = this.qrcode(typeNumber, config.errorCorrection);
      if (characterEncodingConfig === "utf8") {
        qrcode_default.stringToBytes = (s) => {
          const encoder = new TextEncoder();
          return Array.from(encoder.encode(s));
        };
      } else if (characterEncodingConfig === "shift-jis") {
        qrcode_default.stringToBytes = createShiftJISEncoder();
      } else {
        qrcode_default.stringToBytes = defaultStringToBytes;
      }
      const modeMap = {
        numeric: "Numeric",
        alphanumeric: "Alphanumeric",
        byte: "Byte",
        kanji: "Kanji",
        auto: void 0
      };
      const libraryMode = modeMap[encodingMode] || void 0;
      qr.addData(config.content, libraryMode);
      const maskPattern = typeof maskPatternConfig === "number" && maskPatternConfig >= 0 && maskPatternConfig <= 7 ? maskPatternConfig : void 0;
      qr.make(maskPattern);
      moduleCount2 = qr.getModuleCount();
      qrcode_default.stringToBytes = defaultStringToBytes;
      qrMatrixCache.set(qrCacheKey, { qr, moduleCount: moduleCount2 });
    }
    const scale = this.getScaleFactor(config.overlayMode, config);
    if (scale > 1 && processedOverlayCanvas) {
      return await this.generateScaledQR(qr, config, processedOverlayCanvas, moduleCount2, scale);
    }
    const { ditherPattern, overlayData, effectiveIntensity } = await this.prepareUnifiedOverlayData(
      qr,
      { ...config, typeNumber },
      processedOverlayCanvas,
      moduleCount2
    );
    const moduleSize = config.moduleSize;
    const quietZoneMin = config.quietZoneMinEnforce === false ? 0 : 4;
    const margin = Math.max(config.margin, quietZoneMin);
    const frameExtra = config.frameStyle && config.frameStyle !== "none" && config.frameText ? moduleSize * 4 : 0;
    const size = moduleCount2 * moduleSize + margin * 2 * moduleSize + frameExtra;
    const canvas = await this.createCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    if (!config.transparentBg) {
      ctx.fillStyle = config.bgColor;
      ctx.fillRect(0, 0, size, size);
    }
    this.drawFrameBackground(ctx, size, moduleSize, margin, config);
    const version = config.typeNumber || Math.ceil((moduleCount2 - 17) / 4);
    const gradientFill = this.createGradientFill(ctx, config, size);
    const useGradient = config.gradient && config.gradient.type !== "none";
    const cornerRadius = config.cornerRadius || 0;
    const dotRotation = config.dotRotationDeg || 0;
    const alignmentStyle = config.alignmentStyle || "match_finder";
    const timingStyle = config.timingStyle || "match_module";
    const drawnFinderPatterns = /* @__PURE__ */ new Set();
    const drawnAlignmentPatterns = /* @__PURE__ */ new Set();
    const shouldDrawFindersFirst = config.preserveFinders !== false || !overlayData;
    const finderPositions = [
      { row: 0, col: 0 },
      // Top-left
      { row: 0, col: moduleCount2 - 7 },
      // Top-right
      { row: moduleCount2 - 7, col: 0 }
      // Bottom-left
    ];
    if (shouldDrawFindersFirst) {
      for (const pos of finderPositions) {
        const x = (pos.col + margin) * moduleSize;
        const y = (pos.row + margin) * moduleSize;
        this.drawFinderPatternComplete(ctx, x, y, moduleSize, config);
        for (let r = pos.row; r < pos.row + 7; r++) {
          for (let c = pos.col; c < pos.col + 7; c++) {
            drawnFinderPatterns.add(`${r},${c}`);
          }
        }
      }
    }
    const shouldDrawAlignmentFirst = config.preserveAlignment !== false || !overlayData;
    if (version >= 2 && shouldDrawAlignmentFirst) {
      const alignPositions = this.getAlignmentPositions(version, moduleCount2);
      for (const pos of alignPositions) {
        const centerX = (pos.col + margin) * moduleSize + moduleSize / 2;
        const centerY = (pos.row + margin) * moduleSize + moduleSize / 2;
        this.drawAlignmentPattern(ctx, centerX, centerY, moduleSize, alignmentStyle, config);
        for (let r = pos.row - 2; r <= pos.row + 2; r++) {
          for (let c = pos.col - 2; c <= pos.col + 2; c++) {
            drawnAlignmentPatterns.add(`${r},${c}`);
          }
        }
      }
    }
    for (let row2 = 0; row2 < moduleCount2; row2++) {
      for (let col2 = 0; col2 < moduleCount2; col2++) {
        if (drawnFinderPatterns.has(`${row2},${col2}`)) continue;
        if (drawnAlignmentPatterns.has(`${row2},${col2}`)) continue;
        const isDark = ditherPattern ? ditherPattern[row2][col2] : qr.isDark(row2, col2);
        const x = (col2 + margin) * moduleSize;
        const y = (row2 + margin) * moduleSize;
        const isFinder = isFinderPattern(row2, col2, moduleCount2);
        const isTiming = isTimingPattern(row2, col2, moduleCount2);
        const isFormatInfo = this.isFormatInfo(row2, col2, moduleCount2);
        const isVersionInfo = this.isVersionInfo(row2, col2, moduleCount2, version);
        const isInAlignmentSet = drawnAlignmentPatterns.has(`${row2},${col2}`);
        const protectFormat = config.protectFormatInfo;
        const protectVersion = config.protectVersionInfo;
        const applyOverlay = overlayData && !(config.preserveFinders && isFinder) && !(config.preserveTiming && isTiming) && !(config.preserveAlignment && isInAlignmentSet) && !(protectFormat && isFormatInfo) && !(protectVersion && isVersionInfo);
        let moduleColor = isDark ? config.fgColor : config.bgColor;
        let moduleSizeModifier = 1;
        let moduleOpacity = 1;
        let waveOffsetX = 0;
        let waveOffsetY = 0;
        let drawOutlineOnly = false;
        let useHalftoneRendering = false;
        let halftoneBrightness = 0.5;
        let shouldDrawCell = isDark;
        if (applyOverlay) {
          const brightness = overlayData[row2][col2];
          switch (config.overlayMode) {
            case "halftone":
              if (isDark) {
                if (config.halftoneCell || config.halftoneDotShape || config.brightnessCurve) {
                  useHalftoneRendering = true;
                  halftoneBrightness = brightness;
                } else {
                  const intensity = effectiveIntensity / 100;
                  const minSize = 0.3;
                  const maxSize = 1;
                  moduleSizeModifier = minSize + (1 - brightness) * (maxSize - minSize) * intensity + (1 - intensity) * (maxSize - minSize) / 2;
                }
              }
              break;
            case "blend":
              if (isDark) {
                const blendColor = overlayData.colors?.[row2]?.[col2];
                if (blendColor) {
                  const blendAmount = effectiveIntensity / 100;
                  moduleColor = blendColors(config.fgColor, blendColor, blendAmount);
                }
              }
              break;
            case "brightness":
              if (isDark) {
                const threshold = (100 - effectiveIntensity) / 100;
                if (brightness > threshold) {
                  moduleOpacity = 0;
                }
              }
              break;
            case "gapfill":
              if (isDark) {
                moduleColor = config.fgColor;
              } else {
                const gapColor = overlayData.colors?.[row2]?.[col2];
                if (gapColor) {
                  const fadeAmount = config.overlayIntensity / 100 * 0.4;
                  moduleColor = blendColors(config.bgColor, gapColor, fadeAmount);
                  shouldDrawCell = true;
                }
              }
              break;
            case "pixelate":
              if (isDark) {
                const blockSize = 3;
                const blockRow = Math.floor(row2 / blockSize) * blockSize;
                const blockCol = Math.floor(col2 / blockSize) * blockSize;
                let avgR = 0, avgG = 0, avgB = 0, pixCount = 0;
                for (let br = 0; br < blockSize && blockRow + br < moduleCount2; br++) {
                  for (let bc = 0; bc < blockSize && blockCol + bc < moduleCount2; bc++) {
                    const c = overlayData.colors?.[blockRow + br]?.[blockCol + bc];
                    if (c) {
                      const parsed = parseColor(c);
                      avgR += parsed.r;
                      avgG += parsed.g;
                      avgB += parsed.b;
                      pixCount++;
                    }
                  }
                }
                if (pixCount > 0) {
                  avgR = Math.round(avgR / pixCount);
                  avgG = Math.round(avgG / pixCount);
                  avgB = Math.round(avgB / pixCount);
                  const blockColor = `rgb(${avgR},${avgG},${avgB})`;
                  const pixBlendAmt = config.overlayIntensity / 100;
                  moduleColor = blendColors(config.fgColor, blockColor, pixBlendAmt);
                }
              }
              break;
            case "duotone":
              if (isDark) {
                const duotoneArr = config.duotoneColors || [];
                const shadowColor = duotoneArr[0] || config.fgColor;
                const highlightColor = duotoneArr[1] || null;
                const intensity = config.overlayIntensity / 100;
                if (brightness > 0.5 && highlightColor) {
                  moduleColor = blendColors(
                    config.fgColor,
                    highlightColor,
                    intensity * (brightness - 0.5) * 2
                  );
                } else if (brightness > 0.5) {
                  const fgParsed = parseColor(config.fgColor);
                  const lightR = Math.min(255, fgParsed.r + 80);
                  const lightG = Math.min(255, fgParsed.g + 80);
                  const lightB = Math.min(255, fgParsed.b + 80);
                  moduleColor = `rgb(${lightR},${lightG},${lightB})`;
                } else {
                  moduleColor = blendColors(
                    config.fgColor,
                    shadowColor,
                    intensity * (0.5 - brightness) * 2
                  );
                }
              }
              break;
            case "outline":
              if (isDark) {
                drawOutlineOnly = true;
                const outlineColor = overlayData.colors?.[row2]?.[col2];
                if (outlineColor) {
                  const outlineBlend = config.overlayIntensity / 100;
                  moduleColor = blendColors(config.fgColor, outlineColor, outlineBlend);
                }
              }
              break;
            case "wave":
              if (isDark) {
                const waveAmt = (1 - brightness) * (config.overlayIntensity / 100) * 3;
                waveOffsetX = Math.sin(row2 * 0.5) * waveAmt;
                waveOffsetY = Math.cos(col2 * 0.5) * waveAmt;
              }
              break;
            case "mosaic": {
              shouldDrawCell = true;
              const mosaicColor = overlayData.colors?.[row2]?.[col2];
              if (mosaicColor) {
                const intensity = effectiveIntensity / 100;
                if (isDark) {
                  const parsed = parseColor(mosaicColor);
                  const darkFactor = 0.7;
                  moduleColor = `rgb(${Math.round(parsed.r * darkFactor)},${Math.round(parsed.g * darkFactor)},${Math.round(parsed.b * darkFactor)})`;
                } else {
                  const parsed = parseColor(mosaicColor);
                  const lightFactor = 0.4 + (1 - intensity) * 0.4;
                  const lightR = Math.round(255 - (255 - parsed.r) * lightFactor);
                  const lightG = Math.round(255 - (255 - parsed.g) * lightFactor);
                  const lightB = Math.round(255 - (255 - parsed.b) * lightFactor);
                  moduleColor = `rgb(${lightR},${lightG},${lightB})`;
                }
              }
              break;
            }
          }
        }
        if (shouldDrawCell && moduleOpacity > 0) {
          ctx.save();
          ctx.globalAlpha = moduleOpacity;
          let finalModuleColor = moduleColor;
          if (isDark && config.perModuleColorMode && config.perModuleColorMode !== "solid" && overlayData) {
            finalModuleColor = this.applyPerModuleColor(
              config.perModuleColorMode,
              moduleColor,
              overlayData,
              row2,
              col2,
              moduleCount2,
              config
            );
          }
          const paletteBrightness = overlayData?.[row2]?.[col2] ?? 0.5;
          if (isDark && config.palette && config.palette.length > 0) {
            finalModuleColor = this.applyPaletteColor(
              row2,
              col2,
              moduleCount2,
              paletteBrightness,
              config.palette,
              config
            );
          }
          if (isDark && config.contrastGuard && config.minContrastRatio) {
            finalModuleColor = this.ensureContrast(
              finalModuleColor,
              config.bgColor,
              config.minContrastRatio
            );
          }
          if (isDark && useGradient) {
            ctx.fillStyle = gradientFill;
          } else {
            ctx.fillStyle = finalModuleColor;
          }
          let gap = config.moduleGap ? moduleSize * config.moduleGap / 100 : 0;
          const gapMode = config.gapMode || "none";
          let strokeWidth = 0;
          if (gapMode === "inset") {
            gap = Math.max(gap, moduleSize * 0.1);
          } else if (gapMode === "stroke") {
            strokeWidth = Math.max(1, moduleSize * 0.15);
            gap = strokeWidth;
          } else if (gapMode === "negative_space") {
            gap = Math.max(gap, moduleSize * 0.2);
          }
          const adjustedSize = (moduleSize - gap) * moduleSizeModifier;
          const offset = (moduleSize - adjustedSize) / 2;
          let drawX = x + offset + waveOffsetX;
          let drawY = y + offset + waveOffsetY;
          if (config.moduleJitterPx && config.moduleJitterPx > 0) {
            const jitterSeed = (row2 * 31 + col2 * 17 + (config.frameIndex || 0) * 13) % 1e3;
            const jitterX = (jitterSeed % 100 / 100 - 0.5) * 2 * config.moduleJitterPx;
            const jitterY = (jitterSeed * 7 % 100 / 100 - 0.5) * 2 * config.moduleJitterPx;
            drawX += jitterX;
            drawY += jitterY;
          }
          const pixelSnap = config.pixelSnap || "floor";
          if (pixelSnap === "floor") {
            drawX = Math.floor(drawX);
            drawY = Math.floor(drawY);
          } else if (pixelSnap === "round") {
            drawX = Math.round(drawX);
            drawY = Math.round(drawY);
          } else if (pixelSnap === "ceil") {
            drawX = Math.ceil(drawX);
            drawY = Math.ceil(drawY);
          }
          if (drawOutlineOnly || gapMode === "stroke" && isDark) {
            ctx.strokeStyle = finalModuleColor;
            ctx.lineWidth = strokeWidth || 1;
            ctx.strokeRect(
              drawX + ctx.lineWidth / 2,
              drawY + ctx.lineWidth / 2,
              adjustedSize - ctx.lineWidth,
              adjustedSize - ctx.lineWidth
            );
          } else if (useHalftoneRendering && isDark) {
            this.drawHalftoneModule(ctx, drawX, drawY, adjustedSize, halftoneBrightness, config);
          } else if (isTiming) {
            this.drawTimingModule(ctx, drawX, drawY, adjustedSize, timingStyle, config);
          } else {
            this.drawModule(ctx, drawX, drawY, adjustedSize, config.moduleStyle, {
              cornerRadius,
              rotation: dotRotation
            });
          }
          ctx.restore();
        }
      }
    }
    if (processedOverlayCanvas && config.overlayMode === "center") {
      this.drawCenterLogo(ctx, processedOverlayCanvas, size, config.logoSize);
    }
    this.drawFrame(ctx, size, moduleSize, margin, config);
    this.storeMatrix(qr, moduleCount2);
    return canvas;
  }
  /**
   * Check if a module is part of format information area
   */
  isFormatInfo(row2, col2, moduleCount2) {
    if (row2 === 8 && (col2 <= 8 || col2 >= moduleCount2 - 8)) return true;
    if (col2 === 8 && (row2 <= 8 || row2 >= moduleCount2 - 7)) return true;
    return false;
  }
  /**
   * Check if a module is part of version information area (version 7+)
   */
  isVersionInfo(row2, col2, moduleCount2, version) {
    if (version < 7) return false;
    if (row2 >= moduleCount2 - 11 && row2 <= moduleCount2 - 9 && col2 <= 5) return true;
    if (col2 >= moduleCount2 - 11 && col2 <= moduleCount2 - 9 && row2 <= 5) return true;
    return false;
  }
  /**
   * Get the center position of an alignment pattern if this module is part of one
   */
  getAlignmentCenter(row2, col2, moduleCount2, version) {
    if (version < 2) return null;
    const positions = this.getAlignmentPositions(version, moduleCount2);
    for (const pos of positions) {
      if (Math.abs(row2 - pos.row) <= 2 && Math.abs(col2 - pos.col) <= 2) {
        return pos;
      }
    }
    return null;
  }
  /**
   * Get alignment pattern positions with caching
   * Uses qr-core's getAlignmentPatternCenters but adds caching layer
   */
  getAlignmentPositions(version, moduleCount2) {
    if (version < 2) return [];
    const cacheKey = `${version}:${moduleCount2}`;
    const cached = alignmentCache.get(cacheKey);
    if (cached !== void 0) {
      return cached;
    }
    const positions = getAlignmentPatternCenters(version, moduleCount2);
    alignmentCache.set(cacheKey, positions);
    return positions;
  }
  applyTrueDither(qr, overlayData, config, extremeMode = false) {
    const moduleCount2 = qr.getModuleCount();
    const version = config.typeNumber || Math.ceil((moduleCount2 - 17) / 4);
    const eccAware = config.eccAwareEnabled === true;
    let totalModifiedCount = 0;
    const seed = config.seed ?? this.hashString(config.content || "");
    const seededRandom = this.createSeededRandom(seed);
    const modifiedPattern = [];
    for (let row2 = 0; row2 < moduleCount2; row2++) {
      modifiedPattern[row2] = [];
      for (let col2 = 0; col2 < moduleCount2; col2++) {
        modifiedPattern[row2][col2] = qr.isDark(row2, col2);
      }
    }
    let totalDataModules = 0;
    for (let row2 = 0; row2 < moduleCount2; row2++) {
      for (let col2 = 0; col2 < moduleCount2; col2++) {
        if (!isStructuralModule(row2, col2, moduleCount2, version)) {
          totalDataModules++;
        }
      }
    }
    if (extremeMode) {
      for (let row2 = 0; row2 < moduleCount2; row2++) {
        for (let col2 = 0; col2 < moduleCount2; col2++) {
          if (isFinderPattern(row2, col2, moduleCount2)) continue;
          const brightness = overlayData[row2]?.[col2] ?? 0.5;
          const intensity = config.overlayIntensity / 100;
          const desiredDark = brightness < 0.5;
          if (eccAware && desiredDark !== modifiedPattern[row2][col2]) {
            if (!this.isEccSafeToModify(
              row2,
              col2,
              moduleCount2,
              version,
              config,
              totalModifiedCount,
              totalDataModules
            )) {
              continue;
            }
            totalModifiedCount++;
          }
          if (intensity >= 1 || seededRandom() < intensity) {
            modifiedPattern[row2][col2] = desiredDark;
          }
        }
      }
    } else {
      const ecCapacity = { L: 0.07, M: 0.15, Q: 0.25, H: 0.3 };
      const maxFlipRatio = ecCapacity[config.errorCorrection] || 0.25;
      const intensity = config.overlayIntensity / 100;
      let totalDataModules2 = 0;
      const flipCandidates = [];
      for (let row2 = 0; row2 < moduleCount2; row2++) {
        for (let col2 = 0; col2 < moduleCount2; col2++) {
          if (isStructuralModule(row2, col2, moduleCount2, version)) continue;
          totalDataModules2++;
          const currentState = qr.isDark(row2, col2);
          const brightness = overlayData[row2]?.[col2] ?? 0.5;
          const desiredState = brightness < 0.5;
          if (currentState !== desiredState) {
            flipCandidates.push({
              row: row2,
              col: col2,
              score: Math.abs(brightness - 0.5),
              desiredState
            });
          }
        }
      }
      flipCandidates.sort((a, b) => b.score - a.score);
      const maxFlips = Math.floor(totalDataModules2 * maxFlipRatio * intensity);
      for (let i2 = 0; i2 < Math.min(flipCandidates.length, maxFlips); i2++) {
        const c = flipCandidates[i2];
        modifiedPattern[c.row][c.col] = c.desiredState;
      }
    }
    return modifiedPattern;
  }
  /**
   * Create a simple seeded PRNG (mulberry32)
   * Returns a function that generates deterministic pseudo-random numbers [0, 1)
   * @private
   */
  createSeededRandom(seed) {
    let state = seed >>> 0;
    return () => {
      state = state + 1831565813 >>> 0;
      let t = state;
      t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61);
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  /**
   * Simple string hash function (djb2)
   * @private
   */
  hashString(str) {
    let hash = 5381;
    for (let i2 = 0; i2 < str.length; i2++) {
      hash = (hash << 5) + hash + (str.codePointAt(i2) ?? 0);
      hash = hash >>> 0;
    }
    return hash;
  }
  /**
   * Hash canvas content for cache key disambiguation
   * Uses a downscaled 32x32 canvas for speed (avoids full-resolution getImageData)
   * Results are cached in a WeakMap to avoid re-hashing the same canvas
   * @private
   */
  async hashCanvasContent(canvas) {
    const cachedHash = canvasHashCache.get(canvas);
    if (cachedHash !== void 0) {
      return cachedHash;
    }
    try {
      const hashSize = 32;
      const hashCanvas = typeof document !== "undefined" ? (() => {
        const c = document.createElement("canvas");
        c.width = hashSize;
        c.height = hashSize;
        return c;
      })() : await this.createCanvas(hashSize, hashSize);
      const hashCtx = hashCanvas.getContext("2d");
      hashCtx.drawImage(canvas, 0, 0, hashSize, hashSize);
      const imageData = hashCtx.getImageData(0, 0, hashSize, hashSize);
      const data = imageData.data;
      let hash = 5381;
      for (let i2 = 0; i2 < data.length; i2 += 4) {
        hash = (hash << 5) + hash + data[i2];
        hash = (hash << 5) + hash + data[i2 + 1];
        hash = (hash << 5) + hash + data[i2 + 2];
        hash = hash >>> 0;
      }
      const hashStr = hash.toString(16);
      canvasHashCache.set(canvas, hashStr);
      return hashStr;
    } catch (error_) {
      console.warn("Canvas hashing failed:", error_);
      return `${canvas.width}x${canvas.height}`;
    }
  }
  /**
   * Draw a single module with support for style, corner radius, and rotation
   */
  drawModule(ctx, x, y, size, style, options = {}) {
    const { cornerRadius = 0, rotation = 0 } = options;
    const padding = size * 0.05;
    const innerSize = size - padding * 2;
    const radiusPercent = cornerRadius / 100;
    const maxRadius = innerSize / 2;
    const actualRadius = maxRadius * radiusPercent;
    ctx.save();
    if (rotation !== 0) {
      const centerX = x + size / 2;
      const centerY = y + size / 2;
      ctx.translate(centerX, centerY);
      ctx.rotate(rotation * Math.PI / 180);
      ctx.translate(-centerX, -centerY);
    }
    switch (style) {
      case "rounded": {
        const roundedRadius = actualRadius > 0 ? actualRadius : size * 0.3;
        this.roundRect(ctx, x + padding, y + padding, innerSize, innerSize, roundedRadius);
        ctx.fill();
        break;
      }
      case "dots":
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, innerSize / 2, 0, Math.PI * 2);
        ctx.fill();
        break;
      case "diamond":
        ctx.beginPath();
        ctx.moveTo(x + size / 2, y + padding);
        ctx.lineTo(x + size - padding, y + size / 2);
        ctx.lineTo(x + size / 2, y + size - padding);
        ctx.lineTo(x + padding, y + size / 2);
        ctx.closePath();
        ctx.fill();
        break;
      case "connected":
        if (actualRadius > 0) {
          this.roundRect(ctx, x, y, size, size, actualRadius);
          ctx.fill();
        } else {
          ctx.fillRect(x, y, size, size);
        }
        break;
      default:
        if (actualRadius > 0) {
          this.roundRect(ctx, x + padding, y + padding, innerSize, innerSize, actualRadius);
          ctx.fill();
        } else {
          ctx.fillRect(x + padding, y + padding, innerSize, innerSize);
        }
        break;
    }
    ctx.restore();
  }
  /**
   * Draw a single finder pattern module
   */
  drawFinderModule(ctx, x, y, size, style, cornerRadius = 0) {
    const radiusPercent = cornerRadius / 100;
    const maxRadius = size / 2;
    const actualRadius = maxRadius * radiusPercent;
    switch (style) {
      case "rounded": {
        const roundedRadius = actualRadius > 0 ? actualRadius : size * 0.2;
        this.roundRect(ctx, x, y, size, size, roundedRadius);
        ctx.fill();
        break;
      }
      case "circle":
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.fill();
        break;
      default:
        if (actualRadius > 0) {
          this.roundRect(ctx, x, y, size, size, actualRadius);
          ctx.fill();
        } else {
          ctx.fillRect(x, y, size, size);
        }
        break;
    }
  }
  /**
   * Draw a complete finder pattern (eye) with outer and inner styles
   */
  drawFinderPatternComplete(ctx, centerX, centerY, moduleSize, config) {
    const outerStyle = config.eyeOuterStyle || config.finderStyle || "square";
    const innerStyle = config.eyeInnerStyle || config.finderStyle || "square";
    const scale = (config.eyeScale || 100) / 100;
    const cornerRadius = config.cornerRadius || 0;
    const outerSize = 7 * moduleSize * scale;
    const middleSize = 5 * moduleSize * scale;
    const innerSize = 3 * moduleSize * scale;
    const outerOffset = (7 * moduleSize - outerSize) / 2;
    const x = centerX + outerOffset;
    const y = centerY + outerOffset;
    ctx.fillStyle = config.fgColor;
    this.drawFinderModule(ctx, x, y, outerSize, outerStyle, cornerRadius);
    ctx.fillStyle = config.bgColor;
    const middleOffset = (outerSize - middleSize) / 2;
    this.drawFinderModule(
      ctx,
      x + middleOffset,
      y + middleOffset,
      middleSize,
      outerStyle,
      cornerRadius
    );
    ctx.fillStyle = config.fgColor;
    const innerOffset = (outerSize - innerSize) / 2;
    this.drawFinderModule(
      ctx,
      x + innerOffset,
      y + innerOffset,
      innerSize,
      innerStyle,
      cornerRadius
    );
  }
  /**
   * Draw an alignment pattern with specified style
   */
  drawAlignmentPattern(ctx, centerX, centerY, moduleSize, style, config) {
    const cornerRadius = config.cornerRadius || 0;
    const outerSize = 5 * moduleSize;
    const middleSize = 3 * moduleSize;
    const innerSize = 1 * moduleSize;
    const x = centerX - outerSize / 2;
    const y = centerY - outerSize / 2;
    const effectiveStyle = style === "match_finder" ? config.finderStyle || "square" : style;
    ctx.fillStyle = config.fgColor;
    this.drawFinderModule(ctx, x, y, outerSize, effectiveStyle, cornerRadius);
    ctx.fillStyle = config.bgColor;
    const middleX = centerX - middleSize / 2;
    const middleY = centerY - middleSize / 2;
    this.drawFinderModule(ctx, middleX, middleY, middleSize, effectiveStyle, cornerRadius);
    ctx.fillStyle = config.fgColor;
    const innerX = centerX - innerSize / 2;
    const innerY = centerY - innerSize / 2;
    this.drawFinderModule(ctx, innerX, innerY, innerSize, effectiveStyle, cornerRadius);
  }
  /**
   * Draw timing pattern with specified style
   */
  drawTimingModule(ctx, x, y, size, style, config) {
    const cornerRadius = config.cornerRadius || 0;
    const effectiveStyle = style === "match_module" ? config.moduleStyle || "square" : style;
    switch (effectiveStyle) {
      case "solid":
        ctx.fillRect(x, y, size, size);
        break;
      case "dashed": {
        const dashSize = size * 0.7;
        const offset = (size - dashSize) / 2;
        ctx.fillRect(x + offset, y + offset, dashSize, dashSize);
        break;
      }
      default:
        this.drawModule(ctx, x, y, size, effectiveStyle, { cornerRadius });
    }
  }
  /**
   * Create a gradient fill style based on config
   */
  createGradientFill(ctx, config, size) {
    if (!config.gradient || config.gradient.type === "none") {
      return config.fgColor;
    }
    const { type, stops, centerX = 0.5, centerY = 0.5 } = config.gradient;
    const angle = config.gradient.angle || 0;
    let gradient;
    switch (type) {
      case "linear": {
        const angleRad = angle * Math.PI / 180;
        const x1 = size / 2 - Math.cos(angleRad) * size / 2;
        const y1 = size / 2 - Math.sin(angleRad) * size / 2;
        const x2 = size / 2 + Math.cos(angleRad) * size / 2;
        const y2 = size / 2 + Math.sin(angleRad) * size / 2;
        gradient = ctx.createLinearGradient(x1, y1, x2, y2);
        break;
      }
      case "radial": {
        const cx = size * (centerX || 0.5);
        const cy = size * (centerY || 0.5);
        const radius = size * 0.7;
        gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
        break;
      }
      case "conic": {
        const cx = size * (centerX || 0.5);
        const cy = size * (centerY || 0.5);
        gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, size * 0.7);
        break;
      }
      default:
        return config.fgColor;
    }
    if (stops && stops.length > 0) {
      for (const stop of stops) {
        gradient.addColorStop(stop.pos, stop.color);
      }
    } else {
      gradient.addColorStop(0, config.fgColor);
      gradient.addColorStop(1, config.bgColor);
    }
    return gradient;
  }
  /**
   * Draw frame background (sticker) BEFORE QR modules
   * This must be called before drawing QR content so the background is behind
   */
  drawFrameBackground(ctx, size, moduleSize, margin, config) {
    const frameStyle = config.frameStyle;
    if (frameStyle !== "sticker") return;
    const frameText = config.frameText || "";
    const qrSize = size - margin * 2 * moduleSize - (frameText ? moduleSize * 4 : 0);
    const qrStart = margin * moduleSize;
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0.2)";
    ctx.shadowBlur = moduleSize * 2;
    ctx.shadowOffsetX = moduleSize * 0.5;
    ctx.shadowOffsetY = moduleSize * 0.5;
    ctx.fillStyle = config.bgColor;
    const stickerPadding = moduleSize * 1.5;
    this.roundRect(
      ctx,
      qrStart - stickerPadding,
      qrStart - stickerPadding,
      qrSize + stickerPadding * 2,
      qrSize + stickerPadding * 2 + (frameText ? moduleSize * 4 : 0),
      moduleSize * 3
    );
    ctx.fill();
    ctx.shadowColor = "transparent";
    ctx.restore();
  }
  /**
   * Draw a decorative frame around the QR code
   * For sticker style, only draws the text (background is drawn by drawFrameBackground)
   */
  drawFrame(ctx, size, moduleSize, margin, config) {
    const frameStyle = config.frameStyle;
    if (!frameStyle || frameStyle === "none") return;
    const frameText = config.frameText || "";
    const qrSize = size - margin * 2 * moduleSize - (frameText ? moduleSize * 4 : 0);
    const qrStart = margin * moduleSize;
    ctx.save();
    switch (frameStyle) {
      case "rounded_frame": {
        ctx.strokeStyle = config.fgColor;
        ctx.lineWidth = moduleSize * 0.5;
        const frameMargin = moduleSize;
        this.roundRect(
          ctx,
          qrStart - frameMargin,
          qrStart - frameMargin,
          qrSize + frameMargin * 2,
          qrSize + frameMargin * 2 + (frameText ? moduleSize * 3 : 0),
          moduleSize * 2
        );
        ctx.stroke();
        break;
      }
      case "sticker": {
        break;
      }
      case "tag": {
        ctx.fillStyle = config.fgColor;
        const tagPadding = moduleSize;
        const tagWidth = qrSize + tagPadding * 2;
        const tagHeight = qrSize + tagPadding * 2 + (frameText ? moduleSize * 4 : 0);
        const tagX = qrStart - tagPadding;
        const tagY = qrStart - tagPadding;
        ctx.beginPath();
        ctx.moveTo(tagX + moduleSize, tagY);
        ctx.lineTo(tagX + tagWidth - moduleSize, tagY);
        ctx.quadraticCurveTo(tagX + tagWidth, tagY, tagX + tagWidth, tagY + moduleSize);
        ctx.lineTo(tagX + tagWidth, tagY + tagHeight - moduleSize);
        ctx.quadraticCurveTo(
          tagX + tagWidth,
          tagY + tagHeight,
          tagX + tagWidth - moduleSize,
          tagY + tagHeight
        );
        ctx.lineTo(tagX + moduleSize, tagY + tagHeight);
        ctx.quadraticCurveTo(tagX, tagY + tagHeight, tagX, tagY + tagHeight - moduleSize);
        ctx.lineTo(tagX, tagY + moduleSize);
        ctx.quadraticCurveTo(tagX, tagY, tagX + moduleSize, tagY);
        ctx.closePath();
        ctx.stroke();
        break;
      }
    }
    if (frameText) {
      ctx.fillStyle = config.fgColor;
      ctx.font = `bold ${moduleSize * 2}px Arial, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      const textY = qrStart + qrSize + moduleSize * 1.5;
      ctx.fillText(frameText, size / 2, textY);
    }
    ctx.restore();
  }
  roundRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }
  /**
   * Apply preprocessing (brightness, contrast, gamma, saturation, hue rotation, invert,
   * posterize, threshold, blur, sharpen, edge detection) to ImageData.
   * This is a shared helper used by all overlay data loading methods.
   * @private
   */
  preprocessImageData(imageData, config, invertImage = false) {
    const data = imageData.data;
    const brightness_adj = config.overlayBrightness || 0;
    const contrast_adj = config.overlayContrast || 0;
    const gamma_adj = config.overlayGamma || 1;
    const saturation_adj = config.overlaySaturation || 0;
    const hueRotate_adj = config.overlayHueRotate || 0;
    const posterize_levels = config.overlayPosterize || 0;
    const threshold_val = config.overlayThreshold;
    const blur_radius = config.overlayBlur || 0;
    const sharpen_amt = config.overlaySharpen || 0;
    const edge_detect = config.overlayEdgeDetect || "off";
    const needsPerPixelPreprocess = brightness_adj !== 0 || contrast_adj !== 0 || gamma_adj !== 1 || saturation_adj !== 0 || hueRotate_adj !== 0 || posterize_levels >= 2 || threshold_val !== void 0 && threshold_val !== 128 && edge_detect === "off" || invertImage;
    const needsConvolutionFilters = blur_radius > 0 || sharpen_amt > 0 || edge_detect === "sobel" || edge_detect === "canny";
    if (!(needsPerPixelPreprocess || needsConvolutionFilters)) return imageData;
    if (needsPerPixelPreprocess) {
      for (let i2 = 0; i2 < data.length; i2 += 4) {
        let r = data[i2];
        let g = data[i2 + 1];
        let b = data[i2 + 2];
        if (brightness_adj !== 0) {
          const factor = brightness_adj * 2.55;
          r = Math.max(0, Math.min(255, r + factor));
          g = Math.max(0, Math.min(255, g + factor));
          b = Math.max(0, Math.min(255, b + factor));
        }
        if (contrast_adj !== 0) {
          const factor = 259 * (contrast_adj + 255) / (255 * (259 - contrast_adj));
          r = Math.max(0, Math.min(255, factor * (r - 128) + 128));
          g = Math.max(0, Math.min(255, factor * (g - 128) + 128));
          b = Math.max(0, Math.min(255, factor * (b - 128) + 128));
        }
        if (gamma_adj !== 1) {
          const gammaCorrection = 1 / gamma_adj;
          r = 255 * (r / 255) ** gammaCorrection;
          g = 255 * (g / 255) ** gammaCorrection;
          b = 255 * (b / 255) ** gammaCorrection;
        }
        if (saturation_adj !== 0) {
          const gray = r * 0.299 + g * 0.587 + b * 0.114;
          const factor = (saturation_adj + 100) / 100;
          r = Math.max(0, Math.min(255, gray + factor * (r - gray)));
          g = Math.max(0, Math.min(255, gray + factor * (g - gray)));
          b = Math.max(0, Math.min(255, gray + factor * (b - gray)));
        }
        if (hueRotate_adj !== 0) {
          const angle = hueRotate_adj * Math.PI / 180;
          const cos = Math.cos(angle);
          const sin = Math.sin(angle);
          const newR = r * (0.213 + cos * 0.787 - sin * 0.213) + g * (0.715 - cos * 0.715 - sin * 0.715) + b * (0.072 - cos * 0.072 + sin * 0.928);
          const newG = r * (0.213 - cos * 0.213 + sin * 0.143) + g * (0.715 + cos * 0.285 + sin * 0.14) + b * (0.072 - cos * 0.072 - sin * 0.283);
          const newB = r * (0.213 - cos * 0.213 - sin * 0.787) + g * (0.715 - cos * 0.715 + sin * 0.715) + b * (0.072 + cos * 0.928 + sin * 0.072);
          r = Math.max(0, Math.min(255, newR));
          g = Math.max(0, Math.min(255, newG));
          b = Math.max(0, Math.min(255, newB));
        }
        if (posterize_levels >= 2) {
          const levels = posterize_levels;
          const step = 255 / (levels - 1);
          r = Math.round(Math.round(r / step) * step);
          g = Math.round(Math.round(g / step) * step);
          b = Math.round(Math.round(b / step) * step);
        }
        if (threshold_val !== void 0 && threshold_val !== 128 && edge_detect === "off") {
          const gray = r * 0.299 + g * 0.587 + b * 0.114;
          const bw = gray > threshold_val ? 255 : 0;
          r = bw;
          g = bw;
          b = bw;
        }
        if (invertImage) {
          r = 255 - r;
          g = 255 - g;
          b = 255 - b;
        }
        data[i2] = Math.round(r);
        data[i2 + 1] = Math.round(g);
        data[i2 + 2] = Math.round(b);
      }
    }
    if (needsConvolutionFilters) {
      if (blur_radius > 0) {
        this.applyBoxBlur(imageData, Math.min(blur_radius, 5));
      }
      if (sharpen_amt > 0) {
        this.applySharpen(imageData, sharpen_amt / 100);
      }
      if (edge_detect === "sobel") {
        this.applySobelEdge(imageData);
      } else if (edge_detect === "canny") {
        this.applyCannyEdge(imageData);
      }
    }
    return imageData;
  }
  /**
   * Get overlay data - async version using canvas factory
   * OPTIMIZED: Preprocessing is now done at moduleCount resolution (not full res)
   * This is 10-50x faster than preprocessing at full resolution.
   * @private
   */
  async getOverlayData(overlayCanvas, moduleCount2, colorMode = "color", invertImage = false, frameIndex = 0, config = {}) {
    const contentHash = await this.hashCanvasContent(overlayCanvas);
    const canvasKey = `${overlayCanvas.width}x${overlayCanvas.height}:${contentHash}`;
    const preprocessKey = `${config.overlayBrightness || 0}:${config.overlayContrast || 0}:${config.overlayGamma || 1}:${config.overlaySaturation || 0}:${config.overlayHueRotate || 0}:${invertImage}:${config.overlayBlur || 0}:${config.overlaySharpen || 0}:${config.overlayPosterize || 0}:${config.overlayThreshold ?? 128}:${config.overlayEdgeDetect || "off"}`;
    const cacheKey = `${canvasKey}:${moduleCount2}:${colorMode}:${preprocessKey}:${frameIndex}`;
    const cached = overlayDataCache.get(cacheKey);
    if (cached !== void 0) {
      return cached;
    }
    const tempCanvas = await this.createCanvas(moduleCount2, moduleCount2);
    const ctx = tempCanvas.getContext("2d");
    ctx.drawImage(overlayCanvas, 0, 0, moduleCount2, moduleCount2);
    const imageData = ctx.getImageData(0, 0, moduleCount2, moduleCount2);
    this.preprocessImageData(imageData, config, invertImage);
    const data = imageData.data;
    const brightness = [];
    const colors = [];
    for (let row2 = 0; row2 < moduleCount2; row2++) {
      brightness[row2] = [];
      colors[row2] = [];
      for (let col2 = 0; col2 < moduleCount2; col2++) {
        const i2 = (row2 * moduleCount2 + col2) * 4;
        const r = data[i2];
        const g = data[i2 + 1];
        const b = data[i2 + 2];
        const gray = Math.round(r * 0.299 + g * 0.587 + b * 0.114);
        brightness[row2][col2] = gray / 255;
        if (colorMode === "bw") {
          const bw = gray > 127 ? 255 : 0;
          colors[row2][col2] = `rgb(${bw},${bw},${bw})`;
        } else if (colorMode === "grayscale") {
          colors[row2][col2] = `rgb(${gray},${gray},${gray})`;
        } else {
          colors[row2][col2] = `rgb(${r},${g},${b})`;
        }
      }
    }
    brightness.colors = colors;
    overlayDataCache.set(cacheKey, brightness);
    return brightness;
  }
  // blendColors and parseColor are now imported from ./color-utils.ts
  drawCenterLogo(ctx, logoCanvas, canvasSize, logoSizePercent) {
    const logoSize = canvasSize * (logoSizePercent / 100);
    const x = (canvasSize - logoSize) / 2;
    const y = (canvasSize - logoSize) / 2;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(x - 4, y - 4, logoSize + 8, logoSize + 8);
    ctx.drawImage(logoCanvas, x, y, logoSize, logoSize);
  }
  /**
   * Darken a color by a factor (0-1)
   * @private
   */
  darkenColor(color, factor) {
    const hex = color.replace("#", "");
    const r = Math.round(Number.parseInt(hex.substr(0, 2), 16) * (1 - factor));
    const g = Math.round(Number.parseInt(hex.substr(2, 2), 16) * (1 - factor));
    const b = Math.round(Number.parseInt(hex.substr(4, 2), 16) * (1 - factor));
    return `rgb(${r},${g},${b})`;
  }
  /**
   * Lighten a color by a factor (0-1)
   * @private
   */
  lightenColor(color, factor) {
    const hex = color.replace("#", "");
    const r = Math.round(
      Number.parseInt(hex.substr(0, 2), 16) + (255 - Number.parseInt(hex.substr(0, 2), 16)) * factor
    );
    const g = Math.round(
      Number.parseInt(hex.substr(2, 2), 16) + (255 - Number.parseInt(hex.substr(2, 2), 16)) * factor
    );
    const b = Math.round(
      Number.parseInt(hex.substr(4, 2), 16) + (255 - Number.parseInt(hex.substr(4, 2), 16)) * factor
    );
    return `rgb(${r},${g},${b})`;
  }
  /**
   * Apply dithering to a QR matrix with overlay image
   * Uses Floyd-Steinberg error diffusion for free points
   * Supports serpentine scanning for better quality
   */
  /**
   * Diffusion kernel definitions for error diffusion dithering.
   * Each kernel defines offsets (dx, dy) and weights for error distribution.
   * @private
   */
  getDiffusionKernel(kernelName) {
    const kernels = {
      floyd_steinberg: [
        { dx: 1, dy: 0, w: 7 / 16 },
        { dx: -1, dy: 1, w: 3 / 16 },
        { dx: 0, dy: 1, w: 5 / 16 },
        { dx: 1, dy: 1, w: 1 / 16 }
      ],
      jarvis_judice_ninke: [
        { dx: 1, dy: 0, w: 7 / 48 },
        { dx: 2, dy: 0, w: 5 / 48 },
        { dx: -2, dy: 1, w: 3 / 48 },
        { dx: -1, dy: 1, w: 5 / 48 },
        { dx: 0, dy: 1, w: 7 / 48 },
        { dx: 1, dy: 1, w: 5 / 48 },
        { dx: 2, dy: 1, w: 3 / 48 },
        { dx: -2, dy: 2, w: 1 / 48 },
        { dx: -1, dy: 2, w: 3 / 48 },
        { dx: 0, dy: 2, w: 5 / 48 },
        { dx: 1, dy: 2, w: 3 / 48 },
        { dx: 2, dy: 2, w: 1 / 48 }
      ],
      stucki: [
        { dx: 1, dy: 0, w: 8 / 42 },
        { dx: 2, dy: 0, w: 4 / 42 },
        { dx: -2, dy: 1, w: 2 / 42 },
        { dx: -1, dy: 1, w: 4 / 42 },
        { dx: 0, dy: 1, w: 8 / 42 },
        { dx: 1, dy: 1, w: 4 / 42 },
        { dx: 2, dy: 1, w: 2 / 42 },
        { dx: -2, dy: 2, w: 1 / 42 },
        { dx: -1, dy: 2, w: 2 / 42 },
        { dx: 0, dy: 2, w: 4 / 42 },
        { dx: 1, dy: 2, w: 2 / 42 },
        { dx: 2, dy: 2, w: 1 / 42 }
      ],
      burkes: [
        { dx: 1, dy: 0, w: 8 / 32 },
        { dx: 2, dy: 0, w: 4 / 32 },
        { dx: -2, dy: 1, w: 2 / 32 },
        { dx: -1, dy: 1, w: 4 / 32 },
        { dx: 0, dy: 1, w: 8 / 32 },
        { dx: 1, dy: 1, w: 4 / 32 },
        { dx: 2, dy: 1, w: 2 / 32 }
      ],
      sierra: [
        { dx: 1, dy: 0, w: 5 / 32 },
        { dx: 2, dy: 0, w: 3 / 32 },
        { dx: -2, dy: 1, w: 2 / 32 },
        { dx: -1, dy: 1, w: 4 / 32 },
        { dx: 0, dy: 1, w: 5 / 32 },
        { dx: 1, dy: 1, w: 4 / 32 },
        { dx: 2, dy: 1, w: 2 / 32 },
        { dx: -1, dy: 2, w: 2 / 32 },
        { dx: 0, dy: 2, w: 3 / 32 },
        { dx: 1, dy: 2, w: 2 / 32 }
      ],
      sierra_2: [
        { dx: 1, dy: 0, w: 4 / 16 },
        { dx: 2, dy: 0, w: 3 / 16 },
        { dx: -2, dy: 1, w: 1 / 16 },
        { dx: -1, dy: 1, w: 2 / 16 },
        { dx: 0, dy: 1, w: 3 / 16 },
        { dx: 1, dy: 1, w: 2 / 16 },
        { dx: 2, dy: 1, w: 1 / 16 }
      ],
      sierra_lite: [
        { dx: 1, dy: 0, w: 2 / 4 },
        { dx: -1, dy: 1, w: 1 / 4 },
        { dx: 0, dy: 1, w: 1 / 4 }
      ],
      atkinson: [
        { dx: 1, dy: 0, w: 1 / 8 },
        { dx: 2, dy: 0, w: 1 / 8 },
        { dx: -1, dy: 1, w: 1 / 8 },
        { dx: 0, dy: 1, w: 1 / 8 },
        { dx: 1, dy: 1, w: 1 / 8 },
        { dx: 0, dy: 2, w: 1 / 8 }
      ]
    };
    return kernels[kernelName] || kernels.floyd_steinberg;
  }
  /**
   * Apply dithering to QR matrix - async version using canvas factory
   * Supports multiple diffusion kernels, serpentine scanning, and dither strength.
   * @private
   */
  async applyDitherToMatrix(baseMatrix, scaledSize, scale, overlayCanvas, overlayIntensity, colorMode, serpentine = false, config = {}) {
    const matrix = baseMatrix.map((row2) => [...row2]);
    const colors = baseMatrix.map(
      (row2) => row2.map((isDark) => isDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 })
    );
    if (!overlayCanvas) {
      return { matrix, colors };
    }
    const ditherStrength = (config.ditherStrength ?? 100) / 100;
    const diffusionKernel = config.diffusionKernel || "floyd_steinberg";
    const fsKernel = this.getDiffusionKernel(diffusionKernel);
    const imageData = await this.loadImageDataRGB(overlayCanvas, scaledSize, config);
    const intensity = overlayIntensity / 100;
    if (colorMode === "grayscale" || colorMode === "bw") {
      for (let y = 0; y < scaledSize; y++) {
        for (let x = 0; x < scaledSize; x++) {
          const { r, g, b } = imageData[y][x];
          const gray = r * 0.299 + g * 0.587 + b * 0.114;
          imageData[y][x] = { r: gray, g: gray, b: gray };
        }
      }
    }
    for (let y = 0; y < scaledSize; y++) {
      const leftToRight = !serpentine || y % 2 === 0;
      const xStart = leftToRight ? 0 : scaledSize - 1;
      const xEnd = leftToRight ? scaledSize : -1;
      const xStep = leftToRight ? 1 : -1;
      for (let x = xStart; leftToRight ? x < xEnd : x > xEnd; x += xStep) {
        if (isLocked2(scaledSize, x, y, scale)) continue;
        if (isData2(x, y, scale)) continue;
        const pixel = imageData[y][x];
        if (colorMode === "bw") {
          const gray = pixel.r * 0.299 + pixel.g * 0.587 + pixel.b * 0.114;
          const newVal = gray > 0.5 ? 1 : 0;
          const error = gray - newVal;
          imageData[y][x] = { r: newVal, g: newVal, b: newVal };
          this.distributeError(
            imageData,
            x,
            y,
            scaledSize,
            scale,
            error,
            error,
            error,
            leftToRight,
            fsKernel,
            ditherStrength
          );
        } else if (colorMode === "grayscale") {
          const gray = pixel.r;
          const levels = 4;
          const newVal = Math.round(gray * (levels - 1)) / (levels - 1);
          const error = gray - newVal;
          imageData[y][x] = { r: newVal, g: newVal, b: newVal };
          this.distributeError(
            imageData,
            x,
            y,
            scaledSize,
            scale,
            error,
            error,
            error,
            leftToRight,
            fsKernel,
            ditherStrength
          );
        } else {
          const levels = 4;
          const newR = Math.round(pixel.r * (levels - 1)) / (levels - 1);
          const newG = Math.round(pixel.g * (levels - 1)) / (levels - 1);
          const newB = Math.round(pixel.b * (levels - 1)) / (levels - 1);
          const errorR = pixel.r - newR;
          const errorG = pixel.g - newG;
          const errorB = pixel.b - newB;
          imageData[y][x] = { r: newR, g: newG, b: newB };
          this.distributeError(
            imageData,
            x,
            y,
            scaledSize,
            scale,
            errorR,
            errorG,
            errorB,
            leftToRight,
            fsKernel,
            ditherStrength
          );
        }
      }
    }
    const seededRandom = this.createSeededRandom(scale * 12345);
    for (let y = 0; y < scaledSize; y++) {
      for (let x = 0; x < scaledSize; x++) {
        if (isLocked2(scaledSize, x, y, scale)) continue;
        if (isData2(x, y, scale)) continue;
        const pixel = imageData[y][x];
        const brightness = pixel.r * 0.299 + pixel.g * 0.587 + pixel.b * 0.114;
        const useImage = seededRandom() < intensity;
        if (useImage) {
          matrix[y][x] = brightness < 0.5;
          colors[y][x] = {
            r: Math.round(Math.max(0, Math.min(1, pixel.r)) * 255),
            g: Math.round(Math.max(0, Math.min(1, pixel.g)) * 255),
            b: Math.round(Math.max(0, Math.min(1, pixel.b)) * 255)
          };
        }
      }
    }
    return { matrix, colors };
  }
  /**
   * Load image data from canvas as RGB values (0-1 range)
   * Now supports preprocessing via config parameter
   * @private
   */
  async loadImageDataRGB(canvas, size, config = {}) {
    const tempCanvas = await this.createCanvas(size, size);
    const ctx = tempCanvas.getContext("2d");
    ctx.drawImage(canvas, 0, 0, size, size);
    const imgData = ctx.getImageData(0, 0, size, size);
    this.preprocessImageData(imgData, config, config.invertImage);
    const output = [];
    for (let y = 0; y < size; y++) {
      const row2 = [];
      for (let x = 0; x < size; x++) {
        const i2 = (y * size + x) * 4;
        row2.push({
          r: imgData.data[i2] / 255,
          g: imgData.data[i2 + 1] / 255,
          b: imgData.data[i2 + 2] / 255
        });
      }
      output.push(row2);
    }
    return output;
  }
  /**
   * Distribute error to neighboring pixels using the specified diffusion kernel
   * Supports serpentine scanning with leftToRight parameter and dither strength
   */
  distributeError(imageData, x, y, size, scale, errorR, errorG, errorB, leftToRight = true, kernel = null, strength = 1) {
    const canChange = (px, py) => {
      if (px < 0 || py < 0 || px >= size || py >= size) return false;
      return !(isLocked2(size, px, py, scale) || isData2(px, py, scale));
    };
    const scaledErrorR = errorR * strength;
    const scaledErrorG = errorG * strength;
    const scaledErrorB = errorB * strength;
    const diffusionKernel = kernel || [
      { dx: 1, dy: 0, w: 7 / 16 },
      { dx: -1, dy: 1, w: 3 / 16 },
      { dx: 0, dy: 1, w: 5 / 16 },
      { dx: 1, dy: 1, w: 1 / 16 }
    ];
    for (const { dx, dy, w } of diffusionKernel) {
      const effectiveDx = leftToRight ? dx : -dx;
      const nx = x + effectiveDx;
      const ny = y + dy;
      if (canChange(nx, ny)) {
        imageData[ny][nx].r += scaledErrorR * w;
        imageData[ny][nx].g += scaledErrorG * w;
        imageData[ny][nx].b += scaledErrorB * w;
      }
    }
  }
  /**
   * Get subpixel overlay data - async version using canvas factory
   * Now supports preprocessing via config parameter
   * @private
   */
  async getSubpixelOverlayData(overlayCanvas, subpixelCount, colorMode = "color", config = {}) {
    const tempCanvas = await this.createCanvas(subpixelCount, subpixelCount);
    const ctx = tempCanvas.getContext("2d");
    ctx.drawImage(overlayCanvas, 0, 0, subpixelCount, subpixelCount);
    const imageData = ctx.getImageData(0, 0, subpixelCount, subpixelCount);
    this.preprocessImageData(imageData, config, config.invertImage);
    const data = imageData.data;
    const brightness = [];
    const colors = [];
    for (let row2 = 0; row2 < subpixelCount; row2++) {
      brightness[row2] = [];
      colors[row2] = [];
      for (let col2 = 0; col2 < subpixelCount; col2++) {
        const i2 = (row2 * subpixelCount + col2) * 4;
        const r = data[i2];
        const g = data[i2 + 1];
        const b = data[i2 + 2];
        const gray = Math.round(r * 0.299 + g * 0.587 + b * 0.114);
        brightness[row2][col2] = gray / 255;
        if (colorMode === "bw") {
          const bw = gray > 127 ? 255 : 0;
          colors[row2][col2] = `rgb(${bw},${bw},${bw})`;
        } else if (colorMode === "grayscale") {
          colors[row2][col2] = `rgb(${gray},${gray},${gray})`;
        } else {
          colors[row2][col2] = `rgb(${r},${g},${b})`;
        }
      }
    }
    brightness.colors = colors;
    return brightness;
  }
  /**
   * Check if any preprocessing options are set
   * @private
   * @deprecated Color adjustments are now done at moduleCount resolution in _getOverlayData
   */
  hasPreprocessingOptions(config) {
    return config.overlayBrightness && config.overlayBrightness !== 0 || config.overlayContrast && config.overlayContrast !== 0 || config.overlayGamma && config.overlayGamma !== 1 || config.overlaySaturation && config.overlaySaturation !== 0 || config.overlayHueRotate && config.overlayHueRotate !== 0 || config.invertImage || config.overlayBlur && config.overlayBlur > 0 || config.overlaySharpen && config.overlaySharpen > 0 || config.overlayPosterize && config.overlayPosterize > 0 || config.overlayEdgeDetect && config.overlayEdgeDetect !== "off" || config.overlayThreshold !== void 0 && config.overlayThreshold !== 128 || config.overlayFlipX || config.overlayFlipY || config.overlayRotate && config.overlayRotate !== 0;
  }
  /**
   * Check if geometric transforms are needed (rotation, flip)
   * These must be done before downscaling as they affect spatial layout
   * @private
   */
  hasGeometricTransforms(config) {
    return config.overlayFlipX || config.overlayFlipY || config.overlayRotate && config.overlayRotate !== 0;
  }
  /**
   * Apply only geometric transforms (rotation, flip) at full resolution
   * Color adjustments are done at moduleCount resolution in _getOverlayData
   * @private
   */
  async applyGeometricTransforms(overlayCanvas, config) {
    const width = overlayCanvas.width;
    const height = overlayCanvas.height;
    const processedCanvas = await this.createCanvas(width, height);
    const ctx = processedCanvas.getContext("2d");
    ctx.save();
    if (config.overlayRotate && config.overlayRotate !== 0) {
      ctx.translate(width / 2, height / 2);
      ctx.rotate(config.overlayRotate * Math.PI / 180);
      ctx.translate(-width / 2, -height / 2);
    }
    if (config.overlayFlipX || config.overlayFlipY) {
      ctx.translate(config.overlayFlipX ? width : 0, config.overlayFlipY ? height : 0);
      ctx.scale(config.overlayFlipX ? -1 : 1, config.overlayFlipY ? -1 : 1);
    }
    ctx.drawImage(overlayCanvas, 0, 0);
    ctx.restore();
    return processedCanvas;
  }
  /**
   * Preprocess overlay canvas with filters and transforms
   * @private
   */
  async preprocessOverlay(overlayCanvas, config) {
    const width = overlayCanvas.width;
    const height = overlayCanvas.height;
    const processedCanvas = await this.createCanvas(width, height);
    const ctx = processedCanvas.getContext("2d");
    ctx.save();
    if (config.overlayRotate && config.overlayRotate !== 0) {
      ctx.translate(width / 2, height / 2);
      ctx.rotate(config.overlayRotate * Math.PI / 180);
      ctx.translate(-width / 2, -height / 2);
    }
    if (config.overlayFlipX || config.overlayFlipY) {
      ctx.translate(config.overlayFlipX ? width : 0, config.overlayFlipY ? height : 0);
      ctx.scale(config.overlayFlipX ? -1 : 1, config.overlayFlipY ? -1 : 1);
    }
    ctx.drawImage(overlayCanvas, 0, 0);
    ctx.restore();
    const imageData = ctx.getImageData(0, 0, width, height);
    const filterOptions = {
      brightness: config.overlayBrightness || 0,
      contrast: config.overlayContrast || 0,
      gamma: config.overlayGamma || 1,
      saturation: config.overlaySaturation || 0,
      hueRotate: config.overlayHueRotate || 0,
      invert: config.invertImage,
      blur: config.overlayBlur || 0,
      sharpen: config.overlaySharpen || 0,
      posterize: config.overlayPosterize || 0,
      edgeDetect: config.overlayEdgeDetect || "off"
    };
    if (config.overlayThreshold !== void 0 && config.overlayThreshold !== 128 && filterOptions.edgeDetect === "off") {
      filterOptions.threshold = config.overlayThreshold;
    }
    this.applyFiltersManual(imageData, filterOptions);
    ctx.putImageData(imageData, 0, 0);
    return processedCanvas;
  }
  /**
   * Manual filter application - self-contained implementation
   * @private
   */
  applyFiltersManual(imageData, options) {
    const data = imageData.data;
    for (let i2 = 0; i2 < data.length; i2 += 4) {
      let r = data[i2];
      let g = data[i2 + 1];
      let b = data[i2 + 2];
      if (options.brightness && options.brightness !== 0) {
        const factor = options.brightness * 2.55;
        r = Math.max(0, Math.min(255, r + factor));
        g = Math.max(0, Math.min(255, g + factor));
        b = Math.max(0, Math.min(255, b + factor));
      }
      if (options.contrast && options.contrast !== 0) {
        const factor = 259 * (options.contrast + 255) / (255 * (259 - options.contrast));
        r = Math.max(0, Math.min(255, factor * (r - 128) + 128));
        g = Math.max(0, Math.min(255, factor * (g - 128) + 128));
        b = Math.max(0, Math.min(255, factor * (b - 128) + 128));
      }
      if (options.gamma && options.gamma !== 1) {
        const gammaCorrection = 1 / options.gamma;
        r = 255 * (r / 255) ** gammaCorrection;
        g = 255 * (g / 255) ** gammaCorrection;
        b = 255 * (b / 255) ** gammaCorrection;
      }
      if (options.saturation && options.saturation !== 0) {
        const gray = r * 0.299 + g * 0.587 + b * 0.114;
        const factor = (options.saturation + 100) / 100;
        r = Math.max(0, Math.min(255, gray + factor * (r - gray)));
        g = Math.max(0, Math.min(255, gray + factor * (g - gray)));
        b = Math.max(0, Math.min(255, gray + factor * (b - gray)));
      }
      if (options.hueRotate && options.hueRotate !== 0) {
        const angle = options.hueRotate * Math.PI / 180;
        const cos = Math.cos(angle);
        const sin = Math.sin(angle);
        const newR = r * (0.213 + cos * 0.787 - sin * 0.213) + g * (0.715 - cos * 0.715 - sin * 0.715) + b * (0.072 - cos * 0.072 + sin * 0.928);
        const newG = r * (0.213 - cos * 0.213 + sin * 0.143) + g * (0.715 + cos * 0.285 + sin * 0.14) + b * (0.072 - cos * 0.072 - sin * 0.283);
        const newB = r * (0.213 - cos * 0.213 - sin * 0.787) + g * (0.715 - cos * 0.715 + sin * 0.715) + b * (0.072 + cos * 0.928 + sin * 0.072);
        r = Math.max(0, Math.min(255, newR));
        g = Math.max(0, Math.min(255, newG));
        b = Math.max(0, Math.min(255, newB));
      }
      if (options.posterize && options.posterize > 0) {
        const levels = options.posterize;
        const step = 255 / (levels - 1);
        r = Math.round(Math.round(r / step) * step);
        g = Math.round(Math.round(g / step) * step);
        b = Math.round(Math.round(b / step) * step);
      }
      if (options.invert) {
        r = 255 - r;
        g = 255 - g;
        b = 255 - b;
      }
      data[i2] = Math.round(r);
      data[i2 + 1] = Math.round(g);
      data[i2 + 2] = Math.round(b);
    }
    if (options.blur && options.blur > 0) {
      this.applyBoxBlur(imageData, Math.min(options.blur, 5));
    }
    if (options.sharpen && options.sharpen > 0) {
      this.applySharpen(imageData, options.sharpen / 100);
    }
    if (options.edgeDetect === "sobel") {
      this.applySobelEdge(imageData);
    }
  }
  /**
   * Apply box blur
   * @private
   */
  applyBoxBlur(imageData, radius) {
    const data = imageData.data;
    const width = imageData.width;
    const height = imageData.height;
    const copy = new Uint8ClampedArray(data);
    const size = radius * 2 + 1;
    const divisor = size * size;
    for (let y = radius; y < height - radius; y++) {
      for (let x = radius; x < width - radius; x++) {
        let r = 0, g = 0, b = 0;
        for (let ky = -radius; ky <= radius; ky++) {
          for (let kx = -radius; kx <= radius; kx++) {
            const idx = ((y + ky) * width + (x + kx)) * 4;
            r += copy[idx];
            g += copy[idx + 1];
            b += copy[idx + 2];
          }
        }
        const outIdx = (y * width + x) * 4;
        data[outIdx] = Math.round(r / divisor);
        data[outIdx + 1] = Math.round(g / divisor);
        data[outIdx + 2] = Math.round(b / divisor);
      }
    }
  }
  /**
   * Apply sharpen filter
   * @private
   */
  applySharpen(imageData, amount) {
    const data = imageData.data;
    const width = imageData.width;
    const height = imageData.height;
    const copy = new Uint8ClampedArray(data);
    const kernel = [0, -amount, 0, -amount, 1 + 4 * amount, -amount, 0, -amount, 0];
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        let r = 0, g = 0, b = 0;
        let ki = 0;
        for (let ky = -1; ky <= 1; ky++) {
          for (let kx = -1; kx <= 1; kx++) {
            const idx = ((y + ky) * width + (x + kx)) * 4;
            const k = kernel[ki++];
            r += copy[idx] * k;
            g += copy[idx + 1] * k;
            b += copy[idx + 2] * k;
          }
        }
        const outIdx = (y * width + x) * 4;
        data[outIdx] = Math.max(0, Math.min(255, Math.round(r)));
        data[outIdx + 1] = Math.max(0, Math.min(255, Math.round(g)));
        data[outIdx + 2] = Math.max(0, Math.min(255, Math.round(b)));
      }
    }
  }
  /**
   * Apply Canny edge detection (simplified implementation)
   * Uses Gaussian blur -> Sobel gradient -> Non-maximum suppression -> Hysteresis thresholding
   * @private
   */
  applyCannyEdge(imageData) {
    const data = imageData.data;
    const width = imageData.width;
    const height = imageData.height;
    const gray = new Float32Array(width * height);
    for (let i2 = 0; i2 < width * height; i2++) {
      const idx = i2 * 4;
      gray[i2] = data[idx] * 0.299 + data[idx + 1] * 0.587 + data[idx + 2] * 0.114;
    }
    const blurred = new Float32Array(width * height);
    const gaussKernel = [1, 2, 1, 2, 4, 2, 1, 2, 1];
    const gaussSum = 16;
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        let sum = 0;
        let ki = 0;
        for (let ky = -1; ky <= 1; ky++) {
          for (let kx = -1; kx <= 1; kx++) {
            sum += gray[(y + ky) * width + (x + kx)] * gaussKernel[ki++];
          }
        }
        blurred[y * width + x] = sum / gaussSum;
      }
    }
    const sobelX = [-1, 0, 1, -2, 0, 2, -1, 0, 1];
    const sobelY = [-1, -2, -1, 0, 0, 0, 1, 2, 1];
    const magnitude = new Float32Array(width * height);
    const direction = new Float32Array(width * height);
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        let gx = 0, gy = 0;
        let ki = 0;
        for (let ky = -1; ky <= 1; ky++) {
          for (let kx = -1; kx <= 1; kx++) {
            const val = blurred[(y + ky) * width + (x + kx)];
            gx += val * sobelX[ki];
            gy += val * sobelY[ki];
            ki++;
          }
        }
        const idx = y * width + x;
        magnitude[idx] = Math.hypot(gx, gy);
        direction[idx] = Math.atan2(gy, gx);
      }
    }
    const suppressed = new Float32Array(width * height);
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = y * width + x;
        const angle = direction[idx];
        const mag = magnitude[idx];
        let q = 0, r = 0;
        const absAngle = Math.abs(angle);
        if (absAngle < Math.PI / 8 || absAngle > 7 * Math.PI / 8) {
          q = magnitude[idx - 1];
          r = magnitude[idx + 1];
        } else if (absAngle >= Math.PI / 8 && absAngle < 3 * Math.PI / 8) {
          if (angle > 0) {
            q = magnitude[(y - 1) * width + (x + 1)];
            r = magnitude[(y + 1) * width + (x - 1)];
          } else {
            q = magnitude[(y - 1) * width + (x - 1)];
            r = magnitude[(y + 1) * width + (x + 1)];
          }
        } else if (absAngle >= 3 * Math.PI / 8 && absAngle < 5 * Math.PI / 8) {
          q = magnitude[(y - 1) * width + x];
          r = magnitude[(y + 1) * width + x];
        } else if (angle > 0) {
          q = magnitude[(y - 1) * width + (x - 1)];
          r = magnitude[(y + 1) * width + (x + 1)];
        } else {
          q = magnitude[(y - 1) * width + (x + 1)];
          r = magnitude[(y + 1) * width + (x - 1)];
        }
        suppressed[idx] = mag >= q && mag >= r ? mag : 0;
      }
    }
    const highThreshold = 50;
    const lowThreshold = 20;
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = y * width + x;
        const val = suppressed[idx];
        let output = 0;
        if (val >= highThreshold) {
          output = 255;
        } else if (val >= lowThreshold) {
          let hasStrongNeighbor = false;
          for (let ky = -1; ky <= 1 && !hasStrongNeighbor; ky++) {
            for (let kx = -1; kx <= 1 && !hasStrongNeighbor; kx++) {
              const ny = y + ky;
              const nx = x + kx;
              if (ny >= 0 && ny < height && nx >= 0 && nx < width) {
                if (suppressed[ny * width + nx] >= highThreshold) {
                  hasStrongNeighbor = true;
                }
              }
            }
          }
          output = hasStrongNeighbor ? 255 : 0;
        }
        const outIdx = idx * 4;
        data[outIdx] = output;
        data[outIdx + 1] = output;
        data[outIdx + 2] = output;
      }
    }
  }
  /**
   * Apply Sobel edge detection
   * @private
   */
  applySobelEdge(imageData) {
    const data = imageData.data;
    const width = imageData.width;
    const height = imageData.height;
    const gray = new Float32Array(width * height);
    for (let i2 = 0; i2 < width * height; i2++) {
      const idx = i2 * 4;
      gray[i2] = data[idx] * 0.299 + data[idx + 1] * 0.587 + data[idx + 2] * 0.114;
    }
    const sobelX = [-1, 0, 1, -2, 0, 2, -1, 0, 1];
    const sobelY = [-1, -2, -1, 0, 0, 0, 1, 2, 1];
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        let gx = 0, gy = 0;
        let ki = 0;
        for (let ky = -1; ky <= 1; ky++) {
          for (let kx = -1; kx <= 1; kx++) {
            const grayIdx = (y + ky) * width + (x + kx);
            gx += gray[grayIdx] * sobelX[ki];
            gy += gray[grayIdx] * sobelY[ki];
            ki++;
          }
        }
        const magnitude = Math.min(255, Math.hypot(gx, gy));
        const outIdx = (y * width + x) * 4;
        data[outIdx] = magnitude;
        data[outIdx + 1] = magnitude;
        data[outIdx + 2] = magnitude;
      }
    }
  }
  /**
   * Apply per-module color mode
   * @private
   */
  applyPerModuleColor(mode, baseColor, overlayData, row2, col2, moduleCount2, config) {
    const brightness = overlayData[row2]?.[col2] ?? 0.5;
    const overlayColor = overlayData.colors?.[row2]?.[col2];
    const intensity = (config.overlayIntensity || 100) / 100;
    switch (mode) {
      case "by_brightness": {
        const parsed = parseColor(baseColor);
        const factor = 0.5 + brightness * 0.5;
        return `rgb(${Math.round(parsed.r * factor)},${Math.round(parsed.g * factor)},${Math.round(parsed.b * factor)})`;
      }
      case "by_position": {
        const parsed = parseColor(baseColor);
        const xFactor = col2 / moduleCount2;
        const yFactor = row2 / moduleCount2;
        const r = Math.round(parsed.r * (0.5 + xFactor * 0.5));
        const g = Math.round(parsed.g * (0.5 + yFactor * 0.5));
        const b = Math.round(parsed.b * (0.5 + (1 - xFactor) * 0.5));
        return `rgb(${r},${g},${b})`;
      }
      case "by_overlay": {
        if (overlayColor) {
          return blendColors(baseColor, overlayColor, intensity);
        }
        return baseColor;
      }
      case "by_cluster": {
        const blockSize = 3;
        const blockRow = Math.floor(row2 / blockSize);
        const blockCol = Math.floor(col2 / blockSize);
        const seed = blockRow * 100 + blockCol;
        const hueShift = seed * 37 % 360;
        const parsed = parseColor(baseColor);
        const angle = hueShift * Math.PI / 180;
        const cos = Math.cos(angle);
        const sin = Math.sin(angle);
        const r = Math.max(
          0,
          Math.min(
            255,
            parsed.r * (0.213 + cos * 0.787 - sin * 0.213) + parsed.g * (0.715 - cos * 0.715 - sin * 0.715) + parsed.b * (0.072 - cos * 0.072 + sin * 0.928)
          )
        );
        const g = Math.max(
          0,
          Math.min(
            255,
            parsed.r * (0.213 - cos * 0.213 + sin * 0.143) + parsed.g * (0.715 + cos * 0.285 + sin * 0.14) + parsed.b * (0.072 - cos * 0.072 - sin * 0.283)
          )
        );
        const b = Math.max(
          0,
          Math.min(
            255,
            parsed.r * (0.213 - cos * 0.213 - sin * 0.787) + parsed.g * (0.715 - cos * 0.715 + sin * 0.715) + parsed.b * (0.072 + cos * 0.928 + sin * 0.072)
          )
        );
        return `rgb(${Math.round(r)},${Math.round(g)},${Math.round(b)})`;
      }
      default:
        return baseColor;
    }
  }
  /**
   * Ensure module color has sufficient contrast with background
   * @private
   */
  ensureContrast(moduleColor, bgColor, minRatio) {
    try {
      const ratio = getContrastRatio(moduleColor, bgColor);
      if (ratio >= minRatio) {
        return moduleColor;
      }
      const parsed = parseColor(moduleColor);
      let factor = 0.9;
      let newColor = moduleColor;
      for (let i2 = 0; i2 < 10; i2++) {
        const r = Math.round(parsed.r * factor);
        const g = Math.round(parsed.g * factor);
        const b = Math.round(parsed.b * factor);
        newColor = `rgb(${r},${g},${b})`;
        const newRatio = getContrastRatio(newColor, bgColor);
        if (newRatio >= minRatio) {
          return newColor;
        }
        factor *= 0.85;
      }
      return "#000000";
    } catch (error_) {
      console.warn("Contrast check failed:", error_);
      return moduleColor;
    }
  }
  /**
   * Apply advanced dithering using dither-algorithms module
   * Supports all dithering types: ordered, error diffusion, blue noise, etc.
   */
  async applyAdvancedDither(overlayCanvas, moduleCount2, config) {
    const tempCanvas = await this.createCanvas(moduleCount2, moduleCount2);
    const ctx = tempCanvas.getContext("2d");
    ctx.drawImage(overlayCanvas, 0, 0, moduleCount2, moduleCount2);
    const imageData = ctx.getImageData(0, 0, moduleCount2, moduleCount2);
    const ditherOptions = {
      kind: config.ditherKind || "error_diffusion",
      strength: config.ditherStrength ?? 100,
      serpentine: config.serpentine !== false,
      diffusionKernel: config.diffusionKernel || "floyd_steinberg",
      orderedMatrix: config.orderedMatrix || "bayer4",
      colorMode: config.colorMode || "bw",
      levels: 2,
      blueNoiseSeed: config.blueNoiseSeed || 0,
      blueNoiseTileSize: config.blueNoiseTileSize || 64
    };
    const result = applyDither(imageData, ditherOptions);
    return result;
  }
  /**
   * Apply palette color to a module based on position/brightness
   * @private
   */
  applyPaletteColor(row2, col2, moduleCount2, brightness, palette, config) {
    if (!palette || palette.length === 0) return config.fgColor;
    const paletteMode = config.paletteMode || "position";
    switch (paletteMode) {
      case "brightness": {
        const idx = Math.floor((1 - brightness) * (palette.length - 0.01));
        return palette[Math.max(0, Math.min(palette.length - 1, idx))];
      }
      case "diagonal": {
        const diag = (row2 + col2) / (moduleCount2 * 2);
        const idx = Math.floor(diag * palette.length) % palette.length;
        return palette[idx];
      }
      case "radial": {
        const cx = moduleCount2 / 2;
        const cy = moduleCount2 / 2;
        const dist = Math.hypot(row2 - cy, col2 - cx);
        const maxDist = Math.hypot(cx, cy);
        const idx = Math.floor(dist / maxDist * palette.length) % palette.length;
        return palette[idx];
      }
      case "random": {
        const hash = (row2 * 31 + col2) * 17 % palette.length;
        return palette[hash];
      }
      case "row": {
        const idx = Math.floor(row2 / moduleCount2 * palette.length) % palette.length;
        return palette[idx];
      }
      case "column": {
        const idx = Math.floor(col2 / moduleCount2 * palette.length) % palette.length;
        return palette[idx];
      }
      default: {
        const linearPos = row2 * moduleCount2 + col2;
        const idx = linearPos % palette.length;
        return palette[idx];
      }
    }
  }
  /**
   * Apply halftone rendering to a module
   * @private
   */
  drawHalftoneModule(ctx, x, y, size, brightness, config) {
    const htDot = config.halftoneDotShape || "circle";
    const htCurve = config.brightnessCurve || "linear";
    let adjustedBrightness = brightness;
    switch (htCurve) {
      case "s-curve":
        adjustedBrightness = brightness * brightness * (3 - 2 * brightness);
        break;
      case "gamma":
        adjustedBrightness = brightness ** 2.2;
        break;
      default:
        break;
    }
    const minSize = 0.2;
    const maxSize = 1;
    const dotSizeRatio = minSize + (1 - adjustedBrightness) * (maxSize - minSize);
    const dotSize = size * dotSizeRatio;
    const offset = (size - dotSize) / 2;
    const centerX = x + size / 2;
    const centerY = y + size / 2;
    switch (htDot) {
      case "circle":
        ctx.beginPath();
        ctx.arc(centerX, centerY, dotSize / 2, 0, Math.PI * 2);
        ctx.fill();
        break;
      case "square":
        ctx.fillRect(x + offset, y + offset, dotSize, dotSize);
        break;
      case "line": {
        const lineWidth = dotSize * 0.8;
        ctx.fillRect(x, y + (size - lineWidth) / 2, size, lineWidth);
        break;
      }
      case "diamond": {
        ctx.beginPath();
        ctx.moveTo(centerX, y + offset);
        ctx.lineTo(x + size - offset, centerY);
        ctx.lineTo(centerX, y + size - offset);
        ctx.lineTo(x + offset, centerY);
        ctx.closePath();
        ctx.fill();
        break;
      }
    }
  }
  /**
   * Calculate ECC-aware weight for a module position
   * Higher weight = more important to preserve
   * @private
   */
  getEccWeight(_row, _col, _moduleCount, _version, _weightMap) {
    switch (_weightMap) {
      case "distance_to_finders": {
        const distTL = Math.hypot(row, col);
        const distTR = Math.hypot(row, moduleCount - 1 - col);
        const distBL = Math.hypot(moduleCount - 1 - row, col);
        const minDist = Math.min(distTL, distTR, distBL);
        const maxDist = Math.sqrt(2) * moduleCount / 2;
        return 1 - minDist / maxDist;
      }
      case "block_heatmap": {
        const centerRow = moduleCount / 2;
        const centerCol = moduleCount / 2;
        const distToCenter = Math.hypot(row - centerRow, col - centerCol);
        const maxDist = Math.sqrt(2) * moduleCount / 2;
        return distToCenter / maxDist;
      }
      case "empirical_scan_heatmap": {
        const scanProgress = (row + col) / (2 * moduleCount);
        return 1 - scanProgress * 0.5;
      }
      default:
        return 0.5;
    }
  }
  /**
   * Check if modifying a module is safe given ECC-aware constraints
   * Uses deterministic decision based on position hash for reproducibility
   * @private
   */
  isEccSafeToModify(row2, col2, moduleCount2, version, config, modifiedCount, totalDataModules) {
    if (!config.eccAwareEnabled) return true;
    const riskBudget = (config.eccAwareRiskBudget || 50) / 100;
    const eccCapacity = { L: 0.07, M: 0.15, Q: 0.25, H: 0.3 };
    const maxRisk = eccCapacity[config.errorCorrection] || 0.25;
    const allowedModifications = Math.floor(totalDataModules * maxRisk * riskBudget);
    if (modifiedCount >= allowedModifications) return false;
    const weight = this.getEccWeight(
      row2,
      col2,
      moduleCount2,
      version,
      config.eccAwareWeightMap || "distance_to_finders"
    );
    const positionHash = ((row2 * 31 + col2) * 17 + (config.seed || 0)) % 1e3;
    const deterministicValue = positionHash / 1e3;
    return deterministicValue > weight * 0.5;
  }
};

// src/modules/shared/index.ts
function hslToRgbTuple(h, s, l) {
  const sNorm = s / 100;
  const lNorm = l / 100;
  const c = (1 - Math.abs(2 * lNorm - 1)) * sNorm;
  const x = c * (1 - Math.abs(h / 60 % 2 - 1));
  const m = lNorm - c / 2;
  let r;
  let g;
  let b;
  if (h < 60) {
    r = c;
    g = x;
    b = 0;
  } else if (h < 120) {
    r = x;
    g = c;
    b = 0;
  } else if (h < 180) {
    r = 0;
    g = c;
    b = x;
  } else if (h < 240) {
    r = 0;
    g = x;
    b = c;
  } else if (h < 300) {
    r = x;
    g = 0;
    b = c;
  } else {
    r = c;
    g = 0;
    b = x;
  }
  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}
function createSeededRandom(seed) {
  let s = seed;
  return () => {
    s = Math.sin(s * 9999) * 1e4;
    return s - Math.floor(s);
  };
}
function applyEasing(progress, easing) {
  switch (easing) {
    case "ease_in":
      return progress * progress;
    case "ease_out":
      return 1 - (1 - progress) * (1 - progress);
    case "ease_in_out":
      return progress < 0.5 ? 2 * progress * progress : 1 - (-2 * progress + 2) ** 2 / 2;
    case "bounce":
      if (progress < 0.5) {
        return 8 * progress * progress * progress * progress;
      } else {
        return 1 - (-2 * progress + 2) ** 4 / 2;
      }
    default:
      return progress;
  }
}
function applyPulsePattern(data, progress, seed) {
  const pulsePhase = Math.sin(progress * Math.PI * 2);
  const intensity = 0.3 + 0.2 * Math.abs(pulsePhase);
  const hue = seed * 31 % 360;
  const pulseColor = hslToRgbTuple(hue, 70, 50);
  for (let i2 = 0; i2 < data.length; i2 += 4) {
    const r = data[i2], g = data[i2 + 1], b = data[i2 + 2];
    const brightness = (r + g + b) / 3;
    const isDark = brightness < 128;
    if (isDark) {
      const tintAmount = intensity * (0.5 + pulsePhase * 0.5);
      data[i2] = Math.min(255, r + pulseColor[0] * tintAmount);
      data[i2 + 1] = Math.min(255, g + pulseColor[1] * tintAmount);
      data[i2 + 2] = Math.min(255, b + pulseColor[2] * tintAmount);
    } else {
      const bf = 1 - intensity * 0.1 * (1 + pulsePhase);
      data[i2] = Math.max(0, Math.round(r * bf));
      data[i2 + 1] = Math.max(0, Math.round(g * bf));
      data[i2 + 2] = Math.max(0, Math.round(b * bf));
    }
  }
}
function applyWavePattern(data, progress, width, height, seed) {
  const waveFrequency = 3 + seed % 5;
  const baseHue = seed * 23 % 360;
  for (let y = 0; y < height; y++) {
    const wavePhase = Math.sin(y / height * waveFrequency * Math.PI * 2 + progress * Math.PI * 2);
    const waveIntensity = (wavePhase + 1) / 2;
    const rowHue = ((baseHue + wavePhase * 30) % 360 + 360) % 360;
    const waveColor = hslToRgbTuple(rowHue, 70, 50);
    for (let x = 0; x < width; x++) {
      const i2 = (y * width + x) * 4;
      const r = data[i2], g = data[i2 + 1], b = data[i2 + 2];
      const brightness = (r + g + b) / 3;
      const isDark = brightness < 128;
      if (isDark) {
        const tintAmount = waveIntensity * 0.6;
        data[i2] = Math.min(255, r + waveColor[0] * tintAmount);
        data[i2 + 1] = Math.min(255, g + waveColor[1] * tintAmount);
        data[i2 + 2] = Math.min(255, b + waveColor[2] * tintAmount);
      } else {
        const darkenAmount = waveIntensity * 0.15;
        data[i2] = Math.round(r * (1 - darkenAmount));
        data[i2 + 1] = Math.round(g * (1 - darkenAmount));
        data[i2 + 2] = Math.round(b * (1 - darkenAmount));
      }
    }
  }
}
function applyScanlinePattern(data, progress, width, height, seed) {
  const lineWidth = Math.max(4, height * 0.08);
  const lineY = progress * (height + lineWidth * 2) - lineWidth;
  const horizontal = seed % 2 === 0;
  const baseHue = seed * 17 % 360;
  const scanColor = hslToRgbTuple(baseHue, 80, 50);
  const trailColor = hslToRgbTuple((baseHue + 180) % 360, 60, 60);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i2 = (y * width + x) * 4;
      const pos = horizontal ? y : x;
      const linePos = horizontal ? lineY : progress * (width + lineWidth * 2) - lineWidth;
      const distance = Math.abs(pos - linePos);
      const r = data[i2], g = data[i2 + 1], b = data[i2 + 2];
      const brightness = (r + g + b) / 3;
      const isDark = brightness < 128;
      if (distance < lineWidth) {
        const intensity = 1 - distance / lineWidth;
        if (isDark) {
          data[i2] = Math.min(255, r + scanColor[0] * intensity * 0.8);
          data[i2 + 1] = Math.min(255, g + scanColor[1] * intensity * 0.8);
          data[i2 + 2] = Math.min(255, b + scanColor[2] * intensity * 0.8);
        } else {
          data[i2] = Math.max(0, r - trailColor[0] * intensity * 0.3);
          data[i2 + 1] = Math.max(0, g - trailColor[1] * intensity * 0.3);
          data[i2 + 2] = Math.max(0, b - trailColor[2] * intensity * 0.3);
        }
      }
    }
  }
}
function applyShimmerPattern(data, progress, width, height, seed) {
  const random = createSeededRandom(seed + Math.floor(progress * 1e3));
  const spotCount = Math.floor(width * height * 0.02);
  const baseHue = (seed * 13 + progress * 100) % 360;
  for (let s = 0; s < spotCount; s++) {
    const x = Math.floor(random() * width);
    const y = Math.floor(random() * height);
    const i2 = (y * width + x) * 4;
    const r = data[i2], g = data[i2 + 1], b = data[i2 + 2];
    const brightness = (r + g + b) / 3;
    const isDark = brightness < 128;
    const spotHue = (baseHue + random() * 60) % 360;
    const sparkleColor = hslToRgbTuple(spotHue, 90, isDark ? 60 : 40);
    const intensity = 0.5 + random() * 0.5;
    if (isDark) {
      data[i2] = Math.min(255, r + sparkleColor[0] * intensity);
      data[i2 + 1] = Math.min(255, g + sparkleColor[1] * intensity);
      data[i2 + 2] = Math.min(255, b + sparkleColor[2] * intensity);
    } else {
      data[i2] = Math.max(0, r - (255 - sparkleColor[0]) * intensity * 0.3);
      data[i2 + 1] = Math.max(0, g - (255 - sparkleColor[1]) * intensity * 0.3);
      data[i2 + 2] = Math.max(0, b - (255 - sparkleColor[2]) * intensity * 0.3);
    }
  }
}
function applyDriftPattern(data, progress, width, height, seed) {
  const scale = 0.015 + seed % 10 * 3e-3;
  const timeOffset = progress * Math.PI * 2;
  const baseHue = (seed * 41 + progress * 60) % 360;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i2 = (y * width + x) * 4;
      const r = data[i2], g = data[i2 + 1], b = data[i2 + 2];
      const brightness = (r + g + b) / 3;
      const isDark = brightness < 128;
      const drift = Math.sin(x * scale + timeOffset) * Math.cos(y * scale + timeOffset);
      const driftIntensity = (drift + 1) / 2;
      const driftHue = ((baseHue + drift * 40) % 360 + 360) % 360;
      const driftColor = hslToRgbTuple(driftHue, 60, 50);
      if (isDark) {
        const tintAmount = driftIntensity * 0.5;
        data[i2] = Math.min(255, r + driftColor[0] * tintAmount);
        data[i2 + 1] = Math.min(255, g + driftColor[1] * tintAmount);
        data[i2 + 2] = Math.min(255, b + driftColor[2] * tintAmount);
      } else {
        const darkenAmount = driftIntensity * 0.1;
        data[i2] = Math.round(r * (1 - darkenAmount));
        data[i2 + 1] = Math.round(g * (1 - darkenAmount));
        data[i2 + 2] = Math.round(b * (1 - darkenAmount));
      }
    }
  }
}
function applyColorCyclePattern(data, progress, seed) {
  const baseHue = (progress * 360 + seed) % 360;
  const tintColor = hslToRgbTuple(baseHue, 80, 50);
  const complementHue = (baseHue + 180) % 360;
  const complementColor = hslToRgbTuple(complementHue, 30, 70);
  for (let i2 = 0; i2 < data.length; i2 += 4) {
    const r = data[i2], g = data[i2 + 1], b = data[i2 + 2];
    const brightness = (r + g + b) / 3;
    const isDark = brightness < 128;
    if (isDark) {
      const tintAmount = 0.7;
      data[i2] = Math.min(255, r + tintColor[0] * tintAmount);
      data[i2 + 1] = Math.min(255, g + tintColor[1] * tintAmount);
      data[i2 + 2] = Math.min(255, b + tintColor[2] * tintAmount);
    } else {
      const tintAmount = 0.15;
      data[i2] = Math.max(0, Math.round(r - (255 - complementColor[0]) * tintAmount));
      data[i2 + 1] = Math.max(0, Math.round(g - (255 - complementColor[1]) * tintAmount));
      data[i2 + 2] = Math.max(0, Math.round(b - (255 - complementColor[2]) * tintAmount));
    }
  }
}

// netlify/functions/qr.ts
var { GIFEncoder, quantize, applyPalette } = gifenc;
var MAX_SERVER_IMAGE_SIZE = 2048;
var MAX_DATA_LENGTH = 4096;
var MAX_OVERLAY_BYTES = 5 * 1024 * 1024;
var _MAX_OVERLAY_PIXELS = 10 * 1024 * 1024;
var FETCH_TIMEOUT_MS = 1e4;
var DEFAULT_SERVER_DITHER = "ordered_bayer";
var DEFAULT_OUTPUT_FORMAT = "gif";
function isPrivateOrReservedIP(ip) {
  if (ip === "localhost" || ip === "127.0.0.1" || ip === "::1") {
    return true;
  }
  const ipv4Match = ip.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (ipv4Match) {
    const [, a, b, c, _d] = ipv4Match.map(Number);
    if (a === 10) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 169 && b === 254) return true;
    if (a === 127) return true;
    if (a === 0) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    if (a === 192 && b === 0 && c === 0) return true;
    if (a === 192 && b === 0 && c === 2) return true;
    if (a === 198 && b === 51 && c === 100) return true;
    if (a === 203 && b === 0 && c === 113) return true;
    if (a >= 224 && a <= 239) return true;
    if (a >= 240) return true;
  }
  if (ip.startsWith("fe80:") || // link-local
  ip.startsWith("fc") || ip.startsWith("fd") || // unique local
  ip === "::1" || ip.startsWith("::ffff:")) {
    return true;
  }
  return false;
}
var nodeCanvasFactory = {
  createCanvas: async (width, height) => {
    return createCanvas(width, height);
  },
  loadImage: async (src) => {
    return loadImage(src);
  }
};
function createTextWatermark(text, fontSize = 14, fontFamily = "sans-serif", color = "#000000") {
  const measureCanvas = createCanvas(1, 1);
  const measureCtx = measureCanvas.getContext("2d");
  measureCtx.font = `${fontSize}px ${fontFamily}`;
  const metrics = measureCtx.measureText(text);
  const textHeight = fontSize * 1.2;
  const canvas = createCanvas(Math.ceil(metrics.width) + 10, Math.ceil(textHeight) + 10);
  const ctx = canvas.getContext("2d");
  ctx.font = `${fontSize}px ${fontFamily}`;
  ctx.fillStyle = color;
  ctx.textBaseline = "middle";
  ctx.fillText(text, 5, canvas.height / 2);
  return canvas;
}
function getWatermarkPositions(position, canvasWidth, canvasHeight, watermarkWidth, watermarkHeight, margin = 10) {
  const positions = [];
  switch (position) {
    case "center":
      positions.push({
        x: (canvasWidth - watermarkWidth) / 2,
        y: (canvasHeight - watermarkHeight) / 2
      });
      break;
    case "corners":
      positions.push(
        { x: margin, y: margin },
        { x: canvasWidth - watermarkWidth - margin, y: margin },
        { x: margin, y: canvasHeight - watermarkHeight - margin },
        { x: canvasWidth - watermarkWidth - margin, y: canvasHeight - watermarkHeight - margin }
      );
      break;
    case "edges":
      positions.push(
        { x: (canvasWidth - watermarkWidth) / 2, y: margin },
        { x: (canvasWidth - watermarkWidth) / 2, y: canvasHeight - watermarkHeight - margin },
        { x: margin, y: (canvasHeight - watermarkHeight) / 2 },
        { x: canvasWidth - watermarkWidth - margin, y: (canvasHeight - watermarkHeight) / 2 }
      );
      break;
    case "quiet_zone":
      positions.push({ x: margin / 2, y: canvasHeight - watermarkHeight - margin / 2 });
      break;
  }
  return positions;
}
function applyBlendMode(ctx, blend) {
  switch (blend) {
    case "multiply":
      ctx.globalCompositeOperation = "multiply";
      break;
    case "screen":
      ctx.globalCompositeOperation = "screen";
      break;
    case "overlay":
      ctx.globalCompositeOperation = "overlay";
      break;
    default:
      ctx.globalCompositeOperation = "source-over";
      break;
  }
}
function applyWatermarkServer(source, options) {
  if (!options.enabled || options.kind === "text" && !options.text) {
    return source;
  }
  const result = createCanvas(source.width, source.height);
  const ctx = result.getContext("2d");
  if (options.position === "behind") {
    drawWatermarkLayerServer(ctx, options, source.width, source.height);
    ctx.drawImage(source, 0, 0);
  } else {
    ctx.drawImage(source, 0, 0);
    drawWatermarkLayerServer(ctx, options, source.width, source.height);
  }
  return result;
}
function drawWatermarkLayerServer(ctx, options, canvasWidth, canvasHeight) {
  let watermarkCanvas = null;
  if (options.kind === "text" && options.text) {
    watermarkCanvas = createTextWatermark(options.text, 14, "sans-serif", "#000000");
  } else if ((options.kind === "image" || options.kind === "pattern") && options.imageCanvas) {
    watermarkCanvas = options.imageCanvas;
  }
  if (!watermarkCanvas) return;
  ctx.save();
  applyBlendMode(ctx, options.blend);
  ctx.globalAlpha = options.opacity / 100;
  const positions = getWatermarkPositions(
    options.position,
    canvasWidth,
    canvasHeight,
    watermarkCanvas.width,
    watermarkCanvas.height,
    10
  );
  for (const pos of positions) {
    ctx.drawImage(watermarkCanvas, pos.x, pos.y);
  }
  ctx.restore();
}
function calculateCrc32(data) {
  let crc = 4294967295;
  const table = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    table[n] = c;
  }
  for (const byte of data) {
    crc = table[(crc ^ byte) & 255] ^ crc >>> 8;
  }
  return (crc ^ 4294967295) >>> 0;
}
function createPngTextChunk(keyword, text) {
  const keywordBytes = new TextEncoder().encode(keyword);
  const textBytes = new TextEncoder().encode(text);
  const chunkData = new Uint8Array(keywordBytes.length + 1 + textBytes.length);
  chunkData.set(keywordBytes, 0);
  chunkData.set([0], keywordBytes.length);
  chunkData.set(textBytes, keywordBytes.length + 1);
  const chunkType = new TextEncoder().encode("tEXt");
  const chunk = new Uint8Array(4 + 4 + chunkData.length + 4);
  const dataView = new DataView(chunk.buffer);
  dataView.setUint32(0, chunkData.length, false);
  chunk.set(chunkType, 4);
  chunk.set(chunkData, 8);
  const crcData = new Uint8Array(4 + chunkData.length);
  crcData.set(chunkType, 0);
  crcData.set(chunkData, 4);
  const crc = calculateCrc32(crcData);
  dataView.setUint32(8 + chunkData.length, crc, false);
  return chunk;
}
function createPngPhysChunk(dpi) {
  const pixelsPerMeter = Math.round(dpi / 0.0254);
  const chunkData = new Uint8Array(9);
  const chunkDataView = new DataView(chunkData.buffer);
  chunkDataView.setUint32(0, pixelsPerMeter, false);
  chunkDataView.setUint32(4, pixelsPerMeter, false);
  chunkData[8] = 1;
  const chunkType = new TextEncoder().encode("pHYs");
  const chunk = new Uint8Array(4 + 4 + 9 + 4);
  const chunkView = new DataView(chunk.buffer);
  chunkView.setUint32(0, 9, false);
  chunk.set(chunkType, 4);
  chunk.set(chunkData, 8);
  const crcData = new Uint8Array(4 + 9);
  crcData.set(chunkType, 0);
  crcData.set(chunkData, 4);
  const crc = calculateCrc32(crcData);
  chunkView.setUint32(17, crc, false);
  return chunk;
}
function embedPngMetadataAndDpi(pngBuffer, metadata, dpi) {
  const data = new Uint8Array(pngBuffer);
  const pngSignature = [137, 80, 78, 71, 13, 10, 26, 10];
  for (let i2 = 0; i2 < 8; i2++) {
    if (data[i2] !== pngSignature[i2]) {
      return pngBuffer;
    }
  }
  const chunks = [];
  if (dpi && dpi > 0 && dpi !== 72) {
    chunks.push(createPngPhysChunk(dpi));
  }
  if (metadata) {
    const keywordMap = {
      title: "Title",
      author: "Author",
      description: "Description",
      copyright: "Copyright",
      creationTime: "Creation Time",
      software: "Software"
    };
    for (const [key, value] of Object.entries(metadata)) {
      if (value && typeof value === "string") {
        const keyword = keywordMap[key] || key;
        chunks.push(createPngTextChunk(keyword, value));
      }
    }
  }
  if (chunks.length === 0) {
    return pngBuffer;
  }
  const ihdrEnd = 33;
  const totalChunksSize = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
  const newPng = new Uint8Array(data.length + totalChunksSize);
  newPng.set(data.slice(0, ihdrEnd), 0);
  let offset = ihdrEnd;
  for (const chunk of chunks) {
    newPng.set(chunk, offset);
    offset += chunk.length;
  }
  newPng.set(data.slice(ihdrEnd), offset);
  return Buffer.from(newPng);
}
function encodeGif(canvas, colors = 256) {
  const width = canvas.width;
  const height = canvas.height;
  const ctx = canvas.getContext("2d");
  const imageData = ctx.getImageData(0, 0, width, height);
  const { data } = imageData;
  const gif = GIFEncoder();
  const palette = quantize(data, Math.min(256, Math.max(2, colors)));
  const index = applyPalette(data, palette);
  gif.writeFrame(index, width, height, {
    palette,
    delay: 100,
    repeat: 0
  });
  gif.finish();
  return Buffer.from(gif.bytes());
}
function encodeAnimatedGif(frames, frameDelayMs = 100, colors = 256) {
  if (frames.length === 0) {
    throw new Error("No frames to encode");
  }
  const width = frames[0].width;
  const height = frames[0].height;
  const gif = GIFEncoder();
  const paletteSize = Math.min(256, Math.max(2, colors));
  const delayCentiseconds = Math.max(2, Math.round(frameDelayMs / 10));
  for (const frame of frames) {
    const ctx = frame.getContext("2d");
    const imageData = ctx.getImageData(0, 0, width, height);
    const { data } = imageData;
    const palette = quantize(data, paletteSize);
    const index = applyPalette(data, palette);
    const frameOptions = {
      palette,
      delay: delayCentiseconds
    };
    if (i === 0) {
      frameOptions.repeat = 0;
    }
    gif.writeFrame(index, width, height, frameOptions);
  }
  gif.finish();
  return Buffer.from(gif.bytes());
}
function generatePatternFramesServer(sourceCanvas, pattern, frameCount = 24, seed = 0, easing = "linear") {
  if (pattern === "none") {
    return [sourceCanvas];
  }
  const frames = [];
  const width = sourceCanvas.width;
  const height = sourceCanvas.height;
  const sourceCtx = sourceCanvas.getContext("2d");
  const sourceData = sourceCtx.getImageData(0, 0, width, height);
  for (let i2 = 0; i2 < frameCount; i2++) {
    const linearProgress = i2 / frameCount;
    const progress = applyEasing(linearProgress, easing);
    const frame = createCanvas(width, height);
    const ctx = frame.getContext("2d");
    const frameData = ctx.createImageData(width, height);
    frameData.data.set(sourceData.data);
    switch (pattern) {
      case "pulse":
        applyPulsePattern(frameData.data, progress, seed);
        break;
      case "wave":
        applyWavePattern(frameData.data, progress, width, height, seed);
        break;
      case "scanline":
        applyScanlinePattern(frameData.data, progress, width, height, seed);
        break;
      case "shimmer":
        applyShimmerPattern(frameData.data, progress, width, height, seed);
        break;
      case "drift":
        applyDriftPattern(frameData.data, progress, width, height, seed);
        break;
      case "color_cycle":
        applyColorCyclePattern(frameData.data, progress, seed);
        break;
    }
    ctx.putImageData(frameData, 0, 0);
    frames.push(frame);
  }
  return frames;
}
function isGifBuffer(buffer) {
  const view = new DataView(buffer);
  if (view.byteLength < 6) return false;
  const sig = String.fromCodePoint(view.getUint8(0), view.getUint8(1), view.getUint8(2));
  return sig === "GIF";
}
function parseGifFramesServer(arrayBuffer) {
  const gif = parseGIF(arrayBuffer);
  const frames = decompressFrames(gif, true);
  if (frames.length === 0) {
    throw new Error("No frames found in GIF");
  }
  const { width, height } = gif.lsd;
  const compositeCanvas = createCanvas(width, height);
  const compositeCtx = compositeCanvas.getContext("2d");
  const animationFrames = [];
  for (const frame of frames) {
    const { dims, patch, disposalType, delay } = frame;
    const imageData = compositeCtx.createImageData(dims.width, dims.height);
    imageData.data.set(new Uint8ClampedArray(patch));
    const patchCanvas = createCanvas(dims.width, dims.height);
    const patchCtx = patchCanvas.getContext("2d");
    patchCtx.putImageData(imageData, 0, 0);
    compositeCtx.drawImage(patchCanvas, dims.left, dims.top);
    const outputCanvas = createCanvas(width, height);
    const outputCtx = outputCanvas.getContext("2d");
    outputCtx.drawImage(compositeCanvas, 0, 0);
    animationFrames.push({
      canvas: outputCanvas,
      delay: delay * 10,
      // GIF delay is in centiseconds, convert to ms
      disposalType
    });
    if (disposalType === 2) {
      compositeCtx.clearRect(dims.left, dims.top, dims.width, dims.height);
    }
  }
  return animationFrames;
}
function encodeAnimatedGifWithDelays(frames, colors = 256) {
  if (frames.length === 0) {
    throw new Error("No frames to encode");
  }
  const width = frames[0].canvas.width;
  const height = frames[0].canvas.height;
  const gif = GIFEncoder();
  const paletteSize = Math.min(256, Math.max(2, colors));
  for (const frame of frames) {
    const ctx = frame.canvas.getContext("2d");
    const imageData = ctx.getImageData(0, 0, width, height);
    const { data } = imageData;
    const palette = quantize(data, paletteSize);
    const index = applyPalette(data, palette);
    const delayCentiseconds = Math.max(2, Math.round(frame.delay / 10));
    const frameOptions = {
      palette,
      delay: delayCentiseconds
    };
    if (i === 0) {
      frameOptions.repeat = 0;
    }
    gif.writeFrame(index, width, height, frameOptions);
  }
  gif.finish();
  return Buffer.from(gif.bytes());
}
function parseGradientStops(stopsParam) {
  const parts = stopsParam.split(",");
  const stops = [];
  for (let i2 = 0; i2 < parts.length - 1; i2 += 2) {
    const color = `#${parts[i2]}`;
    const pos = Number.parseFloat(parts[i2 + 1]);
    if (!Number.isNaN(pos)) {
      stops.push({ color, pos });
    }
  }
  return stops.length > 0 ? stops : [
    { color: "#000000", pos: 0 },
    { color: "#000000", pos: 1 }
  ];
}
async function fetchImageWithBuffer(url) {
  try {
    let parsedUrl;
    try {
      parsedUrl = new URL(url);
      if (!["http:", "https:"].includes(parsedUrl.protocol)) {
        console.error(`Invalid URL protocol: ${parsedUrl.protocol}`);
        return null;
      }
      if (isPrivateOrReservedIP(parsedUrl.hostname)) {
        console.error(`Blocked request to private/reserved IP: ${parsedUrl.hostname}`);
        return null;
      }
    } catch {
      console.error(`Invalid URL format: ${url}`);
      return null;
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    const response = await fetch(url, {
      headers: {
        "User-Agent": "ANQR-QR-Generator/1.0"
      },
      signal: controller.signal,
      redirect: "follow"
    });
    clearTimeout(timeoutId);
    if (!response.ok) {
      console.error(`Failed to fetch image: ${response.status} ${response.statusText}`);
      return null;
    }
    const contentType = response.headers.get("Content-Type") || "";
    const validImageTypes = [
      "image/png",
      "image/jpeg",
      "image/gif",
      "image/webp",
      "image/svg+xml",
      "image/bmp"
    ];
    const isImage = validImageTypes.some((type) => contentType.toLowerCase().startsWith(type));
    if (!isImage && contentType && !contentType.startsWith("application/octet-stream")) {
      console.error(`Invalid Content-Type for image: ${contentType}`);
      return null;
    }
    const reader = response.body?.getReader();
    if (!reader) {
      console.error("Response body is not readable");
      return null;
    }
    const chunks = [];
    let totalBytes = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        totalBytes += value.byteLength;
        if (totalBytes > MAX_OVERLAY_BYTES) {
          reader.cancel();
          console.error(
            `Overlay image too large: ${totalBytes}+ bytes (max: ${MAX_OVERLAY_BYTES})`
          );
          return null;
        }
        chunks.push(value);
      }
    } catch (streamError) {
      console.error("Error reading overlay stream:", streamError);
      return null;
    }
    const arrayBuffer = new Uint8Array(totalBytes);
    let offset = 0;
    for (const chunk of chunks) {
      arrayBuffer.set(chunk, offset);
      offset += chunk.byteLength;
    }
    const buffer = Buffer.from(arrayBuffer);
    let isAnimatedGif = false;
    if (isGifBuffer(arrayBuffer)) {
      try {
        const gif = parseGIF(arrayBuffer);
        const frames = decompressFrames(gif, true);
        isAnimatedGif = frames.length > 1;
      } catch (e) {
        console.warn("Failed to parse GIF for frame detection:", e);
      }
    }
    const img = await loadImage(buffer);
    if (!(img.width && img.height) || img.width <= 0 || img.height <= 0) {
      console.error(`Invalid image dimensions: ${img.width}x${img.height}`);
      return null;
    }
    const canvas = createCanvas(img.width, img.height);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);
    return {
      canvas,
      arrayBuffer,
      isAnimatedGif
    };
  } catch (error) {
    console.error("Error fetching overlay image:", error);
    return null;
  }
}
async function fetchImageAsCanvas(url) {
  const result = await fetchImageWithBuffer(url);
  return result?.canvas ?? null;
}
async function handler(request) {
  const url = new URL(request.url);
  const params = url.searchParams;
  const data = params.get("data");
  if (!data) {
    return new Response('Missing required "data" parameter', {
      status: 400,
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  }
  if (data.length > MAX_DATA_LENGTH) {
    return new Response(`Data too long: ${data.length} characters (max: ${MAX_DATA_LENGTH})`, {
      status: 400,
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  }
  const sizeParam = Number.parseInt(params.get("size") || "400", 10);
  const modulePxParam = params.get("modulePx") ? Number.parseInt(params.get("modulePx"), 10) : null;
  const widthParam = params.get("w") ? Number.parseInt(params.get("w"), 10) : null;
  const heightParam = params.get("h") ? Number.parseInt(params.get("h"), 10) : null;
  const outputWidth = Math.min(MAX_SERVER_IMAGE_SIZE, Math.max(50, widthParam ?? sizeParam));
  const outputHeight = Math.min(MAX_SERVER_IMAGE_SIZE, Math.max(50, heightParam ?? sizeParam));
  const size = Math.max(outputWidth, outputHeight);
  const fg = params.get("fg") || "000000";
  const bg = params.get("bg") || "ffffff";
  const ec = params.get("ec")?.toUpperCase() || "H";
  const margin = Math.min(20, Math.max(0, Number.parseInt(params.get("margin") || "4", 10)));
  const transparent = params.get("transparent") === "1";
  const encodingMode = params.get("enc") || "auto";
  const version = params.get("v") ? Number.parseInt(params.get("v"), 10) : 0;
  const maskPatternParam = params.get("mask");
  const parsedMask = maskPatternParam ? Number.parseInt(maskPatternParam, 10) : NaN;
  const maskPattern = maskPatternParam === "auto" || !maskPatternParam || Number.isNaN(parsedMask) ? "auto" : Math.min(7, Math.max(0, parsedMask));
  const charsetParam = params.get("charset") || "default";
  const characterEncoding = ["default", "utf8", "shift-jis"].includes(charsetParam) ? charsetParam : "default";
  const borderModulesExtra = Math.min(
    10,
    Math.max(0, Number.parseInt(params.get("border") || "0", 10))
  );
  const crispEdges = params.get("crisp") !== "0";
  const pixelSnap = params.get("snap") || "floor";
  const perModuleColorMode = params.get("modColor") || "solid";
  const contrastGuard = params.get("cGuard") === "1";
  const minContrastRatio = Number.parseFloat(params.get("minContrast") || "4.5");
  const moduleStyle = params.get("style") || "square";
  const finderStyle = params.get("finder") || "square";
  const eyeOuterStyle = params.get("eyeOuter") || finderStyle;
  const eyeInnerStyle = params.get("eyeInner") || finderStyle;
  const eyeScale = Math.min(
    150,
    Math.max(50, Number.parseInt(params.get("eyeScale") || "100", 10))
  );
  const cornerRadius = Math.min(100, Math.max(0, Number.parseInt(params.get("radius") || "0", 10)));
  const moduleGap = Math.min(50, Math.max(0, Number.parseInt(params.get("gap") || "0", 10)));
  const gapMode = params.get("gapMode") || "none";
  const dotRotationDeg = Number.parseInt(params.get("dotRot") || "0", 10);
  const frameStyle = params.get("frame") || "none";
  const frameText = params.get("frameText") || "";
  const gradientType = params.get("grad") || "none";
  const gradientAngle = Number.parseInt(params.get("gradAngle") || "0", 10);
  const gradientStopsParam = params.get("gradStops");
  const gradientStops = gradientStopsParam ? parseGradientStops(gradientStopsParam) : void 0;
  const alignmentStyle = params.get("align") || "match_finder";
  const timingStyle = params.get("timing") || "match_module";
  const preserveFinders = params.get("keepFinders") !== "0";
  const preserveTiming = params.get("keepTiming") === "1";
  const preserveAlignment = params.get("keepAlign") === "1";
  const protectFormatInfo = params.get("protectFmt") === "1";
  const protectVersionInfo = params.get("protectVer") === "1";
  const eccAwareEnabled = params.get("eccAware") === "1";
  const eccAwareRiskBudget = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("eccRisk") || "50", 10))
  );
  const eccAwareWeightMap = params.get("eccMap") || "distance_to_finders";
  const overlayUrl = params.get("img");
  const overlayMode = params.get("mode") || (overlayUrl ? "dithered" : void 0);
  const overlayIntensity = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("intensity") || "100", 10))
  );
  const colorMode = params.get("colorMode") || "color";
  const logoSize = Math.min(50, Math.max(5, Number.parseInt(params.get("logoSize") || "25", 10)));
  const overlayBrightness = Math.min(
    100,
    Math.max(-100, Number.parseInt(params.get("brightness") || "0", 10))
  );
  const overlayContrast = Math.min(
    100,
    Math.max(-100, Number.parseInt(params.get("contrast") || "0", 10))
  );
  const overlayGamma = Math.max(0.1, Math.min(3, Number.parseFloat(params.get("gamma") || "1")));
  const overlaySaturation = Math.min(
    100,
    Math.max(-100, Number.parseInt(params.get("saturation") || "0", 10))
  );
  const overlayHueRotate = Number.parseInt(params.get("hue") || "0", 10);
  const overlayInvert = params.get("invert") === "1";
  const overlayBlur = Math.max(0, Number.parseInt(params.get("blur") || "0", 10));
  const overlaySharpen = Math.max(0, Number.parseInt(params.get("sharpen") || "0", 10));
  const overlayPosterize = Math.max(0, Number.parseInt(params.get("posterize") || "0", 10));
  const overlayThreshold = Math.min(
    255,
    Math.max(0, Number.parseInt(params.get("threshold") || "128", 10))
  );
  const overlayEdgeDetect = params.get("edge") || "off";
  const overlayFit = params.get("fit") || "cover";
  const overlayRotate = Number.parseInt(params.get("rot") || "0", 10);
  const overlayFlipX = params.get("flipX") === "1";
  const overlayFlipY = params.get("flipY") === "1";
  const ditherKindParam = params.get("ditherKind");
  const ditherKind = ditherKindParam || DEFAULT_SERVER_DITHER;
  const diffusionKernel = params.get("diffusionKernel") || "floyd_steinberg";
  const ditherStrength = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("ditherStrength") || "50", 10))
  );
  const ditherSerpentine = params.get("serpentine") === "1";
  const orderedMatrix = params.get("matrix") || "bayer4";
  const blueNoiseTileSize = Number.parseInt(params.get("bnTile") || "64", 10);
  const blueNoiseSeed = Number.parseInt(params.get("bnSeed") || "0", 10);
  const colorDither = params.get("colorDither") || "none";
  const subpixelGridSize = params.get("spGrid") || "3x3";
  const subpixelCenterRule = params.get("spCenter") || "strict";
  const subpixelNeutralColor = params.get("spNeutral") ? `#${params.get("spNeutral")}` : "#808080";
  const subpixelFinderOverride = params.get("spFinder") || "solid";
  const halftoneCell = params.get("htCell") || "per_module";
  const halftoneDotShape = params.get("htDot") || "circle";
  const brightnessCurve = params.get("htCurve") || "linear";
  const duotoneColor1 = params.get("duo1") ? `#${params.get("duo1")}` : "#000000";
  const duotoneColor2 = params.get("duo2") ? `#${params.get("duo2")}` : "#ffffff";
  const paletteParam = params.get("palette");
  const palette = paletteParam ? paletteParam.split(",").map((c) => c.startsWith("#") ? c : `#${c}`) : void 0;
  const paletteMode = params.get("paletteMode") || "position";
  const maxOverlayIntensityL = Number.parseInt(
    params.get("maxIntL") || params.get("maxOverlayIntensityL") || "100",
    10
  );
  const maxOverlayIntensityM = Number.parseInt(
    params.get("maxIntM") || params.get("maxOverlayIntensityM") || "100",
    10
  );
  const maxOverlayIntensityQ = Number.parseInt(
    params.get("maxIntQ") || params.get("maxOverlayIntensityQ") || "100",
    10
  );
  const maxOverlayIntensityH = Number.parseInt(
    params.get("maxIntH") || params.get("maxOverlayIntensityH") || "100",
    10
  );
  let outputFormat = params.get("format") || DEFAULT_OUTPUT_FORMAT;
  const _outputQuality = Math.max(
    0,
    Math.min(1, Number.parseFloat(params.get("quality") || "0.9"))
  );
  const outputDpi = Math.max(1, Math.min(1200, Number.parseInt(params.get("dpi") || "72", 10)));
  const watermarkEnabled = params.get("wmEn") === "1";
  const watermarkKind = params.get("wmKind") || "text";
  const watermarkText = params.get("wmText") || "";
  const watermarkImageUrl = params.get("wmImg") || void 0;
  const watermarkPosition = params.get("wmPos") || "center";
  const watermarkOpacity = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("wmOpacity") || "50", 10))
  );
  const watermarkBlend = params.get("wmBlend") || "normal";
  const animationPattern = params.get("animPattern") || "none";
  const animationFramesRaw = Number.parseInt(params.get("animFrames") || "24", 10);
  const animationFrames = Math.min(
    60,
    Math.max(1, Number.isNaN(animationFramesRaw) ? 24 : animationFramesRaw)
  );
  const animationSpeedRaw = Number.parseInt(params.get("animSpeed") || "100", 10);
  const animationSpeed = Math.min(
    1e3,
    Math.max(10, Number.isNaN(animationSpeedRaw) ? 100 : animationSpeedRaw)
  );
  const animationSeed = Number.parseInt(params.get("animSeed") || "0", 10);
  const animationEasing = params.get("easing") || "linear";
  const webpQuality = Math.min(100, Math.max(0, Number.parseInt(params.get("webpQ") || "90", 10)));
  const gifColors = Math.min(
    256,
    Math.max(2, Number.parseInt(params.get("gifColors") || "256", 10))
  );
  const metaTitle = params.get("metaTitle") || void 0;
  const metaAuthor = params.get("metaAuthor") || void 0;
  const metaCopyright = params.get("metaCopy") || void 0;
  const metaDescription = params.get("metaDesc") || void 0;
  if (!["L", "M", "Q", "H"].includes(ec)) {
    return new Response('Invalid "ec" parameter. Use L, M, Q, or H', {
      status: 400,
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  }
  const validModuleStyles = ["square", "rounded", "dots", "diamond", "connected"];
  if (!validModuleStyles.includes(moduleStyle)) {
    return new Response(`Invalid "style" parameter. Use one of: ${validModuleStyles.join(", ")}`, {
      status: 400,
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  }
  try {
    const qrGenerator = new QRGenerator(nodeCanvasFactory);
    const estimatedVersion = qrGenerator.calculateOptimalVersion(data, ec);
    const estimatedModuleCount = estimatedVersion * 4 + 17;
    const totalMargin = margin + borderModulesExtra;
    const moduleSize = modulePxParam ? Math.max(1, Math.min(50, modulePxParam)) : Math.max(
      1,
      Math.floor((size - totalMargin * 2) / (estimatedModuleCount + totalMargin * 2))
    );
    const config = {
      content: data,
      typeNumber: version,
      // 0 = auto-detect
      errorCorrection: ec,
      encodingMode,
      maskPattern,
      characterEncoding,
      moduleSize,
      margin: margin + borderModulesExtra,
      crispEdges,
      pixelSnap,
      fgColor: `#${fg}`,
      bgColor: `#${bg}`,
      transparentBg: transparent,
      moduleStyle,
      finderStyle,
      alignmentStyle,
      timingStyle,
      eyeOuterStyle,
      eyeInnerStyle,
      eyeScale,
      cornerRadius,
      moduleGap,
      gapMode,
      dotRotationDeg,
      frameStyle,
      frameText,
      perModuleColorMode,
      contrastGuard,
      minContrastRatio,
      overlayMode,
      overlayIntensity,
      colorMode,
      logoSize,
      preserveFinders,
      preserveTiming,
      preserveAlignment,
      protectFormatInfo,
      protectVersionInfo,
      eccAwareEnabled,
      eccAwareRiskBudget,
      eccAwareWeightMap,
      overlayBrightness,
      overlayContrast,
      overlayGamma,
      overlaySaturation,
      overlayHueRotate,
      invertImage: overlayInvert,
      overlayBlur,
      overlaySharpen,
      overlayPosterize,
      overlayThreshold,
      overlayEdgeDetect,
      overlayFit,
      overlayRotate,
      overlayFlipX,
      overlayFlipY,
      // Dither options
      ditherKind,
      diffusionKernel,
      ditherStrength,
      ditherSerpentine,
      orderedMatrix,
      blueNoiseTileSize,
      blueNoiseSeed,
      colorDither,
      // Subpixel options
      subpixelGridSize,
      subpixelCenterRule,
      subpixelNeutralColor,
      subpixelFinderOverride,
      // Halftone options
      halftoneCell,
      halftoneDotShape,
      brightnessCurve,
      duotoneColors: [duotoneColor1, duotoneColor2],
      // Palette
      palette,
      paletteMode,
      gradient: gradientType === "none" ? void 0 : {
        type: gradientType,
        angle: gradientAngle,
        stops: gradientStops
      },
      // Per-ECC intensity limits
      maxOverlayIntensityByEcc: {
        L: maxOverlayIntensityL,
        M: maxOverlayIntensityM,
        Q: maxOverlayIntensityQ,
        H: maxOverlayIntensityH
      },
      // Animation settings (pattern-based animation is supported server-side)
      // Note: colorCycle, temporalDither, interpolate, moduleJitter are client-only
      animationPattern,
      animationFrames,
      animationSpeed,
      animationSeed,
      moduleJitterPx: 0,
      // Not supported server-side (requires per-frame QR generation)
      colorCycle: false
      // Not supported server-side (requires post-processing)
    };
    let overlayCanvas = null;
    let overlayFrames = [];
    let hasAnimatedOverlay = false;
    if (overlayUrl && overlayMode) {
      const fetchedImage = await fetchImageWithBuffer(overlayUrl);
      if (fetchedImage) {
        overlayCanvas = fetchedImage.canvas;
        if (fetchedImage.isAnimatedGif) {
          outputFormat = "gif";
          hasAnimatedOverlay = true;
          overlayFrames = parseGifFramesServer(fetchedImage.arrayBuffer);
        }
      }
    }
    let canvas = await qrGenerator.generate(config, overlayCanvas);
    let watermarkImageCanvas = null;
    if (watermarkEnabled && (watermarkKind === "image" || watermarkKind === "pattern") && watermarkImageUrl) {
      watermarkImageCanvas = await fetchImageAsCanvas(watermarkImageUrl);
    }
    if (watermarkEnabled) {
      canvas = applyWatermarkServer(canvas, {
        enabled: watermarkEnabled,
        kind: watermarkKind,
        text: watermarkText,
        imageCanvas: watermarkImageCanvas,
        position: watermarkPosition,
        opacity: watermarkOpacity,
        blend: watermarkBlend
      });
    }
    let outputCanvas = canvas;
    if (canvas.width !== outputWidth || canvas.height !== outputHeight) {
      outputCanvas = createCanvas(outputWidth, outputHeight);
      const ctx = outputCanvas.getContext("2d");
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(canvas, 0, 0, outputWidth, outputHeight);
    }
    const metadata = metaTitle || metaAuthor || metaCopyright || metaDescription ? {
      title: metaTitle,
      author: metaAuthor,
      copyright: metaCopyright,
      description: metaDescription,
      creationTime: (/* @__PURE__ */ new Date()).toISOString(),
      software: "ANQR - anqr.link"
    } : void 0;
    let animationFrameCanvases = [];
    const animatedOverlayFrames = [];
    if (outputFormat === "gif") {
      if (hasAnimatedOverlay && overlayFrames.length > 1) {
        for (const overlayFrame of overlayFrames) {
          const frameCanvas = await qrGenerator.generate(config, overlayFrame.canvas);
          let scaledFrame = frameCanvas;
          if (frameCanvas.width !== outputWidth || frameCanvas.height !== outputHeight) {
            scaledFrame = createCanvas(outputWidth, outputHeight);
            const ctx = scaledFrame.getContext("2d");
            ctx.imageSmoothingEnabled = false;
            ctx.drawImage(frameCanvas, 0, 0, outputWidth, outputHeight);
          }
          if (watermarkEnabled) {
            scaledFrame = applyWatermarkServer(scaledFrame, {
              enabled: watermarkEnabled,
              kind: watermarkKind,
              text: watermarkText,
              imageCanvas: watermarkImageCanvas,
              position: watermarkPosition,
              opacity: watermarkOpacity,
              blend: watermarkBlend
            });
          }
          animatedOverlayFrames.push({
            canvas: scaledFrame,
            delay: overlayFrame.delay,
            disposalType: overlayFrame.disposalType
          });
        }
      } else if (animationPattern !== "none") {
        animationFrameCanvases = generatePatternFramesServer(
          outputCanvas,
          animationPattern,
          animationFrames,
          animationSeed,
          animationEasing
        );
      }
    }
    let outputBuffer;
    let contentType;
    switch (outputFormat) {
      case "gif":
        if (animatedOverlayFrames.length > 1) {
          outputBuffer = encodeAnimatedGifWithDelays(animatedOverlayFrames, gifColors);
        } else if (animationFrameCanvases.length > 1) {
          outputBuffer = encodeAnimatedGif(animationFrameCanvases, animationSpeed, gifColors);
        } else {
          outputBuffer = encodeGif(outputCanvas, gifColors);
        }
        contentType = "image/gif";
        break;
      case "webp":
        outputBuffer = outputCanvas.toBuffer("image/webp", webpQuality);
        contentType = "image/webp";
        break;
      default:
        outputBuffer = outputCanvas.toBuffer("image/png");
        if (metadata || outputDpi !== 72) {
          outputBuffer = embedPngMetadataAndDpi(outputBuffer, metadata, outputDpi);
        }
        contentType = "image/png";
        break;
    }
    return new Response(new Uint8Array(outputBuffer), {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "public, max-age=31536000, immutable",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error("QR generation error:", error);
    return new Response(`Error generating QR code: ${message}`, {
      status: 500,
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  }
}
var qr_default = handler;
export {
  qr_default as default
};
