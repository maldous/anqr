
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/qr.ts
import * as Sentry2 from "@sentry/node";

// package.json
var package_default = {
  name: "anqr",
  version: "1.0.66",
  description: "These are my existing files for ANQR:",
  scripts: {
    dev: "vite",
    build: "tsc && vite build",
    preview: "vite preview",
    typecheck: "tsc --noEmit",
    test: "playwright test",
    "test:basic": "playwright test --project=basic",
    "test:advanced": "playwright test --project=advanced",
    "test:professional": "playwright test --project=professional",
    "test:permutations": "playwright test --project=permutations",
    "test:ui": "playwright test --ui",
    "test:report": "playwright show-report",
    "test:unit": "ANQR_LOG_LEVEL=error vitest run --maxWorkers=100% --exclude 'tests/unit/gallery-scan-matrix.spec.ts' --exclude 'tests/unit/overlay-preservation-mode-audit.spec.ts'",
    "test:unit:coverage": "ANQR_LOG_LEVEL=error vitest run --maxWorkers=100% --coverage --exclude 'tests/unit/gallery-scan-matrix.spec.ts' --exclude 'tests/unit/overlay-preservation-mode-audit.spec.ts' --exclude 'tests/unit/qr-generator-dithered-scan-gate.spec.ts'",
    "test:coverage:gap": "node scripts/report-code-coverage-gap.js",
    "test:unit:watch": "vitest",
    "test:unit:ci": "npm run test:unit",
    "test:ids": "node scripts/generate-test-ids.js",
    "test:required": "node scripts/generate-required-tests.js",
    "test:required:strict": "node scripts/check-required-tests.js",
    "test:required:gap": "node scripts/report-required-gap.js",
    "test:testid": "node scripts/audit-testid-coverage.js",
    "test:testid:refs": "node scripts/check-testid-references.js",
    "test:i18n": "node scripts/check-i18n-regressions.js",
    "test:bundle:budget": "node scripts/check-bundle-budgets.mjs",
    "report:payload:matrix": "node scripts/generate-payload-matrix.mjs",
    "validate:services": "node scripts/validate-third-party.mjs",
    "check:sentry": "node scripts/check-sentry-regression.mjs",
    "report:i18n:txt": "node scripts/check-i18n-txt.js",
    "qr:art": "npx tsx scripts/run-qr-art.ts",
    "test:signoff": "node scripts/production-signoff-check.js"
  },
  repository: {
    type: "git",
    url: "git@github-private:maldous/anqr.git"
  },
  keywords: [],
  author: "",
  license: "ISC",
  type: "module",
  dependencies: {
    "@capacitor-community/admob": "^8.0.0",
    "@capacitor/android": "^8.0.2",
    "@capacitor/camera": "^8.0.0",
    "@capacitor/core": "^8.0.2",
    "@capacitor/filesystem": "^8.1.0",
    "@capacitor/splash-screen": "^8.0.0",
    "@napi-rs/canvas": "^0.1.90",
    "@radix-ui/react-accordion": "^1.2.12",
    "@radix-ui/react-label": "^2.1.8",
    "@radix-ui/react-popover": "^1.1.15",
    "@radix-ui/react-select": "^2.2.6",
    "@radix-ui/react-slider": "^1.3.6",
    "@radix-ui/react-slot": "^1.2.4",
    "@radix-ui/react-switch": "^1.2.6",
    "@radix-ui/react-tabs": "^1.1.13",
    "@radix-ui/react-tooltip": "^1.2.8",
    "@sentry/node": "^10.38.0",
    "@sentry/react": "^10.38.0",
    "class-variance-authority": "^0.7.1",
    clsx: "^2.1.1",
    "date-fns": "^4.1.0",
    gifenc: "^1.0.3",
    "gifuct-js": "^2.1.2",
    i18next: "^25.8.4",
    "i18next-browser-languagedetector": "^8.2.0",
    lefthook: "^2.1.1",
    loglevel: "^1.9.2",
    "loglevel-plugin-prefix": "^0.8.4",
    "lucide-react": "^0.563.0",
    "open-location-code": "^1.0.3",
    react: "^19.2.4",
    "react-day-picker": "^9.13.1",
    "react-dom": "^19.2.4",
    "react-i18next": "^16.5.4",
    "tailwind-merge": "^3.4.0",
    zustand: "^5.0.11"
  },
  devDependencies: {
    "@biomejs/biome": "^2.3.14",
    "@capacitor/cli": "^8.0.2",
    "@commitlint/cli": "^20.4.1",
    "@commitlint/config-conventional": "^20.4.1",
    "@playwright/test": "^1.58.2",
    "@sentry/vite-plugin": "^4.9.0",
    "@tailwindcss/postcss": "^4.1.18",
    "@types/open-location-code": "^1.0.1",
    "@types/react": "^19.2.13",
    "@types/react-dom": "^19.2.3",
    "@vitejs/plugin-react": "^5.1.3",
    "@vitest/coverage-v8": "^4.0.18",
    autoprefixer: "^10.4.24",
    cspell: "^9.6.4",
    "dependency-cruiser": "^17.3.7",
    "happy-dom": "^20.5.0",
    jscpd: "^4.0.8",
    jsdom: "^28.0.0",
    knip: "^5.83.1",
    "license-checker": "^25.0.1",
    "lint-staged": "^16.2.7",
    "lockfile-lint": "^5.0.0",
    "netlify-cli": "^23.15.1",
    postcss: "^8.5.6",
    puppeteer: "^24.37.2",
    "rollup-plugin-visualizer": "^6.0.5",
    serve: "^14.2.5",
    sharp: "^0.34.5",
    tailwindcss: "^4.1.18",
    terser: "^5.46.0",
    "type-coverage": "^2.29.7",
    typescript: "^5.9.3",
    vite: "^7.3.1",
    "vite-plugin-compression": "^0.5.1",
    "vite-plugin-pwa": "^1.2.0",
    vitest: "^4.0.18"
  }
};

// netlify/functions/qr.ts
import { createHash } from "node:crypto";
import { createCanvas, loadImage } from "@napi-rs/canvas";

// src/lib/logger.ts
import * as Sentry from "@sentry/react";
import loglevel from "loglevel";
import prefix from "loglevel-plugin-prefix";
var MAX_BUFFER_SIZE = 2e3;
var MAX_STRUCTURED_BUFFER_SIZE = 5e3;
var MAX_CONTEXT_DEPTH = 10;
var logBufferEnabled = false;
var logBuffer = [];
var structuredLogBuffer = [];
function safeSerializeContext(context) {
  if (context === null || context === void 0) {
    return context;
  }
  try {
    return structuredClone(context);
  } catch {
  }
  try {
    const jsonStr = JSON.stringify(context, (_key, value) => {
      if (value instanceof Error) {
        return {
          __type: "Error",
          name: value.name,
          message: value.message,
          stack: value.stack
        };
      }
      if (value instanceof Set) {
        return { __type: "Set", values: Array.from(value) };
      }
      if (value instanceof Map) {
        return { __type: "Map", entries: Array.from(value.entries()) };
      }
      if (typeof value === "function") {
        return "[Function]";
      }
      if (value instanceof HTMLElement) {
        return `[HTMLElement: ${value.tagName}]`;
      }
      if (value instanceof Node) {
        return `[Node: ${value.nodeName}]`;
      }
      if (ArrayBuffer.isView(value) && !(value instanceof DataView)) {
        return { __type: value.constructor.name, values: Array.from(value) };
      }
      return value;
    });
    return JSON.parse(jsonStr);
  } catch {
  }
  if (typeof context === "object") {
    const result = {};
    try {
      for (const [key, value] of Object.entries(context)) {
        try {
          if (value === null || value === void 0) {
            result[key] = value;
          } else if (typeof value === "function") {
            result[key] = "[Function]";
          } else if (typeof value === "object") {
            result[key] = JSON.parse(JSON.stringify(value));
          } else {
            result[key] = value;
          }
        } catch {
          result[key] = `[Unserializable: ${typeof value}]`;
        }
      }
      return result;
    } catch {
      return "[Unserializable object]";
    }
  }
  return "[Unserializable]";
}
function captureToBuffer(scope, level, message, context) {
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  if (structuredLogBuffer.length >= MAX_STRUCTURED_BUFFER_SIZE) {
    structuredLogBuffer.shift();
  }
  const serializedContext = context ? safeSerializeContext(context) : void 0;
  structuredLogBuffer.push({
    timestamp,
    scope,
    level,
    message,
    context: serializedContext
  });
  if (!logBufferEnabled) return;
  const prefix2 = `${timestamp} [${scope}:${level}]`;
  let logLine;
  if (context && typeof context === "object") {
    try {
      const dataStr = Object.entries(context).map(([k, v]) => {
        if (typeof v === "object" && v !== null) {
          return `${k}=${JSON.stringify(v)}`;
        }
        return `${k}=${v}`;
      }).join(", ");
      logLine = `${prefix2} ${message} {${dataStr}}`;
    } catch {
      logLine = `${prefix2} ${message} {[serialization failed]}`;
    }
  } else {
    logLine = `${prefix2} ${message}`;
  }
  if (logBuffer.length >= MAX_BUFFER_SIZE) {
    logBuffer.shift();
  }
  logBuffer.push(logLine);
}
var SENSITIVE_KEYS = /* @__PURE__ */ new Set([
  "password",
  "token",
  "secret",
  "apikey",
  "api_key",
  "authorization",
  "auth",
  "credential",
  "sessionid",
  "session_id",
  "accesstoken",
  "access_token",
  "refreshtoken",
  "refresh_token",
  "privatekey",
  "private_key"
]);
var REDACTED = "[REDACTED]";
prefix.reg(loglevel);
prefix.apply(loglevel, {
  format(_level, name) {
    return `[${name}]`;
  }
});
var envLevelRaw = typeof process !== "undefined" ? process.env.ANQR_LOG_LEVEL?.toLowerCase() : void 0;
var envLevel = (() => {
  switch (envLevelRaw) {
    case "trace":
    case "debug":
    case "info":
    case "warn":
    case "error":
    case "silent":
      return envLevelRaw;
    default:
      return void 0;
  }
})();
var isDev = typeof import.meta?.env?.DEV !== "undefined" ? import.meta.env.DEV : process.env.NODE_ENV !== "production";
var defaultLevel = envLevel ?? (isDev ? "debug" : "error");
loglevel.setLevel(defaultLevel);
function redactSensitive(obj, depth = 0) {
  if (depth > MAX_CONTEXT_DEPTH) return "[MAX_DEPTH]";
  if (obj === null || obj === void 0) return obj;
  if (typeof obj !== "object") return obj;
  if (Array.isArray(obj)) {
    return obj.map((item) => redactSensitive(item, depth + 1));
  }
  if (obj instanceof Error) return obj;
  if (obj instanceof Set || obj instanceof Map) return obj;
  if (typeof Node !== "undefined" && obj instanceof Node) return obj;
  if (ArrayBuffer.isView(obj)) return obj;
  const result = {};
  for (const [key, value] of Object.entries(obj)) {
    if (SENSITIVE_KEYS.has(key.toLowerCase())) {
      result[key] = REDACTED;
    } else {
      result[key] = redactSensitive(value, depth + 1);
    }
  }
  return result;
}
function createLogger(scope) {
  const upperScope = scope.toUpperCase();
  const logger = loglevel.getLogger(upperScope);
  logger.setLevel(loglevel.getLevel());
  return {
    trace(message, context) {
      const safe = context ? redactSensitive(context) : void 0;
      captureToBuffer(upperScope, "trace", message, safe);
      if (safe) {
        logger.trace(message, safe);
      } else {
        logger.trace(message);
      }
    },
    debug(message, context) {
      const safe = context ? redactSensitive(context) : void 0;
      captureToBuffer(upperScope, "debug", message, safe);
      if (safe) {
        logger.debug(message, safe);
      } else {
        logger.debug(message);
      }
    },
    info(message, context) {
      const safe = context ? redactSensitive(context) : void 0;
      captureToBuffer(upperScope, "info", message, safe);
      if (safe) {
        logger.info(message, safe);
      } else {
        logger.info(message);
      }
    },
    warn(message, context) {
      const safe = context ? redactSensitive(context) : void 0;
      captureToBuffer(upperScope, "warn", message, safe);
      if (context) {
        logger.warn(message, safe);
      } else {
        logger.warn(message);
      }
      Sentry.addBreadcrumb({
        category: upperScope,
        message,
        level: "warning",
        data: safe
      });
    },
    error(message, context) {
      const safe = context ? redactSensitive(context) : void 0;
      captureToBuffer(upperScope, "error", message, safe);
      if (context) {
        logger.error(message, safe);
      } else {
        logger.error(message);
      }
      Sentry.withScope((sentryScope) => {
        sentryScope.setTag("logger.scope", upperScope);
        if (safe) {
          sentryScope.setExtras(safe);
        }
        const errorObj = context?.error;
        if (errorObj instanceof Error) {
          sentryScope.setExtra("originalMessage", message);
          Sentry.captureException(errorObj);
        } else {
          Sentry.captureMessage(`[${upperScope}] ${message}`, "error");
        }
      });
    }
  };
}

// src/modules/core/color.ts
var _log = createLogger("COLOR");
var BLACK = { r: 0, g: 0, b: 0, a: 1 };
function parseHex(hex) {
  hex = hex.replace("#", "");
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  }
  return {
    r: Number.parseInt(hex.substring(0, 2), 16),
    g: Number.parseInt(hex.substring(2, 4), 16),
    b: Number.parseInt(hex.substring(4, 6), 16)
  };
}
function parseHexAlpha(hex) {
  hex = hex.replace("#", "");
  if (hex.length === 4) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
  }
  const rgb = parseHex(hex.substring(0, 6));
  const a = hex.length >= 8 ? Number.parseInt(hex.substring(6, 8), 16) / 255 : 1;
  return { ...rgb, a };
}
function parseRgbString(str) {
  const rgbRegex = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/;
  const match = rgbRegex.exec(str);
  if (match) {
    return {
      r: Number.parseInt(match[1], 10),
      g: Number.parseInt(match[2], 10),
      b: Number.parseInt(match[3], 10),
      a: match[4] === void 0 ? 1 : Number.parseFloat(match[4])
    };
  }
  return { r: 0, g: 0, b: 0, a: 1 };
}
function parseHslString(str) {
  const hslRegex = /hsla?\((\d+),\s*([\d.]+)%?,\s*([\d.]+)%?(?:,\s*([\d.]+))?\)/;
  const match = hslRegex.exec(str);
  if (match) {
    return {
      h: Number.parseInt(match[1], 10),
      s: Number.parseFloat(match[2]),
      l: Number.parseFloat(match[3]),
      a: match[4] === void 0 ? 1 : Number.parseFloat(match[4])
    };
  }
  return { h: 0, s: 0, l: 0, a: 1 };
}
var NAMED_COLORS = {
  black: "#000000",
  white: "#ffffff",
  red: "#ff0000",
  green: "#00ff00",
  blue: "#0000ff",
  yellow: "#ffff00",
  cyan: "#00ffff",
  magenta: "#ff00ff",
  gray: "#808080",
  grey: "#808080",
  transparent: "#00000000"
};
function parseColor(color) {
  color = color.trim().toLowerCase();
  if (color.startsWith("#")) {
    return parseHexAlpha(color);
  }
  if (color.startsWith("rgb")) {
    return parseRgbString(color);
  }
  if (color.startsWith("hsl")) {
    const hsl = parseHslString(color);
    const rgb = hslToRgb(hsl.h, hsl.s, hsl.l);
    return { ...rgb, a: hsl.a };
  }
  if (NAMED_COLORS[color]) {
    return parseHexAlpha(NAMED_COLORS[color]);
  }
  return null;
}
function rgbToHex(r, g, b) {
  const toHex = (n) => Math.round(n).toString(16).padStart(2, "0");
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
function rgbaToString(r, g, b, a) {
  return `rgba(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)}, ${a})`;
}
function rgbToGray(r, g, b) {
  return r * 0.299 + g * 0.587 + b * 0.114;
}
function rgbToHsl(r, g, b) {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        break;
      case g:
        h = ((b - r) / d + 2) / 6;
        break;
      case b:
        h = ((r - g) / d + 4) / 6;
        break;
    }
  }
  return { h: h * 360, s: s * 100, l: l * 100 };
}
function hslToRgb(h, s, l) {
  h /= 360;
  s /= 100;
  l /= 100;
  let r, g, b;
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p2, q2, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p2 + (q2 - p2) * 6 * t;
      if (t < 1 / 2) return q2;
      if (t < 2 / 3) return p2 + (q2 - p2) * (2 / 3 - t) * 6;
      return p2;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return {
    r: Math.round(r * 255),
    g: Math.round(g * 255),
    b: Math.round(b * 255)
  };
}
function hslToRgbTuple(h, s, l) {
  const rgb = hslToRgb(h, s, l);
  return [rgb.r, rgb.g, rgb.b];
}
function blendColors(color1, color2, ratio) {
  const c1 = parseColor(color1) ?? BLACK;
  const c2 = parseColor(color2) ?? BLACK;
  const r = Math.round(c1.r + (c2.r - c1.r) * ratio);
  const g = Math.round(c1.g + (c2.g - c1.g) * ratio);
  const b = Math.round(c1.b + (c2.b - c1.b) * ratio);
  const a = c1.a + (c2.a - c1.a) * ratio;
  if (a < 1) {
    return rgbaToString(r, g, b, a);
  }
  return rgbToHex(r, g, b);
}
function getRelativeLuminance(color) {
  const c = typeof color === "string" ? parseColor(color) ?? BLACK : color;
  const rsRGB = c.r / 255;
  const gsRGB = c.g / 255;
  const bsRGB = c.b / 255;
  const r = rsRGB <= 0.03928 ? rsRGB / 12.92 : ((rsRGB + 0.055) / 1.055) ** 2.4;
  const g = gsRGB <= 0.03928 ? gsRGB / 12.92 : ((gsRGB + 0.055) / 1.055) ** 2.4;
  const b = bsRGB <= 0.03928 ? bsRGB / 12.92 : ((bsRGB + 0.055) / 1.055) ** 2.4;
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function getContrastRatio(color1, color2) {
  const l1 = getRelativeLuminance(color1);
  const l2 = getRelativeLuminance(color2);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

// src/modules/core/gradient.ts
var _log2 = createLogger("GRADIENT");

// src/modules/core/harmony.ts
var _log3 = createLogger("COLOR");

// src/modules/core/math.ts
var _log4 = createLogger("COLOR");
function createSeededRandom(seed) {
  let s = seed;
  return () => {
    s = Math.sin(s * 9999) * 1e4;
    return s - Math.floor(s);
  };
}
function createRNG(seed) {
  let state = seed >>> 0;
  return () => {
    state = state + 1831565813 >>> 0;
    let t = state;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

// src/modules/core/index.ts
var _log5 = createLogger("CORE");

// src/modules/dither-algorithms/matrices.ts
var _log6 = createLogger("DITHER");
var BAYER_2 = [
  [0, 2],
  [3, 1]
];
var BAYER_4 = [
  [0, 8, 2, 10],
  [12, 4, 14, 6],
  [3, 11, 1, 9],
  [15, 7, 13, 5]
];
var BAYER_8 = [
  [0, 32, 8, 40, 2, 34, 10, 42],
  [48, 16, 56, 24, 50, 18, 58, 26],
  [12, 44, 4, 36, 14, 46, 6, 38],
  [60, 28, 52, 20, 62, 30, 54, 22],
  [3, 35, 11, 43, 1, 33, 9, 41],
  [51, 19, 59, 27, 49, 17, 57, 25],
  [15, 47, 7, 39, 13, 45, 5, 37],
  [63, 31, 55, 23, 61, 29, 53, 21]
];
var CLUSTERED_DOT = [
  [24, 10, 12, 26, 35, 47, 49, 37],
  [8, 0, 2, 14, 45, 59, 61, 51],
  [22, 6, 4, 16, 43, 57, 63, 53],
  [30, 20, 18, 28, 33, 41, 55, 39],
  [34, 46, 48, 36, 25, 11, 13, 27],
  [44, 58, 60, 50, 9, 1, 3, 15],
  [42, 56, 62, 52, 23, 7, 5, 17],
  [32, 40, 54, 38, 31, 21, 19, 29]
];
var VOID_CLUSTER = [
  [13, 9, 5, 12, 18, 22, 26, 19],
  [6, 1, 0, 8, 25, 30, 31, 23],
  [10, 2, 3, 4, 21, 29, 28, 27],
  [14, 7, 11, 15, 17, 24, 20, 16],
  [18, 22, 26, 19, 13, 9, 5, 12],
  [25, 30, 31, 23, 6, 1, 0, 8],
  [21, 29, 28, 27, 10, 2, 3, 4],
  [17, 24, 20, 16, 14, 7, 11, 15]
];

// src/modules/dither-algorithms/utils.ts
var _log7 = createLogger("DITHER");
var createRNG2 = createRNG;
function getOrderedMatrix(name) {
  switch (name) {
    case "bayer2":
      return BAYER_2;
    case "bayer4":
      return BAYER_4;
    case "bayer8":
      return BAYER_8;
    case "clustered_dot":
      return CLUSTERED_DOT;
    case "void_cluster":
      return VOID_CLUSTER;
    default:
      return BAYER_4;
  }
}

// src/modules/dither-algorithms/blue-noise.ts
var _log8 = createLogger("DITHER");
function generateBlueNoiseTile(size, seed) {
  const tile = new Array(size * size);
  const phi = 1.618033988749895;
  const rng = createRNG2(seed);
  const offset = rng();
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const noise = (offset + i * phi) % 1;
      tile[i] = noise;
    }
  }
  return tile;
}
function sampleBlueNoise(x, y, tile, tileSize) {
  const tx = (x % tileSize + tileSize) % tileSize;
  const ty = (y % tileSize + tileSize) % tileSize;
  return tile[ty * tileSize + tx];
}

// src/modules/dither-algorithms/kernels.ts
var _log9 = createLogger("DITHER");
var DIFFUSION_KERNELS = {
  floyd_steinberg: {
    matrix: [
      [0, 0, 7],
      [3, 5, 1]
    ],
    divisor: 16,
    offset: 1
  },
  jarvis_judice_ninke: {
    matrix: [
      [0, 0, 0, 7, 5],
      [3, 5, 7, 5, 3],
      [1, 3, 5, 3, 1]
    ],
    divisor: 48,
    offset: 2
  },
  stucki: {
    matrix: [
      [0, 0, 0, 8, 4],
      [2, 4, 8, 4, 2],
      [1, 2, 4, 2, 1]
    ],
    divisor: 42,
    offset: 2
  },
  burkes: {
    matrix: [
      [0, 0, 0, 8, 4],
      [2, 4, 8, 4, 2]
    ],
    divisor: 32,
    offset: 2
  },
  sierra: {
    matrix: [
      [0, 0, 0, 5, 3],
      [2, 4, 5, 4, 2],
      [0, 2, 3, 2, 0]
    ],
    divisor: 32,
    offset: 2
  },
  sierra_2: {
    matrix: [
      [0, 0, 0, 4, 3],
      [1, 2, 3, 2, 1]
    ],
    divisor: 16,
    offset: 2
  },
  sierra_lite: {
    matrix: [
      [0, 0, 2],
      [1, 1, 0]
    ],
    divisor: 4,
    offset: 1
  },
  two_row_sierra: {
    matrix: [
      [0, 0, 0, 4, 3],
      [1, 2, 3, 2, 1]
    ],
    divisor: 16,
    offset: 2
  },
  atkinson: {
    matrix: [
      [0, 0, 1, 1],
      [1, 1, 1, 0],
      [0, 1, 0, 0]
    ],
    divisor: 8,
    offset: 1
  }
};

// src/modules/dither-algorithms/error-diffusion.ts
var _log10 = createLogger("DITHER");

// src/modules/dither-algorithms/advanced.ts
var _log11 = createLogger("DITHER");

// src/modules/dither-algorithms/noise.ts
var _log12 = createLogger("DITHER");

// src/modules/dither-algorithms/ordered.ts
var _log13 = createLogger("DITHER");

// src/modules/dither-algorithms/temporal.ts
var _log14 = createLogger("DITHER");

// src/modules/dither-algorithms/index.ts
var _log15 = createLogger("DITHER");

// src/modules/animation/state.ts
var _log16 = createLogger("ANIMATION");

// src/modules/animation/animation-loop.ts
var _log17 = createLogger("ANIMATION");

// src/modules/animation/animation-patterns.ts
var _log18 = createLogger("ANIMATION");

// src/modules/animation/apply-animation-pattern.ts
var _log19 = createLogger("ANIMATION");

// src/modules/animation/color-cycle.ts
var _log20 = createLogger("ANIMATION");

// src/modules/animation/decimation.ts
var _log21 = createLogger("ANIMATION");

// src/modules/animation/format-detection.ts
var _log22 = createLogger("ANIMATION");

// src/modules/animation/gif-codec.ts
import * as gifencNs from "gifenc";
import { decompressFrames, parseGIF } from "gifuct-js";
var log = createLogger("ANIMATION");
function resolveGifEnc() {
  const ns = gifencNs;
  return {
    GIFEncoder: ns.GIFEncoder ?? ns.default?.GIFEncoder,
    quantize: ns.quantize ?? ns.default?.quantize,
    applyPalette: ns.applyPalette ?? ns.default?.applyPalette
  };
}
var GIFENC = resolveGifEnc();
function isGifEncodingAvailable() {
  return Boolean(GIFENC.GIFEncoder && GIFENC.quantize && GIFENC.applyPalette);
}
function createGifEncoder() {
  if (!GIFENC.GIFEncoder) {
    throw new Error("GIF encoder is unavailable in this runtime");
  }
  return GIFENC.GIFEncoder();
}
function quantizeGifPalette(data, colors) {
  if (!GIFENC.quantize) {
    throw new Error("GIF encoder is unavailable in this runtime");
  }
  return GIFENC.quantize(data, colors);
}
function indexGifPixels(data, palette) {
  if (!GIFENC.applyPalette) {
    throw new Error("GIF encoder is unavailable in this runtime");
  }
  return GIFENC.applyPalette(data, palette);
}
function decodeGif(arrayBuffer) {
  const parsed = parseGIF(arrayBuffer);
  const frames = decompressFrames(parsed, true);
  const { width, height } = parsed.lsd;
  const uniqueDelays = [...new Set(frames.map((f) => f.delay))].sort((a, b) => a - b);
  const uniqueDisposals = [...new Set(frames.map((f) => f.disposalType))].sort((a, b) => a - b);
  const totalDurationMs = frames.reduce((sum, f) => sum + f.delay, 0);
  log.debug("decodeGif: decoded", {
    width,
    height,
    frameCount: frames.length,
    firstDelays: frames.slice(0, 5).map((f) => f.delay),
    uniqueDelays,
    uniqueDisposals,
    totalDurationMs,
    bytesIn: arrayBuffer.byteLength
  });
  return { width, height, frames };
}
function isGifSignature(buffer) {
  const view = new DataView(buffer);
  if (view.byteLength < 6) return false;
  return view.getUint8(0) === 71 && view.getUint8(1) === 73 && view.getUint8(2) === 70;
}

// src/modules/animation/gif-compositor.ts
var log2 = createLogger("ANIMATION");

// src/modules/animation/interpolate-frames.ts
var _log23 = createLogger("ANIMATION");

// src/modules/animation/parsing.ts
var log3 = createLogger("ANIMATION");

// src/modules/animation/shared-patterns.ts
var _log24 = createLogger("ANIMATION");
function applyAnimationEasing(progress, easing) {
  switch (easing) {
    case "ease_in":
      return progress * progress;
    case "ease_out":
      return 1 - (1 - progress) * (1 - progress);
    case "ease_in_out":
      return progress < 0.5 ? 2 * progress * progress : 1 - (-2 * progress + 2) ** 2 / 2;
    case "bounce":
      if (progress < 0.5) {
        return 8 * progress * progress * progress * progress;
      } else {
        return 1 - (-2 * progress + 2) ** 4 / 2;
      }
    default:
      return progress;
  }
}
function applyAnimationPulse(data, progress, seed) {
  const pulsePhase = Math.sin(progress * Math.PI * 2);
  const intensity = 0.3 + 0.2 * Math.abs(pulsePhase);
  const hue = seed * 31 % 360;
  const pulseColor = hslToRgbTuple(hue, 70, 50);
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const brightness2 = (r + g + b) / 3;
    const isDark2 = brightness2 < 128;
    if (isDark2) {
      const tintAmount = intensity * (0.5 + pulsePhase * 0.5);
      data[i] = Math.min(255, r + pulseColor[0] * tintAmount);
      data[i + 1] = Math.min(255, g + pulseColor[1] * tintAmount);
      data[i + 2] = Math.min(255, b + pulseColor[2] * tintAmount);
    } else {
      const bf = 1 - intensity * 0.1 * (1 + pulsePhase);
      data[i] = Math.max(0, Math.round(r * bf));
      data[i + 1] = Math.max(0, Math.round(g * bf));
      data[i + 2] = Math.max(0, Math.round(b * bf));
    }
  }
}
function applyAnimationWave(data, progress, width, height, seed) {
  const waveFrequency = 3 + seed % 5;
  const baseHue = seed * 23 % 360;
  for (let y = 0; y < height; y++) {
    const wavePhase = Math.sin(y / height * waveFrequency * Math.PI * 2 + progress * Math.PI * 2);
    const waveIntensity = (wavePhase + 1) / 2;
    const rowHue = ((baseHue + wavePhase * 30) % 360 + 360) % 360;
    const waveColor = hslToRgbTuple(rowHue, 70, 50);
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const brightness2 = (r + g + b) / 3;
      const isDark2 = brightness2 < 128;
      if (isDark2) {
        const tintAmount = waveIntensity * 0.6;
        data[i] = Math.min(255, r + waveColor[0] * tintAmount);
        data[i + 1] = Math.min(255, g + waveColor[1] * tintAmount);
        data[i + 2] = Math.min(255, b + waveColor[2] * tintAmount);
      } else {
        const darkenAmount = waveIntensity * 0.15;
        data[i] = Math.round(r * (1 - darkenAmount));
        data[i + 1] = Math.round(g * (1 - darkenAmount));
        data[i + 2] = Math.round(b * (1 - darkenAmount));
      }
    }
  }
}
function applyAnimationScanline(data, progress, width, height, seed) {
  const lineWidth = Math.max(4, height * 0.08);
  const lineY = progress * (height + lineWidth * 2) - lineWidth;
  const horizontal = seed % 2 === 0;
  const baseHue = seed * 17 % 360;
  const scanColor = hslToRgbTuple(baseHue, 80, 50);
  const trailColor = hslToRgbTuple((baseHue + 180) % 360, 60, 60);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      const pos = horizontal ? y : x;
      const linePos = horizontal ? lineY : progress * (width + lineWidth * 2) - lineWidth;
      const distance = Math.abs(pos - linePos);
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const brightness2 = (r + g + b) / 3;
      const isDark2 = brightness2 < 128;
      if (distance < lineWidth) {
        const intensity = 1 - distance / lineWidth;
        if (isDark2) {
          data[i] = Math.min(255, r + scanColor[0] * intensity * 0.8);
          data[i + 1] = Math.min(255, g + scanColor[1] * intensity * 0.8);
          data[i + 2] = Math.min(255, b + scanColor[2] * intensity * 0.8);
        } else {
          data[i] = Math.max(0, r - trailColor[0] * intensity * 0.3);
          data[i + 1] = Math.max(0, g - trailColor[1] * intensity * 0.3);
          data[i + 2] = Math.max(0, b - trailColor[2] * intensity * 0.3);
        }
      }
    }
  }
}
function applyAnimationShimmer(data, progress, width, height, seed) {
  const random = createSeededRandom(seed + Math.floor(progress * 1e3));
  const spotCount = Math.floor(width * height * 0.02);
  const baseHue = (seed * 13 + progress * 100) % 360;
  for (let s = 0; s < spotCount; s++) {
    const x = Math.floor(random() * width);
    const y = Math.floor(random() * height);
    const i = (y * width + x) * 4;
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const brightness2 = (r + g + b) / 3;
    const isDark2 = brightness2 < 128;
    const spotHue = (baseHue + random() * 60) % 360;
    const sparkleColor = hslToRgbTuple(spotHue, 90, isDark2 ? 60 : 40);
    const intensity = 0.5 + random() * 0.5;
    if (isDark2) {
      data[i] = Math.min(255, r + sparkleColor[0] * intensity);
      data[i + 1] = Math.min(255, g + sparkleColor[1] * intensity);
      data[i + 2] = Math.min(255, b + sparkleColor[2] * intensity);
    } else {
      data[i] = Math.max(0, r - (255 - sparkleColor[0]) * intensity * 0.3);
      data[i + 1] = Math.max(0, g - (255 - sparkleColor[1]) * intensity * 0.3);
      data[i + 2] = Math.max(0, b - (255 - sparkleColor[2]) * intensity * 0.3);
    }
  }
}
function applyAnimationDrift(data, progress, width, height, seed) {
  const scale = 0.015 + seed % 10 * 3e-3;
  const timeOffset = progress * Math.PI * 2;
  const baseHue = (seed * 41 + progress * 60) % 360;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const brightness2 = (r + g + b) / 3;
      const isDark2 = brightness2 < 128;
      const drift = Math.sin(x * scale + timeOffset) * Math.cos(y * scale + timeOffset);
      const driftIntensity = (drift + 1) / 2;
      const driftHue = ((baseHue + drift * 40) % 360 + 360) % 360;
      const driftColor = hslToRgbTuple(driftHue, 60, 50);
      if (isDark2) {
        const tintAmount = driftIntensity * 0.5;
        data[i] = Math.min(255, r + driftColor[0] * tintAmount);
        data[i + 1] = Math.min(255, g + driftColor[1] * tintAmount);
        data[i + 2] = Math.min(255, b + driftColor[2] * tintAmount);
      } else {
        const darkenAmount = driftIntensity * 0.1;
        data[i] = Math.round(r * (1 - darkenAmount));
        data[i + 1] = Math.round(g * (1 - darkenAmount));
        data[i + 2] = Math.round(b * (1 - darkenAmount));
      }
    }
  }
}
function applyAnimationColorCycle(data, progress, seed) {
  const baseHue = (progress * 360 + seed) % 360;
  const tintColor = hslToRgbTuple(baseHue, 80, 50);
  const complementHue = (baseHue + 180) % 360;
  const complementColor = hslToRgbTuple(complementHue, 30, 70);
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const brightness2 = (r + g + b) / 3;
    const isDark2 = brightness2 < 128;
    if (isDark2) {
      const tintAmount = 0.7;
      data[i] = Math.min(255, r + tintColor[0] * tintAmount);
      data[i + 1] = Math.min(255, g + tintColor[1] * tintAmount);
      data[i + 2] = Math.min(255, b + tintColor[2] * tintAmount);
    } else {
      const tintAmount = 0.15;
      data[i] = Math.max(0, Math.round(r - (255 - complementColor[0]) * tintAmount));
      data[i + 1] = Math.max(0, Math.round(g - (255 - complementColor[1]) * tintAmount));
      data[i + 2] = Math.max(0, Math.round(b - (255 - complementColor[2]) * tintAmount));
    }
  }
}

// src/modules/animation/temporal-dither.ts
var _log25 = createLogger("ANIMATION");

// src/modules/animation/index.ts
var _log26 = createLogger("ANIMATION");

// src/modules/qr-encoder/bit-buffer.ts
var _log27 = createLogger("ENCODER");
function qrBitBuffer() {
  const _buffer = [];
  let _length = 0;
  const _this = {
    getBuffer: () => _buffer,
    getAt: (index) => {
      const bufIndex = Math.floor(index / 8);
      return (_buffer[bufIndex] >>> 7 - index % 8 & 1) === 1;
    },
    put: (num, length) => {
      for (let i = 0; i < length; i += 1) {
        _this.putBit((num >>> length - i - 1 & 1) === 1);
      }
    },
    getLengthInBits: () => _length,
    putBit: (bit) => {
      const bufIndex = Math.floor(_length / 8);
      if (_buffer.length <= bufIndex) {
        _buffer.push(0);
      }
      if (bit) {
        _buffer[bufIndex] |= 128 >>> _length % 8;
      }
      _length += 1;
    }
  };
  return _this;
}

// src/modules/qr-encoder/string-bytes.ts
var _log28 = createLogger("ENCODER");
var _stringToBytes = (s) => {
  const bytes = [];
  for (let i = 0; i < s.length; i += 1) {
    const c = s.charCodeAt(i);
    bytes.push(c & 255);
  }
  return bytes;
};
function stringToBytesFn(s) {
  return _stringToBytes(s);
}
function setStringToBytes(fn) {
  _stringToBytes = fn;
}
function resetStringToBytes() {
  _stringToBytes = (s) => {
    const bytes = [];
    for (let i = 0; i < s.length; i += 1) {
      const c = s.charCodeAt(i);
      bytes.push(c & 255);
    }
    return bytes;
  };
}

// src/modules/qr-encoder/types.ts
var _log29 = createLogger("ENCODER");
var QRMode = {
  MODE_NUMBER: 1 << 0,
  // 0001
  MODE_ALPHA_NUM: 1 << 1,
  // 0010
  MODE_8BIT_BYTE: 1 << 2,
  // 0100
  MODE_KANJI: 1 << 3
  // 1000
};
var QRErrorCorrectionLevel = {
  L: 1,
  // ~7% recovery
  M: 0,
  // ~15% recovery
  Q: 3,
  // ~25% recovery
  H: 2
  // ~30% recovery
};

// src/modules/qr-encoder/data-modes.ts
var _log30 = createLogger("ENCODER");
function qrNumber(data) {
  const _mode = QRMode.MODE_NUMBER;
  const _data = data;
  const strToNum = (s) => {
    let num = 0;
    for (let i = 0; i < s.length; i += 1) {
      num = num * 10 + charToNum(s.charAt(i));
    }
    return num;
  };
  const charToNum = (c) => {
    if ("0" <= c && c <= "9") {
      return c.charCodeAt(0) - "0".charCodeAt(0);
    }
    throw new Error(`illegal char :${c}`);
  };
  return {
    getMode: () => _mode,
    getLength: () => _data.length,
    write: (buffer) => {
      let i = 0;
      while (i + 2 < _data.length) {
        buffer.put(strToNum(_data.substring(i, i + 3)), 10);
        i += 3;
      }
      if (i < _data.length) {
        if (_data.length - i === 1) {
          buffer.put(strToNum(_data.substring(i, i + 1)), 4);
        } else if (_data.length - i === 2) {
          buffer.put(strToNum(_data.substring(i, i + 2)), 7);
        }
      }
    }
  };
}
function qrAlphaNum(data) {
  const _mode = QRMode.MODE_ALPHA_NUM;
  const _data = data;
  const getCode = (c) => {
    if ("0" <= c && c <= "9") {
      return c.charCodeAt(0) - "0".charCodeAt(0);
    } else if ("A" <= c && c <= "Z") {
      return c.charCodeAt(0) - "A".charCodeAt(0) + 10;
    } else {
      switch (c) {
        case " ":
          return 36;
        case "$":
          return 37;
        case "%":
          return 38;
        case "*":
          return 39;
        case "+":
          return 40;
        case "-":
          return 41;
        case ".":
          return 42;
        case "/":
          return 43;
        case ":":
          return 44;
        default:
          throw new Error(`illegal char :${c}`);
      }
    }
  };
  return {
    getMode: () => _mode,
    getLength: () => _data.length,
    write: (buffer) => {
      const s = _data;
      let i = 0;
      while (i + 1 < s.length) {
        buffer.put(getCode(s.charAt(i)) * 45 + getCode(s.charAt(i + 1)), 11);
        i += 2;
      }
      if (i < s.length) {
        buffer.put(getCode(s.charAt(i)), 6);
      }
    }
  };
}
function qr8BitByte(data) {
  const _mode = QRMode.MODE_8BIT_BYTE;
  const _bytes = stringToBytesFn(data);
  return {
    getMode: () => _mode,
    getLength: () => _bytes.length,
    write: (buffer) => {
      for (let i = 0; i < _bytes.length; i += 1) {
        buffer.put(_bytes[i], 8);
      }
    }
  };
}
function qrKanji(data) {
  const _mode = QRMode.MODE_KANJI;
  const test = stringToBytesFn("\u53CB");
  if (test.length !== 2 || (test[0] << 8 | test[1]) !== 38726) {
    throw new Error("sjis not supported.");
  }
  const _bytes = stringToBytesFn(data);
  return {
    getMode: () => _mode,
    getLength: () => ~~(_bytes.length / 2),
    write: (buffer) => {
      let i = 0;
      while (i + 1 < _bytes.length) {
        let c = (255 & _bytes[i]) << 8 | 255 & _bytes[i + 1];
        if (33088 <= c && c <= 40956) {
          c -= 33088;
        } else if (57408 <= c && c <= 60351) {
          c -= 49472;
        } else {
          throw new Error(`illegal char at ${i + 1}/${c}`);
        }
        c = (c >>> 8 & 255) * 192 + (c & 255);
        buffer.put(c, 13);
        i += 2;
      }
      if (i < _bytes.length) {
        throw new Error(`illegal char at ${i + 1}`);
      }
    }
  };
}

// src/modules/qr-encoder/math.ts
var _log31 = createLogger("ENCODER");
var EXP_TABLE = new Array(256);
var LOG_TABLE = new Array(256);
for (let i = 0; i < 8; i += 1) {
  EXP_TABLE[i] = 1 << i;
}
for (let i = 8; i < 256; i += 1) {
  EXP_TABLE[i] = EXP_TABLE[i - 4] ^ EXP_TABLE[i - 5] ^ EXP_TABLE[i - 6] ^ EXP_TABLE[i - 8];
}
for (let i = 0; i < 255; i += 1) {
  LOG_TABLE[EXP_TABLE[i]] = i;
}
function glog(n) {
  if (n < 1) {
    throw new Error(`glog(${n})`);
  }
  return LOG_TABLE[n];
}
function gexp(n) {
  let exp = n;
  while (exp < 0) {
    exp += 255;
  }
  while (exp >= 256) {
    exp -= 255;
  }
  return EXP_TABLE[exp];
}
function qrPolynomial(num, shift) {
  if (typeof num.length === "undefined") {
    throw new Error(`${num.length}/${shift}`);
  }
  const _num = (() => {
    let offset = 0;
    while (offset < num.length && num[offset] === 0) {
      offset += 1;
    }
    const result = new Array(num.length - offset + shift);
    for (let i = 0; i < num.length - offset; i += 1) {
      result[i] = num[i + offset];
    }
    return result;
  })();
  const _this = {
    getAt: (index) => _num[index],
    getLength: () => _num.length,
    multiply: (e) => {
      const result = new Array(_this.getLength() + e.getLength() - 1);
      for (let i = 0; i < result.length; i++) {
        result[i] = 0;
      }
      for (let i = 0; i < _this.getLength(); i += 1) {
        for (let j = 0; j < e.getLength(); j += 1) {
          result[i + j] ^= gexp(glog(_this.getAt(i)) + glog(e.getAt(j)));
        }
      }
      return qrPolynomial(result, 0);
    },
    mod: (e) => {
      if (_this.getLength() - e.getLength() < 0) {
        return _this;
      }
      const ratio = glog(_this.getAt(0)) - glog(e.getAt(0));
      const result = new Array(_this.getLength());
      for (let i = 0; i < _this.getLength(); i += 1) {
        result[i] = _this.getAt(i);
      }
      for (let i = 0; i < e.getLength(); i += 1) {
        result[i] ^= gexp(glog(e.getAt(i)) + ratio);
      }
      return qrPolynomial(result, 0).mod(e);
    }
  };
  return _this;
}

// src/modules/qr-encoder/output.ts
var _log32 = createLogger("ENCODER");
function byteArrayOutputStream() {
  const _bytes = [];
  return {
    writeByte: (b) => {
      _bytes.push(b & 255);
    },
    writeShort: (i) => {
      _bytes.push(i & 255);
      _bytes.push(i >>> 8 & 255);
    },
    writeBytes: (b, off = 0, len) => {
      const length = len ?? b.length;
      for (let i = 0; i < length; i += 1) {
        _bytes.push(b[i + off] & 255);
      }
    },
    writeString: (s) => {
      for (let i = 0; i < s.length; i += 1) {
        _bytes.push(s.charCodeAt(i) & 255);
      }
    },
    toByteArray: () => _bytes,
    toString: () => {
      let s = "[";
      for (let i = 0; i < _bytes.length; i += 1) {
        if (i > 0) s += ",";
        s += _bytes[i];
      }
      s += "]";
      return s;
    }
  };
}
function base64EncodeOutputStream() {
  let _buffer = 0;
  let _buflen = 0;
  let _length = 0;
  let _base64 = "";
  const encode = (n) => {
    if (n < 0) {
      throw new Error(`n:${n}`);
    } else if (n < 26) {
      return 65 + n;
    } else if (n < 52) {
      return 97 + (n - 26);
    } else if (n < 62) {
      return 48 + (n - 52);
    } else if (n === 62) {
      return 43;
    } else if (n === 63) {
      return 47;
    } else {
      throw new Error(`n:${n}`);
    }
  };
  const writeEncoded = (b) => {
    _base64 += String.fromCharCode(encode(b & 63));
  };
  return {
    writeByte: (n) => {
      _buffer = _buffer << 8 | n & 255;
      _buflen += 8;
      _length += 1;
      while (_buflen >= 6) {
        writeEncoded(_buffer >>> _buflen - 6);
        _buflen -= 6;
      }
    },
    flush: () => {
      if (_buflen > 0) {
        writeEncoded(_buffer << 6 - _buflen);
        _buffer = 0;
        _buflen = 0;
      }
      if (_length % 3 !== 0) {
        const padlen = 3 - _length % 3;
        for (let i = 0; i < padlen; i += 1) {
          _base64 += "=";
        }
      }
    },
    toString: () => _base64
  };
}
function gifImage(width, height) {
  const _data = new Array(width * height);
  const lzwTable = () => {
    const _map = {};
    let _size = 0;
    return {
      add: (key) => {
        if (typeof _map[key] !== "undefined") {
          throw new Error(`dup key:${key}`);
        }
        _map[key] = _size;
        _size += 1;
      },
      size: () => _size,
      indexOf: (key) => _map[key],
      contains: (key) => typeof _map[key] !== "undefined"
    };
  };
  const bitOutputStream = (out) => {
    let _bitLength = 0;
    let _bitBuffer = 0;
    return {
      write: (data, length) => {
        if (data >>> length !== 0) {
          throw new Error("length over");
        }
        while (_bitLength + length >= 8) {
          out.writeByte(255 & (data << _bitLength | _bitBuffer));
          length -= 8 - _bitLength;
          data >>>= 8 - _bitLength;
          _bitBuffer = 0;
          _bitLength = 0;
        }
        _bitBuffer = data << _bitLength | _bitBuffer;
        _bitLength = _bitLength + length;
      },
      flush: () => {
        if (_bitLength > 0) {
          out.writeByte(_bitBuffer);
        }
      }
    };
  };
  const getLZWRaster = (lzwMinCodeSize) => {
    const clearCode = 1 << lzwMinCodeSize;
    const endCode = (1 << lzwMinCodeSize) + 1;
    let bitLength = lzwMinCodeSize + 1;
    const table = lzwTable();
    for (let i = 0; i < clearCode; i += 1) {
      table.add(String.fromCharCode(i));
    }
    table.add(String.fromCharCode(clearCode));
    table.add(String.fromCharCode(endCode));
    const byteOut = byteArrayOutputStream();
    const bitOut = bitOutputStream(byteOut);
    bitOut.write(clearCode, bitLength);
    let dataIndex = 0;
    let s = String.fromCharCode(_data[dataIndex]);
    dataIndex += 1;
    while (dataIndex < _data.length) {
      const c = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;
      if (table.contains(s + c)) {
        s = s + c;
      } else {
        bitOut.write(table.indexOf(s), bitLength);
        if (table.size() < 4095) {
          if (table.size() === 1 << bitLength) {
            bitLength += 1;
          }
          table.add(s + c);
        }
        s = c;
      }
    }
    bitOut.write(table.indexOf(s), bitLength);
    bitOut.write(endCode, bitLength);
    bitOut.flush();
    return byteOut.toByteArray();
  };
  return {
    setPixel: (x, y, pixel) => {
      _data[y * width + x] = pixel;
    },
    write: (out) => {
      out.writeString("GIF87a");
      out.writeShort(width);
      out.writeShort(height);
      out.writeByte(128);
      out.writeByte(0);
      out.writeByte(0);
      out.writeByte(0);
      out.writeByte(0);
      out.writeByte(0);
      out.writeByte(255);
      out.writeByte(255);
      out.writeByte(255);
      out.writeString(",");
      out.writeShort(0);
      out.writeShort(0);
      out.writeShort(width);
      out.writeShort(height);
      out.writeByte(0);
      const lzwMinCodeSize = 2;
      const raster = getLZWRaster(lzwMinCodeSize);
      out.writeByte(lzwMinCodeSize);
      let offset = 0;
      while (raster.length - offset > 255) {
        out.writeByte(255);
        out.writeBytes(raster, offset, 255);
        offset += 255;
      }
      out.writeByte(raster.length - offset);
      out.writeBytes(raster, offset, raster.length - offset);
      out.writeByte(0);
      out.writeString(";");
    }
  };
}
function createDataURL(width, height, getPixel) {
  const gif = gifImage(width, height);
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      gif.setPixel(x, y, getPixel(x, y));
    }
  }
  const b = byteArrayOutputStream();
  gif.write(b);
  const base64 = base64EncodeOutputStream();
  const bytes = b.toByteArray();
  for (let i = 0; i < bytes.length; i += 1) {
    base64.writeByte(bytes[i]);
  }
  base64.flush();
  return `data:image/gif;base64,${base64.toString()}`;
}

// src/modules/qr-encoder/rs-blocks.ts
var _log33 = createLogger("ENCODER");
var RS_BLOCK_TABLE = [
  // L
  // M
  // Q
  // H
  // 1
  [1, 26, 19],
  [1, 26, 16],
  [1, 26, 13],
  [1, 26, 9],
  // 2
  [1, 44, 34],
  [1, 44, 28],
  [1, 44, 22],
  [1, 44, 16],
  // 3
  [1, 70, 55],
  [1, 70, 44],
  [2, 35, 17],
  [2, 35, 13],
  // 4
  [1, 100, 80],
  [2, 50, 32],
  [2, 50, 24],
  [4, 25, 9],
  // 5
  [1, 134, 108],
  [2, 67, 43],
  [2, 33, 15, 2, 34, 16],
  [2, 33, 11, 2, 34, 12],
  // 6
  [2, 86, 68],
  [4, 43, 27],
  [4, 43, 19],
  [4, 43, 15],
  // 7
  [2, 98, 78],
  [4, 49, 31],
  [2, 32, 14, 4, 33, 15],
  [4, 39, 13, 1, 40, 14],
  // 8
  [2, 121, 97],
  [2, 60, 38, 2, 61, 39],
  [4, 40, 18, 2, 41, 19],
  [4, 40, 14, 2, 41, 15],
  // 9
  [2, 146, 116],
  [3, 58, 36, 2, 59, 37],
  [4, 36, 16, 4, 37, 17],
  [4, 36, 12, 4, 37, 13],
  // 10
  [2, 86, 68, 2, 87, 69],
  [4, 69, 43, 1, 70, 44],
  [6, 43, 19, 2, 44, 20],
  [6, 43, 15, 2, 44, 16],
  // 11
  [4, 101, 81],
  [1, 80, 50, 4, 81, 51],
  [4, 50, 22, 4, 51, 23],
  [3, 36, 12, 8, 37, 13],
  // 12
  [2, 116, 92, 2, 117, 93],
  [6, 58, 36, 2, 59, 37],
  [4, 46, 20, 6, 47, 21],
  [7, 42, 14, 4, 43, 15],
  // 13
  [4, 133, 107],
  [8, 59, 37, 1, 60, 38],
  [8, 44, 20, 4, 45, 21],
  [12, 33, 11, 4, 34, 12],
  // 14
  [3, 145, 115, 1, 146, 116],
  [4, 64, 40, 5, 65, 41],
  [11, 36, 16, 5, 37, 17],
  [11, 36, 12, 5, 37, 13],
  // 15
  [5, 109, 87, 1, 110, 88],
  [5, 65, 41, 5, 66, 42],
  [5, 54, 24, 7, 55, 25],
  [11, 36, 12, 7, 37, 13],
  // 16
  [5, 122, 98, 1, 123, 99],
  [7, 73, 45, 3, 74, 46],
  [15, 43, 19, 2, 44, 20],
  [3, 45, 15, 13, 46, 16],
  // 17
  [1, 135, 107, 5, 136, 108],
  [10, 74, 46, 1, 75, 47],
  [1, 50, 22, 15, 51, 23],
  [2, 42, 14, 17, 43, 15],
  // 18
  [5, 150, 120, 1, 151, 121],
  [9, 69, 43, 4, 70, 44],
  [17, 50, 22, 1, 51, 23],
  [2, 42, 14, 19, 43, 15],
  // 19
  [3, 141, 113, 4, 142, 114],
  [3, 70, 44, 11, 71, 45],
  [17, 47, 21, 4, 48, 22],
  [9, 39, 13, 16, 40, 14],
  // 20
  [3, 135, 107, 5, 136, 108],
  [3, 67, 41, 13, 68, 42],
  [15, 54, 24, 5, 55, 25],
  [15, 43, 15, 10, 44, 16],
  // 21
  [4, 144, 116, 4, 145, 117],
  [17, 68, 42],
  [17, 50, 22, 6, 51, 23],
  [19, 46, 16, 6, 47, 17],
  // 22
  [2, 139, 111, 7, 140, 112],
  [17, 74, 46],
  [7, 54, 24, 16, 55, 25],
  [34, 37, 13],
  // 23
  [4, 151, 121, 5, 152, 122],
  [4, 75, 47, 14, 76, 48],
  [11, 54, 24, 14, 55, 25],
  [16, 45, 15, 14, 46, 16],
  // 24
  [6, 147, 117, 4, 148, 118],
  [6, 73, 45, 14, 74, 46],
  [11, 54, 24, 16, 55, 25],
  [30, 46, 16, 2, 47, 17],
  // 25
  [8, 132, 106, 4, 133, 107],
  [8, 75, 47, 13, 76, 48],
  [7, 54, 24, 22, 55, 25],
  [22, 45, 15, 13, 46, 16],
  // 26
  [10, 142, 114, 2, 143, 115],
  [19, 74, 46, 4, 75, 47],
  [28, 50, 22, 6, 51, 23],
  [33, 46, 16, 4, 47, 17],
  // 27
  [8, 152, 122, 4, 153, 123],
  [22, 73, 45, 3, 74, 46],
  [8, 53, 23, 26, 54, 24],
  [12, 45, 15, 28, 46, 16],
  // 28
  [3, 147, 117, 10, 148, 118],
  [3, 73, 45, 23, 74, 46],
  [4, 54, 24, 31, 55, 25],
  [11, 45, 15, 31, 46, 16],
  // 29
  [7, 146, 116, 7, 147, 117],
  [21, 73, 45, 7, 74, 46],
  [1, 53, 23, 37, 54, 24],
  [19, 45, 15, 26, 46, 16],
  // 30
  [5, 145, 115, 10, 146, 116],
  [19, 75, 47, 10, 76, 48],
  [15, 54, 24, 25, 55, 25],
  [23, 45, 15, 25, 46, 16],
  // 31
  [13, 145, 115, 3, 146, 116],
  [2, 74, 46, 29, 75, 47],
  [42, 54, 24, 1, 55, 25],
  [23, 45, 15, 28, 46, 16],
  // 32
  [17, 145, 115],
  [10, 74, 46, 23, 75, 47],
  [10, 54, 24, 35, 55, 25],
  [19, 45, 15, 35, 46, 16],
  // 33
  [17, 145, 115, 1, 146, 116],
  [14, 74, 46, 21, 75, 47],
  [29, 54, 24, 19, 55, 25],
  [11, 45, 15, 46, 46, 16],
  // 34
  [13, 145, 115, 6, 146, 116],
  [14, 74, 46, 23, 75, 47],
  [44, 54, 24, 7, 55, 25],
  [59, 46, 16, 1, 47, 17],
  // 35
  [12, 151, 121, 7, 152, 122],
  [12, 75, 47, 26, 76, 48],
  [39, 54, 24, 14, 55, 25],
  [22, 45, 15, 41, 46, 16],
  // 36
  [6, 151, 121, 14, 152, 122],
  [6, 75, 47, 34, 76, 48],
  [46, 54, 24, 10, 55, 25],
  [2, 45, 15, 64, 46, 16],
  // 37
  [17, 152, 122, 4, 153, 123],
  [29, 74, 46, 14, 75, 47],
  [49, 54, 24, 10, 55, 25],
  [24, 45, 15, 46, 46, 16],
  // 38
  [4, 152, 122, 18, 153, 123],
  [13, 74, 46, 32, 75, 47],
  [48, 54, 24, 14, 55, 25],
  [42, 45, 15, 32, 46, 16],
  // 39
  [20, 147, 117, 4, 148, 118],
  [40, 75, 47, 7, 76, 48],
  [43, 54, 24, 22, 55, 25],
  [10, 45, 15, 67, 46, 16],
  // 40
  [19, 148, 118, 6, 149, 119],
  [18, 75, 47, 31, 76, 48],
  [34, 54, 24, 34, 55, 25],
  [20, 45, 15, 61, 46, 16]
];
function createRSBlock(totalCount, dataCount) {
  return { totalCount, dataCount };
}
function getRsBlockTable(typeNumber, errorCorrectionLevel) {
  switch (errorCorrectionLevel) {
    case QRErrorCorrectionLevel.L:
      return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
    case QRErrorCorrectionLevel.M:
      return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
    case QRErrorCorrectionLevel.Q:
      return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
    case QRErrorCorrectionLevel.H:
      return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
    default:
      return void 0;
  }
}
function getRSBlocks(typeNumber, errorCorrectionLevel) {
  const rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);
  if (typeof rsBlock === "undefined") {
    throw new Error(
      `bad rs block @ typeNumber:${typeNumber}/errorCorrectionLevel:${errorCorrectionLevel}`
    );
  }
  const length = rsBlock.length / 3;
  const list = [];
  for (let i = 0; i < length; i += 1) {
    const count = rsBlock[i * 3 + 0];
    const totalCount = rsBlock[i * 3 + 1];
    const dataCount = rsBlock[i * 3 + 2];
    for (let j = 0; j < count; j += 1) {
      list.push(createRSBlock(totalCount, dataCount));
    }
  }
  return list;
}

// src/modules/qr-spec/bch.ts
var _log34 = createLogger("SPEC");
var G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0;
var G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0;
var G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1;
function getBCHDigit(data) {
  let digit = 0;
  let d = data;
  while (d !== 0) {
    digit += 1;
    d >>>= 1;
  }
  return digit;
}
function getBCHTypeInfo(data) {
  let d = data << 10;
  while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
    d ^= G15 << getBCHDigit(d) - getBCHDigit(G15);
  }
  return (data << 10 | d) ^ G15_MASK;
}
function getBCHTypeNumber(data) {
  let d = data << 12;
  while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
    d ^= G18 << getBCHDigit(d) - getBCHDigit(G18);
  }
  return data << 12 | d;
}

// src/modules/qr-spec/constants.ts
var _log35 = createLogger("SPEC");
var ALIGNMENT_POSITIONS = [
  [],
  // Version 1 - no alignment
  [6, 18],
  // Version 2
  [6, 22],
  // Version 3
  [6, 26],
  // Version 4
  [6, 30],
  // Version 5
  [6, 34],
  // Version 6
  [6, 22, 38],
  // Version 7
  [6, 24, 42],
  // Version 8
  [6, 26, 46],
  // Version 9
  [6, 28, 50],
  // Version 10
  [6, 30, 54],
  // Version 11
  [6, 32, 58],
  // Version 12
  [6, 34, 62],
  // Version 13
  [6, 26, 46, 66],
  // Version 14
  [6, 26, 48, 70],
  // Version 15
  [6, 26, 50, 74],
  // Version 16
  [6, 30, 54, 78],
  // Version 17
  [6, 30, 56, 82],
  // Version 18
  [6, 30, 58, 86],
  // Version 19
  [6, 34, 62, 90],
  // Version 20
  [6, 28, 50, 72, 94],
  // Version 21
  [6, 26, 50, 74, 98],
  // Version 22
  [6, 30, 54, 78, 102],
  // Version 23
  [6, 28, 54, 80, 106],
  // Version 24
  [6, 32, 58, 84, 110],
  // Version 25
  [6, 30, 58, 86, 114],
  // Version 26
  [6, 34, 62, 90, 118],
  // Version 27
  [6, 26, 50, 74, 98, 122],
  // Version 28
  [6, 30, 54, 78, 102, 126],
  // Version 29
  [6, 26, 52, 78, 104, 130],
  // Version 30
  [6, 30, 56, 82, 108, 134],
  // Version 31
  [6, 34, 60, 86, 112, 138],
  // Version 32
  [6, 30, 58, 86, 114, 142],
  // Version 33
  [6, 34, 62, 90, 118, 146],
  // Version 34
  [6, 30, 54, 78, 102, 126, 150],
  // Version 35
  [6, 24, 50, 76, 102, 128, 154],
  // Version 36
  [6, 28, 54, 80, 106, 132, 158],
  // Version 37
  [6, 32, 58, 84, 110, 136, 162],
  // Version 38
  [6, 26, 54, 82, 110, 138, 166],
  // Version 39
  [6, 30, 58, 86, 114, 142, 170]
  // Version 40
];
function getAlignmentPositions(version) {
  if (version < 1 || version > 40) return [];
  return ALIGNMENT_POSITIONS[version - 1] || [];
}
function getVersionFromModuleCount(moduleCount) {
  return (moduleCount - 17) / 4;
}

// src/modules/qr-spec/types.ts
var _log36 = createLogger("SPEC");
var QRMode2 = {
  MODE_NUMBER: 1 << 0,
  // 0001 - Numeric
  MODE_ALPHA_NUM: 1 << 1,
  // 0010 - Alphanumeric
  MODE_8BIT_BYTE: 1 << 2,
  // 0100 - Byte
  MODE_KANJI: 1 << 3
  // 1000 - Kanji
};
var QRMaskPattern = {
  PATTERN000: 0,
  PATTERN001: 1,
  PATTERN010: 2,
  PATTERN011: 3,
  PATTERN100: 4,
  PATTERN101: 5,
  PATTERN110: 6,
  PATTERN111: 7
};

// src/modules/qr-spec/masks.ts
var _log37 = createLogger("SPEC");
function getMaskFunction(maskPattern) {
  switch (maskPattern) {
    case QRMaskPattern.PATTERN000:
    case 0:
      return (i, j) => (i + j) % 2 === 0;
    case QRMaskPattern.PATTERN001:
    case 1:
      return (i) => i % 2 === 0;
    case QRMaskPattern.PATTERN010:
    case 2:
      return (_i, j) => j % 3 === 0;
    case QRMaskPattern.PATTERN011:
    case 3:
      return (i, j) => (i + j) % 3 === 0;
    case QRMaskPattern.PATTERN100:
    case 4:
      return (i, j) => (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
    case QRMaskPattern.PATTERN101:
    case 5:
      return (i, j) => i * j % 2 + i * j % 3 === 0;
    case QRMaskPattern.PATTERN110:
    case 6:
      return (i, j) => (i * j % 2 + i * j % 3) % 2 === 0;
    case QRMaskPattern.PATTERN111:
    case 7:
      return (i, j) => (i * j % 3 + (i + j) % 2) % 2 === 0;
    default:
      throw new Error(`Invalid mask pattern: ${maskPattern}`);
  }
}

// src/modules/qr-spec/qr-patterns.ts
var _log38 = createLogger("SPEC");
function isFinderPattern(row, col, moduleCount) {
  if (row < 7 && col < 7) return true;
  if (row < 7 && col >= moduleCount - 7) return true;
  if (row >= moduleCount - 7 && col < 7) return true;
  return false;
}
function isTimingPattern(row, col, moduleCount) {
  if (row === 6 && col >= 8 && col < moduleCount - 8) return true;
  if (col === 6 && row >= 8 && row < moduleCount - 8) return true;
  return false;
}
function getAlignmentPatternCenters(version, moduleCount) {
  if (version < 2) return [];
  const positions = ALIGNMENT_POSITIONS[version - 1] || [];
  const centers = [];
  for (const row of positions) {
    for (const col of positions) {
      if (isFinderPattern(row, col, moduleCount)) continue;
      let overlapsWithFinder = false;
      for (let dr = -2; dr <= 2 && !overlapsWithFinder; dr++) {
        for (let dc = -2; dc <= 2 && !overlapsWithFinder; dc++) {
          if (isFinderPattern(row + dr, col + dc, moduleCount)) {
            overlapsWithFinder = true;
          }
        }
      }
      if (!overlapsWithFinder) {
        centers.push({ row, col });
      }
    }
  }
  return centers;
}
function isAlignmentPattern(row, col, moduleCount, version) {
  if (version < 2) return false;
  const centers = getAlignmentPatternCenters(version, moduleCount);
  for (const center of centers) {
    if (Math.abs(row - center.row) <= 2 && Math.abs(col - center.col) <= 2) {
      return true;
    }
  }
  return false;
}
function isFormatInfo(row, col, moduleCount) {
  if (row === 8) {
    if (col <= 5) return true;
    if (col === 7 || col === 8) return true;
    if (col >= moduleCount - 8) return true;
  }
  if (col === 8) {
    if (row <= 5) return true;
    if (row === 7 || row === 8) return true;
    if (row >= moduleCount - 7) return true;
  }
  return false;
}
function isVersionInfo(row, col, moduleCount, version) {
  if (version < 7) return false;
  if (row < 6 && col >= moduleCount - 11 && col < moduleCount - 8) return true;
  if (col < 6 && row >= moduleCount - 11 && row < moduleCount - 8) return true;
  return false;
}
function isLocked(row, col, moduleCount, version) {
  if (isFinderPattern(row, col, moduleCount)) return true;
  if (isTimingPattern(row, col, moduleCount)) return true;
  if (isAlignmentPattern(row, col, moduleCount, version)) return true;
  if (isFormatInfo(row, col, moduleCount)) return true;
  if (isVersionInfo(row, col, moduleCount, version)) return true;
  if (row === moduleCount - 8 && col === 8) return true;
  if (row === 7 && col <= 7 || col === 7 && row <= 7) return true;
  if (row === 7 && col >= moduleCount - 8 || col === moduleCount - 8 && row <= 7) return true;
  if (row === moduleCount - 8 && col <= 7 || col === 7 && row >= moduleCount - 8) return true;
  return false;
}
function isStructuralModule(row, col, moduleCount, version) {
  return isLocked(row, col, moduleCount, version);
}

// src/modules/qr-spec/verify.ts
var _log39 = createLogger("SPEC");
function isFinderCoreCorrect(isDark2, baseRow, baseCol) {
  for (let r = 0; r < 7; r++) {
    for (let c = 0; c < 7; c++) {
      const rr = baseRow + r;
      const cc = baseCol + c;
      const expectedDark = r === 0 || r === 6 || c === 0 || c === 6 || r >= 2 && r <= 4 && c >= 2 && c <= 4;
      if (isDark2(rr, cc) !== expectedDark) return false;
    }
  }
  return true;
}
function isAlternatingLine(isDark2, row, colStart, colEnd) {
  let prev = isDark2(row, colStart);
  for (let c = colStart + 1; c <= colEnd; c++) {
    const cur = isDark2(row, c);
    if (cur === prev) return false;
    prev = cur;
  }
  return true;
}
function isAlternatingCol(isDark2, col, rowStart, rowEnd) {
  let prev = isDark2(rowStart, col);
  for (let r = rowStart + 1; r <= rowEnd; r++) {
    const cur = isDark2(r, col);
    if (cur === prev) return false;
    prev = cur;
  }
  return true;
}
function verifyQRStructure(qr, explicitVersion) {
  const issues = [];
  const moduleCount = qr.getModuleCount();
  const rawV = (moduleCount - 17) / 4;
  const version = explicitVersion ?? Math.floor(rawV);
  if (!Number.isFinite(rawV) || rawV < 1 || rawV > 40 || Math.floor(rawV) !== rawV) {
    issues.push(`moduleCount ${moduleCount} does not map to an integer QR version`);
  }
  if (version < 1 || version > 40) {
    issues.push(`version ${version} out of range`);
  }
  const isDark2 = (r, c) => qr.isDark(r, c);
  const tl = isFinderCoreCorrect(isDark2, 0, 0);
  const tr = isFinderCoreCorrect(isDark2, 0, moduleCount - 7);
  const bl = isFinderCoreCorrect(isDark2, moduleCount - 7, 0);
  if (!tl) issues.push("top-left finder core mismatch");
  if (!tr) issues.push("top-right finder core mismatch");
  if (!bl) issues.push("bottom-left finder core mismatch");
  if (moduleCount >= 21) {
    const timingRowOk = isAlternatingLine(isDark2, 6, 8, moduleCount - 9);
    const timingColOk = isAlternatingCol(isDark2, 6, 8, moduleCount - 9);
    if (!timingRowOk) issues.push("timing row does not alternate");
    if (!timingColOk) issues.push("timing col does not alternate");
  }
  const dmRow = moduleCount - 8;
  const dmCol = 8;
  if (dmRow >= 0 && dmRow < moduleCount && dmCol >= 0 && dmCol < moduleCount) {
    if (!isDark2(dmRow, dmCol)) issues.push("fixed dark module is not dark");
  }
  return { ok: issues.length === 0, version, issues };
}

// src/modules/qr-spec/index.ts
var _log40 = createLogger("SPEC");

// src/modules/qr-encoder/utils.ts
var _log41 = createLogger("ENCODER");
var getBCHTypeInfo2 = getBCHTypeInfo;
var getBCHTypeNumber2 = getBCHTypeNumber;
var getMaskFunction2 = getMaskFunction;
function getPatternPosition(typeNumber) {
  return getAlignmentPositions(typeNumber);
}
function getErrorCorrectPolynomial(errorCorrectLength) {
  let a = qrPolynomial([1], 0);
  for (let i = 0; i < errorCorrectLength; i += 1) {
    a = a.multiply(qrPolynomial([1, gexp(i)], 0));
  }
  return a;
}
function getLengthInBits(mode, type) {
  if (1 <= type && type < 10) {
    switch (mode) {
      case QRMode.MODE_NUMBER:
        return 10;
      case QRMode.MODE_ALPHA_NUM:
        return 9;
      case QRMode.MODE_8BIT_BYTE:
        return 8;
      case QRMode.MODE_KANJI:
        return 8;
      default:
        throw new Error(`mode:${mode}`);
    }
  } else if (type < 27) {
    switch (mode) {
      case QRMode.MODE_NUMBER:
        return 12;
      case QRMode.MODE_ALPHA_NUM:
        return 11;
      case QRMode.MODE_8BIT_BYTE:
        return 16;
      case QRMode.MODE_KANJI:
        return 10;
      default:
        throw new Error(`mode:${mode}`);
    }
  } else if (type < 41) {
    switch (mode) {
      case QRMode.MODE_NUMBER:
        return 14;
      case QRMode.MODE_ALPHA_NUM:
        return 13;
      case QRMode.MODE_8BIT_BYTE:
        return 16;
      case QRMode.MODE_KANJI:
        return 12;
      default:
        throw new Error(`mode:${mode}`);
    }
  } else {
    throw new Error(`type:${type}`);
  }
}
function getLostPoint(qrcode2) {
  const moduleCount = qrcode2.getModuleCount();
  let lostPoint = 0;
  for (let row = 0; row < moduleCount; row += 1) {
    for (let col = 0; col < moduleCount; col += 1) {
      let sameCount = 0;
      const dark = qrcode2.isDark(row, col);
      for (let r = -1; r <= 1; r += 1) {
        if (row + r < 0 || moduleCount <= row + r) continue;
        for (let c = -1; c <= 1; c += 1) {
          if (col + c < 0 || moduleCount <= col + c) continue;
          if (r === 0 && c === 0) continue;
          if (dark === qrcode2.isDark(row + r, col + c)) {
            sameCount += 1;
          }
        }
      }
      if (sameCount > 5) {
        lostPoint += 3 + sameCount - 5;
      }
    }
  }
  for (let row = 0; row < moduleCount - 1; row += 1) {
    for (let col = 0; col < moduleCount - 1; col += 1) {
      let count = 0;
      if (qrcode2.isDark(row, col)) count += 1;
      if (qrcode2.isDark(row + 1, col)) count += 1;
      if (qrcode2.isDark(row, col + 1)) count += 1;
      if (qrcode2.isDark(row + 1, col + 1)) count += 1;
      if (count === 0 || count === 4) {
        lostPoint += 3;
      }
    }
  }
  for (let row = 0; row < moduleCount; row += 1) {
    for (let col = 0; col < moduleCount - 6; col += 1) {
      if (qrcode2.isDark(row, col) && !qrcode2.isDark(row, col + 1) && qrcode2.isDark(row, col + 2) && qrcode2.isDark(row, col + 3) && qrcode2.isDark(row, col + 4) && !qrcode2.isDark(row, col + 5) && qrcode2.isDark(row, col + 6)) {
        lostPoint += 40;
      }
    }
  }
  for (let col = 0; col < moduleCount; col += 1) {
    for (let row = 0; row < moduleCount - 6; row += 1) {
      if (qrcode2.isDark(row, col) && !qrcode2.isDark(row + 1, col) && qrcode2.isDark(row + 2, col) && qrcode2.isDark(row + 3, col) && qrcode2.isDark(row + 4, col) && !qrcode2.isDark(row + 5, col) && qrcode2.isDark(row + 6, col)) {
        lostPoint += 40;
      }
    }
  }
  let darkCount = 0;
  for (let col = 0; col < moduleCount; col += 1) {
    for (let row = 0; row < moduleCount; row += 1) {
      if (qrcode2.isDark(row, col)) {
        darkCount += 1;
      }
    }
  }
  const ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
  lostPoint += ratio * 10;
  return lostPoint;
}

// src/modules/qr-encoder/encoder.ts
var _log42 = createLogger("ENCODER");
var PAD0 = 236;
var PAD1 = 17;
function qrcode(typeNumber, errorCorrectionLevel) {
  let _typeNumber = typeNumber;
  const _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
  let _modules = null;
  let _moduleCount = 0;
  let _dataCache = null;
  const _dataList = [];
  const makeImpl = (test, maskPattern) => {
    _moduleCount = _typeNumber * 4 + 17;
    _modules = (() => {
      const modules = new Array(_moduleCount);
      for (let row = 0; row < _moduleCount; row += 1) {
        modules[row] = new Array(_moduleCount);
        for (let col = 0; col < _moduleCount; col += 1) {
          modules[row][col] = null;
        }
      }
      return modules;
    })();
    setupPositionProbePattern(0, 0);
    setupPositionProbePattern(_moduleCount - 7, 0);
    setupPositionProbePattern(0, _moduleCount - 7);
    setupPositionAdjustPattern();
    setupTimingPattern();
    setupTypeInfo(test, maskPattern);
    if (_typeNumber >= 7) {
      setupTypeNumber(test);
    }
    if (_dataCache == null) {
      _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
    }
    mapData(_dataCache, maskPattern);
  };
  const setupPositionProbePattern = (row, col) => {
    for (let r = -1; r <= 7; r += 1) {
      if (row + r <= -1 || _moduleCount <= row + r) continue;
      for (let c = -1; c <= 7; c += 1) {
        if (col + c <= -1 || _moduleCount <= col + c) continue;
        if (0 <= r && r <= 6 && (c === 0 || c === 6) || 0 <= c && c <= 6 && (r === 0 || r === 6) || 2 <= r && r <= 4 && 2 <= c && c <= 4) {
          _modules[row + r][col + c] = true;
        } else {
          _modules[row + r][col + c] = false;
        }
      }
    }
  };
  const getBestMaskPattern = () => {
    let minLostPoint = 0;
    let pattern = 0;
    for (let i = 0; i < 8; i += 1) {
      makeImpl(true, i);
      const lostPoint = getLostPoint(_this);
      if (i === 0 || minLostPoint > lostPoint) {
        minLostPoint = lostPoint;
        pattern = i;
      }
    }
    return pattern;
  };
  const setupTimingPattern = () => {
    for (let r = 8; r < _moduleCount - 8; r += 1) {
      if (_modules[r][6] != null) continue;
      _modules[r][6] = r % 2 === 0;
    }
    for (let c = 8; c < _moduleCount - 8; c += 1) {
      if (_modules[6][c] != null) continue;
      _modules[6][c] = c % 2 === 0;
    }
  };
  const setupPositionAdjustPattern = () => {
    const pos = getPatternPosition(_typeNumber);
    for (let i = 0; i < pos.length; i += 1) {
      for (let j = 0; j < pos.length; j += 1) {
        const row = pos[i];
        const col = pos[j];
        if (_modules[row][col] != null) continue;
        for (let r = -2; r <= 2; r += 1) {
          for (let c = -2; c <= 2; c += 1) {
            if (r === -2 || r === 2 || c === -2 || c === 2 || r === 0 && c === 0) {
              _modules[row + r][col + c] = true;
            } else {
              _modules[row + r][col + c] = false;
            }
          }
        }
      }
    }
  };
  const setupTypeNumber = (test) => {
    const bits = getBCHTypeNumber2(_typeNumber);
    for (let i = 0; i < 18; i += 1) {
      const mod = !test && (bits >> i & 1) === 1;
      _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
    }
    for (let i = 0; i < 18; i += 1) {
      const mod = !test && (bits >> i & 1) === 1;
      _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
    }
  };
  const setupTypeInfo = (test, maskPattern) => {
    const data = _errorCorrectionLevel << 3 | maskPattern;
    const bits = getBCHTypeInfo2(data);
    for (let i = 0; i < 15; i += 1) {
      const mod = !test && (bits >> i & 1) === 1;
      if (i < 6) {
        _modules[i][8] = mod;
      } else if (i < 8) {
        _modules[i + 1][8] = mod;
      } else {
        _modules[_moduleCount - 15 + i][8] = mod;
      }
    }
    for (let i = 0; i < 15; i += 1) {
      const mod = !test && (bits >> i & 1) === 1;
      if (i < 8) {
        _modules[8][_moduleCount - i - 1] = mod;
      } else if (i < 9) {
        _modules[8][15 - i - 1 + 1] = mod;
      } else {
        _modules[8][15 - i - 1] = mod;
      }
    }
    _modules[_moduleCount - 8][8] = !test;
  };
  const mapData = (data, maskPattern) => {
    let inc = -1;
    let row = _moduleCount - 1;
    let bitIndex = 7;
    let byteIndex = 0;
    const maskFunc = getMaskFunction2(maskPattern);
    for (let col = _moduleCount - 1; col > 0; col -= 2) {
      if (col === 6) col -= 1;
      while (true) {
        for (let c = 0; c < 2; c += 1) {
          if (_modules[row][col - c] == null) {
            let dark = false;
            if (byteIndex < data.length) {
              dark = (data[byteIndex] >>> bitIndex & 1) === 1;
            }
            const mask = maskFunc(row, col - c);
            if (mask) {
              dark = !dark;
            }
            _modules[row][col - c] = dark;
            bitIndex -= 1;
            if (bitIndex === -1) {
              byteIndex += 1;
              bitIndex = 7;
            }
          }
        }
        row += inc;
        if (row < 0 || _moduleCount <= row) {
          row -= inc;
          inc = -inc;
          break;
        }
      }
    }
  };
  const createBytes = (buffer, rsBlocks) => {
    let offset = 0;
    let maxDcCount = 0;
    let maxEcCount = 0;
    const dcdata = new Array(rsBlocks.length);
    const ecdata = new Array(rsBlocks.length);
    for (let r = 0; r < rsBlocks.length; r += 1) {
      const dcCount = rsBlocks[r].dataCount;
      const ecCount = rsBlocks[r].totalCount - dcCount;
      maxDcCount = Math.max(maxDcCount, dcCount);
      maxEcCount = Math.max(maxEcCount, ecCount);
      dcdata[r] = new Array(dcCount);
      for (let i = 0; i < dcdata[r].length; i += 1) {
        dcdata[r][i] = 255 & buffer.getBuffer()[i + offset];
      }
      offset += dcCount;
      const rsPoly = getErrorCorrectPolynomial(ecCount);
      const rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);
      const modPoly = rawPoly.mod(rsPoly);
      ecdata[r] = new Array(rsPoly.getLength() - 1);
      for (let i = 0; i < ecdata[r].length; i += 1) {
        const modIndex = i + modPoly.getLength() - ecdata[r].length;
        ecdata[r][i] = modIndex >= 0 ? modPoly.getAt(modIndex) : 0;
      }
    }
    let totalCodeCount = 0;
    for (let i = 0; i < rsBlocks.length; i += 1) {
      totalCodeCount += rsBlocks[i].totalCount;
    }
    const data = new Array(totalCodeCount);
    let index = 0;
    for (let i = 0; i < maxDcCount; i += 1) {
      for (let r = 0; r < rsBlocks.length; r += 1) {
        if (i < dcdata[r].length) {
          data[index] = dcdata[r][i];
          index += 1;
        }
      }
    }
    for (let i = 0; i < maxEcCount; i += 1) {
      for (let r = 0; r < rsBlocks.length; r += 1) {
        if (i < ecdata[r].length) {
          data[index] = ecdata[r][i];
          index += 1;
        }
      }
    }
    return data;
  };
  const createData = (typeNumber2, errorCorrectionLevel2, dataList) => {
    const rsBlocks = getRSBlocks(typeNumber2, errorCorrectionLevel2);
    const buffer = qrBitBuffer();
    for (let i = 0; i < dataList.length; i += 1) {
      const data = dataList[i];
      buffer.put(data.getMode(), 4);
      buffer.put(data.getLength(), getLengthInBits(data.getMode(), typeNumber2));
      data.write(buffer);
    }
    let totalDataCount = 0;
    for (let i = 0; i < rsBlocks.length; i += 1) {
      totalDataCount += rsBlocks[i].dataCount;
    }
    if (buffer.getLengthInBits() > totalDataCount * 8) {
      throw new Error(`code length overflow. (${buffer.getLengthInBits()}>${totalDataCount * 8})`);
    }
    if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
      buffer.put(0, 4);
    }
    while (buffer.getLengthInBits() % 8 !== 0) {
      buffer.putBit(false);
    }
    while (true) {
      if (buffer.getLengthInBits() >= totalDataCount * 8) {
        break;
      }
      buffer.put(PAD0, 8);
      if (buffer.getLengthInBits() >= totalDataCount * 8) {
        break;
      }
      buffer.put(PAD1, 8);
    }
    return createBytes(buffer, rsBlocks);
  };
  const escapeXml = (s) => {
    let escaped = "";
    for (let i = 0; i < s.length; i += 1) {
      const c = s.charAt(i);
      switch (c) {
        case "<":
          escaped += "&lt;";
          break;
        case ">":
          escaped += "&gt;";
          break;
        case "&":
          escaped += "&amp;";
          break;
        case '"':
          escaped += "&quot;";
          break;
        default:
          escaped += c;
          break;
      }
    }
    return escaped;
  };
  const _createHalfASCII = (margin) => {
    const cellSize = 1;
    const marginVal = typeof margin === "undefined" ? cellSize * 2 : margin;
    const size = _moduleCount * cellSize + marginVal * 2;
    const min = marginVal;
    const max = size - marginVal;
    const blocks = {
      "\u2588\u2588": "\u2588",
      "\u2588 ": "\u2580",
      " \u2588": "\u2584",
      "  ": " "
    };
    const blocksLastLineNoMargin = {
      "\u2588\u2588": "\u2580",
      "\u2588 ": "\u2580",
      " \u2588": " ",
      "  ": " "
    };
    let ascii = "";
    for (let y = 0; y < size; y += 2) {
      const r1 = Math.floor((y - min) / cellSize);
      const r2 = Math.floor((y + 1 - min) / cellSize);
      for (let x = 0; x < size; x += 1) {
        let p = "\u2588";
        if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
          p = " ";
        }
        if (min <= x && x < max && min <= y + 1 && y + 1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
          p += " ";
        } else {
          p += "\u2588";
        }
        ascii += marginVal < 1 && y + 1 >= max ? blocksLastLineNoMargin[p] : blocks[p];
      }
      ascii += "\n";
    }
    if (size % 2 && marginVal > 0) {
      return ascii.substring(0, ascii.length - size - 1) + Array(size + 1).join("\u2580");
    }
    return ascii.substring(0, ascii.length - 1);
  };
  const _this = {
    addData: (data, mode) => {
      const modeVal = mode || "Byte";
      let newData = null;
      switch (modeVal) {
        case "Numeric":
          newData = qrNumber(data);
          break;
        case "Alphanumeric":
          newData = qrAlphaNum(data);
          break;
        case "Byte":
          newData = qr8BitByte(data);
          break;
        case "Kanji":
          newData = qrKanji(data);
          break;
        default:
          throw new Error(`mode:${modeVal}`);
      }
      _dataList.push(newData);
      _dataCache = null;
    },
    isDark: (row, col) => {
      if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
        throw new Error(`${row},${col}`);
      }
      return _modules[row][col] === true;
    },
    getModuleCount: () => _moduleCount,
    make: (maskPattern) => {
      if (_typeNumber < 1) {
        let typeNum = 1;
        for (; typeNum < 40; typeNum++) {
          const rsBlocks = getRSBlocks(typeNum, _errorCorrectionLevel);
          const buffer = qrBitBuffer();
          for (let i = 0; i < _dataList.length; i++) {
            const data = _dataList[i];
            buffer.put(data.getMode(), 4);
            buffer.put(data.getLength(), getLengthInBits(data.getMode(), typeNum));
            data.write(buffer);
          }
          let totalDataCount = 0;
          for (let i = 0; i < rsBlocks.length; i++) {
            totalDataCount += rsBlocks[i].dataCount;
          }
          if (buffer.getLengthInBits() <= totalDataCount * 8) {
            break;
          }
        }
        _typeNumber = typeNum;
      }
      const finalMaskPattern = typeof maskPattern === "number" && maskPattern >= 0 && maskPattern <= 7 ? maskPattern : getBestMaskPattern();
      makeImpl(false, finalMaskPattern);
    },
    createTableTag: (cellSize, margin) => {
      const cellSizeVal = cellSize || 2;
      const marginVal = typeof margin === "undefined" ? cellSizeVal * 4 : margin;
      let qrHtml = "";
      qrHtml += '<table style="';
      qrHtml += " border-width: 0px; border-style: none;";
      qrHtml += " border-collapse: collapse;";
      qrHtml += ` padding: 0px; margin: ${marginVal}px;`;
      qrHtml += '">';
      qrHtml += "<tbody>";
      for (let r = 0; r < _this.getModuleCount(); r += 1) {
        qrHtml += "<tr>";
        for (let c = 0; c < _this.getModuleCount(); c += 1) {
          qrHtml += '<td style="';
          qrHtml += " border-width: 0px; border-style: none;";
          qrHtml += " border-collapse: collapse;";
          qrHtml += " padding: 0px; margin: 0px;";
          qrHtml += ` width: ${cellSizeVal}px;`;
          qrHtml += ` height: ${cellSizeVal}px;`;
          qrHtml += " background-color: ";
          qrHtml += _this.isDark(r, c) ? "#000000" : "#ffffff";
          qrHtml += ";";
          qrHtml += '"/>';
        }
        qrHtml += "</tr>";
      }
      qrHtml += "</tbody>";
      qrHtml += "</table>";
      return qrHtml;
    },
    createSvgTag: (cellSize, margin, alt, title) => {
      let opts = {};
      if (typeof cellSize === "object") {
        opts = cellSize;
        cellSize = opts.cellSize;
        margin = opts.margin;
        alt = opts.alt;
        title = opts.title;
      }
      const cellSizeVal = cellSize || 2;
      const marginVal = typeof margin === "undefined" ? cellSizeVal * 4 : margin;
      let altObj = { text: null, id: null };
      if (typeof alt === "string") {
        altObj = { text: alt, id: alt ? "qrcode-description" : null };
      } else if (alt && typeof alt === "object") {
        altObj = alt;
      }
      altObj.text = altObj.text || null;
      altObj.id = altObj.text ? altObj.id || "qrcode-description" : null;
      let titleObj = { text: null, id: null };
      if (typeof title === "string") {
        titleObj = { text: title, id: title ? "qrcode-title" : null };
      } else if (title && typeof title === "object") {
        titleObj = title;
      }
      titleObj.text = titleObj.text || null;
      titleObj.id = titleObj.text ? titleObj.id || "qrcode-title" : null;
      const size = _this.getModuleCount() * cellSizeVal + marginVal * 2;
      const rect = `l${cellSizeVal},0 0,${cellSizeVal} -${cellSizeVal},0 0,-${cellSizeVal}z `;
      let qrSvg = "";
      qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
      qrSvg += !opts.scalable ? ` width="${size}px" height="${size}px"` : "";
      qrSvg += ` viewBox="0 0 ${size} ${size}" `;
      qrSvg += ' preserveAspectRatio="xMinYMin meet"';
      qrSvg += titleObj.text || altObj.text ? ` role="img" aria-labelledby="${escapeXml([titleObj.id, altObj.id].join(" ").trim())}"` : "";
      qrSvg += ">";
      qrSvg += titleObj.text ? `<title id="${escapeXml(titleObj.id || "")}">${escapeXml(titleObj.text)}</title>` : "";
      qrSvg += altObj.text ? `<description id="${escapeXml(altObj.id || "")}">${escapeXml(altObj.text)}</description>` : "";
      qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
      qrSvg += '<path d="';
      for (let r = 0; r < _this.getModuleCount(); r += 1) {
        const mr = r * cellSizeVal + marginVal;
        for (let c = 0; c < _this.getModuleCount(); c += 1) {
          if (_this.isDark(r, c)) {
            const mc = c * cellSizeVal + marginVal;
            qrSvg += `M${mc},${mr}${rect}`;
          }
        }
      }
      qrSvg += '" stroke="transparent" fill="black"/>';
      qrSvg += "</svg>";
      return qrSvg;
    },
    createDataURL: (cellSize, margin) => {
      const cellSizeVal = cellSize || 2;
      const marginVal = typeof margin === "undefined" ? cellSizeVal * 4 : margin;
      const size = _this.getModuleCount() * cellSizeVal + marginVal * 2;
      const min = marginVal;
      const max = size - marginVal;
      return createDataURL(size, size, (x, y) => {
        if (min <= x && x < max && min <= y && y < max) {
          const c = Math.floor((x - min) / cellSizeVal);
          const r = Math.floor((y - min) / cellSizeVal);
          return _this.isDark(r, c) ? 0 : 1;
        } else {
          return 1;
        }
      });
    },
    createImgTag: (cellSize, margin, alt) => {
      const cellSizeVal = cellSize || 2;
      const marginVal = typeof margin === "undefined" ? cellSizeVal * 4 : margin;
      const size = _this.getModuleCount() * cellSizeVal + marginVal * 2;
      let img = "";
      img += "<img";
      img += ' src="';
      img += _this.createDataURL(cellSizeVal, marginVal);
      img += '"';
      img += ' width="';
      img += size;
      img += '"';
      img += ' height="';
      img += size;
      img += '"';
      if (alt) {
        img += ' alt="';
        img += escapeXml(alt);
        img += '"';
      }
      img += "/>";
      return img;
    },
    createASCII: (cellSize, margin) => {
      const cellSizeVal = cellSize || 1;
      if (cellSizeVal < 2) {
        return _createHalfASCII(margin);
      }
      const cs = cellSizeVal - 1;
      const marginVal = typeof margin === "undefined" ? cs * 2 : margin;
      const size = _moduleCount * cs + marginVal * 2;
      const min = marginVal;
      const max = size - marginVal;
      const white = Array(cs + 1).join("\u2588\u2588");
      const black = Array(cs + 1).join("  ");
      let ascii = "";
      for (let y = 0; y < size; y += 1) {
        const r = Math.floor((y - min) / cs);
        let line = "";
        for (let x = 0; x < size; x += 1) {
          let p = 1;
          if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cs))) {
            p = 0;
          }
          line += p ? white : black;
        }
        for (let i = 0; i < cs; i += 1) {
          ascii += `${line}
`;
        }
      }
      return ascii.substring(0, ascii.length - 1);
    },
    renderTo2dContext: (context, cellSize) => {
      const cellSizeVal = cellSize || 2;
      const length = _this.getModuleCount();
      for (let row = 0; row < length; row++) {
        for (let col = 0; col < length; col++) {
          context.fillStyle = _this.isDark(row, col) ? "black" : "white";
          context.fillRect(col * cellSizeVal, row * cellSizeVal, cellSizeVal, cellSizeVal);
        }
      }
    },
    // Debug/test helper to access interleaved data bytes
    getDataCache: () => {
      if (_typeNumber < 1) {
        throw new Error("QR code not initialized: call make() before getDataCache()");
      }
      if (_dataCache == null) {
        _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
      }
      return _dataCache;
    }
  };
  return _this;
}

// src/modules/qr-encoder/encoder-api.ts
var _log43 = createLogger("ENCODER");
function isNumeric(char) {
  return /^[0-9]$/.test(char);
}
function isAlphanumeric(char) {
  return /^[0-9A-Z $%*+\-./:]$/.test(char);
}
function optimizeSegments(text) {
  if (!text || text.length === 0) {
    return [];
  }
  const segments = [];
  let i = 0;
  while (i < text.length) {
    const numericStart = i;
    while (i < text.length && isNumeric(text[i])) {
      i++;
    }
    const numericLen = i - numericStart;
    if (numericLen >= 4) {
      segments.push({ data: text.slice(numericStart, i), mode: "numeric" });
      continue;
    }
    i = numericStart;
    const alphaStart = i;
    const upperText = text.toUpperCase();
    while (i < text.length && isAlphanumeric(upperText[i]) && text[i] === upperText[i]) {
      i++;
    }
    const alphaLen = i - alphaStart;
    if (alphaLen >= 6) {
      segments.push({ data: text.slice(alphaStart, i), mode: "alphanumeric" });
      continue;
    }
    i = alphaStart;
    const byteStart = i;
    while (i < text.length) {
      let numAhead = 0;
      let j = i;
      while (j < text.length && isNumeric(text[j])) {
        numAhead++;
        j++;
      }
      if (numAhead >= 4) break;
      let alphaAhead = 0;
      j = i;
      while (j < text.length && isAlphanumeric(upperText[j]) && text[j] === upperText[j]) {
        alphaAhead++;
        j++;
      }
      if (alphaAhead >= 6) break;
      i++;
    }
    if (i > byteStart) {
      segments.push({ data: text.slice(byteStart, i), mode: "byte" });
    }
  }
  const merged = [];
  for (const seg of segments) {
    if (merged.length > 0 && merged[merged.length - 1].mode === seg.mode) {
      merged[merged.length - 1].data += seg.data;
    } else {
      merged.push({ ...seg });
    }
  }
  return merged;
}
function toEncoderModeToken(mode, content) {
  if (mode === "numeric") return "Numeric";
  if (mode === "alphanumeric") return "Alphanumeric";
  if (mode === "kanji") return "Kanji";
  if (mode === "byte") return "Byte";
  const compatible = getCompatibleMode(content, mode);
  switch (compatible) {
    case "numeric":
      return "Numeric";
    case "alphanumeric":
      return "Alphanumeric";
    case "kanji":
      return "Kanji";
    default:
      return "Byte";
  }
}
function createQRInstanceWithSegments(segments, errorCorrectionLevel = "M", version = 0, options = {}) {
  const typeNumber = version === 0 ? 0 : version;
  const qr = qrcode(
    typeNumber,
    errorCorrectionLevel
  );
  for (const segment of segments) {
    const modeToken = toEncoderModeToken(segment.mode, segment.data);
    qr.addData(segment.data, modeToken);
  }
  const mask = options.maskPattern;
  const maskPattern = typeof mask === "number" && mask >= 0 && mask <= 7 ? mask : void 0;
  qr.make(maskPattern);
  return qr;
}
function createQRInstance(data, errorCorrectionLevel = "M", version = 0, options = {}) {
  if (options.mode === "mixed" || options.mode === "auto") {
    const segments = optimizeSegments(data);
    if (segments.length > 1 || segments.length === 1 && segments[0].mode !== "byte") {
      return createQRInstanceWithSegments(segments, errorCorrectionLevel, version, options);
    }
  }
  const typeNumber = version === 0 ? 0 : version;
  const qr = qrcode(
    typeNumber,
    errorCorrectionLevel
  );
  const modeToken = options.mode && options.mode !== "mixed" ? toEncoderModeToken(options.mode, data) : void 0;
  qr.addData(data, modeToken);
  const mask = options.maskPattern;
  const maskPattern = typeof mask === "number" && mask >= 0 && mask <= 7 ? mask : void 0;
  qr.make(maskPattern);
  return qr;
}
function getCompatibleMode(content, requestedMode) {
  if (requestedMode === "auto") {
    if (/^[0-9]+$/.test(content)) return "numeric";
    if (/^[0-9A-Z $%*+\-./:']+$/.test(content)) return "alphanumeric";
    return "byte";
  }
  switch (requestedMode) {
    case "numeric":
      if (/^[0-9]+$/.test(content)) return "numeric";
      break;
    case "alphanumeric":
      if (/^[0-9A-Z $%*+\-./:']+$/.test(content)) return "alphanumeric";
      break;
    case "kanji":
      return "kanji";
    case "byte":
      return "byte";
  }
  return "byte";
}
function calculateOptimalVersion(data, errorCorrectionLevel = "M") {
  for (let v = 1; v <= 40; v++) {
    try {
      createQRInstance(data, errorCorrectionLevel, v);
      return v;
    } catch {
    }
  }
  return 40;
}

// src/modules/qr-generator/cache.ts
var _log44 = createLogger("GENERATE");
var MemoCache = class {
  cache;
  maxSize;
  constructor(maxSize = 100) {
    this.cache = /* @__PURE__ */ new Map();
    this.maxSize = maxSize;
  }
  get(key) {
    if (this.cache.has(key)) {
      const value = this.cache.get(key);
      this.cache.delete(key);
      this.cache.set(key, value);
      return value;
    }
    return void 0;
  }
  set(key, value) {
    if (this.cache.has(key)) {
      this.cache.delete(key);
    }
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      if (firstKey !== void 0) {
        this.cache.delete(firstKey);
      }
    }
    this.cache.set(key, value);
  }
  clear() {
    this.cache.clear();
  }
};
var alignmentCache = new MemoCache(50);
var overlayDataCache = new MemoCache(20);
var qrMatrixCache = new MemoCache(30);
var canvasHashCache = /* @__PURE__ */ new WeakMap();

// src/modules/qr-generator/canvas-factory.ts
var _log45 = createLogger("GENERATE");
var defaultBrowserCanvasFactory = {
  createCanvas: (width, height) => {
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    return Promise.resolve(canvas);
  },
  loadImage: (src) => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error(`Failed to load image: ${src}`));
      img.src = src;
    });
  }
};

// src/modules/qr-generator/utils.ts
var log4 = createLogger("GENERATE");
function validateColor(color, fallback) {
  if (typeof color !== "string" || !color) {
    return fallback;
  }
  const trimmed = color.trim();
  if (trimmed.length < 4) {
    return fallback;
  }
  if (trimmed.startsWith("#")) {
    const hex = trimmed.slice(1);
    if (!/^[0-9a-fA-F]{3,8}$/.test(hex)) {
      return fallback;
    }
    return trimmed;
  }
  if (trimmed.startsWith("rgb")) {
    return trimmed;
  }
  if (trimmed.startsWith("hsl")) {
    return trimmed;
  }
  if (/^[a-zA-Z]+$/.test(trimmed)) {
    return trimmed;
  }
  return fallback;
}
var getContrastRatio2 = getContrastRatio;
async function hashCanvasContent(canvas, createCanvasFn) {
  const cachedHash = canvas instanceof HTMLCanvasElement ? canvasHashCache.get(canvas) : void 0;
  if (cachedHash !== void 0) {
    return cachedHash;
  }
  try {
    const hashSize = 32;
    const hashCanvas = typeof document !== "undefined" ? (() => {
      const c = document.createElement("canvas");
      c.width = hashSize;
      c.height = hashSize;
      return c;
    })() : await createCanvasFn(hashSize, hashSize);
    const hashCtx = hashCanvas.getContext("2d");
    if (!hashCtx) {
      return `${canvas.width}x${canvas.height}`;
    }
    hashCtx.drawImage(canvas, 0, 0, hashSize, hashSize);
    const imageData = hashCtx.getImageData(0, 0, hashSize, hashSize);
    const data = imageData.data;
    let hash = 5381;
    for (let i = 0; i < data.length; i += 4) {
      hash = (hash << 5) + hash + data[i];
      hash = (hash << 5) + hash + data[i + 1];
      hash = (hash << 5) + hash + data[i + 2];
      hash = hash >>> 0;
    }
    const hashStr = hash.toString(16);
    if (canvas instanceof HTMLCanvasElement) {
      canvasHashCache.set(canvas, hashStr);
    }
    return hashStr;
  } catch (error) {
    log4.warn("Canvas hashing failed", { error });
    return `${canvas.width}x${canvas.height}`;
  }
}

// src/modules/qr-generator/color.ts
var log5 = createLogger("GENERATE");
function applyPerModuleColor(mode, baseColor, overlayData, row, col, moduleCount, config) {
  const brightness2 = overlayData[row]?.[col] ?? 0.5;
  const overlayColor = overlayData.colors?.[row]?.[col];
  const intensity = (config.overlayIntensity || 100) / 100;
  switch (mode) {
    case "by_brightness": {
      const parsed = parseColor(baseColor);
      if (!parsed) return baseColor;
      const factor = 0.5 + brightness2 * 0.5;
      return `rgb(${Math.round(parsed.r * factor)},${Math.round(parsed.g * factor)},${Math.round(parsed.b * factor)})`;
    }
    case "by_position": {
      const parsed = parseColor(baseColor);
      if (!parsed) return baseColor;
      const xFactor = col / moduleCount;
      const yFactor = row / moduleCount;
      const r = Math.round(parsed.r * (0.5 + xFactor * 0.5));
      const g = Math.round(parsed.g * (0.5 + yFactor * 0.5));
      const b = Math.round(parsed.b * (0.5 + (1 - xFactor) * 0.5));
      return `rgb(${r},${g},${b})`;
    }
    case "by_overlay": {
      if (overlayColor) {
        const colorStr = `rgb(${overlayColor.r},${overlayColor.g},${overlayColor.b})`;
        return blendColors(baseColor, colorStr, intensity);
      }
      return baseColor;
    }
    case "by_cluster": {
      const blockSize = 3;
      const blockRow = Math.floor(row / blockSize);
      const blockCol = Math.floor(col / blockSize);
      const seed = blockRow * 100 + blockCol;
      const hueShift = seed * 37 % 360;
      const parsed = parseColor(baseColor);
      if (!parsed) return baseColor;
      const angle = hueShift * Math.PI / 180;
      const cos = Math.cos(angle);
      const sin = Math.sin(angle);
      const r = Math.max(
        0,
        Math.min(
          255,
          parsed.r * (0.213 + cos * 0.787 - sin * 0.213) + parsed.g * (0.715 - cos * 0.715 - sin * 0.715) + parsed.b * (0.072 - cos * 0.072 + sin * 0.928)
        )
      );
      const g = Math.max(
        0,
        Math.min(
          255,
          parsed.r * (0.213 - cos * 0.213 + sin * 0.143) + parsed.g * (0.715 + cos * 0.285 + sin * 0.14) + parsed.b * (0.072 - cos * 0.072 - sin * 0.283)
        )
      );
      const b = Math.max(
        0,
        Math.min(
          255,
          parsed.r * (0.213 - cos * 0.213 - sin * 0.787) + parsed.g * (0.715 - cos * 0.715 + sin * 0.715) + parsed.b * (0.072 + cos * 0.928 + sin * 0.072)
        )
      );
      return `rgb(${Math.round(r)},${Math.round(g)},${Math.round(b)})`;
    }
    default:
      return baseColor;
  }
}
function ensureContrast(moduleColor, bgColor, minRatio) {
  try {
    const ratio = getContrastRatio2(moduleColor, bgColor);
    if (ratio >= minRatio) {
      return moduleColor;
    }
    const parsed = parseColor(moduleColor);
    if (!parsed) return moduleColor;
    const bgLuminance = getRelativeLuminance(bgColor);
    const bgIsDark = bgLuminance < 0.179;
    let newColor = moduleColor;
    if (bgIsDark) {
      let factor = 0.1;
      for (let i = 0; i < 10; i++) {
        const r = Math.round(parsed.r + (255 - parsed.r) * factor);
        const g = Math.round(parsed.g + (255 - parsed.g) * factor);
        const b = Math.round(parsed.b + (255 - parsed.b) * factor);
        newColor = `rgb(${r},${g},${b})`;
        const newRatio = getContrastRatio2(newColor, bgColor);
        if (newRatio >= minRatio) {
          return newColor;
        }
        factor = Math.min(1, factor + 0.1);
      }
      return "#ffffff";
    } else {
      let factor = 0.9;
      for (let i = 0; i < 10; i++) {
        const r = Math.round(parsed.r * factor);
        const g = Math.round(parsed.g * factor);
        const b = Math.round(parsed.b * factor);
        newColor = `rgb(${r},${g},${b})`;
        const newRatio = getContrastRatio2(newColor, bgColor);
        if (newRatio >= minRatio) {
          return newColor;
        }
        factor *= 0.85;
      }
      return "#000000";
    }
  } catch (error) {
    log5.warn("Contrast check failed", { error });
    return moduleColor;
  }
}
function applyPaletteColor(row, col, moduleCount, brightness2, palette, config) {
  if (!palette || palette.length === 0) return config.fgColor;
  const paletteMode = config.paletteMode || "position";
  switch (paletteMode) {
    case "brightness": {
      const idx = Math.floor((1 - brightness2) * (palette.length - 0.01));
      return palette[Math.max(0, Math.min(palette.length - 1, idx))];
    }
    case "diagonal": {
      const diag = (row + col) / (moduleCount * 2);
      const idx = Math.floor(diag * palette.length) % palette.length;
      return palette[idx];
    }
    case "radial": {
      const cx = moduleCount / 2;
      const cy = moduleCount / 2;
      const dist = Math.hypot(row - cy, col - cx);
      const maxDist = Math.hypot(cx, cy);
      const idx = Math.floor(dist / maxDist * palette.length) % palette.length;
      return palette[idx];
    }
    case "random": {
      const hash = (row * 31 + col) * 17 % palette.length;
      return palette[hash];
    }
    case "row": {
      const idx = Math.floor(row / moduleCount * palette.length) % palette.length;
      return palette[idx];
    }
    case "column": {
      const idx = Math.floor(col / moduleCount * palette.length) % palette.length;
      return palette[idx];
    }
    default: {
      const linearPos = row * moduleCount + col;
      const idx = linearPos % palette.length;
      return palette[idx];
    }
  }
}

// src/modules/qr-generator/dithering-advanced.ts
var _log46 = createLogger("GENERATE");

// src/modules/qr-generator/dithering-error.ts
var _log47 = createLogger("GENERATE");
function distributeError(errors, x, y, error, kernel, width, height) {
  for (const offset of kernel.offsets) {
    const nx = x + offset.dx;
    const ny = y + offset.dy;
    if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
      if (!errors[ny]) errors[ny] = [];
      errors[ny][nx] = (errors[ny][nx] || 0) + error * offset.weight / kernel.divisor;
    }
  }
}

// src/modules/qr-generator/dithering-kernels.ts
var _log48 = createLogger("GENERATE");
function getDiffusionKernel(name) {
  const kernels = {
    floyd_steinberg: {
      offsets: [
        { dx: 1, dy: 0, weight: 7 },
        { dx: -1, dy: 1, weight: 3 },
        { dx: 0, dy: 1, weight: 5 },
        { dx: 1, dy: 1, weight: 1 }
      ],
      divisor: 16
    },
    jarvis_judice_ninke: {
      offsets: [
        { dx: 1, dy: 0, weight: 7 },
        { dx: 2, dy: 0, weight: 5 },
        { dx: -2, dy: 1, weight: 3 },
        { dx: -1, dy: 1, weight: 5 },
        { dx: 0, dy: 1, weight: 7 },
        { dx: 1, dy: 1, weight: 5 },
        { dx: 2, dy: 1, weight: 3 },
        { dx: -2, dy: 2, weight: 1 },
        { dx: -1, dy: 2, weight: 3 },
        { dx: 0, dy: 2, weight: 5 },
        { dx: 1, dy: 2, weight: 3 },
        { dx: 2, dy: 2, weight: 1 }
      ],
      divisor: 48
    },
    stucki: {
      offsets: [
        { dx: 1, dy: 0, weight: 8 },
        { dx: 2, dy: 0, weight: 4 },
        { dx: -2, dy: 1, weight: 2 },
        { dx: -1, dy: 1, weight: 4 },
        { dx: 0, dy: 1, weight: 8 },
        { dx: 1, dy: 1, weight: 4 },
        { dx: 2, dy: 1, weight: 2 },
        { dx: -2, dy: 2, weight: 1 },
        { dx: -1, dy: 2, weight: 2 },
        { dx: 0, dy: 2, weight: 4 },
        { dx: 1, dy: 2, weight: 2 },
        { dx: 2, dy: 2, weight: 1 }
      ],
      divisor: 42
    },
    atkinson: {
      offsets: [
        { dx: 1, dy: 0, weight: 1 },
        { dx: 2, dy: 0, weight: 1 },
        { dx: -1, dy: 1, weight: 1 },
        { dx: 0, dy: 1, weight: 1 },
        { dx: 1, dy: 1, weight: 1 },
        { dx: 0, dy: 2, weight: 1 }
      ],
      divisor: 8
    },
    burkes: {
      offsets: [
        { dx: 1, dy: 0, weight: 8 },
        { dx: 2, dy: 0, weight: 4 },
        { dx: -2, dy: 1, weight: 2 },
        { dx: -1, dy: 1, weight: 4 },
        { dx: 0, dy: 1, weight: 8 },
        { dx: 1, dy: 1, weight: 4 },
        { dx: 2, dy: 1, weight: 2 }
      ],
      divisor: 32
    },
    sierra: {
      offsets: [
        { dx: 1, dy: 0, weight: 5 },
        { dx: 2, dy: 0, weight: 3 },
        { dx: -2, dy: 1, weight: 2 },
        { dx: -1, dy: 1, weight: 4 },
        { dx: 0, dy: 1, weight: 5 },
        { dx: 1, dy: 1, weight: 4 },
        { dx: 2, dy: 1, weight: 2 },
        { dx: -1, dy: 2, weight: 2 },
        { dx: 0, dy: 2, weight: 3 },
        { dx: 1, dy: 2, weight: 2 }
      ],
      divisor: 32
    },
    sierra_two_row: {
      offsets: [
        { dx: 1, dy: 0, weight: 4 },
        { dx: 2, dy: 0, weight: 3 },
        { dx: -2, dy: 1, weight: 1 },
        { dx: -1, dy: 1, weight: 2 },
        { dx: 0, dy: 1, weight: 3 },
        { dx: 1, dy: 1, weight: 2 },
        { dx: 2, dy: 1, weight: 1 }
      ],
      divisor: 16
    },
    sierra_lite: {
      offsets: [
        { dx: 1, dy: 0, weight: 2 },
        { dx: -1, dy: 1, weight: 1 },
        { dx: 0, dy: 1, weight: 1 }
      ],
      divisor: 4
    }
  };
  return kernels[name] || kernels.floyd_steinberg;
}

// src/modules/qr-generator/dithering-constants.ts
var HISTOGRAM_BUCKETS = 32;
var BUCKET_SHIFT = 3;
var DARK_REGION_END = 8;
var LIGHT_REGION_START = 24;
var MIN_PEAK_RATIO = 0.12;
var MAX_VALLEY_RATIO = 0.2;
var MIN_PEAK_SEPARATION = 16;
var DARK_DESIRE_MIN = 0.55;
var DARK_DESIRE_MAX = 0.95;
var LIGHT_DESIRE_MIN = 0.05;
var LIGHT_DESIRE_MAX = 0.45;

// src/modules/qr-generator/dithering-matrix.ts
var log6 = createLogger("GENERATE");
function detectBWFromOverlayData(overlayData, moduleCount) {
  const histogram = new Int32Array(HISTOGRAM_BUCKETS);
  let totalPixels = 0;
  for (let row = 0; row < moduleCount; row++) {
    for (let col = 0; col < moduleCount; col++) {
      const brightness2 = overlayData[row]?.[col] ?? 0.5;
      const gray = Math.floor(brightness2 * 255);
      const bucket = Math.min(HISTOGRAM_BUCKETS - 1, gray >> BUCKET_SHIFT);
      histogram[bucket]++;
      totalPixels++;
    }
  }
  if (totalPixels === 0) return false;
  let darkPeakBucket = 0, lightPeakBucket = 0;
  let darkPeak = 0, lightPeak = 0;
  for (let i = 0; i < DARK_REGION_END; i++) {
    if (histogram[i] > darkPeak) {
      darkPeak = histogram[i];
      darkPeakBucket = i;
    }
  }
  for (let i = LIGHT_REGION_START; i < HISTOGRAM_BUCKETS; i++) {
    if (histogram[i] > lightPeak) {
      lightPeak = histogram[i];
      lightPeakBucket = i;
    }
  }
  if (lightPeakBucket - darkPeakBucket < MIN_PEAK_SEPARATION) return false;
  let darkCount = 0, lightCount = 0, valleyCount = 0;
  for (let i = 0; i < DARK_REGION_END; i++) darkCount += histogram[i];
  for (let i = LIGHT_REGION_START; i < HISTOGRAM_BUCKETS; i++) lightCount += histogram[i];
  for (let i = DARK_REGION_END; i < LIGHT_REGION_START; i++) valleyCount += histogram[i];
  return darkCount / totalPixels >= MIN_PEAK_RATIO && lightCount / totalPixels >= MIN_PEAK_RATIO && valleyCount / totalPixels < MAX_VALLEY_RATIO;
}
function isFinderSeparator(row, col, moduleCount) {
  if (row === 7 && col <= 7 || col === 7 && row <= 7) return true;
  if (row === 7 && col >= moduleCount - 8 || col === moduleCount - 8 && row <= 7) return true;
  if (row === moduleCount - 8 && col <= 7 || col === 7 && row >= moduleCount - 8) return true;
  return false;
}
function shouldLockModule(row, col, moduleCount, version, config) {
  const preserveFunctional = config.preserveFunctionalPatterns === true;
  const preserveFinders = config.preserveFinders !== false;
  const preserveTiming = preserveFunctional ? config.preserveTiming !== false : config.preserveTiming === true;
  const preserveAlignment = preserveFunctional ? config.preserveAlignment !== false : config.preserveAlignment === true;
  const protectFormat = preserveFunctional ? config.protectFormatInfo !== false : config.protectFormatInfo === true;
  const protectVersion = preserveFunctional ? config.protectVersionInfo !== false : config.protectVersionInfo === true;
  const preserveFixedDark = preserveFunctional;
  if (row === moduleCount - 8 && col === 8) return preserveFixedDark;
  if (isFinderPattern(row, col, moduleCount) || isFinderSeparator(row, col, moduleCount)) {
    return preserveFinders;
  }
  if (isTimingPattern(row, col, moduleCount)) return preserveTiming;
  if (isAlignmentPattern(row, col, moduleCount, version)) return preserveAlignment;
  if (isFormatInfo(row, col, moduleCount)) return protectFormat;
  if (isVersionInfo(row, col, moduleCount, version)) return protectVersion;
  return false;
}
function applyDitherToMatrix(qr, moduleCount, overlayData, config) {
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  if (detectBWFromOverlayData(overlayData, moduleCount)) {
    log6.debug("Detected high-contrast B&W overlay in dither mode - using QR-first (no dithering)");
    const result2 = [];
    for (let row = 0; row < moduleCount; row++) {
      result2[row] = [];
      for (let col = 0; col < moduleCount; col++) {
        result2[row][col] = qr.isDark(row, col);
      }
    }
    return result2;
  }
  const kernel = getDiffusionKernel(config.ditherKind || "floyd_steinberg");
  const strength = (config.ditherStrength ?? 50) / 100;
  const intensity = (config.overlayIntensity ?? 100) / 100;
  const result = [];
  for (let row = 0; row < moduleCount; row++) {
    result[row] = [];
    for (let col = 0; col < moduleCount; col++) {
      result[row][col] = qr.isDark(row, col);
    }
  }
  const errors = [];
  for (let row = 0; row < moduleCount; row++) {
    errors[row] = new Array(moduleCount).fill(0);
  }
  for (let row = 0; row < moduleCount; row++) {
    for (let col = 0; col < moduleCount; col++) {
      const qrIsDark = qr.isDark(row, col);
      if (shouldLockModule(row, col, moduleCount, version, config)) {
        result[row][col] = qrIsDark;
        continue;
      }
      const brightness2 = overlayData[row]?.[col] ?? 0.5;
      const originalValue = qrIsDark ? 1 : 0;
      const error = errors[row][col] || 0;
      const overlayDark = 1 - brightness2;
      const mix = intensity * strength;
      let targetValue = originalValue * (1 - mix) + overlayDark * mix;
      if (qrIsDark) {
        targetValue = DARK_DESIRE_MIN + targetValue * (DARK_DESIRE_MAX - DARK_DESIRE_MIN);
      } else {
        targetValue = LIGHT_DESIRE_MIN + targetValue * (LIGHT_DESIRE_MAX - LIGHT_DESIRE_MIN);
      }
      const adjustedValue = targetValue + error;
      const threshold2 = qrIsDark ? 0.4 : 0.6;
      const newValue = adjustedValue >= threshold2;
      result[row][col] = newValue;
      const quantError = adjustedValue - (newValue ? 1 : 0);
      distributeError(errors, col, row, quantError, kernel, moduleCount, moduleCount);
    }
  }
  enforceModuleConstraints(qr, result, moduleCount, version, config);
  log6.debug("dither-matrix applied with QR protection", {
    moduleCount,
    strength,
    intensity,
    version
  });
  return result;
}
function enforceModuleConstraints(qr, matrix, moduleCount, version, config) {
  for (let row = 0; row < moduleCount; row++) {
    for (let col = 0; col < moduleCount; col++) {
      const qrIsDark = qr.isDark(row, col);
      if (shouldLockModule(row, col, moduleCount, version, config)) {
        matrix[row][col] = qrIsDark;
      }
    }
  }
}

// src/modules/qr-generator/dithering-true.ts
var _log49 = createLogger("GENERATE");

// src/modules/qr-generator/dithering.ts
var _log50 = createLogger("GENERATE");

// src/modules/qr-encoder/shift-jis.ts
var _log51 = createLogger("ENCODER");
var HIRAGANA_START = 12353;
var HIRAGANA_END = 12438;
var KATAKANA_START = 12449;
var KATAKANA_END = 12534;
var HW_KATAKANA_START = 65377;
var HW_KATAKANA_END = 65439;
var HW_KATAKANA_SJIS_START = 161;
var FULLWIDTH_ASCII_START = 65281;
var FULLWIDTH_ASCII_END = 65374;
var FULLWIDTH_MAP = {
  // Full-width space
  12288: 33088,
  // Full-width punctuation
  12289: 33089,
  // 、
  12290: 33090,
  // 。
  65292: 33091,
  // ，
  65294: 33092,
  // ．
  12539: 33093,
  // ・
  65306: 33094,
  // ：
  65307: 33095,
  // ；
  65311: 33096,
  // ？
  65281: 33097,
  // ！
  12443: 33098,
  // ゛
  12444: 33099,
  // ゜
  180: 33100,
  // ´
  65344: 33101,
  // ｀
  168: 33102,
  // ¨
  65342: 33103,
  // ＾
  65507: 33104,
  // ￣
  65343: 33105,
  // ＿
  // Brackets
  12308: 33131,
  // 〔
  12309: 33132,
  // 〕
  12304: 33133,
  // 【
  12305: 33134,
  // 】
  12298: 33137,
  // 《
  12299: 33138,
  // 》
  12300: 33141,
  // 「
  12301: 33142,
  // 」
  12302: 33143,
  // 『
  12303: 33144,
  // 』
  65288: 33129,
  // （
  65289: 33130,
  // ）
  65339: 33135,
  // ［
  65341: 33136,
  // ］
  65371: 33135,
  // ｛
  65373: 33136,
  // ｝
  // Symbols
  12291: 33110,
  // 〃
  20189: 33111,
  // 仝
  12293: 33112,
  // 々
  12294: 33113,
  // 〆
  12295: 33114,
  // 〇
  12540: 33115,
  // ー (prolonged sound mark)
  8213: 33116,
  // ―
  8208: 33117,
  // ‐
  65295: 33118,
  // ／
  65340: 33119,
  // ＼
  12316: 33120,
  // 〜
  8214: 33121,
  // ‖
  65372: 33122,
  // ｜
  8230: 33123,
  // …
  8229: 33124,
  // ‥
  8216: 33125,
  // '
  8217: 33126,
  // '
  8220: 33127,
  // "
  8221: 33128,
  // "
  // Math symbols
  65291: 33147,
  // ＋
  65293: 33148,
  // －
  177: 33149,
  // ±
  215: 33150,
  // ×
  247: 33152,
  // ÷
  65309: 33153,
  // ＝
  8800: 33154,
  // ≠
  65308: 33155,
  // ＜
  65310: 33156,
  // ＞
  8806: 33157,
  // ≦
  8807: 33158,
  // ≧
  8734: 33159,
  // ∞
  8756: 33160,
  // ∴
  // Currency and special
  65509: 33167,
  // ￥
  65284: 33168,
  // ＄
  65504: 33169,
  // ￠
  65505: 33170,
  // ￡
  65285: 33171,
  // ％
  65283: 33172,
  // ＃
  65286: 33173,
  // ＆
  65290: 33174,
  // ＊
  65312: 33175,
  // ＠
  // Arrows
  8592: 33193,
  // ←
  8593: 33194,
  // ↑
  8594: 33192,
  // →
  8595: 33195,
  // ↓
  // Greek letters (common)
  913: 33695,
  // Α
  914: 33696,
  // Β
  915: 33697,
  // Γ
  916: 33698,
  // Δ
  917: 33699,
  // Ε
  918: 33700,
  // Ζ
  919: 33701,
  // Η
  920: 33702,
  // Θ
  921: 33703,
  // Ι
  922: 33704,
  // Κ
  923: 33705,
  // Λ
  924: 33706,
  // Μ
  925: 33707,
  // Ν
  926: 33708,
  // Ξ
  927: 33709,
  // Ο
  928: 33710,
  // Π
  929: 33711,
  // Ρ
  931: 33712,
  // Σ
  932: 33713,
  // Τ
  933: 33714,
  // Υ
  934: 33715,
  // Φ
  935: 33716,
  // Χ
  936: 33717,
  // Ψ
  937: 33718,
  // Ω
  945: 33727,
  // α
  946: 33728,
  // β
  947: 33729,
  // γ
  948: 33730,
  // δ
  949: 33731,
  // ε
  950: 33732,
  // ζ
  951: 33733,
  // η
  952: 33734,
  // θ
  953: 33735,
  // ι
  954: 33736,
  // κ
  955: 33737,
  // λ
  956: 33738,
  // μ
  957: 33739,
  // ν
  958: 33740,
  // ξ
  959: 33741,
  // ο
  960: 33742,
  // π
  961: 33743,
  // ρ
  963: 33744,
  // σ
  964: 33745,
  // τ
  965: 33746,
  // υ
  966: 33747,
  // φ
  967: 33748,
  // χ
  968: 33749,
  // ψ
  969: 33750
  // ω
};
var KANJI_MAP = {
  // Numbers
  19968: 35050,
  // 一
  20108: 37873,
  // 二
  19977: 36431,
  // 三
  22235: 36460,
  // 四
  20116: 36060,
  // 五
  20845: 39002,
  // 六
  19971: 36533,
  // 七
  20843: 38058,
  // 八
  20061: 35811,
  // 九
  21313: 36700,
  // 十
  30334: 38227,
  // 百
  21315: 37095,
  // 千
  19975: 38556,
  // 万
  20740: 35245,
  // 億
  // Time/Calendar
  26085: 37882,
  // 日
  26376: 35982,
  // 月
  28779: 35278,
  // 火
  27700: 36997,
  // 水
  26408: 38616,
  // 木
  37329: 35808,
  // 金
  22303: 37753,
  // 土
  24180: 37966,
  // 年
  26178: 36510,
  // 時
  20998: 38314,
  // 分
  31186: 38242,
  // 秒
  20170: 36257,
  // 今
  26152: 36346,
  // 昨
  26126: 38590,
  // 明
  // People/Body
  20154: 36972,
  // 人
  30007: 37482,
  // 男
  22899: 36759,
  // 女
  23376: 36465,
  // 子
  27597: 38378,
  // 母
  29238: 38275,
  // 父
  21451: 38726,
  // 友
  25163: 36584,
  // 手
  36275: 37291,
  // 足
  30446: 38618,
  // 目
  32819: 36520,
  // 耳
  21475: 36091,
  // 口
  40763: 38208,
  // 鼻
  24515: 36947,
  // 心
  // Nature
  23665: 36434,
  // 山
  24029: 37100,
  // 川
  28023: 35395,
  // 海
  31354: 35827,
  // 空
  38632: 35137,
  // 雨
  39080: 38295,
  // 風
  38634: 37089,
  // 雪
  33457: 35284,
  // 花
  33609: 37264,
  // 草
  27193: 36599,
  // 樹
  26519: 38865,
  // 林
  26862: 36952,
  // 森
  // Actions
  35211: 36009,
  // 見
  32862: 38327,
  // 聞
  35328: 36030,
  // 言
  35501: 37831,
  // 読
  26360: 36753,
  // 書
  35441: 39010,
  // 話
  39135: 36936,
  // 食
  39154: 35065,
  // 飲
  36208: 37270,
  // 走
  27497: 38368,
  // 歩
  31435: 38823,
  // 立
  24231: 36288,
  // 座
  23517: 36945,
  // 寝
  36215: 35662,
  // 起
  20316: 36332,
  // 作
  20351: 36455,
  // 使
  25345: 36509,
  // 持
  21462: 36582,
  // 取
  20986: 36719,
  // 出
  20837: 37884,
  // 入
  34892: 36211,
  // 行
  26469: 38792,
  // 来
  24112: 35649,
  // 帰
  24453: 37330,
  // 待
  20250: 35311,
  // 会
  30693: 37485,
  // 知
  24605: 36470,
  // 思
  32771: 36204,
  // 考
  20449: 36941,
  // 信
  24859: 34980,
  // 愛
  // Places/Buildings
  23478: 35270,
  // 家
  24215: 37720,
  // 店
  39365: 35191,
  // 駅
  23398: 35447,
  // 学
  26657: 36186,
  // 校
  31038: 36560,
  // 社
  22269: 36241,
  // 国
  24066: 36467,
  // 市
  30010: 37548,
  // 町
  26449: 37306,
  // 村
  36947: 37817,
  // 道
  27211: 35764,
  // 橋
  // Objects
  36554: 36429,
  // 車
  38651: 37732,
  // 電
  26412: 38523,
  // 本
  26032: 36950,
  // 新
  32025: 36486,
  // 紙
  31558: 38221,
  // 筆
  37549: 37534,
  // 銭
  37347: 37347,
  // 釣
  // Adjectives
  22823: 37349,
  // 大
  23567: 36751,
  // 小
  39640: 36226,
  // 高
  20302: 37601,
  // 低
  38263: 37559,
  // 長
  30701: 37466,
  // 短
  33391: 38855,
  // 良
  24746: 34987,
  // 悪
  21476: 36035,
  // 古
  22810: 37309,
  // 多
  23569: 36781,
  // 少
  24375: 35757,
  // 強
  24369: 36579,
  // 弱
  26263: 35011,
  // 暗
  28201: 35255,
  // 温
  23506: 35494,
  // 寒
  29105: 37965,
  // 熱
  20919: 38882,
  // 冷
  // Colors
  36196: 37076,
  // 赤
  38738: 37058,
  // 青
  30333: 38034,
  // 白
  40658: 36245,
  // 黒
  32209: 38862,
  // 緑
  40644: 35241,
  // 黄
  // Position/Direction
  20013: 37510,
  // 中
  22806: 35407,
  // 外
  19978: 36835,
  // 上
  19979: 35258,
  // 下
  24038: 36278,
  // 左
  21491: 35141,
  // 右
  21069: 37199,
  // 前
  24460: 36067,
  // 後
  21271: 38523,
  // 北
  21335: 37868,
  // 南
  26481: 37772,
  // 東
  35199: 37052,
  // 西
  20869: 37856,
  // 内
  // Common abstract concepts
  29289: 38312,
  // 物
  20107: 36502,
  // 事
  32773: 36562,
  // 者
  25152: 36746,
  // 所
  26041: 38395,
  // 方
  27671: 35651,
  // 気
  21147: 38861,
  // 力
  21517: 38588,
  // 名
  27425: 36511,
  // 次
  21021: 36745,
  // 初
  26368: 36293,
  // 最
  26411: 38550,
  // 末
  20808: 37094,
  // 先
  27096: 38808,
  // 様
  24335: 36526,
  // 式
  24615: 37035,
  // 性
  21270: 35259,
  // 化
  29992: 38768,
  // 用
  24471: 37822,
  // 得
  22833: 36536,
  // 失
  21487: 35266,
  // 可
  19981: 38259,
  // 不
  28961: 38579,
  // 無
  26377: 38732,
  // 有
  20840: 37203,
  // 全
  37096: 38292,
  // 部
  21322: 38076,
  // 半
  27491: 37043,
  // 正
  35492: 36064,
  // 誤
  30495: 36958,
  // 真
  20605: 35669,
  // 偽
  22987: 36462,
  // 始
  32066: 36681,
  // 終
  32154: 37297,
  // 続
  27490: 36478,
  // 止
  21205: 37806,
  // 動
  38745: 37059,
  // 静
  22793: 38351,
  // 変
  21516: 37807,
  // 同
  21029: 38346,
  // 別
  29305: 37825,
  // 特
  26222: 38273,
  // 普
  36890: 37578,
  // 通
  20849: 35748,
  // 共
  31169: 36484,
  // 私
  20844: 36086,
  // 公
  20491: 36034,
  // 個
  22243: 37475,
  // 団
  20307: 37324,
  // 体
  32676: 35921,
  // 群
  38598: 36695,
  // 集
  21512: 36231,
  // 合
  35299: 35312,
  // 解
  32080: 35979,
  // 結
  38283: 35402,
  // 開
  38281: 38338,
  // 閉
  29983: 37046,
  // 生
  27515: 36480,
  // 死
  20581: 35986,
  // 健
  24247: 36174,
  // 康
  30149: 38241,
  // 病
  21307: 35043,
  // 医
  34220: 38642,
  // 薬
  // Question words
  20309: 35261,
  // 何
  35504: 37454
  // 誰
};
function hiraganaToShiftJIS(codePoint) {
  if (codePoint < HIRAGANA_START || codePoint > HIRAGANA_END) {
    return [63];
  }
  const offset = codePoint - HIRAGANA_START;
  let sjis = 33439 + offset;
  const lowByte = sjis & 255;
  if (lowByte >= 127) {
    sjis += 1;
  }
  return [sjis >> 8 & 255, sjis & 255];
}
function katakanaToShiftJIS(codePoint) {
  if (codePoint < KATAKANA_START || codePoint > KATAKANA_END) {
    return [63];
  }
  const offset = codePoint - KATAKANA_START;
  let sjis = 33600 + offset;
  let lowByte = sjis & 255;
  if (lowByte >= 127) {
    sjis += 1;
    lowByte = sjis & 255;
  }
  if ((sjis & 65280) === 33536 && lowByte > 158) {
    const extraOffset = lowByte - 158 - 1;
    sjis = 33856 + extraOffset;
  }
  return [sjis >> 8 & 255, sjis & 255];
}
function unicodeToShiftJIS(codePoint) {
  if (codePoint < 128) {
    return [codePoint];
  }
  if (codePoint >= HW_KATAKANA_START && codePoint <= HW_KATAKANA_END) {
    return [HW_KATAKANA_SJIS_START + (codePoint - HW_KATAKANA_START)];
  }
  if (codePoint >= HIRAGANA_START && codePoint <= HIRAGANA_END) {
    return hiraganaToShiftJIS(codePoint);
  }
  if (codePoint >= KATAKANA_START && codePoint <= KATAKANA_END) {
    return katakanaToShiftJIS(codePoint);
  }
  if (FULLWIDTH_MAP[codePoint] !== void 0) {
    const sjis = FULLWIDTH_MAP[codePoint];
    return [sjis >> 8 & 255, sjis & 255];
  }
  if (codePoint >= FULLWIDTH_ASCII_START && codePoint <= FULLWIDTH_ASCII_END) {
    const offset = codePoint - FULLWIDTH_ASCII_START;
    if (offset === 0) return [129, 73];
    if (offset >= 15 && offset <= 24) {
      return [130, 79 + (offset - 15)];
    }
    if (offset >= 32 && offset <= 57) {
      const charOffset = offset - 32;
      let lowByte = 96 + charOffset;
      if (lowByte >= 127) lowByte += 1;
      return [130, lowByte];
    }
    if (offset >= 64 && offset <= 89) {
      const charOffset = offset - 64;
      const lowByte = 129 + charOffset;
      return [130, lowByte];
    }
  }
  if (KANJI_MAP[codePoint] !== void 0) {
    const sjis = KANJI_MAP[codePoint];
    return [sjis >> 8 & 255, sjis & 255];
  }
  return [63];
}
function createShiftJISEncoder() {
  return (s) => {
    const bytes = [];
    for (let i = 0; i < s.length; i++) {
      const codePoint = s.codePointAt(i);
      if (codePoint === void 0) continue;
      if (codePoint > 65535) {
        i++;
        bytes.push(63);
        continue;
      }
      const sjisBytes = unicodeToShiftJIS(codePoint);
      bytes.push(...sjisBytes);
    }
    return bytes;
  };
}

// src/modules/qr-encoder/index.ts
var _log52 = createLogger("ENCODER");

// src/modules/qr-generator/dithering-blue.ts
var _log53 = createLogger("GENERATE");
var BLUE_NOISE_TILE_SIZE = 64;
var BLUE_NOISE_64 = generateBlueNoiseTile(BLUE_NOISE_TILE_SIZE, 0);

// src/modules/qr-generator/drawing-primitives.ts
var _log54 = createLogger("GENERATE");
function roundRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  ctx.fill();
}
function drawModule(ctx, x, y, size, style = "square", options = {}) {
  const { cornerRadius = 0, rotation = 0 } = options;
  ctx.save();
  if (rotation !== 0) {
    const centerX = x + size / 2;
    const centerY = y + size / 2;
    ctx.translate(centerX, centerY);
    ctx.rotate(rotation * Math.PI / 180);
    ctx.translate(-centerX, -centerY);
  }
  switch (style) {
    case "rounded": {
      const radius = cornerRadius / 100 * (size / 2);
      roundRect(ctx, x, y, size, size, radius);
      break;
    }
    case "dots": {
      const radius = size * 0.4;
      ctx.beginPath();
      ctx.arc(x + size / 2, y + size / 2, radius, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "diamond": {
      const half = size / 2;
      ctx.beginPath();
      ctx.moveTo(x + half, y);
      ctx.lineTo(x + size, y + half);
      ctx.lineTo(x + half, y + size);
      ctx.lineTo(x, y + half);
      ctx.closePath();
      ctx.fill();
      break;
    }
    case "star": {
      const cx = x + size / 2;
      const cy = y + size / 2;
      const outerRadius = size * 0.45;
      const innerRadius = size * 0.2;
      const points = 5;
      ctx.beginPath();
      for (let i = 0; i < points * 2; i++) {
        const radius = i % 2 === 0 ? outerRadius : innerRadius;
        const angle = i * Math.PI / points - Math.PI / 2;
        const px = cx + radius * Math.cos(angle);
        const py = cy + radius * Math.sin(angle);
        if (i === 0) {
          ctx.moveTo(px, py);
        } else {
          ctx.lineTo(px, py);
        }
      }
      ctx.closePath();
      ctx.fill();
      break;
    }
    case "heart": {
      const cx = x + size / 2;
      const cy = y + size / 2;
      const s = size * 0.3;
      ctx.beginPath();
      ctx.moveTo(cx, cy + s * 0.8);
      ctx.bezierCurveTo(cx - s * 1.5, cy - s * 0.5, cx - s * 0.5, cy - s * 1.5, cx, cy - s * 0.5);
      ctx.bezierCurveTo(cx + s * 0.5, cy - s * 1.5, cx + s * 1.5, cy - s * 0.5, cx, cy + s * 0.8);
      ctx.fill();
      break;
    }
    default:
      ctx.fillRect(x, y, size, size);
      break;
  }
  ctx.restore();
}

// src/modules/qr-generator/drawing-frames.ts
var _log55 = createLogger("GENERATE");
function drawFrameBackground(ctx, size, _moduleSize, _margin, config) {
  if (!config.frameStyle || config.frameStyle === "none") return;
  const frameColor = config.frameColor || config.bgColor;
  const defaultRadius = config.frameStyle === "sticker" ? 12 : config.frameStyle === "tag" ? 4 : 0;
  const borderRadius = config.frameBorderRadius ?? defaultRadius;
  ctx.fillStyle = frameColor;
  if (borderRadius > 0) {
    const radius = borderRadius / 100 * (size / 4);
    roundRect(ctx, 0, 0, size, size, radius);
  } else {
    ctx.fillRect(0, 0, size, size);
  }
}
function drawFrame(ctx, size, moduleSize, _margin, config) {
  if (!config.frameStyle || config.frameStyle === "none") return;
  const fgColor = config.fgColor || "#000000";
  const defaultRadius = config.frameStyle === "sticker" ? 12 : config.frameStyle === "tag" ? 4 : 0;
  const borderRadius = config.frameBorderRadius ?? defaultRadius;
  const lineWidth = Math.max(1, Math.round(size / 200));
  const inset = lineWidth / 2;
  ctx.strokeStyle = fgColor;
  ctx.lineWidth = lineWidth;
  if (borderRadius > 0) {
    const radius = borderRadius / 100 * (size / 4);
    const r = Math.min(radius, (size - inset * 2) / 2);
    ctx.beginPath();
    ctx.moveTo(inset + r, inset);
    ctx.lineTo(size - inset - r, inset);
    ctx.quadraticCurveTo(size - inset, inset, size - inset, inset + r);
    ctx.lineTo(size - inset, size - inset - r);
    ctx.quadraticCurveTo(size - inset, size - inset, size - inset - r, size - inset);
    ctx.lineTo(inset + r, size - inset);
    ctx.quadraticCurveTo(inset, size - inset, inset, size - inset - r);
    ctx.lineTo(inset, inset + r);
    ctx.quadraticCurveTo(inset, inset, inset + r, inset);
    ctx.closePath();
    ctx.stroke();
  } else {
    ctx.strokeRect(inset, inset, size - inset * 2, size - inset * 2);
  }
  if (!config.frameText) return;
  const textColor = config.frameTextColor || config.fgColor;
  const frameHeight = moduleSize * 4;
  const textY = size - frameHeight / 2;
  ctx.fillStyle = textColor;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const fontSize = Math.max(12, frameHeight * 0.5);
  ctx.font = `${fontSize}px sans-serif`;
  ctx.fillText(config.frameText, size / 2, textY);
}
function drawCenterLogo(ctx, logoCanvas, canvasSize, logoSizePercent = 20) {
  const logoSize = canvasSize * logoSizePercent / 100;
  const logoX = (canvasSize - logoSize) / 2;
  const logoY = (canvasSize - logoSize) / 2;
  ctx.drawImage(logoCanvas, logoX, logoY, logoSize, logoSize);
}

// src/modules/qr-generator/drawing-gradients.ts
var _log56 = createLogger("GENERATE");
function createGradientFill(ctx, config, size) {
  if (!config.gradient || config.gradient.type === "none") {
    return null;
  }
  const { type, angle = 0, stops: configStops = [] } = config.gradient;
  const stops = configStops.length > 0 ? configStops : [
    { pos: 0, color: config.fgColor || "#000000" },
    { pos: 1, color: config.bgColor || "#ffffff" }
  ];
  let gradient;
  switch (type) {
    case "linear": {
      const rad = angle * Math.PI / 180;
      const x1 = size / 2 - Math.cos(rad) * size / 2;
      const y1 = size / 2 - Math.sin(rad) * size / 2;
      const x2 = size / 2 + Math.cos(rad) * size / 2;
      const y2 = size / 2 + Math.sin(rad) * size / 2;
      gradient = ctx.createLinearGradient(x1, y1, x2, y2);
      break;
    }
    case "radial": {
      const centerX = size / 2;
      const centerY = size / 2;
      const radius = size / 2;
      gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
      break;
    }
    case "conic": {
      const centerX = size / 2;
      const centerY = size / 2;
      const radius = size / 2;
      gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
      break;
    }
    default:
      return null;
  }
  for (const stop of stops) {
    gradient.addColorStop(stop.pos, stop.color);
  }
  return gradient;
}

// src/modules/qr-generator/drawing-halftone.ts
var _log57 = createLogger("GENERATE");
function parseHalftoneCell(cellConfig) {
  if (cellConfig === void 0 || cellConfig === "per_module") return 1;
  if (typeof cellConfig === "number") return Math.max(1, Math.round(cellConfig));
  const match = String(cellConfig).match(/^(\d+)[x×](\d+)$/i);
  if (match) {
    return Math.max(1, parseInt(match[1], 10));
  }
  return 1;
}
function drawHalftoneDot(ctx, cx, cy, dotSize, shape, row, col) {
  const halfSize = dotSize / 2;
  switch (shape) {
    case "square":
      ctx.fillRect(cx - halfSize, cy - halfSize, dotSize, dotSize);
      break;
    case "line": {
      ctx.save();
      ctx.translate(cx, cy);
      const angle = (row + col) % 2 === 0 ? Math.PI / 4 : -Math.PI / 4;
      ctx.rotate(angle);
      const lineWidth = dotSize * 0.35;
      const lineLength = dotSize * 1.2;
      ctx.fillRect(-lineLength / 2, -lineWidth / 2, lineLength, lineWidth);
      ctx.restore();
      break;
    }
    default:
      ctx.beginPath();
      ctx.arc(cx, cy, halfSize, 0, Math.PI * 2);
      ctx.fill();
      break;
  }
}
function drawHalftoneModule(ctx, x, y, size, brightness2, config, moduleRow = 0, moduleCol = 0) {
  const htDot = config.htDot ?? 0.8;
  const htCurve = config.htCurve ?? 1;
  const gridSize = parseHalftoneCell(config.halftoneCell ?? config.htCell);
  const dotShape = config.halftoneDotShape || "circle";
  const adjustedBrightness = (1 - brightness2) ** htCurve;
  if (gridSize <= 1) {
    const minSize = size * 0.1;
    const maxSize = size * htDot;
    const dotSize = minSize + adjustedBrightness * (maxSize - minSize);
    const cx = x + size / 2;
    const cy = y + size / 2;
    drawHalftoneDot(ctx, cx, cy, dotSize, dotShape, moduleRow, moduleCol);
  } else {
    const cellSize = size / gridSize;
    const maxDotSize = cellSize * htDot;
    const minDotSize = cellSize * 0.1;
    const dotSize = minDotSize + adjustedBrightness * (maxDotSize - minDotSize);
    for (let row = 0; row < gridSize; row++) {
      for (let col = 0; col < gridSize; col++) {
        const cx = x + (col + 0.5) * cellSize;
        const cy = y + (row + 0.5) * cellSize;
        drawHalftoneDot(
          ctx,
          cx,
          cy,
          dotSize,
          dotShape,
          moduleRow * gridSize + row,
          moduleCol * gridSize + col
        );
      }
    }
  }
}

// src/modules/qr-generator/drawing-patterns.ts
var _log58 = createLogger("GENERATE");
function drawFinderPatternComplete(ctx, x, y, moduleSize, config) {
  const outerStyle = config.eyeOuterStyle || config.finderStyle || "square";
  const innerStyle = config.eyeInnerStyle || config.finderStyle || "square";
  const eyeScale = (config.eyeScale ?? 100) / 100;
  const fgColor = validateColor(config.fgColor, "#000000");
  const bgColor = validateColor(config.bgColor, "#ffffff");
  const outerSize = 7 * moduleSize;
  const middleSize = 5 * moduleSize;
  const innerSize = 3 * moduleSize;
  const scaledOuterSize = outerSize * eyeScale;
  const scaledMiddleSize = middleSize * eyeScale;
  const scaledInnerSize = innerSize * eyeScale;
  const outerOffset = (outerSize - scaledOuterSize) / 2;
  const _middleOffset = moduleSize + (outerSize - scaledOuterSize) / 2;
  const _innerOffset = 2 * moduleSize + (outerSize - scaledOuterSize) / 2;
  ctx.fillStyle = fgColor;
  drawFinderRing(ctx, x + outerOffset, y + outerOffset, scaledOuterSize, outerStyle);
  ctx.fillStyle = bgColor;
  const middleRingSize = scaledMiddleSize;
  const middleRingOffset = (scaledOuterSize - middleRingSize) / 2;
  drawFinderRing(
    ctx,
    x + outerOffset + middleRingOffset,
    y + outerOffset + middleRingOffset,
    middleRingSize,
    outerStyle
  );
  ctx.fillStyle = fgColor;
  const innerDotSize = scaledInnerSize;
  const innerDotOffset = (scaledOuterSize - innerDotSize) / 2;
  drawFinderRing(
    ctx,
    x + outerOffset + innerDotOffset,
    y + outerOffset + innerDotOffset,
    innerDotSize,
    innerStyle
  );
}
function drawFinderRing(ctx, x, y, size, style) {
  switch (style) {
    case "rounded": {
      const radius = size * 0.2;
      roundRect(ctx, x, y, size, size, radius);
      break;
    }
    case "circle": {
      ctx.beginPath();
      ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    default:
      ctx.fillRect(x, y, size, size);
      break;
  }
}
function drawAlignmentPattern(ctx, centerX, centerY, moduleSize, style, config) {
  const fgColor = validateColor(config.fgColor, "#000000");
  const bgColor = validateColor(config.bgColor, "#ffffff");
  const outerSize = 5 * moduleSize;
  const middleSize = 3 * moduleSize;
  const innerSize = 1 * moduleSize;
  const effectiveStyle = style === "match_finder" ? config.finderStyle || "square" : style;
  ctx.fillStyle = fgColor;
  drawAlignmentRing(
    ctx,
    centerX - outerSize / 2,
    centerY - outerSize / 2,
    outerSize,
    effectiveStyle
  );
  ctx.fillStyle = bgColor;
  drawAlignmentRing(
    ctx,
    centerX - middleSize / 2,
    centerY - middleSize / 2,
    middleSize,
    effectiveStyle
  );
  ctx.fillStyle = fgColor;
  drawAlignmentRing(
    ctx,
    centerX - innerSize / 2,
    centerY - innerSize / 2,
    innerSize,
    effectiveStyle
  );
}
function drawAlignmentRing(ctx, x, y, size, style) {
  switch (style) {
    case "rounded": {
      const radius = size * 0.15;
      roundRect(ctx, x, y, size, size, radius);
      break;
    }
    case "circle": {
      ctx.beginPath();
      ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    default:
      ctx.fillRect(x, y, size, size);
      break;
  }
}
function drawTimingModule(ctx, x, y, size, style, config) {
  if (style === "match_module") {
    drawModule(ctx, x, y, size, config.moduleStyle || "square", {
      cornerRadius: config.cornerRadius || 0
    });
  } else if (style === "dashed") {
    const dashSize = size * 0.7;
    const offset = (size - dashSize) / 2;
    ctx.fillRect(x + offset, y + offset, dashSize, dashSize);
  } else {
    ctx.fillRect(x, y, size, size);
  }
}

// src/modules/qr-generator/drawing.ts
var _log59 = createLogger("GENERATE");

// src/modules/qr-generator/ecc.ts
var _log60 = createLogger("GENERATE");

// src/modules/overlay/crop-handler.ts
var _log61 = createLogger("OVERLAY");

// src/modules/overlay/overlay-filters.ts
var log7 = createLogger("OVERLAY");
function copyImageData(imageData) {
  return new ImageData(new Uint8ClampedArray(imageData.data), imageData.width, imageData.height);
}
function brightness(imageData, amount) {
  const data = imageData.data;
  const factor = amount / 100;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.max(0, Math.min(255, Math.round(data[i] + 255 * factor)));
    data[i + 1] = Math.max(0, Math.min(255, Math.round(data[i + 1] + 255 * factor)));
    data[i + 2] = Math.max(0, Math.min(255, Math.round(data[i + 2] + 255 * factor)));
  }
  return imageData;
}
function contrast(imageData, amount) {
  const data = imageData.data;
  const factor = 259 * (amount + 255) / (255 * (259 - amount));
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.max(0, Math.min(255, Math.round(factor * (data[i] - 128) + 128)));
    data[i + 1] = Math.max(0, Math.min(255, Math.round(factor * (data[i + 1] - 128) + 128)));
    data[i + 2] = Math.max(0, Math.min(255, Math.round(factor * (data[i + 2] - 128) + 128)));
  }
  return imageData;
}
function saturation(imageData, amount) {
  const data = imageData.data;
  const factor = amount / 100;
  for (let i = 0; i < data.length; i += 4) {
    const gray = rgbToGray(data[i], data[i + 1], data[i + 2]);
    data[i] = Math.max(0, Math.min(255, Math.round(gray + factor * (data[i] - gray))));
    data[i + 1] = Math.max(0, Math.min(255, Math.round(gray + factor * (data[i + 1] - gray))));
    data[i + 2] = Math.max(0, Math.min(255, Math.round(gray + factor * (data[i + 2] - gray))));
  }
  return imageData;
}
function hueRotate(imageData, degrees) {
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const hsl = rgbToHsl(data[i], data[i + 1], data[i + 2]);
    hsl.h = (hsl.h + degrees) % 360;
    if (hsl.h < 0) hsl.h += 360;
    const rgb = hslToRgb(hsl.h, hsl.s, hsl.l);
    data[i] = rgb.r;
    data[i + 1] = rgb.g;
    data[i + 2] = rgb.b;
  }
  return imageData;
}
function gamma(imageData, value) {
  const data = imageData.data;
  const invGamma = 1 / value;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.round(255 * (data[i] / 255) ** invGamma);
    data[i + 1] = Math.round(255 * (data[i + 1] / 255) ** invGamma);
    data[i + 2] = Math.round(255 * (data[i + 2] / 255) ** invGamma);
  }
  return imageData;
}
function invert(imageData) {
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = 255 - data[i];
    data[i + 1] = 255 - data[i + 1];
    data[i + 2] = 255 - data[i + 2];
  }
  return imageData;
}
function grayscale(imageData) {
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const gray = Math.round(rgbToGray(data[i], data[i + 1], data[i + 2]));
    data[i] = gray;
    data[i + 1] = gray;
    data[i + 2] = gray;
  }
  return imageData;
}
function threshold(imageData, level) {
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const gray = rgbToGray(data[i], data[i + 1], data[i + 2]);
    const value = gray > level ? 255 : 0;
    data[i] = value;
    data[i + 1] = value;
    data[i + 2] = value;
  }
  return imageData;
}
function posterize(imageData, levels) {
  const data = imageData.data;
  const step = 255 / (levels - 1);
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.round(Math.round(data[i] / step) * step);
    data[i + 1] = Math.round(Math.round(data[i + 1] / step) * step);
    data[i + 2] = Math.round(Math.round(data[i + 2] / step) * step);
  }
  return imageData;
}
function duotone(imageData, lightColor, darkColor) {
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const gray = rgbToGray(data[i], data[i + 1], data[i + 2]) / 255;
    data[i] = Math.round(darkColor.r * (1 - gray) + lightColor.r * gray);
    data[i + 1] = Math.round(darkColor.g * (1 - gray) + lightColor.g * gray);
    data[i + 2] = Math.round(darkColor.b * (1 - gray) + lightColor.b * gray);
  }
  return imageData;
}
function convolve(imageData, kernel, divisor) {
  const data = imageData.data;
  const width = imageData.width;
  const height = imageData.height;
  const result = new Uint8ClampedArray(data);
  const kSize = kernel.length;
  const kHalf = Math.floor(kSize / 2);
  const div = divisor ?? (kernel.flat().reduce((a, b) => a + b, 0) || 1);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let r = 0, g = 0, b = 0;
      for (let ky = 0; ky < kSize; ky++) {
        for (let kx = 0; kx < kSize; kx++) {
          const px = Math.max(0, Math.min(width - 1, x + kx - kHalf));
          const py = Math.max(0, Math.min(height - 1, y + ky - kHalf));
          const idx2 = (py * width + px) * 4;
          const weight = kernel[ky][kx];
          r += data[idx2] * weight;
          g += data[idx2 + 1] * weight;
          b += data[idx2 + 2] * weight;
        }
      }
      const idx = (y * width + x) * 4;
      result[idx] = Math.max(0, Math.min(255, Math.round(r / div)));
      result[idx + 1] = Math.max(0, Math.min(255, Math.round(g / div)));
      result[idx + 2] = Math.max(0, Math.min(255, Math.round(b / div)));
    }
  }
  imageData.data.set(result);
  return imageData;
}
function sharpen(imageData, amount = 1) {
  const kernel = [
    [0, -amount, 0],
    [-amount, 1 + 4 * amount, -amount],
    [0, -amount, 0]
  ];
  return convolve(imageData, kernel, 1);
}
function blur(imageData, radius = 1) {
  const size = 2 * radius + 1;
  const kernel = Array(size).fill(null).map(() => Array(size).fill(1));
  return convolve(imageData, kernel);
}
function gaussianBlur(imageData, radius = 1) {
  const kernel = [
    [1, 2, 1],
    [2, 4, 2],
    [1, 2, 1]
  ];
  let result = imageData;
  for (let i = 0; i < radius; i++) {
    result = convolve(result, kernel);
  }
  return result;
}
function sobelEdge(imageData) {
  const data = imageData.data;
  const width = imageData.width;
  const height = imageData.height;
  const result = new Uint8ClampedArray(data.length);
  const sobelX = [
    [-1, 0, 1],
    [-2, 0, 2],
    [-1, 0, 1]
  ];
  const sobelY = [
    [-1, -2, -1],
    [0, 0, 0],
    [1, 2, 1]
  ];
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      let gx = 0, gy = 0;
      for (let ky = -1; ky <= 1; ky++) {
        for (let kx = -1; kx <= 1; kx++) {
          const idx2 = ((y + ky) * width + (x + kx)) * 4;
          const gray = rgbToGray(data[idx2], data[idx2 + 1], data[idx2 + 2]);
          gx += gray * sobelX[ky + 1][kx + 1];
          gy += gray * sobelY[ky + 1][kx + 1];
        }
      }
      const magnitude = Math.min(255, Math.sqrt(gx * gx + gy * gy));
      const idx = (y * width + x) * 4;
      result[idx] = magnitude;
      result[idx + 1] = magnitude;
      result[idx + 2] = magnitude;
      result[idx + 3] = data[idx + 3];
    }
  }
  imageData.data.set(result);
  return imageData;
}
function cannyEdge(imageData, lowThreshold = 50, highThreshold = 150) {
  const sobelResult = sobelEdge(copyImageData(imageData));
  const data = sobelResult.data;
  for (let i = 0; i < data.length; i += 4) {
    const magnitude = data[i];
    const value = magnitude > highThreshold ? 255 : magnitude > lowThreshold ? 128 : 0;
    data[i] = value;
    data[i + 1] = value;
    data[i + 2] = value;
  }
  imageData.data.set(data);
  return imageData;
}
function applyColorMode(imageData, mode) {
  if (mode === "color") return imageData;
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const gray = Math.round(rgbToGray(data[i], data[i + 1], data[i + 2]));
    if (mode === "bw") {
      const value = gray > 128 ? 255 : 0;
      data[i] = value;
      data[i + 1] = value;
      data[i + 2] = value;
    } else {
      data[i] = gray;
      data[i + 1] = gray;
      data[i + 2] = gray;
    }
  }
  return imageData;
}
function applyFilters(imageData, options) {
  let result = copyImageData(imageData);
  log7.trace("applyFilters called", {
    brightness: options.brightness,
    contrast: options.contrast,
    saturation: options.saturation,
    hue: options.hue,
    gamma: options.gamma,
    invert: options.invert,
    grayscale: options.grayscale,
    threshold: options.threshold,
    posterize: options.posterize,
    sharpen: options.sharpen,
    blur: options.blur,
    colorMode: options.colorMode,
    hasDuotone: !!options.duotone
  });
  if (options.brightness !== void 0 && options.brightness !== 0) {
    log7.trace("Applying brightness", { value: options.brightness });
    result = brightness(result, options.brightness);
  }
  if (options.contrast !== void 0 && options.contrast !== 0) {
    log7.trace("Applying contrast", { value: options.contrast });
    result = contrast(result, options.contrast);
  }
  if (options.saturation !== void 0 && options.saturation !== 100) {
    log7.trace("Applying saturation", { value: options.saturation });
    result = saturation(result, options.saturation);
  }
  if (options.hue !== void 0 && options.hue !== 0) {
    log7.trace("Applying hue rotation", { value: options.hue });
    result = hueRotate(result, options.hue);
  }
  if (options.gamma !== void 0 && options.gamma !== 1) {
    log7.trace("Applying gamma", { value: options.gamma });
    result = gamma(result, options.gamma);
  }
  if (options.invert) {
    log7.trace("Applying INVERT - this will flip perceived brightness");
    result = invert(result);
  }
  if (options.grayscale) {
    log7.trace("Applying grayscale");
    result = grayscale(result);
  }
  if (options.threshold !== void 0) {
    log7.trace("Applying threshold", { value: options.threshold });
    result = threshold(result, options.threshold);
  }
  if (options.posterize !== void 0 && options.posterize > 0) {
    log7.trace("Applying posterize", { value: options.posterize });
    result = posterize(result, options.posterize);
  }
  if (options.sharpen !== void 0 && options.sharpen > 0) {
    log7.trace("Applying sharpen", { value: options.sharpen });
    result = sharpen(result, options.sharpen);
  }
  if (options.blur !== void 0 && options.blur > 0) {
    log7.trace("Applying blur", { value: options.blur });
    result = blur(result, options.blur);
  }
  if (options.duotone) {
    log7.trace("Applying duotone");
    result = duotone(result, options.duotone.light, options.duotone.dark);
  }
  if (options.colorMode) {
    log7.trace("Applying colorMode", { mode: options.colorMode });
    result = applyColorMode(result, options.colorMode);
  }
  log7.trace("Filter pipeline complete");
  return result;
}

// src/modules/overlay/processor.ts
var _log62 = createLogger("OVERLAY");

// src/modules/overlay/watermark.ts
var _log63 = createLogger("WATERMARK");

// src/modules/overlay/index.ts
var _log64 = createLogger("OVERLAY");

// src/modules/qr-generator/filters-edge.ts
var _log65 = createLogger("GENERATE");

// src/modules/qr-generator/filters-preprocess.ts
var log8 = createLogger("GENERATE");
function detectBimodalBW(imageData) {
  const data = imageData.data;
  const totalPixels = data.length / 4;
  const histogram = new Int32Array(HISTOGRAM_BUCKETS);
  for (let i = 0; i < data.length; i += 4) {
    const gray = rgbToGray(data[i], data[i + 1], data[i + 2]);
    const bucket = Math.min(HISTOGRAM_BUCKETS - 1, gray >> BUCKET_SHIFT);
    histogram[bucket]++;
  }
  let darkPeak = 0;
  let darkPeakBucket = 0;
  for (let i = 0; i < DARK_REGION_END; i++) {
    if (histogram[i] > darkPeak) {
      darkPeak = histogram[i];
      darkPeakBucket = i;
    }
  }
  let lightPeak = 0;
  let lightPeakBucket = 0;
  for (let i = LIGHT_REGION_START; i < HISTOGRAM_BUCKETS; i++) {
    if (histogram[i] > lightPeak) {
      lightPeak = histogram[i];
      lightPeakBucket = i;
    }
  }
  if (lightPeakBucket - darkPeakBucket < MIN_PEAK_SEPARATION) {
    return false;
  }
  let darkRegionCount = 0;
  for (let i = 0; i < DARK_REGION_END; i++) {
    darkRegionCount += histogram[i];
  }
  let lightRegionCount = 0;
  for (let i = LIGHT_REGION_START; i < HISTOGRAM_BUCKETS; i++) {
    lightRegionCount += histogram[i];
  }
  let valleyCount = 0;
  for (let i = DARK_REGION_END; i < LIGHT_REGION_START; i++) {
    valleyCount += histogram[i];
  }
  const darkRatio = darkRegionCount / totalPixels;
  const lightRatio = lightRegionCount / totalPixels;
  const valleyRatio = valleyCount / totalPixels;
  const isBimodal = darkRatio >= MIN_PEAK_RATIO && lightRatio >= MIN_PEAK_RATIO && valleyRatio < MAX_VALLEY_RATIO;
  if (isBimodal) {
    log8.debug("Detected bimodal B&W image", {
      darkRatio: darkRatio.toFixed(3),
      lightRatio: lightRatio.toFixed(3),
      valleyRatio: valleyRatio.toFixed(3),
      darkPeakBucket,
      lightPeakBucket
    });
  }
  return isBimodal;
}
function softenBWImage(imageData) {
  log8.debug("Softening B&W image for better dithering");
  let result = copyImageData(imageData);
  result = gaussianBlur(result, 3);
  result = gamma(result, 0.65);
  return result;
}
function preprocessImageData(imageData, config, debug = false) {
  const filterOptions = {};
  if (config.filterBrightness !== void 0 && config.filterBrightness !== 0) {
    filterOptions.brightness = config.filterBrightness;
  }
  if (config.filterContrast !== void 0 && config.filterContrast !== 0) {
    filterOptions.contrast = config.filterContrast;
  }
  if (config.filterSaturation !== void 0 && config.filterSaturation !== 0) {
    filterOptions.saturation = config.filterSaturation + 100;
  }
  if (config.filterHue !== void 0 && config.filterHue !== 0) {
    filterOptions.hue = config.filterHue;
  }
  if (config.filterGamma !== void 0 && config.filterGamma !== 1) {
    filterOptions.gamma = config.filterGamma;
  }
  if (config.filterInvert) {
    filterOptions.invert = true;
  }
  if (config.filterGrayscale) {
    filterOptions.grayscale = true;
  }
  if (config.filterThreshold !== void 0 && config.filterThreshold > 0) {
    filterOptions.threshold = config.filterThreshold;
  }
  if (config.filterBlur !== void 0 && config.filterBlur > 0) {
    filterOptions.blur = config.filterBlur;
  }
  if (config.filterSharpen !== void 0 && config.filterSharpen > 0) {
    filterOptions.sharpen = config.filterSharpen;
  }
  if (config.filterPosterize !== void 0 && config.filterPosterize > 0) {
    filterOptions.posterize = config.filterPosterize;
  }
  if (config.overlayMode === "duotone" && config.filterDuotone1 && config.filterDuotone2 && config.colorMode !== "color") {
    const lightRgb = parseColor(config.filterDuotone1);
    const darkRgb = parseColor(config.filterDuotone2);
    if (lightRgb && darkRgb) {
      filterOptions.duotone = { light: lightRgb, dark: darkRgb };
    }
  }
  if (config.colorMode) {
    if (config.colorMode === "color") {
      filterOptions.grayscale = false;
    } else {
      filterOptions.colorMode = config.colorMode;
      filterOptions.grayscale = false;
    }
  }
  if (debug) {
    log8.debug("preprocessImageData - filter options", {
      brightness: filterOptions.brightness,
      contrast: filterOptions.contrast,
      saturation: filterOptions.saturation,
      hue: filterOptions.hue,
      gamma: filterOptions.gamma,
      invert: filterOptions.invert,
      grayscale: filterOptions.grayscale,
      threshold: filterOptions.threshold,
      blur: filterOptions.blur,
      sharpen: filterOptions.sharpen,
      posterize: filterOptions.posterize,
      colorMode: filterOptions.colorMode,
      hasDuotone: !!filterOptions.duotone,
      configColorMode: config.colorMode
    });
  }
  let workingData = copyImageData(imageData);
  if (!(config.disableAutoSoften || config.qrFirstMode)) {
    if (detectBimodalBW(workingData)) {
      if (debug) {
        log8.debug("preprocessImageData - detected high-contrast B&W, applying softening");
      }
      workingData = softenBWImage(workingData);
    }
  }
  if (Object.keys(filterOptions).length === 0) {
    if (debug) {
      log8.debug("preprocessImageData - no additional filters to apply");
    }
    return workingData;
  }
  if (debug) {
    log8.debug("preprocessImageData - applying filters");
  }
  let out = applyFilters(workingData, filterOptions);
  if (config.filterEdgeDetect) {
    const mode = (config.filterEdgeMode || "sobel").toLowerCase();
    if (debug) {
      log8.debug("preprocessImageData - applying edge detection", { mode });
    }
    out = mode === "canny" ? cannyEdge(out) : sobelEdge(out);
  }
  if (debug) {
    log8.debug("preprocessImageData - complete");
  }
  return out;
}

// src/modules/qr-generator/filters.ts
var _log66 = createLogger("GENERATE");

// src/modules/qr-generator/overlay-data.ts
var _log67 = createLogger("GENERATE");
async function getOverlayData(overlayCanvas, moduleCount, config, createCanvasFn) {
  if (!overlayCanvas) {
    return {};
  }
  const canvasHash = await hashCanvasContent(overlayCanvas, createCanvasFn);
  const cacheKey = `${canvasHash}:${moduleCount}:${config.overlayIntensity}:${config.colorMode}`;
  const cached = overlayDataCache.get(cacheKey);
  if (cached) {
    return cached;
  }
  const scaledCanvas = await createCanvasFn(moduleCount, moduleCount);
  const ctx = scaledCanvas.getContext("2d");
  if (!ctx) {
    return {};
  }
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(overlayCanvas, 0, 0, moduleCount, moduleCount);
  const imageData = ctx.getImageData(0, 0, moduleCount, moduleCount);
  const data = imageData.data;
  const result = {};
  const includeColors = config.colorMode !== "bw";
  if (includeColors) {
    result.colors = {};
  }
  for (let row = 0; row < moduleCount; row++) {
    result[row] = {};
    if (includeColors) {
      if (!result.colors) result.colors = {};
      result.colors[row] = {};
    }
    for (let col = 0; col < moduleCount; col++) {
      const idx = (row * moduleCount + col) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const brightness2 = rgbToGray(r, g, b) / 255;
      result[row][col] = brightness2;
      if (includeColors && result.colors) {
        result.colors[row][col] = { r, g, b };
      }
    }
  }
  overlayDataCache.set(cacheKey, result);
  return result;
}

// src/modules/qr-generator/overlay-subpixel.ts
var log9 = createLogger("GENERATE");
function parseGridSize(gridSize) {
  if (!gridSize) return 3;
  const match = gridSize.match(/^(\d+)x\d+$/);
  if (match) {
    return parseInt(match[1], 10);
  }
  return 3;
}
function parseHexColor(hex) {
  if (!hex) return null;
  const match = hex.match(/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i);
  if (match) {
    return {
      r: parseInt(match[1], 16),
      g: parseInt(match[2], 16),
      b: parseInt(match[3], 16)
    };
  }
  return null;
}
function isFinderSeparator2(row, col, moduleCount) {
  return row === 7 && col <= 7 || col === 7 && row <= 7 || row === 7 && col >= moduleCount - 8 || col === moduleCount - 8 && row <= 7 || row === moduleCount - 8 && col <= 7 || col === 7 && row >= moduleCount - 8;
}
function shouldLockModule2(row, col, moduleCount, version, config) {
  const preserveFunctional = config.preserveFunctionalPatterns === true;
  const preserveFinders = config.preserveFinders !== false;
  const preserveTiming = preserveFunctional ? config.preserveTiming !== false : config.preserveTiming === true;
  const preserveAlignment = preserveFunctional ? config.preserveAlignment !== false : config.preserveAlignment === true;
  const protectFormat = preserveFunctional ? config.protectFormatInfo !== false : config.protectFormatInfo === true;
  const protectVersion = preserveFunctional ? config.protectVersionInfo !== false : config.protectVersionInfo === true;
  const preserveFixedDark = preserveFunctional;
  if (row === moduleCount - 8 && col === 8) return preserveFixedDark;
  if (isFinderPattern(row, col, moduleCount) || isFinderSeparator2(row, col, moduleCount)) {
    return preserveFinders;
  }
  if (isTimingPattern(row, col, moduleCount)) return preserveTiming;
  if (isAlignmentPattern(row, col, moduleCount, version)) return preserveAlignment;
  if (isFormatInfo(row, col, moduleCount)) return protectFormat;
  if (isVersionInfo(row, col, moduleCount, version)) return protectVersion;
  return false;
}
async function getSubpixelOverlayData(overlayCanvas, moduleCount, scale, _config, createCanvasFn) {
  const scaledSize = moduleCount * scale;
  const scaledCanvas = await createCanvasFn(scaledSize, scaledSize);
  const ctx = scaledCanvas.getContext("2d");
  if (!ctx) {
    return { brightness: [], colors: [] };
  }
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(overlayCanvas, 0, 0, scaledSize, scaledSize);
  const imageData = ctx.getImageData(0, 0, scaledSize, scaledSize);
  const data = imageData.data;
  const brightness2 = [];
  const colors = [];
  for (let y = 0; y < scaledSize; y++) {
    brightness2[y] = [];
    colors[y] = [];
    for (let x = 0; x < scaledSize; x++) {
      const idx = (y * scaledSize + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      brightness2[y][x] = rgbToGray(r, g, b) / 255;
      colors[y][x] = { r, g, b };
    }
  }
  return { brightness: brightness2, colors };
}
async function generateSubpixelMatrix(qr, config, overlayCanvas, moduleCount, scale, useHalftoneCenter, createCanvasFn) {
  const gridScale = parseGridSize(config.subpixelGridSize) || scale;
  const actualScale = gridScale;
  const scaledSize = moduleCount * actualScale;
  const intensity = (config.overlayIntensity ?? 100) / 100;
  const { brightness: brightness2, colors } = await getSubpixelOverlayData(
    overlayCanvas,
    moduleCount,
    actualScale,
    config,
    createCanvasFn
  );
  const matrix = [];
  const colorMatrix = [];
  const centerIdx = Math.floor(actualScale / 2);
  const neutralColor = parseHexColor(config.subpixelNeutralColor);
  const centerRule = config.subpixelCenterRule || "strict";
  const useHalftone = centerRule === "halftone_center" || useHalftoneCenter;
  const finderOverride = config.subpixelFinderOverride || "solid";
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  log9.debug("Subpixel matrix generation", {
    gridScale,
    actualScale,
    scaledSize,
    intensity,
    centerRule,
    finderOverride,
    hasNeutralColor: !!neutralColor
  });
  for (let y = 0; y < scaledSize; y++) {
    matrix[y] = [];
    colorMatrix[y] = [];
    for (let x = 0; x < scaledSize; x++) {
      const moduleRow = Math.floor(y / actualScale);
      const moduleCol = Math.floor(x / actualScale);
      const subX = x % actualScale;
      const subY = y % actualScale;
      const isCenter = subX === centerIdx && subY === centerIdx;
      const qrValue = qr.isDark(moduleRow, moduleCol);
      const overlayBrightness = brightness2[y]?.[x] ?? 0.5;
      const overlayColor = colors[y]?.[x];
      const lockModule = shouldLockModule2(moduleRow, moduleCol, moduleCount, version, config);
      const isFinderModule = isFinderPattern(moduleRow, moduleCol, moduleCount) || isFinderSeparator2(moduleRow, moduleCol, moduleCount);
      const forceSolidFinder = finderOverride === "solid" && isFinderModule && lockModule;
      if (lockModule || forceSolidFinder) {
        matrix[y][x] = qrValue;
        colorMatrix[y][x] = null;
        continue;
      }
      if (isCenter) {
        matrix[y][x] = qrValue;
        if (useHalftone && qrValue) {
          colorMatrix[y][x] = overlayColor ? {
            ...overlayColor,
            halftone: true,
            sizeRatio: 0.5 + overlayBrightness * 0.5
          } : neutralColor ? { ...neutralColor, halftone: true, sizeRatio: 0.5 + overlayBrightness * 0.5 } : null;
        } else {
          colorMatrix[y][x] = overlayColor ? { ...overlayColor } : neutralColor ? { ...neutralColor } : null;
        }
      } else {
        const threshold2 = 0.5 - intensity * 0.3;
        matrix[y][x] = overlayBrightness < threshold2;
        colorMatrix[y][x] = overlayColor ? { ...overlayColor } : neutralColor ? { ...neutralColor } : null;
      }
    }
  }
  return {
    matrix,
    colors: colorMatrix,
    scale: actualScale,
    overlayData: null,
    effectiveIntensity: intensity * 100
    // Return as percentage (0-100) for consistency
  };
}

// src/modules/qr-generator/overlay-transforms.ts
var log10 = createLogger("GENERATE");
function hasPreprocessingOptions(config) {
  return config.filterBrightness !== void 0 && config.filterBrightness !== 0 || config.filterContrast !== void 0 && config.filterContrast !== 0 || config.filterSaturation !== void 0 && config.filterSaturation !== 0 || config.filterHue !== void 0 && config.filterHue !== 0 || config.filterGamma !== void 0 && config.filterGamma !== 1 || !!config.filterInvert || !!config.filterGrayscale || config.filterThreshold !== void 0 && config.filterThreshold > 0 || config.filterBlur !== void 0 && config.filterBlur > 0 || config.filterSharpen !== void 0 && config.filterSharpen > 0 || config.filterPosterize !== void 0 && config.filterPosterize > 0 || !!config.filterDuotone1 && !!config.filterDuotone2 || !!config.filterEdgeDetect || // colorMode 'grayscale' or 'bw' requires preprocessing
  config.colorMode !== void 0 && config.colorMode !== "color";
}
function hasGeometricTransforms(_config) {
  return false;
}
async function applyGeometricTransforms(canvas, config, createCanvasFn) {
  if (!hasGeometricTransforms(config)) {
    return canvas;
  }
  const result = await createCanvasFn(canvas.width, canvas.height);
  const ctx = result.getContext("2d");
  if (!ctx) return canvas;
  ctx.drawImage(canvas, 0, 0);
  return result;
}
async function preprocessOverlay(canvas, config, createCanvasFn) {
  const debug = config.debugOverlayDither === true;
  if (!hasPreprocessingOptions(config)) {
    if (debug) {
      log10.debug("preprocessOverlay - no preprocessing needed, returning original canvas");
    }
    return canvas;
  }
  if (debug) {
    log10.debug("preprocessOverlay - starting preprocessing", {
      canvasSize: { width: canvas.width, height: canvas.height },
      colorMode: config.colorMode,
      filterGrayscale: config.filterGrayscale,
      filterBrightness: config.filterBrightness,
      filterContrast: config.filterContrast
    });
  }
  const ctx = canvas.getContext("2d", {
    willReadFrequently: true
  });
  if (!ctx) return canvas;
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const processed = preprocessImageData(imageData, config, debug);
  const result = await createCanvasFn(canvas.width, canvas.height);
  const resultCtx = result.getContext("2d");
  if (!resultCtx) return canvas;
  resultCtx.putImageData(processed, 0, 0);
  if (debug) {
    log10.debug("preprocessOverlay - complete", {
      resultSize: { width: result.width, height: result.height }
    });
  }
  return result;
}

// src/modules/qr-generator/overlay.ts
var _log68 = createLogger("GENERATE");

// src/modules/qr-generator/pattern-helpers.ts
var isFormatInfo2 = isFormatInfo;
var isVersionInfo2 = isVersionInfo;
function getAlignmentPositionsCached(version, moduleCount) {
  if (version < 2) return [];
  const cacheKey = `${version}-${moduleCount}`;
  const cached = alignmentCache.get(cacheKey);
  if (cached !== void 0) {
    return cached;
  }
  const positions = getAlignmentPatternCenters(version, moduleCount);
  alignmentCache.set(cacheKey, positions);
  return positions;
}

// src/modules/qr-generator/pixel-matrix-dither.ts
var _log69 = createLogger("GENERATE");
function normalizeColors(colors, moduleCount) {
  const result = [];
  for (let row = 0; row < moduleCount; row++) {
    result[row] = [];
    for (let col = 0; col < moduleCount; col++) {
      const color = colors?.[row]?.[col];
      if (color) {
        result[row][col] = {
          r: color.r,
          g: color.g,
          b: color.b
        };
      } else {
        result[row][col] = null;
      }
    }
  }
  return result;
}
async function generateDitherModeMatrix(qr, _config, overlayCanvas, moduleCount, effectiveIntensity, effectiveConfig, _overlayMode, createCanvasFn) {
  const overlayData = await getOverlayData(
    overlayCanvas,
    moduleCount,
    effectiveConfig,
    createCanvasFn
  );
  const matrix = applyDitherToMatrix(qr, moduleCount, overlayData, effectiveConfig);
  const colors = normalizeColors(overlayData.colors, moduleCount);
  return {
    matrix,
    colors,
    scale: 1,
    overlayData,
    effectiveIntensity
  };
}

// src/modules/qr-generator/pixel-matrix-dithered.ts
var log11 = createLogger("DITHER");
function resolveDitherKind(config) {
  if (typeof config.ditherKind === "string" && config.ditherKind.length > 0)
    return config.ditherKind;
  if (config.ditherMode === "blue_noise") return "blue_noise";
  return "error_diffusion";
}
function resolveDiffusionKernel(configuredKernel, ditherKind) {
  if (configuredKernel && configuredKernel in DIFFUSION_KERNELS) {
    return configuredKernel;
  }
  const kindKernelMap = {
    floyd_steinberg: "floyd_steinberg",
    atkinson: "atkinson",
    stucki: "stucki",
    burkes: "burkes",
    sierra: "sierra"
  };
  return kindKernelMap[ditherKind] ?? "floyd_steinberg";
}
function resolveOrderedMatrixName(ditherKind, configured) {
  if (ditherKind === "ordered_clustered") return "clustered_dot";
  if (ditherKind === "ordered_void_cluster") return "void_cluster";
  if (configured === "bayer2" || configured === "bayer4" || configured === "bayer8")
    return configured;
  if (configured === "clustered_dot" || configured === "void_cluster") return configured;
  return "bayer4";
}
function resolveThresholdPattern(ditherKind) {
  switch (ditherKind) {
    case "white_noise":
      return "white_noise";
    case "gaussian_noise":
      return "gaussian_noise";
    case "triangular_noise":
      return "triangular_noise";
    case "ordered_bayer":
    case "ordered_clustered":
    case "ordered_void_cluster":
    case "true_dither":
      return "ordered";
    case "screened_blue_noise":
      return "screened_blue_noise";
    case "temporal_blue_noise":
      return "temporal_blue_noise";
    case "adaptive_threshold":
      return "adaptive_threshold";
    default:
      return "blue_noise";
  }
}
function isThresholdOnlyDitherKind(ditherKind) {
  switch (ditherKind) {
    case "blue_noise":
    case "blue_noise_threshold":
    case "white_noise":
    case "gaussian_noise":
    case "triangular_noise":
    case "ordered_bayer":
    case "ordered_clustered":
    case "ordered_void_cluster":
    case "true_dither":
    case "temporal_blue_noise":
    case "adaptive_threshold":
      return true;
    default:
      return false;
  }
}
async function generateBWFirstMatrix(qr, config, overlayCanvas, moduleCount, scale, effectiveIntensity, createCanvasFn) {
  const scaledSize = moduleCount * scale;
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  const scaledCanvas = await createCanvasFn(scaledSize, scaledSize);
  const ctx = scaledCanvas.getContext("2d");
  if (!ctx) return createEmptyMatrix(scaledSize, scale, effectiveIntensity);
  ctx.drawImage(overlayCanvas, 0, 0, scaledSize, scaledSize);
  const imageData = ctx.getImageData(0, 0, scaledSize, scaledSize);
  const data = imageData.data;
  const matrix = [];
  const colors = [];
  const clampByte = (v) => Math.max(0, Math.min(255, Math.round(v)));
  const mapShadeWithSourceColor = (srcR, srcG, srcB, shade, qrDark) => {
    const gray = (srcR + srcG + srcB) / 3;
    const chromaScale = qrDark ? 0.9 : 0.58;
    let rOut = gray + (srcR - gray) * chromaScale;
    let gOut = gray + (srcG - gray) * chromaScale;
    let bOut = gray + (srcB - gray) * chromaScale;
    const currentShade = rgbToGray(clampByte(rOut), clampByte(gOut), clampByte(bOut));
    const delta = shade - currentShade;
    rOut += delta;
    gOut += delta;
    bOut += delta;
    return { r: clampByte(rOut), g: clampByte(gOut), b: clampByte(bOut) };
  };
  const textureAmount = Math.min(1, effectiveIntensity);
  const seed = config.blueNoiseSeed ?? 1337;
  const tileSize = config.blueNoiseTileSize ?? 64;
  const blueNoiseTile = generateBlueNoiseTile(tileSize, seed);
  const contrastPower = 1.5;
  for (let y = 0; y < scaledSize; y++) {
    matrix[y] = [];
    colors[y] = [];
    for (let x = 0; x < scaledSize; x++) {
      const idx = (y * scaledSize + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const moduleRow = Math.floor(y / scale);
      const moduleCol = Math.floor(x / scale);
      const qrIsDark = qr.isDark(moduleRow, moduleCol);
      matrix[y][x] = qrIsDark;
      let overlayBrightness = rgbToGray(r, g, b) / 255;
      overlayBrightness = overlayBrightness ** contrastPower;
      const noise = sampleBlueNoise(x, y, blueNoiseTile, tileSize);
      const noiseVariation = (noise - 0.5) * 0.3;
      let shade;
      if (qrIsDark) {
        const darkMin = 0;
        const darkMax = 100;
        const darkRange = darkMax - darkMin;
        let normalizedShade = (1 - overlayBrightness) * textureAmount;
        normalizedShade = clamp013(normalizedShade + noiseVariation * textureAmount);
        shade = darkMin + Math.floor((1 - normalizedShade) * darkRange);
      } else {
        const lightMin = 155;
        const lightMax = 255;
        const lightRange = lightMax - lightMin;
        let normalizedShade = overlayBrightness * textureAmount;
        normalizedShade = clamp013(normalizedShade + noiseVariation * textureAmount);
        shade = lightMin + Math.floor(normalizedShade * lightRange);
        if (textureAmount === 0) shade = 255;
      }
      if (shouldLockModule3(moduleRow, moduleCol, moduleCount, version, config)) {
        shade = qrIsDark ? 0 : 255;
      }
      colors[y][x] = config.colorMode !== "bw" ? mapShadeWithSourceColor(r, g, b, shade, qrIsDark) : null;
    }
  }
  log11.debug("QR-first B&W matrix generated", {
    scaledSize,
    moduleCount,
    scale,
    textureAmount,
    contrastPower,
    mode: "bw-first"
  });
  return { matrix, colors, scale, overlayData: null, effectiveIntensity };
}
function luma01(r, g, b) {
  return rgbToGray(r, g, b) / 255;
}
function clamp013(x) {
  return x < 0 ? 0 : x > 1 ? 1 : x;
}
function shapeOverlayDarkness(overlayDark) {
  const t = clamp013(overlayDark);
  const gammaLift = t ** 0.9;
  const smooth = t * t * (3 - 2 * t);
  const midBoost = gammaLift + 0.14 * (1 - Math.abs(2 * smooth - 1));
  return clamp013(0.58 * gammaLift + 0.42 * midBoost);
}
function moduleCenterWeight(x, y, scale) {
  const fx = (x % scale + 0.5) / Math.max(1, scale) - 0.5;
  const fy = (y % scale + 0.5) / Math.max(1, scale) - 0.5;
  const r2 = fx * fx + fy * fy;
  const radial = Math.max(0, 1 - r2 * 3.8);
  return radial * radial;
}
function lerp2(a, b, t) {
  return a + (b - a) * t;
}
function distributeError2(errors, x, y, error, kernel, scaledSize, leftToRight) {
  const { matrix, divisor, offset } = kernel;
  for (let ky = 0; ky < matrix.length; ky++) {
    for (let kx = 0; kx < matrix[ky].length; kx++) {
      const weight = matrix[ky][kx];
      if (weight === 0) continue;
      let offsetX = kx - offset;
      if (!leftToRight) offsetX = -offsetX;
      const nx = x + offsetX;
      const ny = y + ky;
      if (nx >= 0 && nx < scaledSize && ny < scaledSize) {
        errors[ny][nx] += error * weight / divisor;
      }
    }
  }
}
function createEmptyMatrix(size, scale, effectiveIntensity) {
  const matrix = [];
  const colors = [];
  for (let y = 0; y < size; y++) {
    matrix[y] = [];
    colors[y] = [];
    for (let x = 0; x < size; x++) {
      matrix[y][x] = false;
      colors[y][x] = null;
    }
  }
  return { matrix, colors, scale, overlayData: null, effectiveIntensity };
}
function shouldLockModule3(row, col, moduleCount, version, config) {
  const preserveFunctional = config.preserveFunctionalPatterns === true;
  const preserveFinders = config.preserveFinders !== false;
  const preserveTiming = preserveFunctional ? config.preserveTiming !== false : config.preserveTiming === true;
  const preserveAlignment = preserveFunctional ? config.preserveAlignment !== false : config.preserveAlignment === true;
  const protectFormat = preserveFunctional ? config.protectFormatInfo !== false : config.protectFormatInfo === true;
  const protectVersion = preserveFunctional ? config.protectVersionInfo !== false : config.protectVersionInfo === true;
  const preserveFixedDark = preserveFunctional;
  const isFinderSeparator3 = isFinderModuleOrSeparator(row, col, moduleCount, true);
  if (row === moduleCount - 8 && col === 8) return preserveFixedDark;
  if (isFinderPattern(row, col, moduleCount)) {
    return preserveFinders;
  }
  if (isFinderSeparator3) {
    return preserveFinders;
  }
  if (isTimingPattern(row, col, moduleCount)) {
    return preserveTiming;
  }
  if (isAlignmentPattern(row, col, moduleCount, version)) {
    return preserveAlignment;
  }
  if (isFormatInfo(row, col, moduleCount)) {
    return protectFormat;
  }
  if (isVersionInfo(row, col, moduleCount, version)) {
    return protectVersion;
  }
  return false;
}
function isFinderModuleOrSeparator(row, col, moduleCount, separatorsOnly = false) {
  const isFinderSeparator3 = row === 7 && col <= 7 || col === 7 && row <= 7 || row === 7 && col >= moduleCount - 8 || col === moduleCount - 8 && row <= 7 || row === moduleCount - 8 && col <= 7 || col === 7 && row >= moduleCount - 8;
  if (separatorsOnly) return isFinderSeparator3;
  return isFinderPattern(row, col, moduleCount) || isFinderSeparator3;
}
function isFixedDarkModule(row, col, moduleCount) {
  return row === moduleCount - 8 && col === 8;
}
function isFunctionalPatternModule(row, col, moduleCount, version) {
  return isFixedDarkModule(row, col, moduleCount) || isFinderModuleOrSeparator(row, col, moduleCount) || isTimingPattern(row, col, moduleCount) || isAlignmentPattern(row, col, moduleCount, version) || isFormatInfo(row, col, moduleCount) || isVersionInfo(row, col, moduleCount, version);
}
function enforceModuleConstraints2(qr, matrix, desire, moduleCount, scale, version, config) {
  const baseDarkMin = clamp013(config.darkMinOccupancy ?? 0.38);
  const baseLightMax = clamp013(config.lightMaxOccupancy ?? 0.62);
  if (baseDarkMin <= 1e-3 && baseLightMax >= 0.999) return;
  const total = scale * scale;
  const maxIters = Math.max(1, Math.min(16, config.optimizeIterations ?? 8));
  const centerRadius = Math.max(1, Math.floor(scale * 0.18));
  const centerArea = (centerRadius * 2 + 1) * (centerRadius * 2 + 1);
  const moduleCenter = (scale - 1) / 2;
  const occupancies = Array.from(
    { length: moduleCount },
    () => new Array(moduleCount).fill(0)
  );
  const centerOcc = Array.from(
    { length: moduleCount },
    () => new Array(moduleCount).fill(0)
  );
  const darkMinMap = Array.from(
    { length: moduleCount },
    () => new Array(moduleCount).fill(baseDarkMin)
  );
  const lightMaxMap = Array.from(
    { length: moduleCount },
    () => new Array(moduleCount).fill(baseLightMax)
  );
  const darkCenterMinMap = Array.from(
    { length: moduleCount },
    () => new Array(moduleCount).fill(Math.min(0.64, baseDarkMin + 0.18))
  );
  const lightCenterMaxMap = Array.from(
    { length: moduleCount },
    () => new Array(moduleCount).fill(Math.max(0.36, baseLightMax - 0.18))
  );
  const locked = Array.from(
    { length: moduleCount },
    () => new Array(moduleCount).fill(false)
  );
  const decoupleFinderOptimization = config.preserveFinders === false && config.blendPreservations !== true;
  const finderBlendGuidance = config.preserveFinders === false && config.blendPreservations === true;
  for (let mr = 0; mr < moduleCount; mr++) {
    for (let mc = 0; mc < moduleCount; mc++) {
      locked[mr][mc] = shouldLockModule3(mr, mc, moduleCount, version, config) || decoupleFinderOptimization && isFinderModuleOrSeparator(mr, mc, moduleCount);
    }
  }
  const recomputeModuleStats = () => {
    for (let mr = 0; mr < moduleCount; mr++) {
      for (let mc = 0; mc < moduleCount; mc++) {
        const y0 = mr * scale;
        const x0 = mc * scale;
        let darkCount = 0;
        let centerDarkCount = 0;
        let desireSum = 0;
        let desireSq = 0;
        for (let y = 0; y < scale; y++) {
          for (let x = 0; x < scale; x++) {
            const yy = y0 + y;
            const xx = x0 + x;
            const dark = matrix[yy][xx];
            if (dark) darkCount++;
            if (dark && Math.abs(y - moduleCenter) <= centerRadius && Math.abs(x - moduleCenter) <= centerRadius) {
              centerDarkCount++;
            }
            const d = desire[y0 + y][x0 + x];
            desireSum += d;
            desireSq += d * d;
          }
        }
        occupancies[mr][mc] = darkCount / total;
        centerOcc[mr][mc] = centerDarkCount / Math.max(1, centerArea);
        const mean = desireSum / total;
        const variance = Math.max(0, desireSq / total - mean * mean);
        const contrast2 = clamp013(Math.sqrt(variance) * 3.2);
        darkMinMap[mr][mc] = clamp013(Math.max(0.34, Math.min(0.5, baseDarkMin - contrast2 * 0.02)));
        lightMaxMap[mr][mc] = clamp013(
          Math.max(0.5, Math.min(0.66, baseLightMax + contrast2 * 0.02))
        );
        darkCenterMinMap[mr][mc] = clamp013(
          Math.max(
            darkMinMap[mr][mc] + 0.12,
            Math.min(0.68, darkMinMap[mr][mc] + 0.2 - contrast2 * 0.04)
          )
        );
        lightCenterMaxMap[mr][mc] = clamp013(
          Math.min(
            lightMaxMap[mr][mc] - 0.12,
            Math.max(0.34, lightMaxMap[mr][mc] - 0.2 + contrast2 * 0.04)
          )
        );
        if (finderBlendGuidance && isFunctionalPatternModule(mr, mc, moduleCount, version)) {
          if (qr.isDark(mr, mc)) {
            darkMinMap[mr][mc] = Math.max(darkMinMap[mr][mc], 0.58);
            darkCenterMinMap[mr][mc] = Math.max(darkCenterMinMap[mr][mc], 0.74);
          } else {
            lightMaxMap[mr][mc] = Math.min(lightMaxMap[mr][mc], 0.26);
            lightCenterMaxMap[mr][mc] = Math.min(lightCenterMaxMap[mr][mc], 0.14);
          }
        }
      }
    }
  };
  const computeViolationEnergy = () => {
    let energy = 0;
    for (let mr = 0; mr < moduleCount; mr++) {
      for (let mc = 0; mc < moduleCount; mc++) {
        if (locked[mr][mc]) continue;
        if (isFixedDarkModule(mr, mc, moduleCount)) continue;
        const qrIsDark = qr.isDark(mr, mc);
        if (qrIsDark) {
          const occViolation = Math.max(0, darkMinMap[mr][mc] - occupancies[mr][mc]);
          const centerViolation = Math.max(0, darkCenterMinMap[mr][mc] - centerOcc[mr][mc]);
          energy += occViolation * 0.35 + centerViolation * 1.8;
        } else {
          const occViolation = Math.max(0, occupancies[mr][mc] - lightMaxMap[mr][mc]);
          const centerViolation = Math.max(0, centerOcc[mr][mc] - lightCenterMaxMap[mr][mc]);
          energy += occViolation * 0.35 + centerViolation * 1.8;
        }
      }
    }
    return energy;
  };
  recomputeModuleStats();
  let prevViolationEnergy = computeViolationEnergy();
  for (let iter = 0; iter < maxIters; iter++) {
    const candidates = [];
    let totalViolationEnergy = 0;
    for (let mr = 0; mr < moduleCount; mr++) {
      for (let mc = 0; mc < moduleCount; mc++) {
        if (locked[mr][mc]) continue;
        if (isFixedDarkModule(mr, mc, moduleCount)) continue;
        const qrIsDark = qr.isDark(mr, mc);
        const occ = occupancies[mr][mc];
        const cOcc = centerOcc[mr][mc];
        const darkMin = darkMinMap[mr][mc];
        const lightMax = lightMaxMap[mr][mc];
        const darkCenterMin = darkCenterMinMap[mr][mc];
        const lightCenterMax = lightCenterMaxMap[mr][mc];
        let occViolation = 0;
        let centerViolation = 0;
        let toDark = false;
        if (qrIsDark && occ < darkMin) {
          occViolation = darkMin - occ;
          toDark = true;
        } else if (!qrIsDark && occ > lightMax) {
          occViolation = occ - lightMax;
          toDark = false;
        }
        if (qrIsDark && cOcc < darkCenterMin) {
          centerViolation = darkCenterMin - cOcc;
          toDark = true;
        } else if (!qrIsDark && cOcc > lightCenterMax) {
          centerViolation = cOcc - lightCenterMax;
          toDark = false;
        }
        if (occViolation <= 0 && centerViolation <= 0) continue;
        totalViolationEnergy += occViolation * 0.35 + centerViolation * 1.8;
        const y0 = mr * scale;
        const x0 = mc * scale;
        for (let y = 0; y < scale; y++) {
          for (let x = 0; x < scale; x++) {
            const yy = y0 + y;
            const xx = x0 + x;
            const current = matrix[yy][xx];
            if (toDark && current || !(toDark || current)) continue;
            const inCenter = Math.abs(y - moduleCenter) <= centerRadius && Math.abs(x - moduleCenter) <= centerRadius;
            const occGain = occViolation > 0 ? Math.min(occViolation, 1 / total) * 0.35 : 0;
            const centerGain = inCenter && centerViolation > 0 ? Math.min(centerViolation, 1 / centerArea) * 1.8 : 0;
            const scanGain = occGain + centerGain;
            if (scanGain <= 0) continue;
            const d = desire[yy][xx];
            const beforeErr = Math.abs((current ? 1 : 0) - d);
            const afterErr = Math.abs((toDark ? 1 : 0) - d);
            const artPenalty = afterErr - beforeErr;
            const edgeBand = x <= 1 || y <= 1 || x >= scale - 2 || y >= scale - 2;
            const edgePenalty = edgeBand ? 0.44 : 0;
            const centerBonus = inCenter ? 0.07 : 0;
            const score = scanGain * 12.5 - artPenalty * 1.7 - edgePenalty + centerBonus;
            candidates.push({ y: yy, x: xx, score, toDark, scanGain });
          }
        }
      }
    }
    if (totalViolationEnergy <= 1e-5) break;
    if (candidates.length === 0) break;
    candidates.sort((a, b) => b.score - a.score);
    const targetGain = totalViolationEnergy * 0.9;
    const maxFlips = Math.max(
      1,
      Math.min(candidates.length, Math.ceil(totalViolationEnergy * total * 0.9))
    );
    let applied = 0;
    let gained = 0;
    for (let i = 0; i < candidates.length && applied < maxFlips && gained < targetGain; i++) {
      const c = candidates[i];
      if (c.score < -0.2 && gained > targetGain * 0.6) break;
      const current = matrix[c.y][c.x];
      if (c.toDark === current) continue;
      matrix[c.y][c.x] = c.toDark;
      applied++;
      gained += c.scanGain;
    }
    if (applied === 0) break;
    recomputeModuleStats();
    const newViolationEnergy = computeViolationEnergy();
    if (prevViolationEnergy - newViolationEnergy < 1e-4) break;
    prevViolationEnergy = newViolationEnergy;
  }
}
function removeIsolatedSpeckles(qr, matrix, moduleCount, scale, version, config) {
  const size = matrix.length;
  const copy = matrix.map((row) => row.slice());
  for (let y = 1; y < size - 1; y++) {
    for (let x = 1; x < size - 1; x++) {
      const mr = Math.floor(y / scale);
      const mc = Math.floor(x / scale);
      if (mr < 0 || mc < 0 || mr >= moduleCount || mc >= moduleCount || shouldLockModule3(mr, mc, moduleCount, version, config)) {
        continue;
      }
      const current = copy[y][x];
      let sameNeighbors = 0;
      for (let oy = -1; oy <= 1; oy++) {
        for (let ox = -1; ox <= 1; ox++) {
          if (ox === 0 && oy === 0) continue;
          if (copy[y + oy][x + ox] === current) sameNeighbors++;
        }
      }
      if (sameNeighbors <= 1) {
        matrix[y][x] = qr.isDark(mr, mc);
      }
    }
  }
}
function computeQualityMetrics(matrix, desire, scale) {
  const h = matrix.length;
  const w = matrix[0]?.length ?? 0;
  if (h === 0 || w === 0) return { artCorrelation: 0, edgeImprint: 0 };
  let mae = 0;
  let count = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      mae += Math.abs((matrix[y][x] ? 1 : 0) - desire[y][x]);
      count++;
    }
  }
  const artCorrelation = 1 - mae / Math.max(1, count);
  let boundaryDiff = 0;
  let nonBoundaryDiff = 0;
  let boundaryCount = 0;
  let nonBoundaryCount = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w - 1; x++) {
      const d = Math.abs((matrix[y][x] ? 1 : 0) - (matrix[y][x + 1] ? 1 : 0));
      if ((x + 1) % scale === 0) {
        boundaryDiff += d;
        boundaryCount++;
      } else {
        nonBoundaryDiff += d;
        nonBoundaryCount++;
      }
    }
  }
  const b = boundaryDiff / Math.max(1, boundaryCount);
  const n = nonBoundaryDiff / Math.max(1, nonBoundaryCount);
  return { artCorrelation: clamp013(artCorrelation), edgeImprint: b - n };
}
async function generateDitheredMatrix(qr, config, overlayCanvas, moduleCount, scale, effectiveIntensity, _effectiveConfig, createCanvasFn) {
  const scaledSize = moduleCount * scale;
  if (config.qrFirstMode) {
    log11.debug("QR-first mode enabled via config - using QR-first matrix");
    return generateBWFirstMatrix(
      qr,
      config,
      overlayCanvas,
      moduleCount,
      scale,
      effectiveIntensity,
      createCanvasFn
    );
  }
  const intensity = effectiveIntensity;
  const rawStrength = config.ditherStrength ?? 0.85;
  const ditherStrength = rawStrength > 1 ? rawStrength / 100 : rawStrength;
  const ditherScale = Math.max(0, config.ditherScale ?? 1);
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  const serpentine = config.ditherSerpentine ?? true;
  const colorDitherMode = config.colorDither ?? "none";
  const useColorDither = colorDitherMode !== "none";
  const ditherKind = resolveDitherKind(config);
  const thresholdPattern = resolveThresholdPattern(ditherKind);
  const thresholdOnly = isThresholdOnlyDitherKind(ditherKind);
  const kernelName = resolveDiffusionKernel(config.diffusionKernel, ditherKind);
  const kernel = DIFFUSION_KERNELS[kernelName] ?? DIFFUSION_KERNELS.floyd_steinberg;
  const seed = config.blueNoiseSeed ?? config.seed ?? 1337;
  const tileSize = config.blueNoiseTileSize ?? 64;
  const noiseTile = generateBlueNoiseTile(tileSize, seed);
  const orderedMatrixName = resolveOrderedMatrixName(ditherKind, config.orderedMatrix);
  const orderedMatrix = getOrderedMatrix(orderedMatrixName);
  const orderedH = orderedMatrix.length;
  const orderedW = orderedMatrix[0]?.length ?? orderedH;
  const orderedDivisor = Math.max(1, orderedH * orderedW);
  const whiteNoiseRng = createRNG2((seed ^ 2654435769) >>> 0);
  const gaussianNoiseRng = createRNG2((seed ^ 2135587861) >>> 0);
  const triangularNoiseRng = createRNG2((seed ^ 2496678331) >>> 0);
  const gaussian01 = () => {
    const u1 = Math.max(1e-6, gaussianNoiseRng());
    const u2 = gaussianNoiseRng();
    const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return clamp013(0.5 + z * 0.18);
  };
  const triangular01 = () => (triangularNoiseRng() + triangularNoiseRng()) * 0.5;
  const frameIndex = config.frameIndex ?? 0;
  const temporalOffsetX = frameIndex * 17 % tileSize;
  const temporalOffsetY = frameIndex * 29 % tileSize;
  const scaledCanvas = await createCanvasFn(scaledSize, scaledSize);
  const ctx = scaledCanvas.getContext("2d");
  if (!ctx) return createEmptyMatrix(scaledSize, scale, effectiveIntensity);
  ctx.drawImage(overlayCanvas, 0, 0, scaledSize, scaledSize);
  const imageData = ctx.getImageData(0, 0, scaledSize, scaledSize);
  const data = imageData.data;
  const matrix = [];
  const colors = [];
  const desire = [];
  const errors = [];
  for (let y = 0; y < scaledSize; y++) {
    matrix[y] = [];
    colors[y] = [];
    desire[y] = new Array(scaledSize).fill(0.5);
    errors[y] = new Array(scaledSize).fill(0);
  }
  const mix = clamp013(intensity * ditherStrength * ditherScale);
  const qrBitBiasStrength = clamp013(config.qrBitBiasStrength ?? 0);
  const sampleThreshold = (x, y, overlayDark) => {
    const centered = (value01) => clamp013(0.5 + (value01 - 0.5) * mix);
    switch (thresholdPattern) {
      case "white_noise":
        return centered(whiteNoiseRng());
      case "gaussian_noise":
        return centered(gaussian01());
      case "triangular_noise":
        return centered(triangular01());
      case "ordered": {
        const rank = orderedMatrix[y % orderedH]?.[x % orderedW] ?? 0;
        return centered((rank + 0.5) / orderedDivisor);
      }
      case "screened_blue_noise": {
        const blue = sampleBlueNoise(x, y, noiseTile, tileSize);
        const screen = clamp013(0.5 + 0.5 * Math.sin(x * 0.37 + y * 0.29));
        return centered(blue * 0.72 + screen * 0.28);
      }
      case "temporal_blue_noise":
        return centered(
          sampleBlueNoise(x + temporalOffsetX, y + temporalOffsetY, noiseTile, tileSize)
        );
      case "adaptive_threshold":
        return centered(clamp013(0.55 - (overlayDark - 0.5) * 0.9));
      default:
        return centered(sampleBlueNoise(x, y, noiseTile, tileSize));
    }
  };
  for (let y = 0; y < scaledSize; y++) {
    const leftToRight = serpentine ? y % 2 === 0 : true;
    const startX = leftToRight ? 0 : scaledSize - 1;
    const endX = leftToRight ? scaledSize : -1;
    const deltaX = leftToRight ? 1 : -1;
    for (let x = startX; leftToRight ? x < endX : x > endX; x += deltaX) {
      const idx = (y * scaledSize + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const moduleRow = Math.floor(y / scale);
      const moduleCol = Math.floor(x / scale);
      const qrIsDark = qr.isDark(moduleRow, moduleCol);
      const moduleLocked = shouldLockModule3(moduleRow, moduleCol, moduleCount, version, config);
      const fixedDarkUnlocked = !moduleLocked && isFixedDarkModule(moduleRow, moduleCol, moduleCount);
      const overlayDark = shapeOverlayDarkness(1 - luma01(r, g, b));
      const centerW = moduleCenterWeight(x, y, scale);
      const qrBias = fixedDarkUnlocked ? 0 : (qrIsDark ? 1 : -1) * qrBitBiasStrength * centerW * (0.45 + mix * 0.8);
      const biasedOverlayDark = clamp013(overlayDark + qrBias);
      const threshold2 = sampleThreshold(x, y, overlayDark);
      let isDarkCandidate;
      if (thresholdOnly && !useColorDither) {
        isDarkCandidate = biasedOverlayDark > threshold2;
      } else {
        const adjusted = biasedOverlayDark + errors[y][x];
        isDarkCandidate = adjusted > threshold2;
        const err = (biasedOverlayDark - (isDarkCandidate ? 1 : 0)) * mix;
        distributeError2(errors, x, y, err, kernel, scaledSize, leftToRight);
      }
      matrix[y][x] = moduleLocked ? qrIsDark : isDarkCandidate;
      desire[y][x] = moduleLocked ? qrIsDark ? 1 : 0 : overlayDark;
      colors[y][x] = config.colorMode !== "bw" ? {
        r,
        g,
        b
      } : null;
    }
  }
  enforceModuleConstraints2(qr, matrix, desire, moduleCount, scale, version, config);
  if (config.cleanupSpeckle === true) {
    removeIsolatedSpeckles(qr, matrix, moduleCount, scale, version, config);
  }
  const center = Math.floor(scale / 2);
  const sampleMr = Math.min(10, moduleCount - 1);
  const sampleMc = Math.min(10, moduleCount - 1);
  const sy = sampleMr * scale + center;
  const sx = sampleMc * scale + center;
  log11.debug("dithered-matrix generated", {
    scaledSize,
    moduleCount,
    scale,
    mix,
    serpentine,
    ditherKind,
    thresholdPattern,
    thresholdOnly,
    colorDitherMode,
    kernelName,
    sample: {
      module: { row: sampleMr, col: sampleMc, qrIsDark: qr.isDark(sampleMr, sampleMc) },
      centerPixel: { y: sy, x: sx, isDark: matrix[sy]?.[sx], desire: desire[sy]?.[sx] }
    },
    quality: computeQualityMetrics(matrix, desire, scale)
  });
  return { matrix, colors, scale, overlayData: null, effectiveIntensity };
}
async function generateBlueNoiseMatrix(qr, config, overlayCanvas, moduleCount, scale, effectiveIntensity, _canvasFactory, createCanvasFn) {
  const scaledSize = moduleCount * scale;
  if (config.qrFirstMode) {
    log11.debug("QR-first mode enabled via config in blue-noise mode - using QR-first matrix");
    return generateBWFirstMatrix(
      qr,
      config,
      overlayCanvas,
      moduleCount,
      scale,
      effectiveIntensity,
      createCanvasFn
    );
  }
  const intensity = effectiveIntensity;
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  const scaledCanvas = await createCanvasFn(scaledSize, scaledSize);
  const ctx = scaledCanvas.getContext("2d");
  if (!ctx) return createEmptyMatrix(scaledSize, scale, effectiveIntensity);
  ctx.drawImage(overlayCanvas, 0, 0, scaledSize, scaledSize);
  const imageData = ctx.getImageData(0, 0, scaledSize, scaledSize);
  const data = imageData.data;
  const matrix = [];
  const colors = [];
  const desire = [];
  for (let y = 0; y < scaledSize; y++) {
    matrix[y] = [];
    colors[y] = [];
    desire[y] = new Array(scaledSize).fill(0.5);
  }
  const seed = config.blueNoiseSeed ?? config.seed ?? 1337;
  const tileSize = config.blueNoiseTileSize ?? 64;
  const tile = generateBlueNoiseTile(tileSize, seed);
  const qrBitBiasStrength = clamp013(config.qrBitBiasStrength ?? 0);
  const scanGateProfile = config.scanGateProfile ?? "full";
  const scanGateActive = scanGateProfile !== "off";
  const scanGateBiasBoost = scanGateActive ? 0.06 + intensity * 0.04 : 0;
  const minPolarityBias = 0.08 + intensity * 0.08;
  const effectiveBitBias = Math.max(
    qrBitBiasStrength + scanGateBiasBoost,
    minPolarityBias + scanGateBiasBoost * 0.4
  );
  for (let y = 0; y < scaledSize; y++) {
    for (let x = 0; x < scaledSize; x++) {
      const idx = (y * scaledSize + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const moduleRow = Math.floor(y / scale);
      const moduleCol = Math.floor(x / scale);
      const qrIsDark = qr.isDark(moduleRow, moduleCol);
      const moduleLocked = shouldLockModule3(moduleRow, moduleCol, moduleCount, version, config);
      const fixedDarkUnlocked = !moduleLocked && isFixedDarkModule(moduleRow, moduleCol, moduleCount);
      if (moduleLocked) {
        matrix[y][x] = qrIsDark;
        colors[y][x] = config.colorMode !== "bw" ? { r, g, b } : null;
        desire[y][x] = qrIsDark ? 1 : 0;
        continue;
      }
      const overlayDark = shapeOverlayDarkness(1 - luma01(r, g, b));
      const centerW = moduleCenterWeight(x, y, scale);
      const polarityBoost = scanGateActive ? 1.18 : 1;
      const polarityBias = (qrIsDark ? 1 : -1) * (0.14 + intensity * 0.18) * (0.4 + centerW * 0.6) * polarityBoost;
      const qrBias = fixedDarkUnlocked ? 0 : (qrIsDark ? 1 : -1) * effectiveBitBias * centerW * (0.45 + intensity * 0.8);
      const decisionGain = (0.64 + intensity * 0.44) * (scanGateActive ? 1.04 : 1);
      const d = clamp013((overlayDark + qrBias + polarityBias) * decisionGain);
      desire[y][x] = clamp013(overlayDark + (qrIsDark ? 0.12 : -0.12));
      const n = sampleBlueNoise(x, y, tile, tileSize);
      const isDark2 = n < d;
      matrix[y][x] = isDark2;
      colors[y][x] = config.colorMode !== "bw" ? { r, g, b } : null;
    }
  }
  const strictConstraintConfig = {
    ...config,
    darkMinOccupancy: Math.max(
      config.darkMinOccupancy ?? 0,
      (scanGateActive ? 0.56 : 0.52) + intensity * 0.08
    ),
    lightMaxOccupancy: Math.min(
      config.lightMaxOccupancy ?? 1,
      (scanGateActive ? 0.44 : 0.48) - intensity * 0.08
    ),
    optimizeIterations: Math.max(config.optimizeIterations ?? 0, scanGateActive ? 10 : 8)
  };
  enforceModuleConstraints2(qr, matrix, desire, moduleCount, scale, version, strictConstraintConfig);
  if (config.cleanupSpeckle === true) {
    removeIsolatedSpeckles(qr, matrix, moduleCount, scale, version, config);
  }
  log11.debug("blue-noise-matrix generated", {
    scaledSize,
    moduleCount,
    scale,
    tileSize,
    seed
  });
  return { matrix, colors, scale, overlayData: null, effectiveIntensity };
}
async function generateHalftoneDitheredOverlayData(qr, config, overlayCanvas, moduleCount, effectiveIntensity, effectiveConfig, createCanvasFn) {
  const scale = 4;
  const ditheredResult = await generateDitheredMatrix(
    qr,
    config,
    overlayCanvas,
    moduleCount,
    scale,
    effectiveIntensity,
    effectiveConfig,
    createCanvasFn
  );
  const moduleCanvas = await createCanvasFn(moduleCount, moduleCount);
  const moduleCtx = moduleCanvas.getContext("2d");
  let moduleData = null;
  if (moduleCtx) {
    moduleCtx.imageSmoothingEnabled = true;
    moduleCtx.imageSmoothingQuality = "high";
    moduleCtx.drawImage(overlayCanvas, 0, 0, moduleCount, moduleCount);
    moduleData = moduleCtx.getImageData(0, 0, moduleCount, moduleCount).data;
  }
  const overlayData = {};
  overlayData.colors = {};
  const total = scale * scale;
  const densityInfluence = clamp013(0.15 + effectiveIntensity * 0.15);
  for (let mr = 0; mr < moduleCount; mr++) {
    overlayData[mr] = {};
    overlayData.colors[mr] = {};
    for (let mc = 0; mc < moduleCount; mc++) {
      let darkCount = 0;
      let sumR = 0;
      let sumG = 0;
      let sumB = 0;
      let colorCount = 0;
      let srcR = 127;
      let srcG = 127;
      let srcB = 127;
      let srcBrightness = 0.5;
      if (moduleData) {
        const srcIdx = (mr * moduleCount + mc) * 4;
        srcR = moduleData[srcIdx];
        srcG = moduleData[srcIdx + 1];
        srcB = moduleData[srcIdx + 2];
        srcBrightness = luma01(srcR, srcG, srcB);
      }
      for (let sy = 0; sy < scale; sy++) {
        for (let sx = 0; sx < scale; sx++) {
          const y = mr * scale + sy;
          const x = mc * scale + sx;
          if (ditheredResult.matrix[y]?.[x]) darkCount++;
          const c = ditheredResult.colors[y]?.[x];
          if (c) {
            sumR += c.r;
            sumG += c.g;
            sumB += c.b;
            colorCount++;
          }
        }
      }
      const density = darkCount / total;
      const densityBrightness = 1 - density;
      overlayData[mr][mc] = clamp013(lerp2(srcBrightness, densityBrightness, densityInfluence));
      if (colorCount > 0) {
        const ditherR = Math.round(sumR / colorCount);
        const ditherG = Math.round(sumG / colorCount);
        const ditherB = Math.round(sumB / colorCount);
        const colorMix = clamp013(0.2 + effectiveIntensity * 0.25);
        overlayData.colors[mr][mc] = {
          r: Math.round(lerp2(srcR, ditherR, colorMix)),
          g: Math.round(lerp2(srcG, ditherG, colorMix)),
          b: Math.round(lerp2(srcB, ditherB, colorMix))
        };
      } else {
        overlayData.colors[mr][mc] = { r: srcR, g: srcG, b: srcB };
      }
    }
  }
  log11.debug("halftone-dithered overlay data generated", {
    moduleCount,
    scale,
    effectiveIntensity
  });
  return { overlayData, effectiveIntensity };
}

// src/modules/qr-generator/pixel-matrix-standard.ts
var _log70 = createLogger("GENERATE");
async function generateStandardMatrix(qr, _config, overlayCanvas, moduleCount, effectiveIntensity, effectiveConfig, createCanvasFn) {
  const overlayData = await getOverlayData(
    overlayCanvas,
    moduleCount,
    effectiveConfig,
    createCanvasFn
  );
  const matrix = [];
  for (let row = 0; row < moduleCount; row++) {
    matrix[row] = [];
    for (let col = 0; col < moduleCount; col++) {
      matrix[row][col] = qr.isDark(row, col);
    }
  }
  const colors = normalizeColors(overlayData.colors, moduleCount);
  return {
    matrix,
    colors,
    scale: 1,
    overlayData,
    effectiveIntensity
  };
}

// src/modules/qr-generator/pixel-matrix-utils.ts
var _log71 = createLogger("GENERATE");
function getScaleFactor(overlayMode, config) {
  const renderScale = Math.max(12, Math.min(24, Math.round(config.renderScalePerModule ?? 18)));
  switch (overlayMode) {
    case "dithered":
      return renderScale;
    case "blue-noise":
    case "blue_noise":
      return renderScale;
    case "subpixel":
    case "subpixel-size":
      return config.subpixelGrid ?? 3;
    default:
      return config.forceScaledOverlay ? renderScale : 1;
  }
}
var DEFAULT_ECC_LIMITS = {
  L: 30,
  M: 50,
  Q: 70,
  H: 85
};
function getEffectiveIntensity(config) {
  const intensity = (config.overlayIntensity ?? 100) / 100;
  const eccLimits = config.maxOverlayIntensityByEcc ?? DEFAULT_ECC_LIMITS;
  const maxIntensityPct = eccLimits[config.errorCorrection] ?? 50;
  const maxIntensity = maxIntensityPct / 100;
  const effectiveIntensity = Math.min(intensity, maxIntensity);
  return {
    effectiveIntensity,
    effectiveConfig: { ...config, overlayIntensity: effectiveIntensity * 100 }
  };
}
function generateBaseMatrix(qr, scaledSize, scale) {
  const _moduleCount = scaledSize / scale;
  const matrix = [];
  const colors = [];
  for (let y = 0; y < scaledSize; y++) {
    matrix[y] = [];
    colors[y] = [];
    for (let x = 0; x < scaledSize; x++) {
      const moduleRow = Math.floor(y / scale);
      const moduleCol = Math.floor(x / scale);
      matrix[y][x] = qr.isDark(moduleRow, moduleCol);
      colors[y][x] = null;
    }
  }
  return { matrix, colors };
}

// src/modules/qr-generator/pixel-matrix-overlay.ts
var _log72 = createLogger("GENERATE");
async function prepareUnifiedOverlayData(qr, config, overlayCanvas, moduleCount, createCanvasFn) {
  if (!overlayCanvas) {
    return {
      ditherPattern: null,
      overlayData: null,
      effectiveIntensity: 0
    };
  }
  const { effectiveIntensity, effectiveConfig } = getEffectiveIntensity(config);
  const overlayMode = config.overlayMode || "blend";
  if (overlayMode === "halftone-dithered") {
    const result = await generateHalftoneDitheredOverlayData(
      // Safe: QRCodeObject satisfies QRCodeInstance (isDark + getModuleCount)
      qr,
      effectiveConfig,
      overlayCanvas,
      moduleCount,
      effectiveIntensity,
      effectiveConfig,
      createCanvasFn
    );
    return {
      ditherPattern: null,
      overlayData: result.overlayData,
      effectiveIntensity: result.effectiveIntensity
    };
  }
  const overlayData = await getOverlayData(
    overlayCanvas,
    moduleCount,
    effectiveConfig,
    createCanvasFn
  );
  let ditherPattern = null;
  if (overlayMode === "dither" || overlayMode === "extreme") {
    ditherPattern = applyDitherToMatrix(qr, moduleCount, overlayData, effectiveConfig);
  }
  return {
    ditherPattern,
    overlayData,
    effectiveIntensity
  };
}

// src/modules/qr-generator/pixel-matrix.ts
var log12 = createLogger("GENERATE");
async function generatePixelDecisionMatrix(qr, config, overlayCanvas, moduleCount, createCanvasFn, canvasFactory) {
  const overlayMode = config.overlayMode;
  const scale = getScaleFactor(overlayMode, config);
  const scaledSize = moduleCount * scale;
  const { effectiveIntensity, effectiveConfig } = getEffectiveIntensity(config);
  if (config.debugOverlayDither) {
    log12.debug("pixel-matrix", {
      overlayMode,
      scale,
      scaledSize,
      hasOverlay: !!overlayCanvas,
      effectiveIntensity,
      colorMode: config.colorMode
    });
  }
  if (overlayCanvas === null || overlayCanvas === void 0) {
    const { matrix, colors } = generateBaseMatrix(qr, scaledSize, scale);
    return { matrix, colors, scale, overlayData: null, effectiveIntensity };
  }
  if (config.forceScaledOverlay && scale > 1) {
    const isAlreadyScaled = overlayMode === "dithered" || overlayMode === "blue-noise" || overlayMode === "blue_noise" || overlayMode === "subpixel" || overlayMode === "subpixel-size";
    if (!isAlreadyScaled) {
      return generateDitheredMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        scale,
        effectiveIntensity,
        effectiveConfig,
        createCanvasFn
      );
    }
  }
  switch (overlayMode) {
    case "dithered":
      if (config.ditherMode === "blue_noise" || config.ditherKind === "blue_noise") {
        return generateBlueNoiseMatrix(
          qr,
          config,
          overlayCanvas,
          moduleCount,
          scale,
          effectiveIntensity,
          canvasFactory,
          createCanvasFn
        );
      }
      return generateDitheredMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        scale,
        effectiveIntensity,
        effectiveConfig,
        createCanvasFn
      );
    case "blue-noise":
    case "blue_noise":
      return generateBlueNoiseMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        scale,
        effectiveIntensity,
        canvasFactory,
        createCanvasFn
      );
    case "subpixel":
    case "subpixel-size": {
      const useHalftoneCenter = overlayMode === "subpixel-size";
      return await generateSubpixelMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        scale,
        useHalftoneCenter,
        createCanvasFn
      );
    }
    case "dither":
    case "extreme":
      return generateDitherModeMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        effectiveIntensity,
        effectiveConfig,
        overlayMode,
        createCanvasFn
      );
    default:
      return generateStandardMatrix(
        qr,
        config,
        overlayCanvas,
        moduleCount,
        effectiveIntensity,
        effectiveConfig,
        createCanvasFn
      );
  }
}

// src/modules/qr-decoder/exceptions.ts
var _log73 = createLogger("DECODER");
var DecoderException = class extends Error {
  static kind = "DecoderException";
  constructor(message) {
    super(message);
    this.name = this.constructor.name;
  }
  getKind() {
    return this.constructor.kind;
  }
};
var NotFoundException = class _NotFoundException extends DecoderException {
  static kind = "NotFoundException";
  static getNotFoundInstance() {
    return new _NotFoundException();
  }
};
var FormatException = class _FormatException extends DecoderException {
  static kind = "FormatException";
  static getFormatInstance() {
    return new _FormatException();
  }
};
var ChecksumException = class _ChecksumException extends DecoderException {
  static kind = "ChecksumException";
  static getChecksumInstance() {
    return new _ChecksumException();
  }
};
var IllegalArgumentException = class extends DecoderException {
  static kind = "IllegalArgumentException";
};
var IllegalStateException = class extends DecoderException {
  static kind = "IllegalStateException";
};
var ArithmeticException = class extends DecoderException {
  static kind = "ArithmeticException";
};
var ReedSolomonException = class extends DecoderException {
  static kind = "ReedSolomonException";
};
var UnsupportedOperationException = class extends DecoderException {
  static kind = "UnsupportedOperationException";
};

// src/modules/qr-decoder/util.ts
var _log74 = createLogger("DECODER");
var Arrays = class {
  /**
   * Fill array with a value
   */
  static fill(a, val) {
    for (let i = 0; i < a.length; i++) {
      a[i] = val;
    }
  }
  /**
   * Fill array range with a value
   */
  static fillWithin(a, fromIndex, toIndex, val) {
    for (let i = fromIndex; i < toIndex; i++) {
      a[i] = val;
    }
  }
  /**
   * Create a list from arguments
   */
  static asList(...args) {
    return args;
  }
  /**
   * Create a 2D array
   */
  static create(rows, cols, value) {
    return Array.from({ length: rows }, () => Array.from({ length: cols }).fill(value));
  }
  /**
   * Create a 2D Int32Array
   */
  static createInt32Array(rows, cols, value) {
    return Array.from({ length: rows }, () => {
      const arr = new Int32Array(cols);
      if (value !== void 0) arr.fill(value);
      return arr;
    });
  }
  /**
   * Check array equality
   */
  static equals(first, second) {
    if (!(first && second)) return false;
    if (!(first.length && second.length)) return false;
    if (first.length !== second.length) return false;
    for (let i = 0; i < first.length; i++) {
      if (first[i] !== second[i]) return false;
    }
    return true;
  }
  /**
   * Compute hash code for array
   */
  static hashCode(a) {
    if (a === null) return 0;
    let result = 1;
    for (const element of a) {
      result = 31 * result + element;
    }
    return result;
  }
  /**
   * Fill Uint8Array with value
   */
  static fillUint8Array(a, value) {
    for (let i = 0; i < a.length; i++) {
      a[i] = value;
    }
  }
  /**
   * Copy array to new length
   */
  static copyOf(original, newLength) {
    return original.slice(0, newLength);
  }
  /**
   * Copy Uint8Array to new length
   */
  static copyOfUint8Array(original, newLength) {
    if (original.length <= newLength) {
      const newArray = new Uint8Array(newLength);
      newArray.set(original);
      return newArray;
    }
    return original.slice(0, newLength);
  }
  /**
   * Copy range of array
   */
  static copyOfRange(original, from, to) {
    const newLength = to - from;
    const copy = new Int32Array(newLength);
    arraycopy(original, from, copy, 0, newLength);
    return copy;
  }
  /**
   * Binary search in sorted array
   */
  static binarySearch(ar, el, comparator) {
    if (comparator === void 0) {
      comparator = (a, b) => a - b;
    }
    let m = 0;
    let n = ar.length - 1;
    while (m <= n) {
      const k = n + m >> 1;
      const cmp = comparator(el, ar[k]);
      if (cmp > 0) {
        m = k + 1;
      } else if (cmp < 0) {
        n = k - 1;
      } else {
        return k;
      }
    }
    return -m - 1;
  }
};
function arraycopy(src, srcPos, dest, destPos, length) {
  if (src === dest && srcPos < destPos) {
    destPos += length - 1;
    srcPos += length - 1;
    while (length--) {
      dest[destPos--] = src[srcPos--];
    }
  } else {
    while (length--) {
      dest[destPos++] = src[srcPos++];
    }
  }
}
var Integer = class {
  static MIN_VALUE_32_BITS = -2147483648;
  static MAX_VALUE = Number.MAX_SAFE_INTEGER;
  /**
   * Count trailing zeros
   */
  static numberOfTrailingZeros(i) {
    if (i === 0) return 32;
    let n = 31;
    let y = i << 16;
    if (y !== 0) {
      n -= 16;
      i = y;
    }
    y = i << 8;
    if (y !== 0) {
      n -= 8;
      i = y;
    }
    y = i << 4;
    if (y !== 0) {
      n -= 4;
      i = y;
    }
    y = i << 2;
    if (y !== 0) {
      n -= 2;
      i = y;
    }
    return n - (i << 1 >>> 31);
  }
  /**
   * Count leading zeros
   */
  static numberOfLeadingZeros(i) {
    if (i === 0) return 32;
    let n = 1;
    if (i >>> 16 === 0) {
      n += 16;
      i <<= 16;
    }
    if (i >>> 24 === 0) {
      n += 8;
      i <<= 8;
    }
    if (i >>> 28 === 0) {
      n += 4;
      i <<= 4;
    }
    if (i >>> 30 === 0) {
      n += 2;
      i <<= 2;
    }
    n -= i >>> 31;
    return n;
  }
  /**
   * Convert to hex string
   */
  static toHexString(i) {
    return i.toString(16);
  }
  /**
   * Count set bits (population count)
   */
  static bitCount(i) {
    i = i - (i >>> 1 & 1431655765);
    i = (i & 858993459) + (i >>> 2 & 858993459);
    i = i + (i >>> 4) & 252645135;
    i = i + (i >>> 8);
    i = i + (i >>> 16);
    return i & 63;
  }
  /**
   * Truncated integer division
   */
  static truncDivision(dividend, divisor) {
    return Math.trunc(dividend / divisor);
  }
  /**
   * Parse integer
   */
  static parseInt(num, radix) {
    return parseInt(num, radix);
  }
};
var Float = class {
  static MAX_VALUE = Number.MAX_SAFE_INTEGER;
  static floatToIntBits(f) {
    return f;
  }
};
var StringBuilder = class {
  value;
  encoding = null;
  constructor(value = "") {
    this.value = value;
  }
  enableDecoding(encoding) {
    this.encoding = encoding;
    return this;
  }
  append(s) {
    if (typeof s === "string") {
      this.value += s;
    } else if (this.encoding) {
      this.value += StringUtils.castAsNonUtf8Char(s, this.encoding);
    } else {
      this.value += String.fromCharCode(s);
    }
    return this;
  }
  appendChars(str, offset, len) {
    for (let i = offset; i < offset + len; i++) {
      this.append(str[i]);
    }
    return this;
  }
  length() {
    return this.value.length;
  }
  charAt(n) {
    return this.value.charAt(n);
  }
  deleteCharAt(n) {
    this.value = this.value.substr(0, n) + this.value.substring(n + 1);
  }
  setCharAt(n, c) {
    this.value = this.value.substr(0, n) + c + this.value.substr(n + 1);
  }
  substring(start, end) {
    return this.value.substring(start, end);
  }
  setLengthToZero() {
    this.value = "";
  }
  toString() {
    return this.value;
  }
  insert(n, c) {
    this.value = this.value.substring(0, n) + c + this.value.substring(n);
  }
};
var CharacterSetECI = class _CharacterSetECI {
  constructor(values, name, ...otherNames) {
    this.values = values;
    this.name = name;
    for (const value of values) {
      _CharacterSetECI.VALUE_TO_ECI.set(value, this);
    }
    _CharacterSetECI.NAME_TO_ECI.set(name, this);
    for (const otherName of otherNames) {
      _CharacterSetECI.NAME_TO_ECI.set(otherName, this);
    }
  }
  static VALUE_TO_ECI = /* @__PURE__ */ new Map();
  static NAME_TO_ECI = /* @__PURE__ */ new Map();
  static Cp437 = new _CharacterSetECI([0, 2], "Cp437");
  static ISO8859_1 = new _CharacterSetECI([1, 3], "ISO-8859-1", "ISO8859_1");
  static ISO8859_2 = new _CharacterSetECI([4], "ISO-8859-2", "ISO8859_2");
  static ISO8859_3 = new _CharacterSetECI([5], "ISO-8859-3", "ISO8859_3");
  static ISO8859_4 = new _CharacterSetECI([6], "ISO-8859-4", "ISO8859_4");
  static ISO8859_5 = new _CharacterSetECI([7], "ISO-8859-5", "ISO8859_5");
  static ISO8859_6 = new _CharacterSetECI([8], "ISO-8859-6", "ISO8859_6");
  static ISO8859_7 = new _CharacterSetECI([9], "ISO-8859-7", "ISO8859_7");
  static ISO8859_8 = new _CharacterSetECI([10], "ISO-8859-8", "ISO8859_8");
  static ISO8859_9 = new _CharacterSetECI([11], "ISO-8859-9", "ISO8859_9");
  static ISO8859_10 = new _CharacterSetECI([12], "ISO-8859-10", "ISO8859_10");
  static ISO8859_11 = new _CharacterSetECI([13], "ISO-8859-11", "ISO8859_11");
  static ISO8859_13 = new _CharacterSetECI([15], "ISO-8859-13", "ISO8859_13");
  static ISO8859_14 = new _CharacterSetECI([16], "ISO-8859-14", "ISO8859_14");
  static ISO8859_15 = new _CharacterSetECI([17], "ISO-8859-15", "ISO8859_15");
  static ISO8859_16 = new _CharacterSetECI([18], "ISO-8859-16", "ISO8859_16");
  static SJIS = new _CharacterSetECI([20], "SJIS", "Shift_JIS");
  static Cp1250 = new _CharacterSetECI([21], "Cp1250", "windows-1250");
  static Cp1251 = new _CharacterSetECI([22], "Cp1251", "windows-1251");
  static Cp1252 = new _CharacterSetECI([23], "Cp1252", "windows-1252");
  static Cp1256 = new _CharacterSetECI([24], "Cp1256", "windows-1256");
  static UnicodeBigUnmarked = new _CharacterSetECI(
    [25],
    "UnicodeBigUnmarked",
    "UTF-16BE",
    "UnicodeBig"
  );
  static UTF8 = new _CharacterSetECI([26], "UTF-8", "UTF8");
  static ASCII = new _CharacterSetECI([27, 170], "ASCII", "US-ASCII");
  static Big5 = new _CharacterSetECI([28], "Big5");
  static GB18030 = new _CharacterSetECI([29], "GB18030", "GB2312", "EUC_CN", "GBK");
  static EUC_KR = new _CharacterSetECI([30], "EUC-KR", "EUC_KR");
  getName() {
    return this.name;
  }
  getValue() {
    return this.values[0];
  }
  equals(other) {
    if (!other) return false;
    return this.name === other.name;
  }
  static getCharacterSetECIByValue(value) {
    if (value < 0 || value >= 900) return null;
    return _CharacterSetECI.VALUE_TO_ECI.get(value) || null;
  }
  static getCharacterSetECIByName(name) {
    return _CharacterSetECI.NAME_TO_ECI.get(name) || null;
  }
};
var StringEncoding = class _StringEncoding {
  static customDecoder = null;
  static customEncoder = null;
  static decode(bytes, encoding) {
    const encodingName = _StringEncoding.encodingName(encoding);
    if (_StringEncoding.customDecoder) {
      return _StringEncoding.customDecoder(bytes, encodingName);
    }
    if (typeof TextDecoder === "undefined" || _StringEncoding.shouldDecodeOnFallback(encodingName)) {
      return _StringEncoding.decodeFallback(bytes, encodingName);
    }
    return new TextDecoder(encodingName).decode(bytes);
  }
  static shouldDecodeOnFallback(encodingName) {
    return !_StringEncoding.isBrowser() && encodingName === "ISO-8859-1";
  }
  static encode(s, encoding) {
    const encodingName = _StringEncoding.encodingName(encoding);
    if (_StringEncoding.customEncoder) {
      return _StringEncoding.customEncoder(s, encodingName);
    }
    if (typeof TextEncoder === "undefined") {
      return _StringEncoding.encodeFallback(s);
    }
    return new TextEncoder().encode(s);
  }
  static isBrowser() {
    return typeof window !== "undefined" && {}.toString.call(window) === "[object Window]";
  }
  static encodingName(encoding) {
    return typeof encoding === "string" ? encoding : encoding.getName();
  }
  static encodingCharacterSet(encoding) {
    if (encoding instanceof CharacterSetECI) {
      return encoding;
    }
    return CharacterSetECI.getCharacterSetECIByName(encoding);
  }
  static decodeFallback(bytes, encoding) {
    const characterSet = _StringEncoding.encodingCharacterSet(encoding);
    if (characterSet && _StringEncoding.isDecodeFallbackSupported(characterSet)) {
      let s = "";
      for (let i = 0; i < bytes.length; i++) {
        let h = bytes[i].toString(16);
        if (h.length < 2) h = `0${h}`;
        s += `%${h}`;
      }
      return decodeURIComponent(s);
    }
    if (characterSet?.equals(CharacterSetECI.UnicodeBigUnmarked)) {
      return String.fromCharCode.apply(null, Array.from(new Uint16Array(bytes.buffer)));
    }
    throw new Error(`Encoding ${_StringEncoding.encodingName(encoding)} not supported by fallback.`);
  }
  static isDecodeFallbackSupported(characterSet) {
    return characterSet.equals(CharacterSetECI.UTF8) || characterSet.equals(CharacterSetECI.ISO8859_1) || characterSet.equals(CharacterSetECI.ASCII);
  }
  static encodeFallback(s) {
    const encodedURIstring = btoa(unescape(encodeURIComponent(s)));
    const charList = encodedURIstring.split("");
    const uintArray = [];
    for (let i = 0; i < charList.length; i++) {
      uintArray.push(charList[i].charCodeAt(0));
    }
    return new Uint8Array(uintArray);
  }
};
var StringUtils = class {
  static SHIFT_JIS = "SJIS";
  static GB2312 = "GB2312";
  static ISO88591 = CharacterSetECI.ISO8859_1;
  static UTF8 = CharacterSetECI.UTF8;
  static castAsNonUtf8Char(code, encoding) {
    const bytes = new Uint8Array([code]);
    return StringEncoding.decode(bytes, encoding);
  }
  static guessEncoding(bytes, _hints) {
    if (bytes.length > 2 && bytes[0] === 239 && bytes[1] === 187 && bytes[2] === 191) {
      return CharacterSetECI.UTF8.getName();
    }
    let hasHighBytes = false;
    for (let i = 0; i < bytes.length; i++) {
      if ((bytes[i] & 128) !== 0) {
        hasHighBytes = true;
        break;
      }
    }
    if (!hasHighBytes) {
      return CharacterSetECI.ISO8859_1.getName();
    }
    return CharacterSetECI.UTF8.getName();
  }
};
function currentTimeMillis() {
  return Date.now();
}

// src/modules/qr-decoder/bit-matrix.ts
var _log75 = createLogger("DECODER");
var BitArray = class _BitArray {
  size;
  bits;
  constructor(size, bits) {
    if (size === void 0) {
      this.size = 0;
      this.bits = new Int32Array(1);
    } else {
      this.size = size;
      this.bits = bits ?? _BitArray.makeArray(size);
    }
  }
  getSize() {
    return this.size;
  }
  getSizeInBytes() {
    return Math.floor((this.size + 7) / 8);
  }
  ensureCapacity(size) {
    if (size > this.bits.length * 32) {
      const newBits = _BitArray.makeArray(size);
      arraycopy(this.bits, 0, newBits, 0, this.bits.length);
      this.bits = newBits;
    }
  }
  get(i) {
    return (this.bits[Math.floor(i / 32)] & 1 << (i & 31)) !== 0;
  }
  set(i) {
    this.bits[Math.floor(i / 32)] |= 1 << (i & 31);
  }
  flip(i) {
    this.bits[Math.floor(i / 32)] ^= 1 << (i & 31);
  }
  getNextSet(from) {
    const size = this.size;
    if (from >= size) return size;
    const bits = this.bits;
    let bitsOffset = Math.floor(from / 32);
    let currentBits = bits[bitsOffset];
    currentBits &= ~((1 << (from & 31)) - 1);
    const length = bits.length;
    while (currentBits === 0) {
      if (++bitsOffset === length) return size;
      currentBits = bits[bitsOffset];
    }
    const result = bitsOffset * 32 + Integer.numberOfTrailingZeros(currentBits);
    return result > size ? size : result;
  }
  getNextUnset(from) {
    const size = this.size;
    if (from >= size) return size;
    const bits = this.bits;
    let bitsOffset = Math.floor(from / 32);
    let currentBits = ~bits[bitsOffset];
    currentBits &= ~((1 << (from & 31)) - 1);
    const length = bits.length;
    while (currentBits === 0) {
      if (++bitsOffset === length) return size;
      currentBits = ~bits[bitsOffset];
    }
    const result = bitsOffset * 32 + Integer.numberOfTrailingZeros(currentBits);
    return result > size ? size : result;
  }
  setBulk(i, newBits) {
    this.bits[Math.floor(i / 32)] = newBits;
  }
  setRange(start, end) {
    if (end < start || start < 0 || end > this.size) {
      throw new IllegalArgumentException();
    }
    if (end === start) return;
    end--;
    const firstInt = Math.floor(start / 32);
    const lastInt = Math.floor(end / 32);
    const bits = this.bits;
    for (let i = firstInt; i <= lastInt; i++) {
      const firstBit = i > firstInt ? 0 : start & 31;
      const lastBit = i < lastInt ? 31 : end & 31;
      const mask = (2 << lastBit) - (1 << firstBit);
      bits[i] |= mask;
    }
  }
  clear() {
    const bits = this.bits;
    for (let i = 0; i < bits.length; i++) {
      bits[i] = 0;
    }
  }
  isRange(start, end, value) {
    if (end < start || start < 0 || end > this.size) {
      throw new IllegalArgumentException();
    }
    if (end === start) return true;
    end--;
    const firstInt = Math.floor(start / 32);
    const lastInt = Math.floor(end / 32);
    const bits = this.bits;
    for (let i = firstInt; i <= lastInt; i++) {
      const firstBit = i > firstInt ? 0 : start & 31;
      const lastBit = i < lastInt ? 31 : end & 31;
      const mask = (2 << lastBit) - (1 << firstBit) & 4294967295;
      if ((bits[i] & mask) !== (value ? mask : 0)) return false;
    }
    return true;
  }
  appendBit(bit) {
    this.ensureCapacity(this.size + 1);
    if (bit) {
      this.bits[Math.floor(this.size / 32)] |= 1 << (this.size & 31);
    }
    this.size++;
  }
  appendBits(value, numBits) {
    if (numBits < 0 || numBits > 32) {
      throw new IllegalArgumentException("Num bits must be between 0 and 32");
    }
    this.ensureCapacity(this.size + numBits);
    for (let numBitsLeft = numBits; numBitsLeft > 0; numBitsLeft--) {
      this.appendBit((value >> numBitsLeft - 1 & 1) === 1);
    }
  }
  appendBitArray(other) {
    const otherSize = other.size;
    this.ensureCapacity(this.size + otherSize);
    for (let i = 0; i < otherSize; i++) {
      this.appendBit(other.get(i));
    }
  }
  xor(other) {
    if (this.size !== other.size) {
      throw new IllegalArgumentException("Sizes don't match");
    }
    const bits = this.bits;
    for (let i = 0; i < bits.length; i++) {
      bits[i] ^= other.bits[i];
    }
  }
  toBytes(bitOffset, array, offset, numBytes) {
    for (let i = 0; i < numBytes; i++) {
      let theByte = 0;
      for (let j = 0; j < 8; j++) {
        if (this.get(bitOffset)) {
          theByte |= 1 << 7 - j;
        }
        bitOffset++;
      }
      array[offset + i] = theByte;
    }
  }
  getBitArray() {
    return this.bits;
  }
  reverse() {
    const newBits = new Int32Array(this.bits.length);
    const len = Math.floor((this.size - 1) / 32);
    const oldBitsLen = len + 1;
    const bits = this.bits;
    for (let i = 0; i < oldBitsLen; i++) {
      let x = bits[i];
      x = x >> 1 & 1431655765 | (x & 1431655765) << 1;
      x = x >> 2 & 858993459 | (x & 858993459) << 2;
      x = x >> 4 & 252645135 | (x & 252645135) << 4;
      x = x >> 8 & 16711935 | (x & 16711935) << 8;
      x = x >> 16 & 65535 | (x & 65535) << 16;
      newBits[len - i] = x;
    }
    if (this.size !== oldBitsLen * 32) {
      const leftOffset = oldBitsLen * 32 - this.size;
      let currentInt = newBits[0] >>> leftOffset;
      for (let i = 1; i < oldBitsLen; i++) {
        const nextInt = newBits[i];
        currentInt |= nextInt << 32 - leftOffset;
        newBits[i - 1] = currentInt;
        currentInt = nextInt >>> leftOffset;
      }
      newBits[oldBitsLen - 1] = currentInt;
    }
    this.bits = newBits;
  }
  static makeArray(size) {
    return new Int32Array(Math.floor((size + 31) / 32));
  }
  equals(o) {
    if (!(o instanceof _BitArray)) return false;
    return this.size === o.size && Arrays.equals(this.bits, o.bits);
  }
  hashCode() {
    return 31 * this.size + Arrays.hashCode(this.bits);
  }
  toString() {
    let result = "";
    for (let i = 0; i < this.size; i++) {
      if ((i & 7) === 0) result += " ";
      result += this.get(i) ? "X" : ".";
    }
    return result;
  }
  clone() {
    return new _BitArray(this.size, this.bits.slice());
  }
  toArray() {
    const result = [];
    for (let i = 0; i < this.size; i++) {
      result.push(this.get(i));
    }
    return result;
  }
};
var BitMatrix = class _BitMatrix {
  width;
  height;
  rowSize;
  bits;
  constructor(width, height, rowSize, bits) {
    this.width = width;
    this.height = height ?? width;
    if (width < 1 || this.height < 1) {
      throw new IllegalArgumentException("Both dimensions must be greater than 0");
    }
    this.rowSize = rowSize ?? Math.floor((width + 31) / 32);
    this.bits = bits ?? new Int32Array(this.rowSize * this.height);
  }
  static parseFromBooleanArray(image) {
    const height = image.length;
    const width = image[0].length;
    const bits = new _BitMatrix(width, height);
    for (let i = 0; i < height; i++) {
      const imageI = image[i];
      for (let j = 0; j < width; j++) {
        if (imageI[j]) bits.set(j, i);
      }
    }
    return bits;
  }
  static parseFromString(stringRepresentation, setString, unsetString) {
    if (stringRepresentation === null) {
      throw new IllegalArgumentException("stringRepresentation cannot be null");
    }
    const bits = [];
    let bitsPos = 0;
    let rowStartPos = 0;
    let rowLength = -1;
    let nRows = 0;
    let pos = 0;
    while (pos < stringRepresentation.length) {
      if (stringRepresentation.charAt(pos) === "\n" || stringRepresentation.charAt(pos) === "\r") {
        if (bitsPos > rowStartPos) {
          if (rowLength === -1) {
            rowLength = bitsPos - rowStartPos;
          } else if (bitsPos - rowStartPos !== rowLength) {
            throw new IllegalArgumentException("row lengths do not match");
          }
          rowStartPos = bitsPos;
          nRows++;
        }
        pos++;
      } else if (stringRepresentation.substring(pos, pos + setString.length) === setString) {
        pos += setString.length;
        bits[bitsPos] = true;
        bitsPos++;
      } else if (stringRepresentation.substring(pos, pos + unsetString.length) === unsetString) {
        pos += unsetString.length;
        bits[bitsPos] = false;
        bitsPos++;
      } else {
        throw new IllegalArgumentException(
          `illegal character encountered: ${stringRepresentation.substring(pos)}`
        );
      }
    }
    if (bitsPos > rowStartPos) {
      if (rowLength === -1) {
        rowLength = bitsPos - rowStartPos;
      } else if (bitsPos - rowStartPos !== rowLength) {
        throw new IllegalArgumentException("row lengths do not match");
      }
      nRows++;
    }
    const matrix = new _BitMatrix(rowLength, nRows);
    for (let i = 0; i < bitsPos; i++) {
      if (bits[i]) matrix.set(Math.floor(i % rowLength), Math.floor(i / rowLength));
    }
    return matrix;
  }
  get(x, y) {
    const offset = y * this.rowSize + Math.floor(x / 32);
    return (this.bits[offset] >>> (x & 31) & 1) !== 0;
  }
  set(x, y) {
    const offset = y * this.rowSize + Math.floor(x / 32);
    this.bits[offset] |= 1 << (x & 31) & 4294967295;
  }
  unset(x, y) {
    const offset = y * this.rowSize + Math.floor(x / 32);
    this.bits[offset] &= ~(1 << (x & 31) & 4294967295);
  }
  flip(x, y) {
    const offset = y * this.rowSize + Math.floor(x / 32);
    this.bits[offset] ^= 1 << (x & 31) & 4294967295;
  }
  xor(mask) {
    if (this.width !== mask.getWidth() || this.height !== mask.getHeight() || this.rowSize !== mask.getRowSize()) {
      throw new IllegalArgumentException("input matrix dimensions do not match");
    }
    const rowArray = new BitArray(Math.floor(this.width / 32) + 1);
    for (let y = 0; y < this.height; y++) {
      const offset = y * this.rowSize;
      const row = mask.getRow(y, rowArray).getBitArray();
      for (let x = 0; x < this.rowSize; x++) {
        this.bits[offset + x] ^= row[x];
      }
    }
  }
  clear() {
    for (let i = 0; i < this.bits.length; i++) {
      this.bits[i] = 0;
    }
  }
  setRegion(left, top, width, height) {
    if (top < 0 || left < 0) {
      throw new IllegalArgumentException("Left and top must be nonnegative");
    }
    if (height < 1 || width < 1) {
      throw new IllegalArgumentException("Height and width must be at least 1");
    }
    const right = left + width;
    const bottom = top + height;
    if (bottom > this.height || right > this.width) {
      throw new IllegalArgumentException("The region must fit inside the matrix");
    }
    for (let y = top; y < bottom; y++) {
      const offset = y * this.rowSize;
      for (let x = left; x < right; x++) {
        this.bits[offset + Math.floor(x / 32)] |= 1 << (x & 31) & 4294967295;
      }
    }
  }
  getRow(y, row) {
    if (row === null || row === void 0 || row.getSize() < this.width) {
      row = new BitArray(this.width);
    } else {
      row.clear();
    }
    const offset = y * this.rowSize;
    for (let x = 0; x < this.rowSize; x++) {
      row.setBulk(x * 32, this.bits[offset + x]);
    }
    return row;
  }
  setRow(y, row) {
    arraycopy(row.getBitArray(), 0, this.bits, y * this.rowSize, this.rowSize);
  }
  rotate180() {
    const width = this.getWidth();
    const height = this.getHeight();
    let topRow = new BitArray(width);
    let bottomRow = new BitArray(width);
    for (let i = 0; i < Math.floor((height + 1) / 2); i++) {
      topRow = this.getRow(i, topRow);
      bottomRow = this.getRow(height - 1 - i, bottomRow);
      topRow.reverse();
      bottomRow.reverse();
      this.setRow(i, bottomRow);
      this.setRow(height - 1 - i, topRow);
    }
  }
  getEnclosingRectangle() {
    let left = this.width;
    let top = this.height;
    let right = -1;
    let bottom = -1;
    for (let y = 0; y < this.height; y++) {
      for (let x32 = 0; x32 < this.rowSize; x32++) {
        const theBits = this.bits[y * this.rowSize + x32];
        if (theBits !== 0) {
          if (y < top) top = y;
          if (y > bottom) bottom = y;
          if (x32 * 32 < left) {
            let bit = 0;
            while ((theBits << 31 - bit & 4294967295) === 0) bit++;
            if (x32 * 32 + bit < left) left = x32 * 32 + bit;
          }
          if (x32 * 32 + 31 > right) {
            let bit = 31;
            while (theBits >>> bit === 0) bit--;
            if (x32 * 32 + bit > right) right = x32 * 32 + bit;
          }
        }
      }
    }
    if (right < left || bottom < top) return null;
    return Int32Array.from([left, top, right - left + 1, bottom - top + 1]);
  }
  getTopLeftOnBit() {
    let bitsOffset = 0;
    while (bitsOffset < this.bits.length && this.bits[bitsOffset] === 0) bitsOffset++;
    if (bitsOffset === this.bits.length) return null;
    const y = bitsOffset / this.rowSize;
    let x = bitsOffset % this.rowSize * 32;
    const theBits = this.bits[bitsOffset];
    let bit = 0;
    while ((theBits << 31 - bit & 4294967295) === 0) bit++;
    x += bit;
    return Int32Array.from([x, y]);
  }
  getBottomRightOnBit() {
    let bitsOffset = this.bits.length - 1;
    while (bitsOffset >= 0 && this.bits[bitsOffset] === 0) bitsOffset--;
    if (bitsOffset < 0) return null;
    const y = Math.floor(bitsOffset / this.rowSize);
    let x = Math.floor(bitsOffset % this.rowSize) * 32;
    const theBits = this.bits[bitsOffset];
    let bit = 31;
    while (theBits >>> bit === 0) bit--;
    x += bit;
    return Int32Array.from([x, y]);
  }
  getWidth() {
    return this.width;
  }
  getHeight() {
    return this.height;
  }
  getRowSize() {
    return this.rowSize;
  }
  equals(o) {
    if (!(o instanceof _BitMatrix)) return false;
    return this.width === o.width && this.height === o.height && this.rowSize === o.rowSize && Arrays.equals(this.bits, o.bits);
  }
  hashCode() {
    let hash = this.width;
    hash = 31 * hash + this.width;
    hash = 31 * hash + this.height;
    hash = 31 * hash + this.rowSize;
    hash = 31 * hash + Arrays.hashCode(this.bits);
    return hash;
  }
  toString(setString = "X ", unsetString = "  ", lineSeparator = "\n") {
    const result = new StringBuilder();
    for (let y = 0; y < this.height; y++) {
      for (let x = 0; x < this.width; x++) {
        result.append(this.get(x, y) ? setString : unsetString);
      }
      result.append(lineSeparator);
    }
    return result.toString();
  }
  clone() {
    return new _BitMatrix(this.width, this.height, this.rowSize, this.bits.slice());
  }
};

// src/modules/qr-decoder/luminance.ts
var _log76 = createLogger("DECODER");
var LuminanceSource = class {
  constructor(width, height) {
    this.width = width;
    this.height = height;
  }
  getWidth() {
    return this.width;
  }
  getHeight() {
    return this.height;
  }
  isCropSupported() {
    return false;
  }
  crop(_left, _top, _width, _height) {
    throw new UnsupportedOperationException("This luminance source does not support cropping.");
  }
  isRotateSupported() {
    return false;
  }
  rotateCounterClockwise() {
    throw new UnsupportedOperationException(
      "This luminance source does not support rotation by 90 degrees."
    );
  }
  rotateCounterClockwise45() {
    throw new UnsupportedOperationException(
      "This luminance source does not support rotation by 45 degrees."
    );
  }
  toString() {
    const row = new Uint8ClampedArray(this.width);
    const result = new StringBuilder();
    for (let y = 0; y < this.height; y++) {
      const sourceRow = this.getRow(y, row);
      for (let x = 0; x < this.width; x++) {
        const luminance = sourceRow[x] & 255;
        let c;
        if (luminance < 64) c = "#";
        else if (luminance < 128) c = "+";
        else if (luminance < 192) c = ".";
        else c = " ";
        result.append(c);
      }
      result.append("\n");
    }
    return result.toString();
  }
};
var InvertedLuminanceSource = class _InvertedLuminanceSource extends LuminanceSource {
  constructor(delegate) {
    super(delegate.getWidth(), delegate.getHeight());
    this.delegate = delegate;
  }
  getRow(y, row) {
    const sourceRow = this.delegate.getRow(y, row);
    const width = this.getWidth();
    for (let i = 0; i < width; i++) {
      sourceRow[i] = 255 - (sourceRow[i] & 255);
    }
    return sourceRow;
  }
  getMatrix() {
    const matrix = this.delegate.getMatrix();
    const length = this.getWidth() * this.getHeight();
    const invertedMatrix = new Uint8ClampedArray(length);
    for (let i = 0; i < length; i++) {
      invertedMatrix[i] = 255 - (matrix[i] & 255);
    }
    return invertedMatrix;
  }
  isCropSupported() {
    return this.delegate.isCropSupported();
  }
  crop(left, top, width, height) {
    return new _InvertedLuminanceSource(this.delegate.crop(left, top, width, height));
  }
  isRotateSupported() {
    return this.delegate.isRotateSupported();
  }
  invert() {
    return this.delegate;
  }
  rotateCounterClockwise() {
    return new _InvertedLuminanceSource(this.delegate.rotateCounterClockwise());
  }
  rotateCounterClockwise45() {
    return new _InvertedLuminanceSource(this.delegate.rotateCounterClockwise45());
  }
};
var RGBALuminanceSource = class _RGBALuminanceSource extends LuminanceSource {
  luminances;
  constructor(luminances, width, height) {
    super(width, height);
    this.luminances = luminances;
  }
  static createFromImageData(imageData) {
    const { data, width, height } = imageData;
    const luminances = new Uint8ClampedArray(width * height);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = (y * width + x) * 4;
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        luminances[y * width + x] = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
      }
    }
    return new _RGBALuminanceSource(luminances, width, height);
  }
  getRow(y, row) {
    const width = this.getWidth();
    if (row === void 0 || row === null || row.length < width) {
      row = new Uint8ClampedArray(width);
    }
    const offset = y * width;
    for (let x = 0; x < width; x++) {
      row[x] = this.luminances[offset + x];
    }
    return row;
  }
  getMatrix() {
    return this.luminances;
  }
  invert() {
    return new InvertedLuminanceSource(this);
  }
};
var Binarizer = class {
  constructor(source) {
    this.source = source;
  }
  getLuminanceSource() {
    return this.source;
  }
  getWidth() {
    return this.source.getWidth();
  }
  getHeight() {
    return this.source.getHeight();
  }
};
var BinaryBitmap = class _BinaryBitmap {
  constructor(binarizer) {
    this.binarizer = binarizer;
    if (binarizer === null) {
      throw new IllegalArgumentException("Binarizer must be non-null.");
    }
  }
  matrix = null;
  getWidth() {
    return this.binarizer.getWidth();
  }
  getHeight() {
    return this.binarizer.getHeight();
  }
  getBlackRow(y, row) {
    return this.binarizer.getBlackRow(y, row);
  }
  getBlackMatrix() {
    if (this.matrix === null) {
      this.matrix = this.binarizer.getBlackMatrix();
    }
    return this.matrix;
  }
  isCropSupported() {
    return this.binarizer.getLuminanceSource().isCropSupported();
  }
  crop(left, top, width, height) {
    const newSource = this.binarizer.getLuminanceSource().crop(left, top, width, height);
    return new _BinaryBitmap(this.binarizer.createBinarizer(newSource));
  }
  isRotateSupported() {
    return this.binarizer.getLuminanceSource().isRotateSupported();
  }
  rotateCounterClockwise() {
    const newSource = this.binarizer.getLuminanceSource().rotateCounterClockwise();
    return new _BinaryBitmap(this.binarizer.createBinarizer(newSource));
  }
  rotateCounterClockwise45() {
    const newSource = this.binarizer.getLuminanceSource().rotateCounterClockwise45();
    return new _BinaryBitmap(this.binarizer.createBinarizer(newSource));
  }
  toString() {
    try {
      return this.getBlackMatrix().toString();
    } catch (_e) {
      return "";
    }
  }
};

// src/modules/qr-decoder/binarizer.ts
var _log77 = createLogger("DECODER");
var GlobalHistogramBinarizer = class _GlobalHistogramBinarizer extends Binarizer {
  static LUMINANCE_BITS = 5;
  static LUMINANCE_SHIFT = 8 - _GlobalHistogramBinarizer.LUMINANCE_BITS;
  static LUMINANCE_BUCKETS = 1 << _GlobalHistogramBinarizer.LUMINANCE_BITS;
  static EMPTY = Uint8ClampedArray.from([0]);
  luminances;
  buckets;
  constructor(source) {
    super(source);
    this.luminances = _GlobalHistogramBinarizer.EMPTY;
    this.buckets = new Int32Array(_GlobalHistogramBinarizer.LUMINANCE_BUCKETS);
  }
  getBlackRow(y, row) {
    const source = this.getLuminanceSource();
    const width = source.getWidth();
    if (row === void 0 || row === null || row.getSize() < width) {
      row = new BitArray(width);
    } else {
      row.clear();
    }
    this.initArrays(width);
    const localLuminances = source.getRow(y, this.luminances);
    const localBuckets = this.buckets;
    for (let x = 0; x < width; x++) {
      localBuckets[(localLuminances[x] & 255) >> _GlobalHistogramBinarizer.LUMINANCE_SHIFT]++;
    }
    const blackPoint = _GlobalHistogramBinarizer.estimateBlackPoint(localBuckets);
    if (width < 3) {
      for (let x = 0; x < width; x++) {
        if ((localLuminances[x] & 255) < blackPoint) {
          row.set(x);
        }
      }
    } else {
      let left = localLuminances[0] & 255;
      let center = localLuminances[1] & 255;
      for (let x = 1; x < width - 1; x++) {
        const right = localLuminances[x + 1] & 255;
        if ((center * 4 - left - right) / 2 < blackPoint) {
          row.set(x);
        }
        left = center;
        center = right;
      }
    }
    return row;
  }
  getBlackMatrix() {
    const source = this.getLuminanceSource();
    const width = source.getWidth();
    const height = source.getHeight();
    const matrix = new BitMatrix(width, height);
    this.initArrays(width);
    const localBuckets = this.buckets;
    for (let y = 1; y < 5; y++) {
      const row = Math.floor(height * y / 5);
      const localLuminances2 = source.getRow(row, this.luminances);
      const right = Math.floor(width * 4 / 5);
      for (let x = Math.floor(width / 5); x < right; x++) {
        const pixel = localLuminances2[x] & 255;
        localBuckets[pixel >> _GlobalHistogramBinarizer.LUMINANCE_SHIFT]++;
      }
    }
    const blackPoint = _GlobalHistogramBinarizer.estimateBlackPoint(localBuckets);
    const localLuminances = source.getMatrix();
    for (let y = 0; y < height; y++) {
      const offset = y * width;
      for (let x = 0; x < width; x++) {
        const pixel = localLuminances[offset + x] & 255;
        if (pixel < blackPoint) {
          matrix.set(x, y);
        }
      }
    }
    return matrix;
  }
  createBinarizer(source) {
    return new _GlobalHistogramBinarizer(source);
  }
  initArrays(luminanceSize) {
    if (this.luminances.length < luminanceSize) {
      this.luminances = new Uint8ClampedArray(luminanceSize);
    }
    const buckets = this.buckets;
    for (let x = 0; x < _GlobalHistogramBinarizer.LUMINANCE_BUCKETS; x++) {
      buckets[x] = 0;
    }
  }
  static estimateBlackPoint(buckets) {
    const numBuckets = buckets.length;
    let maxBucketCount = 0;
    let firstPeak = 0;
    let firstPeakSize = 0;
    for (let x = 0; x < numBuckets; x++) {
      if (buckets[x] > firstPeakSize) {
        firstPeak = x;
        firstPeakSize = buckets[x];
      }
      if (buckets[x] > maxBucketCount) {
        maxBucketCount = buckets[x];
      }
    }
    let secondPeak = 0;
    let secondPeakScore = 0;
    for (let x = 0; x < numBuckets; x++) {
      const distanceToBiggest = x - firstPeak;
      const score = buckets[x] * distanceToBiggest * distanceToBiggest;
      if (score > secondPeakScore) {
        secondPeak = x;
        secondPeakScore = score;
      }
    }
    if (firstPeak > secondPeak) {
      const temp = firstPeak;
      firstPeak = secondPeak;
      secondPeak = temp;
    }
    if (secondPeak - firstPeak <= numBuckets / 16) {
      throw new NotFoundException();
    }
    let bestValley = secondPeak - 1;
    let bestValleyScore = -1;
    for (let x = secondPeak - 1; x > firstPeak; x--) {
      const fromFirst = x - firstPeak;
      const score = fromFirst * fromFirst * (secondPeak - x) * (maxBucketCount - buckets[x]);
      if (score > bestValleyScore) {
        bestValley = x;
        bestValleyScore = score;
      }
    }
    return bestValley << _GlobalHistogramBinarizer.LUMINANCE_SHIFT;
  }
};
var HybridBinarizer = class _HybridBinarizer extends GlobalHistogramBinarizer {
  static BLOCK_SIZE_POWER = 3;
  static BLOCK_SIZE = 1 << _HybridBinarizer.BLOCK_SIZE_POWER;
  static BLOCK_SIZE_MASK = _HybridBinarizer.BLOCK_SIZE - 1;
  static MINIMUM_DIMENSION = _HybridBinarizer.BLOCK_SIZE * 5;
  static MIN_DYNAMIC_RANGE = 24;
  matrix = null;
  getBlackMatrix() {
    if (this.matrix !== null) {
      return this.matrix;
    }
    const source = this.getLuminanceSource();
    const width = source.getWidth();
    const height = source.getHeight();
    if (width >= _HybridBinarizer.MINIMUM_DIMENSION && height >= _HybridBinarizer.MINIMUM_DIMENSION) {
      const luminances = source.getMatrix();
      let subWidth = width >> _HybridBinarizer.BLOCK_SIZE_POWER;
      if ((width & _HybridBinarizer.BLOCK_SIZE_MASK) !== 0) subWidth++;
      let subHeight = height >> _HybridBinarizer.BLOCK_SIZE_POWER;
      if ((height & _HybridBinarizer.BLOCK_SIZE_MASK) !== 0) subHeight++;
      const blackPoints = _HybridBinarizer.calculateBlackPoints(
        luminances,
        subWidth,
        subHeight,
        width,
        height
      );
      const newMatrix = new BitMatrix(width, height);
      _HybridBinarizer.calculateThresholdForBlock(
        luminances,
        subWidth,
        subHeight,
        width,
        height,
        blackPoints,
        newMatrix
      );
      this.matrix = newMatrix;
    } else {
      this.matrix = super.getBlackMatrix();
    }
    return this.matrix;
  }
  createBinarizer(source) {
    return new _HybridBinarizer(source);
  }
  static calculateThresholdForBlock(luminances, subWidth, subHeight, width, height, blackPoints, matrix) {
    const maxYOffset = height - _HybridBinarizer.BLOCK_SIZE;
    const maxXOffset = width - _HybridBinarizer.BLOCK_SIZE;
    for (let y = 0; y < subHeight; y++) {
      let yoffset = y << _HybridBinarizer.BLOCK_SIZE_POWER;
      if (yoffset > maxYOffset) yoffset = maxYOffset;
      const top = _HybridBinarizer.cap(y, 2, subHeight - 3);
      for (let x = 0; x < subWidth; x++) {
        let xoffset = x << _HybridBinarizer.BLOCK_SIZE_POWER;
        if (xoffset > maxXOffset) xoffset = maxXOffset;
        const left = _HybridBinarizer.cap(x, 2, subWidth - 3);
        let sum = 0;
        for (let z = -2; z <= 2; z++) {
          const blackRow = blackPoints[top + z];
          sum += blackRow[left - 2] + blackRow[left - 1] + blackRow[left] + blackRow[left + 1] + blackRow[left + 2];
        }
        const average = sum / 25;
        _HybridBinarizer.thresholdBlock(luminances, xoffset, yoffset, average, width, matrix);
      }
    }
  }
  static cap(value, min, max) {
    return value < min ? min : value > max ? max : value;
  }
  static thresholdBlock(luminances, xoffset, yoffset, threshold2, stride, matrix) {
    for (let y = 0, offset = yoffset * stride + xoffset; y < _HybridBinarizer.BLOCK_SIZE; y++, offset += stride) {
      for (let x = 0; x < _HybridBinarizer.BLOCK_SIZE; x++) {
        if ((luminances[offset + x] & 255) <= threshold2) {
          matrix.set(xoffset + x, yoffset + y);
        }
      }
    }
  }
  static calculateBlackPoints(luminances, subWidth, subHeight, width, height) {
    const maxYOffset = height - _HybridBinarizer.BLOCK_SIZE;
    const maxXOffset = width - _HybridBinarizer.BLOCK_SIZE;
    const blackPoints = new Array(subHeight);
    for (let y = 0; y < subHeight; y++) {
      blackPoints[y] = new Int32Array(subWidth);
      let yoffset = y << _HybridBinarizer.BLOCK_SIZE_POWER;
      if (yoffset > maxYOffset) yoffset = maxYOffset;
      for (let x = 0; x < subWidth; x++) {
        let xoffset = x << _HybridBinarizer.BLOCK_SIZE_POWER;
        if (xoffset > maxXOffset) xoffset = maxXOffset;
        let sum = 0;
        let min = 255;
        let max = 0;
        for (let yy = 0, offset = yoffset * width + xoffset; yy < _HybridBinarizer.BLOCK_SIZE; yy++, offset += width) {
          for (let xx = 0; xx < _HybridBinarizer.BLOCK_SIZE; xx++) {
            const pixel = luminances[offset + xx] & 255;
            sum += pixel;
            if (pixel < min) min = pixel;
            if (pixel > max) max = pixel;
          }
          if (max - min > _HybridBinarizer.MIN_DYNAMIC_RANGE) {
            for (yy++, offset += width; yy < _HybridBinarizer.BLOCK_SIZE; yy++, offset += width) {
              for (let xx = 0; xx < _HybridBinarizer.BLOCK_SIZE; xx++) {
                sum += luminances[offset + xx] & 255;
              }
            }
          }
        }
        let average = sum >> _HybridBinarizer.BLOCK_SIZE_POWER * 2;
        if (max - min <= _HybridBinarizer.MIN_DYNAMIC_RANGE) {
          average = min / 2;
          if (y > 0 && x > 0) {
            const averageNeighborBlackPoint = (blackPoints[y - 1][x] + 2 * blackPoints[y][x - 1] + blackPoints[y - 1][x - 1]) / 4;
            if (min < averageNeighborBlackPoint) {
              average = averageNeighborBlackPoint;
            }
          }
        }
        blackPoints[y][x] = average;
      }
    }
    return blackPoints;
  }
};

// src/modules/qr-decoder/types.ts
var _log78 = createLogger("DECODER");
var ECC_LEVEL_MAP2 = {
  0: "M",
  1: "L",
  2: "H",
  3: "Q"
};
var MODE_NUMERIC2 = 1;
var MODE_ALPHANUMERIC2 = 2;
var MODE_BYTE2 = 4;
var MODE_KANJI2 = 8;
var MODE_ECI = 7;
var MODE_TERMINATOR2 = 0;
var ALPHANUMERIC_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";

// src/modules/qr-decoder/decode.ts
var qrDecoderLog = createLogger("DECODER");
var RS_BLOCKS = {
  L: [
    [[1, 26, 19]],
    [[1, 44, 34]],
    [[1, 70, 55]],
    [[1, 100, 80]],
    [[1, 134, 108]],
    [[2, 86, 68]],
    [[2, 98, 78]],
    [[2, 121, 97]],
    [[2, 146, 116]],
    [
      [2, 86, 68],
      [2, 87, 69]
    ],
    [[4, 101, 81]],
    [
      [2, 116, 92],
      [2, 117, 93]
    ],
    [[4, 133, 107]],
    [
      [3, 145, 115],
      [1, 146, 116]
    ],
    [
      [5, 109, 87],
      [1, 110, 88]
    ],
    [
      [5, 122, 98],
      [1, 123, 99]
    ],
    [
      [1, 135, 107],
      [5, 136, 108]
    ],
    [
      [5, 150, 120],
      [1, 151, 121]
    ],
    [
      [3, 141, 113],
      [4, 142, 114]
    ],
    [
      [3, 135, 107],
      [5, 136, 108]
    ],
    [
      [4, 144, 116],
      [4, 145, 117]
    ],
    [
      [2, 139, 111],
      [7, 140, 112]
    ],
    [
      [4, 151, 121],
      [5, 152, 122]
    ],
    [
      [6, 147, 117],
      [4, 148, 118]
    ],
    [
      [8, 132, 106],
      [4, 133, 107]
    ],
    [
      [10, 142, 114],
      [2, 143, 115]
    ],
    [
      [8, 152, 122],
      [4, 153, 123]
    ],
    [
      [3, 147, 117],
      [10, 148, 118]
    ],
    [
      [7, 146, 116],
      [7, 147, 117]
    ],
    [
      [5, 145, 115],
      [10, 146, 116]
    ],
    [
      [13, 145, 115],
      [3, 146, 116]
    ],
    [[17, 145, 115]],
    [
      [17, 145, 115],
      [1, 146, 116]
    ],
    [
      [13, 145, 115],
      [6, 146, 116]
    ],
    [
      [12, 151, 121],
      [7, 152, 122]
    ],
    [
      [6, 151, 121],
      [14, 152, 122]
    ],
    [
      [17, 152, 122],
      [4, 153, 123]
    ],
    [
      [4, 152, 122],
      [18, 153, 123]
    ],
    [
      [20, 147, 117],
      [4, 148, 118]
    ],
    [
      [19, 148, 118],
      [6, 149, 119]
    ]
  ],
  M: [
    [[1, 26, 16]],
    [[1, 44, 28]],
    [[1, 70, 44]],
    [[2, 50, 32]],
    [[2, 67, 43]],
    [[4, 43, 27]],
    [[4, 49, 31]],
    [
      [2, 60, 38],
      [2, 61, 39]
    ],
    [
      [3, 58, 36],
      [2, 59, 37]
    ],
    [
      [4, 69, 43],
      [1, 70, 44]
    ],
    [
      [1, 80, 50],
      [4, 81, 51]
    ],
    [
      [6, 58, 36],
      [2, 59, 37]
    ],
    [
      [8, 59, 37],
      [1, 60, 38]
    ],
    [
      [4, 64, 40],
      [5, 65, 41]
    ],
    [
      [5, 65, 41],
      [5, 66, 42]
    ],
    [
      [7, 73, 45],
      [3, 74, 46]
    ],
    [
      [10, 74, 46],
      [1, 75, 47]
    ],
    [
      [9, 69, 43],
      [4, 70, 44]
    ],
    [
      [3, 70, 44],
      [11, 71, 45]
    ],
    [
      [3, 67, 41],
      [13, 68, 42]
    ],
    [[17, 68, 42]],
    [[17, 74, 46]],
    [
      [4, 75, 47],
      [14, 76, 48]
    ],
    [
      [6, 73, 45],
      [14, 74, 46]
    ],
    [
      [8, 75, 47],
      [13, 76, 48]
    ],
    [
      [19, 74, 46],
      [4, 75, 47]
    ],
    [
      [22, 73, 45],
      [3, 74, 46]
    ],
    [
      [3, 73, 45],
      [23, 74, 46]
    ],
    [
      [21, 73, 45],
      [7, 74, 46]
    ],
    [
      [19, 75, 47],
      [10, 76, 48]
    ],
    [
      [2, 74, 46],
      [29, 75, 47]
    ],
    [
      [10, 74, 46],
      [23, 75, 47]
    ],
    [
      [14, 74, 46],
      [21, 75, 47]
    ],
    [
      [14, 74, 46],
      [23, 75, 47]
    ],
    [
      [12, 75, 47],
      [26, 76, 48]
    ],
    [
      [6, 75, 47],
      [34, 76, 48]
    ],
    [
      [29, 74, 46],
      [14, 75, 47]
    ],
    [
      [13, 74, 46],
      [32, 75, 47]
    ],
    [
      [40, 75, 47],
      [7, 76, 48]
    ],
    [
      [18, 75, 47],
      [31, 76, 48]
    ]
  ],
  Q: [
    [[1, 26, 13]],
    [[1, 44, 22]],
    [[2, 35, 17]],
    [[2, 50, 24]],
    [
      [2, 33, 15],
      [2, 34, 16]
    ],
    [[4, 43, 19]],
    [
      [2, 32, 14],
      [4, 33, 15]
    ],
    [
      [4, 40, 18],
      [2, 41, 19]
    ],
    [
      [4, 36, 16],
      [4, 37, 17]
    ],
    [
      [6, 43, 19],
      [2, 44, 20]
    ],
    [
      [4, 50, 22],
      [4, 51, 23]
    ],
    [
      [4, 46, 20],
      [6, 47, 21]
    ],
    [
      [8, 44, 20],
      [4, 45, 21]
    ],
    [
      [11, 36, 16],
      [5, 37, 17]
    ],
    [
      [5, 54, 24],
      [7, 55, 25]
    ],
    [
      [15, 43, 19],
      [2, 44, 20]
    ],
    [
      [1, 50, 22],
      [15, 51, 23]
    ],
    [
      [17, 50, 22],
      [1, 51, 23]
    ],
    [
      [17, 47, 21],
      [4, 48, 22]
    ],
    [
      [15, 54, 24],
      [5, 55, 25]
    ],
    [
      [17, 50, 22],
      [6, 51, 23]
    ],
    [
      [7, 54, 24],
      [16, 55, 25]
    ],
    [
      [11, 54, 24],
      [14, 55, 25]
    ],
    [
      [11, 54, 24],
      [16, 55, 25]
    ],
    [
      [7, 54, 24],
      [22, 55, 25]
    ],
    [
      [28, 50, 22],
      [6, 51, 23]
    ],
    [
      [8, 53, 23],
      [26, 54, 24]
    ],
    [
      [4, 54, 24],
      [31, 55, 25]
    ],
    [
      [1, 53, 23],
      [37, 54, 24]
    ],
    [
      [15, 54, 24],
      [25, 55, 25]
    ],
    [
      [42, 54, 24],
      [1, 55, 25]
    ],
    [
      [10, 54, 24],
      [35, 55, 25]
    ],
    [
      [29, 54, 24],
      [19, 55, 25]
    ],
    [
      [44, 54, 24],
      [7, 55, 25]
    ],
    [
      [39, 54, 24],
      [14, 55, 25]
    ],
    [
      [46, 54, 24],
      [10, 55, 25]
    ],
    [
      [49, 54, 24],
      [10, 55, 25]
    ],
    [
      [48, 54, 24],
      [14, 55, 25]
    ],
    [
      [43, 54, 24],
      [22, 55, 25]
    ],
    [
      [34, 54, 24],
      [34, 55, 25]
    ]
  ],
  H: [
    [[1, 26, 9]],
    [[1, 44, 16]],
    [[2, 35, 13]],
    [[4, 25, 9]],
    [
      [2, 33, 11],
      [2, 34, 12]
    ],
    [[4, 43, 15]],
    [
      [4, 39, 13],
      [1, 40, 14]
    ],
    [
      [4, 40, 14],
      [2, 41, 15]
    ],
    [
      [4, 36, 12],
      [4, 37, 13]
    ],
    [
      [6, 43, 15],
      [2, 44, 16]
    ],
    [
      [3, 36, 12],
      [8, 37, 13]
    ],
    [
      [7, 42, 14],
      [4, 43, 15]
    ],
    [
      [12, 33, 11],
      [4, 34, 12]
    ],
    [
      [11, 36, 12],
      [5, 37, 13]
    ],
    [
      [11, 36, 12],
      [7, 37, 13]
    ],
    [
      [3, 45, 15],
      [13, 46, 16]
    ],
    [
      [2, 42, 14],
      [17, 43, 15]
    ],
    [
      [2, 42, 14],
      [19, 43, 15]
    ],
    [
      [9, 39, 13],
      [16, 40, 14]
    ],
    [
      [15, 43, 15],
      [10, 44, 16]
    ],
    [
      [19, 46, 16],
      [6, 47, 17]
    ],
    [[34, 37, 13]],
    [
      [16, 45, 15],
      [14, 46, 16]
    ],
    [
      [30, 46, 16],
      [2, 47, 17]
    ],
    [
      [22, 45, 15],
      [13, 46, 16]
    ],
    [
      [33, 46, 16],
      [4, 47, 17]
    ],
    [
      [12, 45, 15],
      [28, 46, 16]
    ],
    [
      [11, 45, 15],
      [31, 46, 16]
    ],
    [
      [19, 45, 15],
      [26, 46, 16]
    ],
    [
      [23, 45, 15],
      [25, 46, 16]
    ],
    [
      [23, 45, 15],
      [28, 46, 16]
    ],
    [
      [19, 45, 15],
      [35, 46, 16]
    ],
    [
      [11, 45, 15],
      [46, 46, 16]
    ],
    [
      [59, 46, 16],
      [1, 47, 17]
    ],
    [
      [22, 45, 15],
      [41, 46, 16]
    ],
    [
      [2, 45, 15],
      [64, 46, 16]
    ],
    [
      [24, 45, 15],
      [46, 46, 16]
    ],
    [
      [42, 45, 15],
      [32, 46, 16]
    ],
    [
      [10, 45, 15],
      [67, 46, 16]
    ],
    [
      [20, 45, 15],
      [61, 46, 16]
    ]
  ]
};
function readCodewords(matrix, moduleCount) {
  const codewords = [];
  let currentByte = 0;
  let bitsRead = 0;
  const version = getVersionFromModuleCount(moduleCount);
  const skipCounts = {
    finder: 0,
    separator: 0,
    timing: 0,
    format: 0,
    version: 0,
    alignment: 0,
    darkModule: 0,
    other: 0
  };
  let visitedModules = 0;
  let skippedAsFunction = 0;
  const isSeparator = (row, col) => {
    if (row === 7 && col <= 7 || col === 7 && row <= 7) return true;
    if (row === 7 && col >= moduleCount - 8 || col === moduleCount - 8 && row <= 7) return true;
    if (row === moduleCount - 8 && col <= 7 || col === 7 && row >= moduleCount - 8) return true;
    return false;
  };
  const isDarkModule = (row, col) => row === moduleCount - 8 && col === 8;
  qrDecoderLog.trace("codewords: Starting codeword extraction", {
    moduleCount,
    matrixRows: matrix.length
  });
  let up = true;
  for (let col = moduleCount - 1; col >= 1; col -= 2) {
    if (col === 6) col = 5;
    for (let row = up ? moduleCount - 1 : 0; up ? row >= 0 : row < moduleCount; row += up ? -1 : 1) {
      for (let c = 0; c < 2; c++) {
        const currentCol = col - c;
        visitedModules++;
        if (!isStructuralModule(row, currentCol, moduleCount, version)) {
          currentByte = currentByte << 1 | (matrix[row]?.[currentCol] ? 1 : 0);
          bitsRead++;
          if (bitsRead === 8) {
            codewords.push(currentByte);
            currentByte = 0;
            bitsRead = 0;
          }
        } else {
          skippedAsFunction++;
          if (isFinderPattern(row, currentCol, moduleCount)) skipCounts.finder++;
          else if (isSeparator(row, currentCol)) skipCounts.separator++;
          else if (isTimingPattern(row, currentCol, moduleCount)) skipCounts.timing++;
          else if (isFormatInfo(row, currentCol, moduleCount)) skipCounts.format++;
          else if (isVersionInfo(row, currentCol, moduleCount, version)) skipCounts.version++;
          else if (isAlignmentPattern(row, currentCol, moduleCount, version))
            skipCounts.alignment++;
          else if (isDarkModule(row, currentCol)) skipCounts.darkModule++;
          else skipCounts.other++;
        }
      }
    }
    up = !up;
  }
  qrDecoderLog.trace("codewords: Extracted codewords", {
    count: codewords.length,
    first10: codewords.slice(0, 10).map((c) => c.toString(16).padStart(2, "0")).join(" "),
    traversal: {
      visitedModules,
      skippedAsFunction,
      skipCounts
    }
  });
  return codewords;
}
function modeToName(mode) {
  switch (mode) {
    case MODE_NUMERIC2:
      return "numeric";
    case MODE_ALPHANUMERIC2:
      return "alphanumeric";
    case MODE_BYTE2:
      return "byte";
    case MODE_KANJI2:
      return "kanji";
    case MODE_ECI:
      return "eci";
    case MODE_TERMINATOR2:
      return "terminator";
    default:
      return "unknown";
  }
}
function decodeDataCodewordsDetailed(dataCodewords, version) {
  const bits = new BitStream(dataCodewords);
  let text = "";
  const outBytes = [];
  const modesSeen = /* @__PURE__ */ new Set();
  const segments = [];
  let segmentIndex = 0;
  let valid = true;
  let foundTerminator = false;
  let primarySegmentEnded = false;
  let hasExtraSegmentsAfterPrimary = false;
  qrDecoderLog.trace("decode: Starting data decode (detailed)", {
    dataCodewords: dataCodewords.length,
    version
  });
  while (bits.available() >= 4) {
    const bitOffset = dataCodewords.length * 8 - bits.available();
    const mode = bits.read(4);
    if (mode === MODE_TERMINATOR2) {
      qrDecoderLog.trace("decode: Found terminator", { segmentIndex: segmentIndex + 1 });
      segments.push({
        index: segmentIndex,
        mode,
        modeName: "terminator",
        charCount: 0,
        decodedLength: 0,
        valid: true,
        bitOffset
      });
      segmentIndex++;
      foundTerminator = true;
      break;
    }
    const charCountBits = getCharCountBits(mode, version);
    if (bits.available() < charCountBits) {
      qrDecoderLog.debug("decode: Not enough bits for char count - decode invalid", {
        mode,
        charCountBits,
        available: bits.available()
      });
      segments.push({
        index: segmentIndex,
        mode,
        modeName: modeToName(mode),
        charCount: -1,
        // Unknown - couldn't read
        decodedLength: 0,
        valid: false,
        bitOffset
      });
      segmentIndex++;
      valid = false;
      if (primarySegmentEnded) {
        hasExtraSegmentsAfterPrimary = true;
      }
      break;
    }
    const charCount = bits.read(charCountBits);
    if (charCount > 7e3) {
      qrDecoderLog.debug("decode: Unreasonable char count, aborting - decode invalid", {
        charCount,
        mode
      });
      segments.push({
        index: segmentIndex,
        mode,
        modeName: modeToName(mode),
        charCount,
        decodedLength: 0,
        valid: false,
        bitOffset
      });
      segmentIndex++;
      valid = false;
      if (primarySegmentEnded) {
        hasExtraSegmentsAfterPrimary = true;
      }
      break;
    }
    let decodedText = "";
    let decodedBytes = [];
    let modeTag = "unknown";
    let segmentValid = true;
    switch (mode) {
      case MODE_NUMERIC2: {
        decodedText = decodeNumeric(bits, charCount);
        modeTag = "numeric";
        for (let i = 0; i < decodedText.length; i++)
          outBytes.push(decodedText.charCodeAt(i) & 255);
        if (decodedText.length !== charCount) {
          qrDecoderLog.debug("decode: Numeric segment truncated - decode invalid", {
            expected: charCount,
            got: decodedText.length
          });
          segmentValid = false;
        }
        break;
      }
      case MODE_ALPHANUMERIC2: {
        decodedText = decodeAlphanumeric(bits, charCount);
        modeTag = "alphanumeric";
        for (let i = 0; i < decodedText.length; i++)
          outBytes.push(decodedText.charCodeAt(i) & 255);
        if (decodedText.length !== charCount) {
          qrDecoderLog.debug("decode: Alphanumeric segment truncated - decode invalid", {
            expected: charCount,
            got: decodedText.length
          });
          segmentValid = false;
        }
        break;
      }
      case MODE_BYTE2: {
        const r = decodeByteDetailed(bits, charCount);
        decodedText = r.text;
        decodedBytes = r.bytes;
        modeTag = "byte";
        for (const b of decodedBytes) outBytes.push(b);
        if (decodedBytes.length !== charCount) {
          qrDecoderLog.debug("decode: Byte segment truncated - decode invalid", {
            expected: charCount,
            got: decodedBytes.length
          });
          segmentValid = false;
        }
        break;
      }
      case MODE_KANJI2: {
        const r = decodeKanjiDetailed(bits, charCount);
        decodedText = r.text;
        decodedBytes = r.bytes;
        modeTag = "kanji";
        for (const b of decodedBytes) outBytes.push(b);
        if (decodedBytes.length !== charCount * 2) {
          qrDecoderLog.debug("decode: Kanji segment truncated - decode invalid", {
            expected: charCount * 2,
            got: decodedBytes.length
          });
          segmentValid = false;
        }
        break;
      }
      default: {
        qrDecoderLog.debug("decode: Unknown mode indicator - decode invalid", { mode });
        modeTag = "unknown";
        segmentValid = false;
        break;
      }
    }
    const decodedLength = modeTag === "kanji" ? decodedBytes.length / 2 : modeTag === "byte" ? decodedBytes.length : decodedText.length;
    segments.push({
      index: segmentIndex,
      mode,
      modeName: modeToName(mode),
      charCount,
      decodedLength,
      valid: segmentValid,
      bitOffset
    });
    segmentIndex++;
    if (!segmentValid) {
      valid = false;
      if (primarySegmentEnded) {
        hasExtraSegmentsAfterPrimary = true;
      }
    } else {
      if (modeTag !== "unknown") {
        primarySegmentEnded = true;
      }
    }
    if (modeTag !== "unknown") modesSeen.add(modeTag);
    text += decodedText;
    qrDecoderLog.trace(`decode: Decoded segment ${segmentIndex}`, {
      mode: modeTag,
      charCount,
      textLen: decodedText.length,
      bytesLen: decodedBytes.length,
      segmentValid,
      preview: decodedText.slice(0, 50)
    });
    if (!segmentValid) {
      break;
    }
  }
  const encodingMode = (() => {
    if (modesSeen.size === 1) {
      for (const m of modesSeen) return m;
    }
    if (modesSeen.size > 1) return "mixed";
    return "unknown";
  })();
  const structurallyValid = valid && !hasExtraSegmentsAfterPrimary;
  qrDecoderLog.trace("decode: Data decode complete", {
    valid,
    structurallyValid,
    foundTerminator,
    hasExtraSegmentsAfterPrimary,
    segmentCount: segments.length,
    segmentModes: segments.map((s) => s.modeName),
    textLength: text.length,
    bytesLength: outBytes.length,
    encodingMode
  });
  return {
    text,
    bytes: new Uint8Array(outBytes),
    encodingMode,
    valid,
    structurallyValid,
    segmentCount: segments.length,
    segments
  };
}
function getCharCountBits(mode, version) {
  if (version <= 9) {
    switch (mode) {
      case MODE_NUMERIC2:
        return 10;
      case MODE_ALPHANUMERIC2:
        return 9;
      case MODE_BYTE2:
        return 8;
      case MODE_KANJI2:
        return 8;
    }
  } else if (version <= 26) {
    switch (mode) {
      case MODE_NUMERIC2:
        return 12;
      case MODE_ALPHANUMERIC2:
        return 11;
      case MODE_BYTE2:
        return 16;
      case MODE_KANJI2:
        return 10;
    }
  } else {
    switch (mode) {
      case MODE_NUMERIC2:
        return 14;
      case MODE_ALPHANUMERIC2:
        return 13;
      case MODE_BYTE2:
        return 16;
      case MODE_KANJI2:
        return 12;
    }
  }
  return 8;
}
function decodeNumeric(bits, count) {
  let result = "";
  let remaining = count;
  while (remaining >= 3) {
    if (bits.available() < 10) break;
    const value = bits.read(10);
    if (value > 999) {
      qrDecoderLog.debug("numeric: Invalid 3-digit value", { value });
      result += "???";
    } else {
      result += value.toString().padStart(3, "0");
    }
    remaining -= 3;
  }
  if (remaining === 2 && bits.available() >= 7) {
    const value = bits.read(7);
    if (value > 99) {
      qrDecoderLog.debug("numeric: Invalid 2-digit value", { value });
      result += "??";
    } else {
      result += value.toString().padStart(2, "0");
    }
  } else if (remaining === 1 && bits.available() >= 4) {
    const value = bits.read(4);
    if (value > 9) {
      qrDecoderLog.debug("numeric: Invalid 1-digit value", { value });
      result += "?";
    } else {
      result += value.toString();
    }
  }
  return result;
}
function decodeAlphanumeric(bits, count) {
  let result = "";
  let remaining = count;
  while (remaining >= 2) {
    if (bits.available() < 11) break;
    const value = bits.read(11);
    const c1 = Math.floor(value / 45);
    const c2 = value % 45;
    if (c1 >= 0 && c1 < ALPHANUMERIC_CHARS.length && c2 >= 0 && c2 < ALPHANUMERIC_CHARS.length) {
      result += ALPHANUMERIC_CHARS[c1] + ALPHANUMERIC_CHARS[c2];
    } else {
      qrDecoderLog.debug("alphanumeric: Invalid character index", { value, c1, c2 });
      result += "??";
    }
    remaining -= 2;
  }
  if (remaining === 1 && bits.available() >= 6) {
    const value = bits.read(6);
    if (value >= 0 && value < ALPHANUMERIC_CHARS.length) {
      result += ALPHANUMERIC_CHARS[value];
    } else {
      qrDecoderLog.debug("alphanumeric: Invalid single character index", { value });
      result += "?";
    }
  }
  return result;
}
function decodeByteDetailed(bits, count) {
  const bytes = [];
  for (let i = 0; i < count; i++) {
    if (bits.available() < 8) break;
    bytes.push(bits.read(8));
  }
  let utf8Text = "";
  try {
    utf8Text = new TextDecoder("utf-8").decode(new Uint8Array(bytes));
  } catch {
    utf8Text = "";
  }
  if (utf8Text.includes("\uFFFD")) {
    const latin1 = String.fromCharCode(...bytes);
    return { text: latin1, bytes };
  }
  if (utf8Text.length > 0) return { text: utf8Text, bytes };
  return { text: String.fromCharCode(...bytes), bytes };
}
function decodeKanjiDetailed(bits, count) {
  const bytes = [];
  for (let i = 0; i < count; i++) {
    if (bits.available() < 13) break;
    let value = bits.read(13);
    const byte1 = Math.floor(value / 192);
    const byte2 = value % 192;
    value = byte1 << 8 | byte2;
    if (value < 7936) {
      value += 33088;
    } else {
      value += 49472;
    }
    bytes.push(value >> 8 & 255);
    bytes.push(value & 255);
  }
  let text = "";
  try {
    text = new TextDecoder("shift-jis").decode(new Uint8Array(bytes));
  } catch {
    text = "";
  }
  return { text, bytes };
}
var BitStream = class {
  bytes;
  byteIndex = 0;
  bitIndex = 0;
  constructor(bytes) {
    this.bytes = bytes;
  }
  available() {
    return (this.bytes.length - this.byteIndex) * 8 - this.bitIndex;
  }
  read(numBits) {
    let result = 0;
    for (let i = 0; i < numBits; i++) {
      if (this.byteIndex >= this.bytes.length) return result;
      const bit = this.bytes[this.byteIndex] >> 7 - this.bitIndex & 1;
      result = result << 1 | bit;
      this.bitIndex++;
      if (this.bitIndex === 8) {
        this.bitIndex = 0;
        this.byteIndex++;
      }
    }
    return result;
  }
};

// src/modules/qr-decoder/utils.ts
var _log79 = createLogger("DECODER");
function pointDistance(a, b) {
  return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2);
}

// src/modules/qr-decoder/extract.ts
var qrDecoderLog2 = createLogger("DECODER");
var BLOCK_SIZE_POWER = 3;
var BLOCK_SIZE = 1 << BLOCK_SIZE_POWER;
var BLOCK_SIZE_MASK = BLOCK_SIZE - 1;
function calculateLocation(topLeft, topRight, bottomLeft) {
  const moduleSize = (topLeft.moduleSize + topRight.moduleSize + bottomLeft.moduleSize) / 3;
  const topDist = pointDistance(topLeft.center, topRight.center);
  const leftDist = pointDistance(topLeft.center, bottomLeft.center);
  const avgDist = (topDist + leftDist) / 2;
  const moduleSpan = avgDist / moduleSize;
  const rawModuleCount = moduleSpan + 7;
  const version = Math.round((rawModuleCount - 17) / 4);
  const clampedVersion = Math.max(1, Math.min(40, version));
  const moduleCount = clampedVersion * 4 + 17;
  qrDecoderLog2.trace("extract: Calculated location", {
    moduleSize: moduleSize.toFixed(2),
    topDist: topDist.toFixed(1),
    leftDist: leftDist.toFixed(1),
    avgDist: avgDist.toFixed(1),
    moduleSpan: moduleSpan.toFixed(1),
    rawModuleCount: rawModuleCount.toFixed(1),
    version: clampedVersion,
    moduleCount
  });
  const bottomRight = {
    x: topRight.center.x + (bottomLeft.center.x - topLeft.center.x),
    y: topRight.center.y + (bottomLeft.center.y - topLeft.center.y)
  };
  return {
    topLeft: topLeft.center,
    topRight: topRight.center,
    bottomLeft: bottomLeft.center,
    bottomRight,
    moduleSize,
    moduleCount
  };
}
function sampleSinglePixel(pixels, width, height, x, y) {
  const ix = Math.round(x);
  const iy = Math.round(y);
  if (ix < 0 || ix >= width || iy < 0 || iy >= height) {
    return 255;
  }
  const idx = (iy * width + ix) * 4;
  const a = pixels[idx + 3] / 255;
  if (a <= 0) return 255;
  if (a >= 1) return (pixels[idx] + pixels[idx + 1] + pixels[idx + 2]) / 3;
  const inv = 1 - a;
  const r = pixels[idx] * a + 255 * inv;
  const g = pixels[idx + 1] * a + 255 * inv;
  const b = pixels[idx + 2] * a + 255 * inv;
  return (r + g + b) / 3;
}
function extractModuleMatrix(imageData, location, globalThreshold) {
  const { data: pixels, width, height } = imageData;
  const { moduleCount } = location;
  const finderOffset = 3.5;
  const moduleSpan = moduleCount - 7;
  const topDist = Math.sqrt(
    (location.topRight.x - location.topLeft.x) ** 2 + (location.topRight.y - location.topLeft.y) ** 2
  );
  const leftDist = Math.sqrt(
    (location.bottomLeft.x - location.topLeft.x) ** 2 + (location.bottomLeft.y - location.topLeft.y) ** 2
  );
  const avgDist = (topDist + leftDist) / 2;
  const unifiedPitch = avgDist / moduleSpan;
  const rightDirX = (location.topRight.x - location.topLeft.x) / topDist;
  const rightDirY = (location.topRight.y - location.topLeft.y) / topDist;
  const downDirX = (location.bottomLeft.x - location.topLeft.x) / leftDist;
  const downDirY = (location.bottomLeft.y - location.topLeft.y) / leftDist;
  const rightVec = {
    x: rightDirX * unifiedPitch,
    y: rightDirY * unifiedPitch
  };
  const downVec = {
    x: downDirX * unifiedPitch,
    y: downDirY * unifiedPitch
  };
  qrDecoderLog2.trace("extract: Unified pitch calculation", {
    topDist: topDist.toFixed(2),
    leftDist: leftDist.toFixed(2),
    avgDist: avgDist.toFixed(2),
    moduleSpan,
    unifiedPitch: unifiedPitch.toFixed(3),
    originalRightMag: (topDist / moduleSpan).toFixed(3),
    originalDownMag: (leftDist / moduleSpan).toFixed(3),
    driftPerModule: Math.abs(topDist / moduleSpan - leftDist / moduleSpan).toFixed(4),
    totalDriftOver29Modules: (Math.abs(topDist / moduleSpan - leftDist / moduleSpan) * 29).toFixed(
      2
    )
  });
  const origin = {
    x: location.topLeft.x - finderOffset * rightVec.x - finderOffset * downVec.x,
    y: location.topLeft.y - finderOffset * rightVec.y - finderOffset * downVec.y
  };
  const verifyTopLeft = {
    x: origin.x + finderOffset * rightVec.x + finderOffset * downVec.x,
    y: origin.y + finderOffset * rightVec.y + finderOffset * downVec.y
  };
  const topLeftError = Math.sqrt(
    (verifyTopLeft.x - location.topLeft.x) ** 2 + (verifyTopLeft.y - location.topLeft.y) ** 2
  );
  const verifyTopRight = {
    x: origin.x + (moduleCount - finderOffset) * rightVec.x + finderOffset * downVec.x,
    y: origin.y + (moduleCount - finderOffset) * rightVec.y + finderOffset * downVec.y
  };
  const topRightError = Math.sqrt(
    (verifyTopRight.x - location.topRight.x) ** 2 + (verifyTopRight.y - location.topRight.y) ** 2
  );
  const verifyBottomLeft = {
    x: origin.x + finderOffset * rightVec.x + (moduleCount - finderOffset) * downVec.x,
    y: origin.y + finderOffset * rightVec.y + (moduleCount - finderOffset) * downVec.y
  };
  const bottomLeftError = Math.sqrt(
    (verifyBottomLeft.x - location.bottomLeft.x) ** 2 + (verifyBottomLeft.y - location.bottomLeft.y) ** 2
  );
  qrDecoderLog2.trace("extract: Origin validation", {
    origin: `(${origin.x.toFixed(1)}, ${origin.y.toFixed(1)})`,
    rightVec: `(${rightVec.x.toFixed(2)}, ${rightVec.y.toFixed(2)})`,
    downVec: `(${downVec.x.toFixed(2)}, ${downVec.y.toFixed(2)})`,
    topLeftExpected: `(${location.topLeft.x.toFixed(1)}, ${location.topLeft.y.toFixed(1)})`,
    topLeftComputed: `(${verifyTopLeft.x.toFixed(1)}, ${verifyTopLeft.y.toFixed(1)})`,
    topLeftError: topLeftError.toFixed(2),
    topRightExpected: `(${location.topRight.x.toFixed(1)}, ${location.topRight.y.toFixed(1)})`,
    topRightComputed: `(${verifyTopRight.x.toFixed(1)}, ${verifyTopRight.y.toFixed(1)})`,
    topRightError: topRightError.toFixed(2),
    bottomLeftExpected: `(${location.bottomLeft.x.toFixed(1)}, ${location.bottomLeft.y.toFixed(1)})`,
    bottomLeftComputed: `(${verifyBottomLeft.x.toFixed(1)}, ${verifyBottomLeft.y.toFixed(1)})`,
    bottomLeftError: bottomLeftError.toFixed(2)
  });
  if (topLeftError > 1 || topRightError > 1 || bottomLeftError > 1) {
    qrDecoderLog2.debug("extract: Finder center mapping errors detected", {
      topLeftError: topLeftError.toFixed(2),
      topRightError: topRightError.toFixed(2),
      bottomLeftError: bottomLeftError.toFixed(2)
    });
  }
  qrDecoderLog2.trace("extract: Sampling configuration", {
    moduleSize: location.moduleSize.toFixed(1),
    samplingMode: "global threshold (from finder patterns)",
    globalThreshold: globalThreshold.toFixed(1)
  });
  const finderPattern = [
    [1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 1, 0, 1],
    [1, 0, 1, 1, 1, 0, 1],
    [1, 0, 1, 1, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1]
  ];
  const matrix = [];
  let totalDarkModules = 0;
  let totalLightModules = 0;
  for (let row = 0; row < moduleCount; row++) {
    const matrixRow = [];
    for (let col = 0; col < moduleCount; col++) {
      const x = origin.x + (col + 0.5) * rightVec.x + (row + 0.5) * downVec.x;
      const y = origin.y + (col + 0.5) * rightVec.y + (row + 0.5) * downVec.y;
      const gray = sampleSinglePixel(pixels, width, height, x, y);
      const isDark2 = gray < globalThreshold;
      matrixRow.push(isDark2);
      if (isDark2) totalDarkModules++;
      else totalLightModules++;
    }
    matrix.push(matrixRow);
  }
  qrDecoderLog2.trace("extract: Extracted matrix", {
    moduleCount,
    thresholdMode: "global (from finder patterns)",
    threshold: globalThreshold.toFixed(1),
    darkModules: totalDarkModules,
    lightModules: totalLightModules,
    darkRatio: `${(totalDarkModules / (totalDarkModules + totalLightModules) * 100).toFixed(1)}%`
  });
  let tlMatches = 0;
  let tlMismatches = 0;
  const tlErrors = [];
  for (let row = 0; row < 7; row++) {
    for (let col = 0; col < 7; col++) {
      const expected = finderPattern[row][col] === 1;
      const actual = matrix[row]?.[col] ?? false;
      if (expected === actual) {
        tlMatches++;
      } else {
        tlMismatches++;
        if (tlErrors.length < 5) {
          tlErrors.push(
            `(${row},${col}): expected ${expected ? "dark" : "light"}, got ${actual ? "dark" : "light"}`
          );
        }
      }
    }
  }
  qrDecoderLog2.trace("extract: Top-left finder pattern validation", {
    matches: tlMatches,
    mismatches: tlMismatches,
    accuracy: `${(tlMatches / 49 * 100).toFixed(1)}%`,
    errors: tlErrors.length > 0 ? tlErrors : "none"
  });
  let trMatches = 0;
  let trMismatches = 0;
  const trErrors = [];
  const trColOffset = moduleCount - 7;
  for (let row = 0; row < 7; row++) {
    for (let col = 0; col < 7; col++) {
      const expected = finderPattern[row][col] === 1;
      const actual = matrix[row]?.[trColOffset + col] ?? false;
      if (expected === actual) {
        trMatches++;
      } else {
        trMismatches++;
        if (trErrors.length < 5) {
          trErrors.push(
            `(${row},${trColOffset + col}): expected ${expected ? "dark" : "light"}, got ${actual ? "dark" : "light"}`
          );
        }
      }
    }
  }
  qrDecoderLog2.trace("extract: Top-right finder pattern validation", {
    matches: trMatches,
    mismatches: trMismatches,
    accuracy: `${(trMatches / 49 * 100).toFixed(1)}%`,
    errors: trErrors.length > 0 ? trErrors : "none"
  });
  const tlAccuracy = tlMatches / 49;
  const trAccuracy = trMatches / 49;
  if (tlMismatches > 20 || trMismatches > 20) {
    qrDecoderLog2.debug("extract: Finder pattern accuracy very low - matrix may be mis-oriented", {
      topLeftAccuracy: `${(tlAccuracy * 100).toFixed(1)}%`,
      topRightAccuracy: `${(trAccuracy * 100).toFixed(1)}%`
    });
  }
  if (tlAccuracy > 0.8 && trAccuracy < 0.5) {
    qrDecoderLog2.debug(
      "extract: Possible 180\xB0 rotation detected - top-left OK but top-right wrong"
    );
  } else if (trAccuracy > 0.8 && tlAccuracy < 0.5) {
    qrDecoderLog2.debug(
      "extract: Possible 180\xB0 rotation detected - top-right OK but top-left wrong"
    );
  }
  return matrix;
}

// src/modules/qr-decoder/format.ts
var qrDecoderLog3 = createLogger("DECODER");
var FORMAT_INFO_DECODE_TABLE = /* @__PURE__ */ new Map();
function initFormatTable() {
  if (FORMAT_INFO_DECODE_TABLE.size > 0) return;
  const G152 = 1335;
  const G15_MASK2 = 21522;
  for (let eccLevel = 0; eccLevel < 4; eccLevel++) {
    for (let mask = 0; mask < 8; mask++) {
      const data = eccLevel << 3 | mask;
      let bits = data << 10;
      for (let i = 4; i >= 0; i--) {
        if (bits & 1 << i + 10) {
          bits ^= G152 << i;
        }
      }
      const encoded = (data << 10 | bits) ^ G15_MASK2;
      FORMAT_INFO_DECODE_TABLE.set(encoded, { eccLevel, maskPattern: mask });
    }
  }
}
function hammingDistance(a, b) {
  let diff = a ^ b;
  let count = 0;
  while (diff) {
    count += diff & 1;
    diff >>>= 1;
  }
  return count;
}
function readFormatInfo(matrix, moduleCount) {
  initFormatTable();
  const trace1 = [];
  const trace2 = [];
  let bits1 = 0;
  for (let i = 0; i <= 5; i++) {
    const row = i;
    const col = 8;
    const value = matrix[row]?.[col] ?? false;
    if (value) bits1 |= 1 << i;
    trace1.push({ bit: i, row, col, value });
  }
  {
    const row = 7;
    const col = 8;
    const value = matrix[row]?.[col] ?? false;
    if (value) bits1 |= 1 << 6;
    trace1.push({ bit: 6, row, col, value });
  }
  {
    const row = 8;
    const col = 8;
    const value = matrix[row]?.[col] ?? false;
    if (value) bits1 |= 1 << 7;
    trace1.push({ bit: 7, row, col, value });
  }
  {
    const row = 8;
    const col = 7;
    const value = matrix[row]?.[col] ?? false;
    if (value) bits1 |= 1 << 8;
    trace1.push({ bit: 8, row, col, value });
  }
  for (let i = 9; i <= 14; i++) {
    const row = 8;
    const col = 14 - i;
    const value = matrix[row]?.[col] ?? false;
    if (value) bits1 |= 1 << i;
    trace1.push({ bit: i, row, col, value });
  }
  let bits2 = 0;
  for (let i = 0; i <= 7; i++) {
    const row = 8;
    const col = moduleCount - 1 - i;
    const value = matrix[row]?.[col] ?? false;
    if (value) bits2 |= 1 << i;
    trace2.push({ bit: i, row, col, value });
  }
  for (let i = 8; i <= 14; i++) {
    const row = moduleCount - 15 + i;
    const col = 8;
    const value = matrix[row]?.[col] ?? false;
    if (value) bits2 |= 1 << i;
    trace2.push({ bit: i, row, col, value });
  }
  qrDecoderLog3.trace("format: Read format bits with trace", {
    bits1: bits1.toString(2).padStart(15, "0"),
    bits2: bits2.toString(2).padStart(15, "0"),
    bits1Hex: `0x${bits1.toString(16).padStart(4, "0")}`,
    bits2Hex: `0x${bits2.toString(16).padStart(4, "0")}`,
    moduleCount,
    trace1: trace1.map((t) => `bit${t.bit}:(${t.row},${t.col})=${t.value ? 1 : 0}`).join(" "),
    trace2: trace2.map((t) => `bit${t.bit}:(${t.row},${t.col})=${t.value ? 1 : 0}`).join(" ")
  });
  let bestMatch = null;
  let bestDistance = 4;
  let bestDistCopy1 = 15;
  let bestDistCopy2 = 15;
  let bestFromCopy = 0;
  for (const [pattern, info] of FORMAT_INFO_DECODE_TABLE) {
    const d1 = hammingDistance(bits1, pattern);
    const d2 = hammingDistance(bits2, pattern);
    const minD = Math.min(d1, d2);
    if (minD < bestDistance) {
      bestDistance = minD;
      bestDistCopy1 = d1;
      bestDistCopy2 = d2;
      bestFromCopy = d1 <= d2 ? 1 : 2;
      bestMatch = info;
    }
  }
  if (bestMatch) {
    const eccChar = ECC_LEVEL_MAP2[bestMatch.eccLevel];
    qrDecoderLog3.trace("format: Decoded format info", {
      eccLevel: bestMatch.eccLevel,
      eccChar,
      maskPattern: bestMatch.maskPattern,
      hammingDistance: bestDistance,
      hammingDistCopy1: bestDistCopy1,
      hammingDistCopy2: bestDistCopy2,
      usedCopy: bestFromCopy
    });
  } else {
    qrDecoderLog3.trace("format: Failed to decode format info", {
      bits1: bits1.toString(2).padStart(15, "0"),
      bits2: bits2.toString(2).padStart(15, "0"),
      bits1Hex: `0x${bits1.toString(16).padStart(4, "0")}`,
      bits2Hex: `0x${bits2.toString(16).padStart(4, "0")}`
    });
  }
  return bestMatch;
}
function getECCLevelChar(eccLevel) {
  return ECC_LEVEL_MAP2[eccLevel] || "M";
}
var getMaskFunction3 = getMaskFunction;
function unmaskMatrix(matrix, maskPattern, moduleCount) {
  const maskFunc = getMaskFunction3(maskPattern);
  const unmasked = [];
  const version = getVersionFromModuleCount(moduleCount);
  for (let row = 0; row < moduleCount; row++) {
    const unmaskedRow = [];
    for (let col = 0; col < moduleCount; col++) {
      let value = matrix[row]?.[col] ?? false;
      if (!isStructuralModule(row, col, moduleCount, version)) {
        if (maskFunc(row, col)) {
          value = !value;
        }
      }
      unmaskedRow.push(value);
    }
    unmasked.push(unmaskedRow);
  }
  return unmasked;
}

// src/modules/qr-decoder/locate.ts
var qrDecoderLog4 = createLogger("DECODER");
function grayAt(pixels, idx) {
  const a = pixels[idx + 3] / 255;
  if (a <= 0) return 255;
  if (a >= 1) return (pixels[idx] + pixels[idx + 1] + pixels[idx + 2]) / 3;
  const inv = 1 - a;
  const r = pixels[idx] * a + 255 * inv;
  const g = pixels[idx + 1] * a + 255 * inv;
  const b = pixels[idx + 2] * a + 255 * inv;
  return (r + g + b) / 3;
}
function isFinderPatternRatio(counts) {
  const total = counts.reduce((a, b) => a + b, 0);
  if (total < 7) return false;
  const moduleSize = total / 7;
  const tolerance = moduleSize * 0.5;
  return Math.abs(counts[0] - moduleSize) < tolerance && Math.abs(counts[1] - moduleSize) < tolerance && Math.abs(counts[2] - 3 * moduleSize) < tolerance && Math.abs(counts[3] - moduleSize) < tolerance && Math.abs(counts[4] - moduleSize) < tolerance;
}
function scanRow(pixels, width, y, threshold2) {
  const results = [];
  const counts = [0, 0, 0, 0, 0];
  let state = 0;
  for (let x = 0; x < width; x++) {
    const idx = (y * width + x) * 4;
    const gray = grayAt(pixels, idx);
    const isDark2 = gray < threshold2;
    if (isDark2) {
      if (state === 1 || state === 3) {
        state++;
      }
      counts[state]++;
    } else {
      if (state === 0 || state === 2 || state === 4) {
        if (state === 4) {
          if (isFinderPatternRatio(counts)) {
            const total = counts.reduce((a, b) => a + b, 0);
            const center = x - total / 2;
            results.push({
              center,
              moduleSize: total / 7
            });
          }
          counts[0] = counts[2];
          counts[1] = counts[3];
          counts[2] = counts[4];
          counts[3] = 1;
          counts[4] = 0;
          state = 3;
        } else {
          state++;
          counts[state]++;
        }
      } else {
        counts[state]++;
      }
    }
  }
  if (state === 4 && isFinderPatternRatio(counts)) {
    const total = counts.reduce((a, b) => a + b, 0);
    const center = width - total / 2;
    results.push({
      center,
      moduleSize: total / 7
    });
  }
  return results;
}
function verifyVertical(pixels, width, height, x, y, expectedModuleSize, threshold2) {
  const counts = [0, 0, 0, 0, 0];
  let state = 2;
  for (let row = Math.floor(y); row >= 0; row--) {
    const idx = (row * width + Math.floor(x)) * 4;
    const gray = grayAt(pixels, idx);
    const isDark2 = gray < threshold2;
    if (state === 2) {
      if (isDark2) counts[2]++;
      else {
        state = 1;
        counts[1]++;
      }
    } else if (state === 1) {
      if (!isDark2) counts[1]++;
      else {
        state = 0;
        counts[0]++;
      }
    } else if (state === 0) {
      if (isDark2) counts[0]++;
      else break;
    }
  }
  state = 2;
  for (let row = Math.floor(y) + 1; row < height; row++) {
    const idx = (row * width + Math.floor(x)) * 4;
    const gray = grayAt(pixels, idx);
    const isDark2 = gray < threshold2;
    if (state === 2) {
      if (isDark2) counts[2]++;
      else {
        state = 3;
        counts[3]++;
      }
    } else if (state === 3) {
      if (!isDark2) counts[3]++;
      else {
        state = 4;
        counts[4]++;
      }
    } else if (state === 4) {
      if (isDark2) counts[4]++;
      else break;
    }
  }
  if (!isFinderPatternRatio(counts)) {
    return { valid: false, center: y, moduleSize: expectedModuleSize };
  }
  const total = counts.reduce((a, b) => a + b, 0);
  const moduleSize = total / 7;
  const moduleSizeError = Math.abs(moduleSize - expectedModuleSize);
  if (moduleSizeError > expectedModuleSize * 0.5) {
    return { valid: false, center: y, moduleSize: expectedModuleSize };
  }
  const newCenter = y + (counts[3] + counts[4] - counts[0] - counts[1]) / 2;
  return { valid: true, center: newCenter, moduleSize };
}
function findFinderPatterns(imageData) {
  const { data: pixels, width, height } = imageData;
  qrDecoderLog4.trace("locate: Finding finder patterns", { width, height });
  let sum = 0;
  let count = 0;
  for (let i = 0; i < pixels.length; i += 4) {
    sum += grayAt(pixels, i);
    count++;
  }
  const threshold2 = sum / count;
  qrDecoderLog4.trace("locate: Calculated threshold", { threshold: threshold2.toFixed(1) });
  const candidates = /* @__PURE__ */ new Map();
  const step = Math.max(1, Math.floor(height / 100));
  for (let y = step; y < height - step; y += step) {
    const rowResults = scanRow(pixels, width, y, threshold2);
    for (const result of rowResults) {
      const vertical = verifyVertical(
        pixels,
        width,
        height,
        result.center,
        y,
        result.moduleSize,
        threshold2
      );
      if (vertical.valid) {
        const refined = refineFinderPatternCenter(
          pixels,
          width,
          height,
          result.center,
          vertical.center,
          vertical.moduleSize,
          threshold2
        );
        const gridSize = vertical.moduleSize * 5;
        const gridX = Math.round(refined.x / gridSize);
        const gridY = Math.round(refined.y / gridSize);
        const key = `${gridX},${gridY}`;
        const existing = candidates.get(key);
        if (!existing || existing.count < 10) {
          candidates.set(key, {
            center: { x: refined.x, y: refined.y },
            moduleSize: vertical.moduleSize,
            count: (existing?.count || 0) + 1
          });
        }
      }
    }
  }
  const patterns = Array.from(candidates.values()).filter((p) => p.count >= 1).sort((a, b) => b.count - a.count);
  qrDecoderLog4.trace("locate: Found finder pattern candidates", {
    count: patterns.length,
    patterns: patterns.slice(0, 5).map((p) => ({
      x: p.center.x.toFixed(1),
      y: p.center.y.toFixed(1),
      moduleSize: p.moduleSize.toFixed(2),
      hitCount: p.count
    }))
  });
  return { patterns, threshold: threshold2 };
}
var DARK_CORE_MODULES = [
  [2, 2],
  [3, 2],
  [4, 2],
  [2, 3],
  [3, 3],
  [4, 3],
  [2, 4],
  [3, 4],
  [4, 4]
];
var WHITE_RING_MODULES = [
  [1, 2],
  [1, 3],
  [1, 4],
  // left column of white ring
  [5, 2],
  [5, 3],
  [5, 4],
  // right column of white ring
  [2, 1],
  [3, 1],
  [4, 1],
  // top row of white ring
  [2, 5],
  [3, 5],
  [4, 5]
  // bottom row of white ring
];
function computeFinderContrast(pixels, width, height, testX, testY, moduleSize) {
  const finderOriginX = testX - 3.5 * moduleSize;
  const finderOriginY = testY - 3.5 * moduleSize;
  let darkSum = 0;
  let darkCount = 0;
  for (const [col, row] of DARK_CORE_MODULES) {
    const px = Math.round(finderOriginX + (col + 0.5) * moduleSize);
    const py = Math.round(finderOriginY + (row + 0.5) * moduleSize);
    if (px >= 0 && px < width && py >= 0 && py < height) {
      const idx = (py * width + px) * 4;
      darkSum += grayAt(pixels, idx);
      darkCount++;
    }
  }
  let lightSum = 0;
  let lightCount = 0;
  for (const [col, row] of WHITE_RING_MODULES) {
    const px = Math.round(finderOriginX + (col + 0.5) * moduleSize);
    const py = Math.round(finderOriginY + (row + 0.5) * moduleSize);
    if (px >= 0 && px < width && py >= 0 && py < height) {
      const idx = (py * width + px) * 4;
      lightSum += grayAt(pixels, idx);
      lightCount++;
    }
  }
  const avgDark = darkCount > 0 ? darkSum / darkCount : 127;
  const avgLight = lightCount > 0 ? lightSum / lightCount : 127;
  const contrast2 = avgLight - avgDark;
  return { avgDark, avgLight, contrast: contrast2 };
}
function scoreFinderCenter(pixels, width, height, testX, testY, moduleSize, threshold2) {
  const finderOriginX = testX - 3.5 * moduleSize;
  const finderOriginY = testY - 3.5 * moduleSize;
  let darkSum = 0;
  let darkCount = 0;
  for (const [col, row] of DARK_CORE_MODULES) {
    const px = Math.round(finderOriginX + (col + 0.5) * moduleSize);
    const py = Math.round(finderOriginY + (row + 0.5) * moduleSize);
    if (px >= 0 && px < width && py >= 0 && py < height) {
      const idx = (py * width + px) * 4;
      darkSum += grayAt(pixels, idx);
      darkCount++;
    }
  }
  let lightSum = 0;
  let lightCount = 0;
  for (const [col, row] of WHITE_RING_MODULES) {
    const px = Math.round(finderOriginX + (col + 0.5) * moduleSize);
    const py = Math.round(finderOriginY + (row + 0.5) * moduleSize);
    if (px >= 0 && px < width && py >= 0 && py < height) {
      const idx = (py * width + px) * 4;
      lightSum += grayAt(pixels, idx);
      lightCount++;
    }
  }
  if (darkCount < 5 || lightCount < 5) return -Infinity;
  const avgDark = darkSum / darkCount;
  const avgLight = lightSum / lightCount;
  const contrast2 = avgLight - avgDark;
  const darkPenalty = avgDark > threshold2 ? (avgDark - threshold2) / 255 : 0;
  const lightPenalty = avgLight < threshold2 ? (threshold2 - avgLight) / 255 : 0;
  return contrast2 - darkPenalty * 100 - lightPenalty * 100;
}
function refineFinderPatternCenter(pixels, width, height, centerX, centerY, moduleSize, threshold2) {
  const searchRadius = Math.ceil(moduleSize * 2.5);
  const step = Math.max(1, Math.floor(moduleSize / 4));
  let bestX = centerX;
  let bestY = centerY;
  const initialScore = scoreFinderCenter(
    pixels,
    width,
    height,
    centerX,
    centerY,
    moduleSize,
    threshold2
  );
  let bestScore = initialScore;
  for (let dy = -searchRadius; dy <= searchRadius; dy += step) {
    for (let dx = -searchRadius; dx <= searchRadius; dx += step) {
      const testX = centerX + dx;
      const testY = centerY + dy;
      const score = scoreFinderCenter(pixels, width, height, testX, testY, moduleSize, threshold2);
      if (score > bestScore) {
        bestScore = score;
        bestX = testX;
        bestY = testY;
      }
    }
  }
  if (step > 1) {
    const fineStep = Math.max(1, Math.floor(step / 2));
    const fineRadius = step * 2;
    for (let dy = -fineRadius; dy <= fineRadius; dy += fineStep) {
      for (let dx = -fineRadius; dx <= fineRadius; dx += fineStep) {
        const testX = bestX + dx;
        const testY = bestY + dy;
        const score = scoreFinderCenter(pixels, width, height, testX, testY, moduleSize, threshold2);
        if (score > bestScore) {
          bestScore = score;
          bestX = testX;
          bestY = testY;
        }
      }
    }
  }
  const deltaX = bestX - centerX;
  const deltaY = bestY - centerY;
  const refined = bestScore > initialScore;
  const bestContrast = computeFinderContrast(pixels, width, height, bestX, bestY, moduleSize);
  const originalContrast = computeFinderContrast(
    pixels,
    width,
    height,
    centerX,
    centerY,
    moduleSize
  );
  qrDecoderLog4.trace("locate: Finder center refinement", {
    original: `(${centerX.toFixed(1)}, ${centerY.toFixed(1)})`,
    refined: `(${bestX.toFixed(1)}, ${bestY.toFixed(1)})`,
    delta: `(${deltaX.toFixed(1)}, ${deltaY.toFixed(1)})`,
    moduleSize: moduleSize.toFixed(1),
    searchRadius,
    step,
    initialScore: initialScore.toFixed(1),
    bestScore: bestScore.toFixed(1),
    scoreImprovement: (bestScore - initialScore).toFixed(1),
    refinementHelped: refined,
    originalAvgDark: originalContrast.avgDark.toFixed(1),
    originalAvgLight: originalContrast.avgLight.toFixed(1),
    bestAvgDark: bestContrast.avgDark.toFixed(1),
    bestAvgLight: bestContrast.avgLight.toFixed(1),
    bestContrast: bestContrast.contrast.toFixed(1),
    note: bestContrast.avgDark > 80 || bestContrast.avgLight < 180 ? "WARNING: Poor contrast suggests finder center still not accurate" : "OK - good contrast detected"
  });
  return { x: bestX, y: bestY, score: bestScore };
}
function selectFinderPatterns(patterns) {
  if (patterns.length < 3) {
    qrDecoderLog4.debug("select: Not enough patterns found", { count: patterns.length });
    return null;
  }
  const candidates = [];
  for (let i = 0; i < Math.min(patterns.length, 10); i++) {
    for (let j = i + 1; j < Math.min(patterns.length, 10); j++) {
      for (let k = j + 1; k < Math.min(patterns.length, 10); k++) {
        const p1 = patterns[i];
        const p2 = patterns[j];
        const p3 = patterns[k];
        const avgSize = (p1.moduleSize + p2.moduleSize + p3.moduleSize) / 3;
        const sizeVariance = (Math.abs(p1.moduleSize - avgSize) + Math.abs(p2.moduleSize - avgSize) + Math.abs(p3.moduleSize - avgSize)) / avgSize;
        if (sizeVariance > 0.3) {
          continue;
        }
        const ordered = orderFinderPatterns(p1, p2, p3);
        if (!ordered) continue;
        const [topLeft, topRight, bottomLeft] = ordered;
        const topDist = pointDistance(topLeft.center, topRight.center);
        const leftDist = pointDistance(topLeft.center, bottomLeft.center);
        const avgDist = (topDist + leftDist) / 2;
        const squareness = Math.abs(topDist - leftDist) / avgDist;
        const vecRight = {
          x: topRight.center.x - topLeft.center.x,
          y: topRight.center.y - topLeft.center.y
        };
        const vecDown = {
          x: bottomLeft.center.x - topLeft.center.x,
          y: bottomLeft.center.y - topLeft.center.y
        };
        const dotProduct = vecRight.x * vecDown.x + vecRight.y * vecDown.y;
        const magRight = Math.sqrt(vecRight.x ** 2 + vecRight.y ** 2);
        const magDown = Math.sqrt(vecDown.x ** 2 + vecDown.y ** 2);
        const cosAngle = dotProduct / (magRight * magDown);
        const angleDev = Math.abs(cosAngle);
        const minHits = Math.min(p1.count, p2.count, p3.count);
        const _totalHits = p1.count + p2.count + p3.count;
        const hitCountPenalty = Math.max(0, (8 - minHits) / 8);
        const spanInModules = avgDist / avgSize;
        const referenceSpan = 22;
        const spanBonus = (referenceSpan - spanInModules) / referenceSpan;
        const score = squareness * 5 + angleDev * 5 + sizeVariance + hitCountPenalty * 2 + spanBonus * 2;
        qrDecoderLog4.trace("select: Evaluating triplet", {
          topLeft: { x: topLeft.center.x.toFixed(1), y: topLeft.center.y.toFixed(1) },
          topRight: { x: topRight.center.x.toFixed(1), y: topRight.center.y.toFixed(1) },
          bottomLeft: { x: bottomLeft.center.x.toFixed(1), y: bottomLeft.center.y.toFixed(1) },
          topDist: topDist.toFixed(1),
          leftDist: leftDist.toFixed(1),
          squareness: squareness.toFixed(3),
          angleDev: angleDev.toFixed(3),
          spanInModules: spanInModules.toFixed(1),
          hitCounts: `${p1.count}/${p2.count}/${p3.count}`,
          score: score.toFixed(3)
        });
        if (squareness > 0.1) {
          qrDecoderLog4.trace("select: Rejecting - not square enough", {
            squareness: squareness.toFixed(3)
          });
          continue;
        }
        if (angleDev > 0.26) {
          qrDecoderLog4.trace("select: Rejecting - angle not close to 90\xB0", {
            angleDev: angleDev.toFixed(3)
          });
          continue;
        }
        candidates.push({
          ordered,
          score,
          squareness,
          moduleSizeVariance: sizeVariance
        });
      }
    }
  }
  if (candidates.length === 0) {
    qrDecoderLog4.debug("select: Could not find valid pattern triplet");
    return null;
  }
  candidates.sort((a, b) => a.score - b.score);
  const best = candidates[0];
  qrDecoderLog4.trace("select: Selected finder patterns", {
    topLeft: { x: best.ordered[0].center.x.toFixed(1), y: best.ordered[0].center.y.toFixed(1) },
    topRight: { x: best.ordered[1].center.x.toFixed(1), y: best.ordered[1].center.y.toFixed(1) },
    bottomLeft: { x: best.ordered[2].center.x.toFixed(1), y: best.ordered[2].center.y.toFixed(1) },
    score: best.score.toFixed(3),
    squareness: best.squareness.toFixed(3),
    candidatesEvaluated: candidates.length
  });
  return best.ordered;
}
function orderFinderPatterns(p1, p2, p3) {
  const d12 = pointDistance(p1.center, p2.center);
  const d13 = pointDistance(p1.center, p3.center);
  const d23 = pointDistance(p2.center, p3.center);
  let topLeft;
  let topRight;
  let bottomLeft;
  if (d12 >= d13 && d12 >= d23) {
    topLeft = p3;
    [topRight, bottomLeft] = orderByAngle(p3, p1, p2);
  } else if (d13 >= d12 && d13 >= d23) {
    topLeft = p2;
    [topRight, bottomLeft] = orderByAngle(p2, p1, p3);
  } else {
    topLeft = p1;
    [topRight, bottomLeft] = orderByAngle(p1, p2, p3);
  }
  return [topLeft, topRight, bottomLeft];
}
function orderByAngle(topLeft, a, b) {
  const cross = (a.center.x - topLeft.center.x) * (b.center.y - topLeft.center.y) - (a.center.y - topLeft.center.y) * (b.center.x - topLeft.center.x);
  qrDecoderLog4.trace("select: Cross product calculation", {
    topLeft: { x: topLeft.center.x.toFixed(1), y: topLeft.center.y.toFixed(1) },
    a: { x: a.center.x.toFixed(1), y: a.center.y.toFixed(1) },
    b: { x: b.center.x.toFixed(1), y: b.center.y.toFixed(1) },
    cross: cross.toFixed(1),
    aIsTopRight: cross > 0
  });
  if (cross > 0) {
    return [a, b];
  } else {
    return [b, a];
  }
}

// src/modules/qr-decoder/rs-decoder.ts
var qrDecoderLog5 = createLogger("DECODER");
var GF_EXP = new Uint8Array(512);
var GF_LOG = new Uint8Array(256);
(function initGFTables() {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF_EXP[i] = x;
    GF_LOG[x] = i;
    x <<= 1;
    if (x & 256) {
      x ^= 285;
    }
  }
  for (let i = 255; i < 512; i++) {
    GF_EXP[i] = GF_EXP[i - 255];
  }
  GF_LOG[0] = 0;
})();
function gfAdd(a, b) {
  return a ^ b;
}
function gfMul(a, b) {
  if (a === 0 || b === 0) return 0;
  return GF_EXP[GF_LOG[a] + GF_LOG[b]];
}
function gfInv(a) {
  if (a === 0) throw new Error("Inverse of zero in GF(256)");
  return GF_EXP[255 - GF_LOG[a]];
}
function polyDegree(poly) {
  if (poly.length === 0) return 0;
  for (let i = 0; i < poly.length; i++) {
    if (poly[i] !== 0) return poly.length - 1 - i;
  }
  return 0;
}
function polyGetCoeff(poly, degree) {
  const idx = poly.length - 1 - degree;
  if (idx < 0 || idx >= poly.length) return 0;
  return poly[idx];
}
function polyIsZero(poly) {
  return poly.every((c) => c === 0);
}
function polyEval(poly, x) {
  if (poly.length === 0) return 0;
  if (x === 0) {
    return poly[poly.length - 1];
  }
  let result = poly[0];
  for (let i = 1; i < poly.length; i++) {
    result = gfAdd(gfMul(result, x), poly[i]);
  }
  return result;
}
function polyAddOrSubtract(p1, p2) {
  if (polyIsZero(p1)) return [...p2];
  if (polyIsZero(p2)) return [...p1];
  const smaller = p1.length < p2.length ? p1 : p2;
  const larger = p1.length < p2.length ? p2 : p1;
  const result = [...larger];
  const offset = larger.length - smaller.length;
  for (let i = 0; i < smaller.length; i++) {
    result[offset + i] = gfAdd(result[offset + i], smaller[i]);
  }
  return polyTrimLeadingZeros(result);
}
function polyTrimLeadingZeros(poly) {
  let firstNonZero = 0;
  while (firstNonZero < poly.length - 1 && poly[firstNonZero] === 0) {
    firstNonZero++;
  }
  if (firstNonZero === 0) return poly;
  return poly.slice(firstNonZero);
}
function polyMultiply(p1, p2) {
  if (polyIsZero(p1) || polyIsZero(p2)) return [0];
  const result = new Array(p1.length + p2.length - 1).fill(0);
  for (let i = 0; i < p1.length; i++) {
    for (let j = 0; j < p2.length; j++) {
      result[i + j] = gfAdd(result[i + j], gfMul(p1[i], p2[j]));
    }
  }
  return result;
}
function polyMultiplyScalar(poly, scalar) {
  if (scalar === 0) return [0];
  return poly.map((c) => gfMul(c, scalar));
}
function polyMultiplyByMonomial(poly, degree, coeff) {
  if (coeff === 0) return [0];
  const result = new Array(poly.length + degree).fill(0);
  for (let i = 0; i < poly.length; i++) {
    result[i] = gfMul(poly[i], coeff);
  }
  return result;
}
function buildMonomial(degree, coeff) {
  if (coeff === 0) return [0];
  const result = new Array(degree + 1).fill(0);
  result[0] = coeff;
  return result;
}
var POLY_ZERO = [0];
var POLY_ONE = [1];
function calculateSyndromePolynomial(codeword, numEcc) {
  const syndromeCoeffs = new Array(numEcc).fill(0);
  let noError = true;
  for (let i = 0; i < numEcc; i++) {
    const x = GF_EXP[i];
    let evalResult = codeword[0];
    for (let j = 1; j < codeword.length; j++) {
      evalResult = gfAdd(gfMul(evalResult, x), codeword[j]);
    }
    syndromeCoeffs[numEcc - 1 - i] = evalResult;
    if (evalResult !== 0) {
      noError = false;
    }
  }
  if (noError) {
    return POLY_ZERO;
  }
  return syndromeCoeffs;
}
function isSyndromeZero(syndromePoly) {
  return polyIsZero(syndromePoly);
}
function runEuclideanAlgorithm(syndromePoly, numEcc) {
  let a = buildMonomial(numEcc, 1);
  let b = syndromePoly;
  if (polyDegree(a) < polyDegree(b)) {
    const temp = a;
    a = b;
    b = temp;
  }
  let rLast = a;
  let r = b;
  let tLast = POLY_ZERO;
  let t = POLY_ONE;
  const halfR = Math.floor(numEcc / 2);
  while (polyDegree(r) >= halfR) {
    const rLastLast = rLast;
    const tLastLast = tLast;
    rLast = r;
    tLast = t;
    if (polyIsZero(rLast)) {
      qrDecoderLog5.trace("rs-decoder: Euclidean r_{i-1} was zero");
      return null;
    }
    r = rLastLast;
    let q = POLY_ZERO;
    const denominatorLeadingTerm = rLast[0];
    const dltInverse = gfInv(denominatorLeadingTerm);
    while (polyDegree(r) >= polyDegree(rLast) && !polyIsZero(r)) {
      const degreeDiff = polyDegree(r) - polyDegree(rLast);
      const scale = gfMul(r[0], dltInverse);
      q = polyAddOrSubtract(q, buildMonomial(degreeDiff, scale));
      r = polyAddOrSubtract(r, polyMultiplyByMonomial(rLast, degreeDiff, scale));
    }
    t = polyAddOrSubtract(polyMultiply(q, tLast), tLastLast);
    if (polyDegree(r) >= polyDegree(rLast)) {
      qrDecoderLog5.trace("rs-decoder: Euclidean Division algorithm failed to reduce polynomial");
      return null;
    }
  }
  const sigmaTildeAtZero = polyGetCoeff(t, 0);
  if (sigmaTildeAtZero === 0) {
    qrDecoderLog5.trace("rs-decoder: Euclidean sigmaTilde(0) was zero");
    return null;
  }
  const inverse = gfInv(sigmaTildeAtZero);
  const sigma = polyMultiplyScalar(t, inverse);
  const omega = polyMultiplyScalar(r, inverse);
  qrDecoderLog5.trace("rs-decoder: Euclidean algorithm completed", {
    sigmaDegree: polyDegree(sigma),
    omegaDegree: polyDegree(omega),
    sigmaCoeffs: sigma.map((s) => s.toString(16).padStart(2, "0")).join(" "),
    omegaCoeffs: omega.map((o) => o.toString(16).padStart(2, "0")).join(" ")
  });
  return { sigma, omega };
}
function findErrorLocations(sigma, n) {
  const numErrors = polyDegree(sigma);
  if (numErrors === 1) {
    const coeff1 = polyGetCoeff(sigma, 1);
    return [coeff1];
  }
  const result = [];
  qrDecoderLog5.trace("rs-decoder: Chien search starting", {
    numErrors,
    n,
    sigmaCoeffs: sigma.map((s) => s.toString(16).padStart(2, "0")).join(" ")
  });
  for (let i = 1; i < 256 && result.length < numErrors; i++) {
    if (polyEval(sigma, i) === 0) {
      result.push(gfInv(i));
      qrDecoderLog5.trace("rs-decoder: Chien found root", {
        i,
        errorLocator: gfInv(i).toString(16).padStart(2, "0")
      });
    }
  }
  if (result.length !== numErrors) {
    qrDecoderLog5.trace("rs-decoder: Chien search wrong number of roots", {
      expected: numErrors,
      found: result.length
    });
    return null;
  }
  qrDecoderLog5.trace("rs-decoder: Chien search found all roots", {
    errorLocators: result.map((e) => e.toString(16).padStart(2, "0")).join(" ")
  });
  return result;
}
function findErrorMagnitudes(omega, errorLocators) {
  const numErrors = errorLocators.length;
  const result = new Array(numErrors);
  qrDecoderLog5.trace("rs-decoder: Forney calculating magnitudes (direct product)", {
    numErrors,
    errorLocators: errorLocators.map((e) => e.toString(16).padStart(2, "0")).join(" "),
    omegaCoeffs: omega.map((o) => o.toString(16).padStart(2, "0")).join(" ")
  });
  for (let i = 0; i < numErrors; i++) {
    const xiInverse = gfInv(errorLocators[i]);
    let denominator = 1;
    for (let j = 0; j < numErrors; j++) {
      if (i !== j) {
        const term = gfMul(errorLocators[j], xiInverse);
        const termPlus1 = (term & 1) === 0 ? term | 1 : term & ~1;
        denominator = gfMul(denominator, termPlus1);
      }
    }
    const omegaVal = polyEval(omega, xiInverse);
    result[i] = gfMul(omegaVal, gfInv(denominator));
    qrDecoderLog5.trace(`rs-decoder: Forney magnitude for error ${i}`, {
      errorLocator: errorLocators[i].toString(16).padStart(2, "0"),
      xiInverse: xiInverse.toString(16).padStart(2, "0"),
      omegaVal: omegaVal.toString(16).padStart(2, "0"),
      denominator: denominator.toString(16).padStart(2, "0"),
      magnitude: result[i].toString(16).padStart(2, "0")
    });
  }
  return result;
}
function correctRSBlock(codeword, dataCount, eccCount) {
  const n = codeword.length;
  if (n !== dataCount + eccCount) {
    qrDecoderLog5.debug("rs-decoder: Codeword length mismatch", {
      n,
      expected: dataCount + eccCount
    });
    return null;
  }
  qrDecoderLog5.trace("rs-decoder: Starting RS error correction", {
    n,
    dataCount,
    eccCount,
    maxCorrectableErrors: Math.floor(eccCount / 2)
  });
  const syndromePoly = calculateSyndromePolynomial(codeword, eccCount);
  qrDecoderLog5.trace("rs-decoder: Syndromes calculated", {
    syndromes: syndromePoly.map((s) => s.toString(16).padStart(2, "0")).join(" "),
    allZero: isSyndromeZero(syndromePoly)
  });
  if (isSyndromeZero(syndromePoly)) {
    qrDecoderLog5.trace("rs-decoder: No errors detected (all syndromes zero)");
    return codeword.slice(0, dataCount);
  }
  const euclideanResult = runEuclideanAlgorithm(syndromePoly, eccCount);
  if (!euclideanResult) {
    qrDecoderLog5.debug("rs-decoder: Euclidean algorithm failed");
    return null;
  }
  const { sigma, omega } = euclideanResult;
  qrDecoderLog5.trace("rs-decoder: Error locator polynomial found", {
    degree: polyDegree(sigma),
    coeffs: sigma.map((s) => s.toString(16).padStart(2, "0")).join(" ")
  });
  const errorLocators = findErrorLocations(sigma, n);
  if (!errorLocators) {
    qrDecoderLog5.debug("rs-decoder: Chien search failed");
    return null;
  }
  const magnitudes = findErrorMagnitudes(omega, errorLocators);
  qrDecoderLog5.trace("rs-decoder: Error magnitudes calculated", {
    magnitudes: magnitudes.map((m) => m.toString(16).padStart(2, "0")).join(" ")
  });
  const corrected = [...codeword];
  for (let i = 0; i < errorLocators.length; i++) {
    const position = n - 1 - GF_LOG[errorLocators[i]];
    if (position < 0) {
      qrDecoderLog5.debug("rs-decoder: Bad error location", {
        position,
        errorLocator: errorLocators[i]
      });
      return null;
    }
    corrected[position] = gfAdd(corrected[position], magnitudes[i]);
    qrDecoderLog5.trace(`rs-decoder: Corrected position ${position}`, {
      original: codeword[position].toString(16).padStart(2, "0"),
      magnitude: magnitudes[i].toString(16).padStart(2, "0"),
      corrected: corrected[position].toString(16).padStart(2, "0")
    });
  }
  const verifySyndromes = calculateSyndromePolynomial(corrected, eccCount);
  if (!isSyndromeZero(verifySyndromes)) {
    qrDecoderLog5.debug("rs-decoder: Correction verification failed (syndromes not zero)");
    return null;
  }
  qrDecoderLog5.trace("rs-decoder: Correction verified successfully", {
    errorsFixed: errorLocators.length
  });
  return corrected.slice(0, dataCount);
}
function correctRSCodewords(codewords, rsBlocks) {
  const blockConfigs = [];
  for (const blockGroup of rsBlocks) {
    const numBlocks2 = blockGroup[0];
    const totalCount = blockGroup[1];
    const dataCount = blockGroup[2];
    const eccCount = totalCount - dataCount;
    for (let i = 0; i < numBlocks2; i++) {
      blockConfigs.push({ dataCount, eccCount });
    }
  }
  const numBlocks = blockConfigs.length;
  const maxDataCount = Math.max(...blockConfigs.map((b) => b.dataCount));
  const maxEccCount = Math.max(...blockConfigs.map((b) => b.eccCount));
  const blockData = blockConfigs.map(() => []);
  let idx = 0;
  for (let pos = 0; pos < maxDataCount; pos++) {
    for (let b = 0; b < numBlocks; b++) {
      if (pos < blockConfigs[b].dataCount && idx < codewords.length) {
        blockData[b].push(codewords[idx++]);
      }
    }
  }
  const blockEcc = blockConfigs.map(() => []);
  for (let pos = 0; pos < maxEccCount; pos++) {
    for (let b = 0; b < numBlocks; b++) {
      if (pos < blockConfigs[b].eccCount && idx < codewords.length) {
        blockEcc[b].push(codewords[idx++]);
      }
    }
  }
  qrDecoderLog5.trace("rs-decoder: De-interleaved into blocks", {
    numBlocks,
    blockDataLengths: blockData.map((d) => d.length).join(","),
    blockEccLengths: blockEcc.map((e) => e.length).join(",")
  });
  const correctedBlocks = [];
  let totalCorrections = 0;
  for (let b = 0; b < numBlocks; b++) {
    const blockCodeword = [...blockData[b], ...blockEcc[b]];
    const { dataCount, eccCount } = blockConfigs[b];
    qrDecoderLog5.trace(`rs-decoder: Processing block ${b}`, {
      dataCount,
      eccCount,
      blockLength: blockCodeword.length
    });
    const corrected = correctRSBlock(blockCodeword, dataCount, eccCount);
    if (corrected === null) {
      qrDecoderLog5.debug(`rs-decoder: Block ${b} is uncorrectable`);
      return null;
    }
    for (let i = 0; i < corrected.length; i++) {
      if (corrected[i] !== blockData[b][i]) {
        totalCorrections++;
      }
    }
    correctedBlocks.push(corrected);
  }
  const dataCodewords = correctedBlocks.flat();
  qrDecoderLog5.trace("rs-decoder: RS correction complete", {
    totalDataCodewords: dataCodewords.length,
    totalCorrections
  });
  return { dataCodewords, correctionsMade: totalCorrections };
}

// src/modules/qr-decoder/rs-rootability.ts
var _log80 = createLogger("DECODER");
var GF_EXP2 = new Uint8Array(512);
var GF_LOG2 = new Uint8Array(256);
var GF_INIT = false;
function initGF() {
  if (GF_INIT) return;
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF_EXP2[i] = x;
    GF_LOG2[x] = i;
    x <<= 1;
    if (x & 256) x ^= 285;
  }
  for (let i = 255; i < 512; i++) GF_EXP2[i] = GF_EXP2[i - 255];
  GF_INIT = true;
}
function gfMul2(a, b) {
  if (a === 0 || b === 0) return 0;
  return GF_EXP2[GF_LOG2[a] + GF_LOG2[b]];
}
function gfInv2(a) {
  if (a === 0) return 0;
  return GF_EXP2[255 - GF_LOG2[a]];
}
function polyEvalAsc(poly, x) {
  let y = 0;
  let p = 1;
  for (let i = 0; i < poly.length; i++) {
    y ^= gfMul2(poly[i] ?? 0, p);
    p = gfMul2(p, x);
  }
  return y;
}
function polyEvalHighToLow(coeffs, x) {
  let y = 0;
  for (let i = 0; i < coeffs.length; i++) {
    y = gfMul2(y, x) ^ (coeffs[i] ?? 0);
  }
  return y;
}
function computeSyndromes(received, eccCount) {
  const synd = [];
  for (let i = 0; i < eccCount; i++) {
    const x = GF_EXP2[i];
    synd.push(polyEvalHighToLow(received, x));
  }
  return synd;
}
function berlekampMassey(syndromes) {
  const C = [1];
  const B = [1];
  let L = 0;
  let m = 1;
  let b = 1;
  for (let n = 0; n < syndromes.length; n++) {
    let d = syndromes[n] ?? 0;
    for (let i = 1; i <= L; i++) {
      d ^= gfMul2(C[i] ?? 0, syndromes[n - i] ?? 0);
    }
    if (d === 0) {
      m++;
      continue;
    }
    const T = C.slice();
    const coef = gfMul2(d, gfInv2(b));
    for (let i = 0; i < B.length; i++) {
      const idx = i + m;
      C[idx] = (C[idx] ?? 0) ^ gfMul2(coef, B[i] ?? 0);
    }
    if (2 * L <= n) {
      L = n + 1 - L;
      b = d;
      B.length = 0;
      for (let i = 0; i < T.length; i++) B.push(T[i] ?? 0);
      m = 1;
    } else {
      m++;
    }
  }
  while (C.length > 1 && C[C.length - 1] === 0) C.pop();
  return { sigma: C, degree: L };
}
function chienRootCount(locator) {
  let roots = 0;
  for (let i = 0; i < 255; i++) {
    const x = GF_EXP2[i];
    if (polyEvalAsc(locator, x) === 0) roots++;
  }
  return roots;
}
function rsRootabilityFor(codewords, version, ecc) {
  initGF();
  const rsBlocks = RS_BLOCKS[ecc]?.[version - 1];
  if (!rsBlocks) return [];
  const blockDataSizes = [];
  const blockTotalSizes = [];
  for (const g of rsBlocks) {
    const numBlocks2 = g[0];
    const total = g[1];
    const data = g[2];
    for (let i = 0; i < numBlocks2; i++) {
      blockDataSizes.push(data);
      blockTotalSizes.push(total);
    }
  }
  const numBlocks = blockDataSizes.length;
  const blockEccSizes = blockTotalSizes.map((t, i) => t - (blockDataSizes[i] ?? 0));
  const maxData = Math.max(...blockDataSizes);
  const maxEcc = Math.max(...blockEccSizes);
  const blocks = Array.from({ length: numBlocks }, () => []);
  let idx = 0;
  for (let i = 0; i < maxData; i++) {
    for (let b = 0; b < numBlocks; b++) {
      if (i < (blockDataSizes[b] ?? 0)) {
        blocks[b]?.push(codewords[idx++] ?? 0);
      }
    }
  }
  for (let i = 0; i < maxEcc; i++) {
    for (let b = 0; b < numBlocks; b++) {
      if (i < (blockEccSizes[b] ?? 0)) {
        blocks[b]?.push(codewords[idx++] ?? 0);
      }
    }
  }
  const results = [];
  for (let b = 0; b < numBlocks; b++) {
    const dataCount = blockDataSizes[b] ?? 0;
    const eccCount = blockEccSizes[b] ?? 0;
    const received = blocks[b] ?? [];
    const syndromes = computeSyndromes(received, eccCount);
    const syndromeNonZeroCount = syndromes.filter((s) => s !== 0).length;
    const { sigma, degree } = berlekampMassey(syndromes);
    const rootsFound = degree === 0 ? 0 : chienRootCount(sigma);
    results.push({
      blockIndex: b,
      dataCount,
      eccCount,
      syndromeNonZeroCount,
      bmDegree: degree,
      chienRootsFound: rootsFound
    });
  }
  return results;
}

// src/modules/qr-decoder/decode-qr.ts
var qrDecoderLog6 = createLogger("DECODER");
function decodeQR(imageData, options = {}) {
  const { inversionAttempts = "attemptBoth" } = options;
  if (inversionAttempts !== "onlyInvert") {
    const result = tryDecode(imageData);
    if (result) return result;
  }
  if (inversionAttempts !== "dontInvert") {
    const inverted = invertImageData(imageData);
    const result = tryDecode(inverted);
    if (result) return result;
  }
  return null;
}
function tryDecode(imageData) {
  try {
    qrDecoderLog6.trace("main: Starting decode attempt", {
      width: imageData.width,
      height: imageData.height
    });
    const { patterns, threshold: threshold2 } = findFinderPatterns(imageData);
    if (patterns.length < 3) {
      qrDecoderLog6.trace("main: Failed - not enough finder patterns", { found: patterns.length });
      return null;
    }
    const selected = selectFinderPatterns(patterns);
    if (!selected) {
      qrDecoderLog6.trace("main: Failed - could not select valid pattern triplet");
      return null;
    }
    const [topLeft, topRight, bottomLeft] = selected;
    const location = calculateLocation(topLeft, topRight, bottomLeft);
    const version = (location.moduleCount - 17) / 4;
    qrDecoderLog6.trace("main: Calculated version", { version, moduleCount: location.moduleCount });
    const rawMatrix = extractModuleMatrix(imageData, location, threshold2);
    const formatInfo = readFormatInfo(rawMatrix, location.moduleCount);
    if (!formatInfo) {
      qrDecoderLog6.trace("main: Failed - could not read format info");
      return null;
    }
    const moduleCount = location.moduleCount;
    const versionRounded = Math.round(version);
    const timingMismatches = [];
    for (let c = 8; c < moduleCount - 8; c++) {
      const exp = c % 2 === 0 ? 1 : 0;
      const got = rawMatrix[6]?.[c] ? 1 : 0;
      if (exp !== got && timingMismatches.length < 12) timingMismatches.push({ r: 6, c, exp, got });
    }
    for (let r = 8; r < moduleCount - 8; r++) {
      const exp = r % 2 === 0 ? 1 : 0;
      const got = rawMatrix[r]?.[6] ? 1 : 0;
      if (exp !== got && timingMismatches.length < 12) timingMismatches.push({ r, c: 6, exp, got });
    }
    qrDecoderLog6.trace("diag: Timing pattern mismatches (first 12)", {
      count: timingMismatches.length,
      mismatches: timingMismatches.map((m) => `(${m.r},${m.c}) exp=${m.exp} got=${m.got}`)
    });
    const centers = getAlignmentPatternCenters(versionRounded, moduleCount);
    const alignmentScores = [];
    for (const center of centers) {
      const cx = center.col;
      const cy = center.row;
      if (cx <= 8 && cy <= 8 || cx >= moduleCount - 9 && cy <= 8 || cx <= 8 && cy >= moduleCount - 9) {
        continue;
      }
      let good = 0;
      let total = 0;
      const mism = [];
      for (let dy = -2; dy <= 2; dy++) {
        for (let dx = -2; dx <= 2; dx++) {
          const r = cy + dy;
          const c = cx + dx;
          const got = rawMatrix[r]?.[c] ? 1 : 0;
          const exp = Math.max(Math.abs(dx), Math.abs(dy)) === 2 || dx === 0 && dy === 0 ? 1 : 0;
          total++;
          if (got === exp) good++;
          else if (mism.length < 6) mism.push(`(${r},${c}) exp=${exp} got=${got}`);
        }
      }
      alignmentScores.push({
        center: `(${cx},${cy})`,
        score: `${good}/${total}`,
        mismatches: mism
      });
    }
    if (alignmentScores.length) {
      qrDecoderLog6.trace("diag: Alignment pattern scores", {
        version: versionRounded,
        scores: alignmentScores
      });
    } else {
      qrDecoderLog6.trace("diag: Alignment pattern scores", {
        version: versionRounded,
        scores: "none (v1 or finder-overlap only)"
      });
    }
    const diagEccChar = getECCLevelChar(formatInfo.eccLevel);
    const maskSweep = [];
    for (let m = 0; m <= 7; m++) {
      const unmasked = unmaskMatrix(rawMatrix, m, moduleCount);
      const cw = readCodewords(unmasked, moduleCount);
      const rs = rsRootabilityFor(cw, versionRounded, diagEccChar);
      maskSweep.push({
        mask: m,
        codewords: cw.length,
        blocks: rs.map((b) => ({
          b: b.blockIndex,
          nz: b.syndromeNonZeroCount,
          deg: b.bmDegree,
          roots: b.chienRootsFound
        }))
      });
    }
    qrDecoderLog6.trace("diag: RS rootability sweep (masks 0..7)", {
      version: versionRounded,
      ecc: diagEccChar,
      maskSweep
    });
    const matrix = unmaskMatrix(rawMatrix, formatInfo.maskPattern, location.moduleCount);
    const codewords = readCodewords(matrix, location.moduleCount);
    qrDecoderLog6.trace("main: Read codewords", { count: codewords.length });
    const eccChar = getECCLevelChar(formatInfo.eccLevel);
    const rsBlocks = RS_BLOCKS[eccChar]?.[Math.round(version) - 1];
    if (!rsBlocks) {
      qrDecoderLog6.trace("main: Failed - No RS block configuration found", {
        version: Math.round(version),
        eccLevel: eccChar
      });
      return null;
    }
    qrDecoderLog6.trace("main: Starting RS error correction", {
      version: Math.round(version),
      eccLevel: eccChar,
      rsBlocks: rsBlocks.map((b) => `${b[0]}x(${b[2]}d+${b[1] - b[2]}e)`).join(", "),
      totalCodewords: codewords.length
    });
    let rsResult = correctRSCodewords(codewords, rsBlocks);
    let usedMask = formatInfo.maskPattern;
    if (rsResult === null) {
      qrDecoderLog6.trace("main: RS error correction failed with detected mask, trying fallback");
      for (let testMask = 0; testMask < 8; testMask++) {
        if (testMask === formatInfo.maskPattern) continue;
        const testMatrix = unmaskMatrix(rawMatrix, testMask, location.moduleCount);
        const testCodewords = readCodewords(testMatrix, location.moduleCount);
        const testRsResult = correctRSCodewords(testCodewords, rsBlocks);
        if (testRsResult !== null) {
          qrDecoderLog6.trace("main: Mask fallback SUCCESS", {
            originalMask: formatInfo.maskPattern,
            workingMask: testMask,
            corrections: testRsResult.correctionsMade
          });
          rsResult = testRsResult;
          usedMask = testMask;
          break;
        }
      }
      if (rsResult === null) {
        qrDecoderLog6.trace(
          "main: Failed - RS error correction failed (too many errors, all masks tried)"
        );
        return null;
      }
    }
    const { dataCodewords, correctionsMade } = rsResult;
    qrDecoderLog6.trace("main: RS correction completed", {
      dataCodewords: dataCodewords.length,
      correctionsMade,
      first10: dataCodewords.slice(0, 10).map((c) => c.toString(16).padStart(2, "0")).join(" ")
    });
    const decoded = decodeDataCodewordsDetailed(dataCodewords, Math.round(version));
    const data = decoded.text;
    const dataBytes = decoded.bytes;
    const encodingMode = decoded.encodingMode;
    if (!decoded.valid) {
      qrDecoderLog6.trace("main: Failed - decode reported invalid (truncation or corrupt data)", {
        structurallyValid: decoded.structurallyValid,
        segmentCount: decoded.segmentCount,
        segments: decoded.segments.map((s) => ({
          mode: s.modeName,
          valid: s.valid,
          charCount: s.charCount
        }))
      });
      return null;
    }
    if (!data) {
      qrDecoderLog6.trace("main: Failed - could not decode data");
      return null;
    }
    qrDecoderLog6.trace("main: Decode SUCCESS", {
      version: Math.round(version),
      eccLevel: getECCLevelChar(formatInfo.eccLevel),
      dataLength: data.length,
      dataPreview: data.slice(0, 50)
    });
    return {
      success: true,
      data,
      dataBytes,
      encodingMode,
      error: null,
      location: {
        topLeftCorner: topLeft.center,
        topRightCorner: topRight.center,
        bottomLeftCorner: bottomLeft.center,
        bottomRightCorner: location.bottomRight
      },
      version: Math.round(version),
      eccLevel: getECCLevelChar(formatInfo.eccLevel),
      maskPattern: usedMask,
      structurallyValid: decoded.structurallyValid,
      segmentCount: decoded.segmentCount,
      segments: decoded.segments
    };
  } catch (err) {
    qrDecoderLog6.trace("main: Exception during decode", { error: String(err) });
    return null;
  }
}
function invertImageData(imageData) {
  const data = new Uint8ClampedArray(imageData.data.length);
  for (let i = 0; i < imageData.data.length; i += 4) {
    data[i] = 255 - imageData.data[i];
    data[i + 1] = 255 - imageData.data[i + 1];
    data[i + 2] = 255 - imageData.data[i + 2];
    data[i + 3] = imageData.data[i + 3];
  }
  return new ImageData(data, imageData.width, imageData.height);
}

// src/modules/qr-decoder/qr-version.ts
var _log81 = createLogger("DECODER");
var ErrorCorrectionLevel = class _ErrorCorrectionLevel {
  constructor(value, stringValue, bits) {
    this.value = value;
    this.stringValue = stringValue;
    this.bits = bits;
    _ErrorCorrectionLevel.FOR_BITS.set(bits, this);
  }
  static FOR_BITS = /* @__PURE__ */ new Map();
  static L = new _ErrorCorrectionLevel(0 /* L */, "L", 1);
  static M = new _ErrorCorrectionLevel(1 /* M */, "M", 0);
  static Q = new _ErrorCorrectionLevel(2 /* Q */, "Q", 3);
  static H = new _ErrorCorrectionLevel(3 /* H */, "H", 2);
  getValue() {
    return this.value;
  }
  getBits() {
    return this.bits;
  }
  toString() {
    return this.stringValue;
  }
  equals(o) {
    if (!(o instanceof _ErrorCorrectionLevel)) return false;
    return this.value === o.value;
  }
  static forBits(bits) {
    if (bits < 0 || bits >= _ErrorCorrectionLevel.FOR_BITS.size) {
      throw new IllegalArgumentException();
    }
    return _ErrorCorrectionLevel.FOR_BITS.get(bits);
  }
  static fromString(s) {
    switch (s) {
      case "L":
        return _ErrorCorrectionLevel.L;
      case "M":
        return _ErrorCorrectionLevel.M;
      case "Q":
        return _ErrorCorrectionLevel.Q;
      case "H":
        return _ErrorCorrectionLevel.H;
      default:
        throw new IllegalArgumentException(`${s} not available`);
    }
  }
};
var Mode = class _Mode {
  constructor(value, stringValue, characterCountBitsForVersions, bits) {
    this.value = value;
    this.stringValue = stringValue;
    this.characterCountBitsForVersions = characterCountBitsForVersions;
    this.bits = bits;
    _Mode.FOR_BITS.set(bits, this);
  }
  static FOR_BITS = /* @__PURE__ */ new Map();
  static TERMINATOR = new _Mode(
    0 /* TERMINATOR */,
    "TERMINATOR",
    Int32Array.from([0, 0, 0]),
    0
  );
  static NUMERIC = new _Mode(1 /* NUMERIC */, "NUMERIC", Int32Array.from([10, 12, 14]), 1);
  static ALPHANUMERIC = new _Mode(
    2 /* ALPHANUMERIC */,
    "ALPHANUMERIC",
    Int32Array.from([9, 11, 13]),
    2
  );
  static STRUCTURED_APPEND = new _Mode(
    3 /* STRUCTURED_APPEND */,
    "STRUCTURED_APPEND",
    Int32Array.from([0, 0, 0]),
    3
  );
  static BYTE = new _Mode(4 /* BYTE */, "BYTE", Int32Array.from([8, 16, 16]), 4);
  static ECI = new _Mode(5 /* ECI */, "ECI", Int32Array.from([0, 0, 0]), 7);
  static KANJI = new _Mode(6 /* KANJI */, "KANJI", Int32Array.from([8, 10, 12]), 8);
  static FNC1_FIRST_POSITION = new _Mode(
    7 /* FNC1_FIRST_POSITION */,
    "FNC1_FIRST_POSITION",
    Int32Array.from([0, 0, 0]),
    5
  );
  static FNC1_SECOND_POSITION = new _Mode(
    8 /* FNC1_SECOND_POSITION */,
    "FNC1_SECOND_POSITION",
    Int32Array.from([0, 0, 0]),
    9
  );
  static HANZI = new _Mode(9 /* HANZI */, "HANZI", Int32Array.from([8, 10, 12]), 13);
  static forBits(bits) {
    const mode = _Mode.FOR_BITS.get(bits);
    if (mode === void 0) throw new IllegalArgumentException();
    return mode;
  }
  getCharacterCountBits(version) {
    const versionNumber = version.getVersionNumber();
    let offset;
    if (versionNumber <= 9) offset = 0;
    else if (versionNumber <= 26) offset = 1;
    else offset = 2;
    return this.characterCountBitsForVersions[offset];
  }
  getValue() {
    return this.value;
  }
  getBits() {
    return this.bits;
  }
  equals(o) {
    if (!(o instanceof _Mode)) return false;
    return this.value === o.value;
  }
  toString() {
    return this.stringValue;
  }
};
var ECB = class {
  constructor(count, dataCodewords) {
    this.count = count;
    this.dataCodewords = dataCodewords;
  }
  getCount() {
    return this.count;
  }
  getDataCodewords() {
    return this.dataCodewords;
  }
};
var ECBlocks = class {
  constructor(ecCodewordsPerBlock, ...ecBlocks) {
    this.ecCodewordsPerBlock = ecCodewordsPerBlock;
    this.ecBlocks = ecBlocks;
  }
  ecBlocks;
  getECCodewordsPerBlock() {
    return this.ecCodewordsPerBlock;
  }
  getNumBlocks() {
    let total = 0;
    for (const ecBlock of this.ecBlocks) {
      total += ecBlock.getCount();
    }
    return total;
  }
  getTotalECCodewords() {
    return this.ecCodewordsPerBlock * this.getNumBlocks();
  }
  getECBlocks() {
    return this.ecBlocks;
  }
};
var Version = class _Version {
  constructor(versionNumber, alignmentPatternCenters, ...ecBlocks) {
    this.versionNumber = versionNumber;
    this.alignmentPatternCenters = alignmentPatternCenters;
    this.ecBlocks = ecBlocks;
    let total = 0;
    const ecCodewords = ecBlocks[0].getECCodewordsPerBlock();
    const ecbArray = ecBlocks[0].getECBlocks();
    for (const ecBlock of ecbArray) {
      total += ecBlock.getCount() * (ecBlock.getDataCodewords() + ecCodewords);
    }
    this.totalCodewords = total;
  }
  static VERSION_DECODE_INFO = Int32Array.from([
    31892,
    34236,
    39577,
    42195,
    48118,
    51042,
    55367,
    58893,
    63784,
    68472,
    70749,
    76311,
    79154,
    84390,
    87683,
    92361,
    96236,
    102084,
    102881,
    110507,
    110734,
    117786,
    119615,
    126325,
    127568,
    133589,
    136944,
    141498,
    145311,
    150283,
    152622,
    158308,
    161089,
    167017
  ]);
  static VERSIONS = _Version.buildVersions();
  ecBlocks;
  totalCodewords;
  getVersionNumber() {
    return this.versionNumber;
  }
  getAlignmentPatternCenters() {
    return this.alignmentPatternCenters;
  }
  getTotalCodewords() {
    return this.totalCodewords;
  }
  getDimensionForVersion() {
    return 17 + 4 * this.versionNumber;
  }
  getECBlocksForLevel(ecLevel) {
    return this.ecBlocks[ecLevel.getValue()];
  }
  static getProvisionalVersionForDimension(dimension) {
    if (dimension % 4 !== 1) throw new FormatException();
    try {
      return _Version.getVersionForNumber((dimension - 17) / 4);
    } catch (_ignored) {
      throw new FormatException();
    }
  }
  static getVersionForNumber(versionNumber) {
    if (versionNumber < 1 || versionNumber > 40) throw new IllegalArgumentException();
    return _Version.VERSIONS[versionNumber - 1];
  }
  static decodeVersionInformation(versionBits) {
    let bestDifference = Number.MAX_SAFE_INTEGER;
    let bestVersion = 0;
    for (let i = 0; i < _Version.VERSION_DECODE_INFO.length; i++) {
      const targetVersion = _Version.VERSION_DECODE_INFO[i];
      if (targetVersion === versionBits) return _Version.getVersionForNumber(i + 7);
      const bitsDifference = FormatInformation.numBitsDiffering(versionBits, targetVersion);
      if (bitsDifference < bestDifference) {
        bestVersion = i + 7;
        bestDifference = bitsDifference;
      }
    }
    if (bestDifference <= 3) return _Version.getVersionForNumber(bestVersion);
    return null;
  }
  buildFunctionPattern() {
    const dimension = this.getDimensionForVersion();
    const bitMatrix = new BitMatrix(dimension);
    bitMatrix.setRegion(0, 0, 9, 9);
    bitMatrix.setRegion(dimension - 8, 0, 8, 9);
    bitMatrix.setRegion(0, dimension - 8, 9, 8);
    const max = this.alignmentPatternCenters.length;
    for (let x = 0; x < max; x++) {
      const i = this.alignmentPatternCenters[x] - 2;
      for (let y = 0; y < max; y++) {
        if (x === 0 && (y === 0 || y === max - 1) || x === max - 1 && y === 0) continue;
        bitMatrix.setRegion(this.alignmentPatternCenters[y] - 2, i, 5, 5);
      }
    }
    bitMatrix.setRegion(6, 9, 1, dimension - 17);
    bitMatrix.setRegion(9, 6, dimension - 17, 1);
    if (this.versionNumber > 6) {
      bitMatrix.setRegion(dimension - 11, 0, 3, 6);
      bitMatrix.setRegion(0, dimension - 11, 6, 3);
    }
    return bitMatrix;
  }
  toString() {
    return `${this.versionNumber}`;
  }
  static buildVersions() {
    return [
      new _Version(
        1,
        new Int32Array(0),
        new ECBlocks(7, new ECB(1, 19)),
        new ECBlocks(10, new ECB(1, 16)),
        new ECBlocks(13, new ECB(1, 13)),
        new ECBlocks(17, new ECB(1, 9))
      ),
      new _Version(
        2,
        Int32Array.from([6, 18]),
        new ECBlocks(10, new ECB(1, 34)),
        new ECBlocks(16, new ECB(1, 28)),
        new ECBlocks(22, new ECB(1, 22)),
        new ECBlocks(28, new ECB(1, 16))
      ),
      new _Version(
        3,
        Int32Array.from([6, 22]),
        new ECBlocks(15, new ECB(1, 55)),
        new ECBlocks(26, new ECB(1, 44)),
        new ECBlocks(18, new ECB(2, 17)),
        new ECBlocks(22, new ECB(2, 13))
      ),
      new _Version(
        4,
        Int32Array.from([6, 26]),
        new ECBlocks(20, new ECB(1, 80)),
        new ECBlocks(18, new ECB(2, 32)),
        new ECBlocks(26, new ECB(2, 24)),
        new ECBlocks(16, new ECB(4, 9))
      ),
      new _Version(
        5,
        Int32Array.from([6, 30]),
        new ECBlocks(26, new ECB(1, 108)),
        new ECBlocks(24, new ECB(2, 43)),
        new ECBlocks(18, new ECB(2, 15), new ECB(2, 16)),
        new ECBlocks(22, new ECB(2, 11), new ECB(2, 12))
      ),
      new _Version(
        6,
        Int32Array.from([6, 34]),
        new ECBlocks(18, new ECB(2, 68)),
        new ECBlocks(16, new ECB(4, 27)),
        new ECBlocks(24, new ECB(4, 19)),
        new ECBlocks(28, new ECB(4, 15))
      ),
      new _Version(
        7,
        Int32Array.from([6, 22, 38]),
        new ECBlocks(20, new ECB(2, 78)),
        new ECBlocks(18, new ECB(4, 31)),
        new ECBlocks(18, new ECB(2, 14), new ECB(4, 15)),
        new ECBlocks(26, new ECB(4, 13), new ECB(1, 14))
      ),
      new _Version(
        8,
        Int32Array.from([6, 24, 42]),
        new ECBlocks(24, new ECB(2, 97)),
        new ECBlocks(22, new ECB(2, 38), new ECB(2, 39)),
        new ECBlocks(22, new ECB(4, 18), new ECB(2, 19)),
        new ECBlocks(26, new ECB(4, 14), new ECB(2, 15))
      ),
      new _Version(
        9,
        Int32Array.from([6, 26, 46]),
        new ECBlocks(30, new ECB(2, 116)),
        new ECBlocks(22, new ECB(3, 36), new ECB(2, 37)),
        new ECBlocks(20, new ECB(4, 16), new ECB(4, 17)),
        new ECBlocks(24, new ECB(4, 12), new ECB(4, 13))
      ),
      new _Version(
        10,
        Int32Array.from([6, 28, 50]),
        new ECBlocks(18, new ECB(2, 68), new ECB(2, 69)),
        new ECBlocks(26, new ECB(4, 43), new ECB(1, 44)),
        new ECBlocks(24, new ECB(6, 19), new ECB(2, 20)),
        new ECBlocks(28, new ECB(6, 15), new ECB(2, 16))
      ),
      // Versions 11-40 abbreviated for brevity - same pattern
      new _Version(
        11,
        Int32Array.from([6, 30, 54]),
        new ECBlocks(20, new ECB(4, 81)),
        new ECBlocks(30, new ECB(1, 50), new ECB(4, 51)),
        new ECBlocks(28, new ECB(4, 22), new ECB(4, 23)),
        new ECBlocks(24, new ECB(3, 12), new ECB(8, 13))
      ),
      new _Version(
        12,
        Int32Array.from([6, 32, 58]),
        new ECBlocks(24, new ECB(2, 92), new ECB(2, 93)),
        new ECBlocks(22, new ECB(6, 36), new ECB(2, 37)),
        new ECBlocks(26, new ECB(4, 20), new ECB(6, 21)),
        new ECBlocks(28, new ECB(7, 14), new ECB(4, 15))
      ),
      new _Version(
        13,
        Int32Array.from([6, 34, 62]),
        new ECBlocks(26, new ECB(4, 107)),
        new ECBlocks(22, new ECB(8, 37), new ECB(1, 38)),
        new ECBlocks(24, new ECB(8, 20), new ECB(4, 21)),
        new ECBlocks(22, new ECB(12, 11), new ECB(4, 12))
      ),
      new _Version(
        14,
        Int32Array.from([6, 26, 46, 66]),
        new ECBlocks(30, new ECB(3, 115), new ECB(1, 116)),
        new ECBlocks(24, new ECB(4, 40), new ECB(5, 41)),
        new ECBlocks(20, new ECB(11, 16), new ECB(5, 17)),
        new ECBlocks(24, new ECB(11, 12), new ECB(5, 13))
      ),
      new _Version(
        15,
        Int32Array.from([6, 26, 48, 70]),
        new ECBlocks(22, new ECB(5, 87), new ECB(1, 88)),
        new ECBlocks(24, new ECB(5, 41), new ECB(5, 42)),
        new ECBlocks(30, new ECB(5, 24), new ECB(7, 25)),
        new ECBlocks(24, new ECB(11, 12), new ECB(7, 13))
      ),
      new _Version(
        16,
        Int32Array.from([6, 26, 50, 74]),
        new ECBlocks(24, new ECB(5, 98), new ECB(1, 99)),
        new ECBlocks(28, new ECB(7, 45), new ECB(3, 46)),
        new ECBlocks(24, new ECB(15, 19), new ECB(2, 20)),
        new ECBlocks(30, new ECB(3, 15), new ECB(13, 16))
      ),
      new _Version(
        17,
        Int32Array.from([6, 30, 54, 78]),
        new ECBlocks(28, new ECB(1, 107), new ECB(5, 108)),
        new ECBlocks(28, new ECB(10, 46), new ECB(1, 47)),
        new ECBlocks(28, new ECB(1, 22), new ECB(15, 23)),
        new ECBlocks(28, new ECB(2, 14), new ECB(17, 15))
      ),
      new _Version(
        18,
        Int32Array.from([6, 30, 56, 82]),
        new ECBlocks(30, new ECB(5, 120), new ECB(1, 121)),
        new ECBlocks(26, new ECB(9, 43), new ECB(4, 44)),
        new ECBlocks(28, new ECB(17, 22), new ECB(1, 23)),
        new ECBlocks(28, new ECB(2, 14), new ECB(19, 15))
      ),
      new _Version(
        19,
        Int32Array.from([6, 30, 58, 86]),
        new ECBlocks(28, new ECB(3, 113), new ECB(4, 114)),
        new ECBlocks(26, new ECB(3, 44), new ECB(11, 45)),
        new ECBlocks(26, new ECB(17, 21), new ECB(4, 22)),
        new ECBlocks(26, new ECB(9, 13), new ECB(16, 14))
      ),
      new _Version(
        20,
        Int32Array.from([6, 34, 62, 90]),
        new ECBlocks(28, new ECB(3, 107), new ECB(5, 108)),
        new ECBlocks(26, new ECB(3, 41), new ECB(13, 42)),
        new ECBlocks(30, new ECB(15, 24), new ECB(5, 25)),
        new ECBlocks(28, new ECB(15, 15), new ECB(10, 16))
      ),
      new _Version(
        21,
        Int32Array.from([6, 28, 50, 72, 94]),
        new ECBlocks(28, new ECB(4, 116), new ECB(4, 117)),
        new ECBlocks(26, new ECB(17, 42)),
        new ECBlocks(28, new ECB(17, 22), new ECB(6, 23)),
        new ECBlocks(30, new ECB(19, 16), new ECB(6, 17))
      ),
      new _Version(
        22,
        Int32Array.from([6, 26, 50, 74, 98]),
        new ECBlocks(28, new ECB(2, 111), new ECB(7, 112)),
        new ECBlocks(28, new ECB(17, 46)),
        new ECBlocks(30, new ECB(7, 24), new ECB(16, 25)),
        new ECBlocks(24, new ECB(34, 13))
      ),
      new _Version(
        23,
        Int32Array.from([6, 30, 54, 78, 102]),
        new ECBlocks(30, new ECB(4, 121), new ECB(5, 122)),
        new ECBlocks(28, new ECB(4, 47), new ECB(14, 48)),
        new ECBlocks(30, new ECB(11, 24), new ECB(14, 25)),
        new ECBlocks(30, new ECB(16, 15), new ECB(14, 16))
      ),
      new _Version(
        24,
        Int32Array.from([6, 28, 54, 80, 106]),
        new ECBlocks(30, new ECB(6, 117), new ECB(4, 118)),
        new ECBlocks(28, new ECB(6, 45), new ECB(14, 46)),
        new ECBlocks(30, new ECB(11, 24), new ECB(16, 25)),
        new ECBlocks(30, new ECB(30, 16), new ECB(2, 17))
      ),
      new _Version(
        25,
        Int32Array.from([6, 32, 58, 84, 110]),
        new ECBlocks(26, new ECB(8, 106), new ECB(4, 107)),
        new ECBlocks(28, new ECB(8, 47), new ECB(13, 48)),
        new ECBlocks(30, new ECB(7, 24), new ECB(22, 25)),
        new ECBlocks(30, new ECB(22, 15), new ECB(13, 16))
      ),
      new _Version(
        26,
        Int32Array.from([6, 30, 58, 86, 114]),
        new ECBlocks(28, new ECB(10, 114), new ECB(2, 115)),
        new ECBlocks(28, new ECB(19, 46), new ECB(4, 47)),
        new ECBlocks(28, new ECB(28, 22), new ECB(6, 23)),
        new ECBlocks(30, new ECB(33, 16), new ECB(4, 17))
      ),
      new _Version(
        27,
        Int32Array.from([6, 34, 62, 90, 118]),
        new ECBlocks(30, new ECB(8, 122), new ECB(4, 123)),
        new ECBlocks(28, new ECB(22, 45), new ECB(3, 46)),
        new ECBlocks(30, new ECB(8, 23), new ECB(26, 24)),
        new ECBlocks(30, new ECB(12, 15), new ECB(28, 16))
      ),
      new _Version(
        28,
        Int32Array.from([6, 26, 50, 74, 98, 122]),
        new ECBlocks(30, new ECB(3, 117), new ECB(10, 118)),
        new ECBlocks(28, new ECB(3, 45), new ECB(23, 46)),
        new ECBlocks(30, new ECB(4, 24), new ECB(31, 25)),
        new ECBlocks(30, new ECB(11, 15), new ECB(31, 16))
      ),
      new _Version(
        29,
        Int32Array.from([6, 30, 54, 78, 102, 126]),
        new ECBlocks(30, new ECB(7, 116), new ECB(7, 117)),
        new ECBlocks(28, new ECB(21, 45), new ECB(7, 46)),
        new ECBlocks(30, new ECB(1, 23), new ECB(37, 24)),
        new ECBlocks(30, new ECB(19, 15), new ECB(26, 16))
      ),
      new _Version(
        30,
        Int32Array.from([6, 26, 52, 78, 104, 130]),
        new ECBlocks(30, new ECB(5, 115), new ECB(10, 116)),
        new ECBlocks(28, new ECB(19, 47), new ECB(10, 48)),
        new ECBlocks(30, new ECB(15, 24), new ECB(25, 25)),
        new ECBlocks(30, new ECB(23, 15), new ECB(25, 16))
      ),
      new _Version(
        31,
        Int32Array.from([6, 30, 56, 82, 108, 134]),
        new ECBlocks(30, new ECB(13, 115), new ECB(3, 116)),
        new ECBlocks(28, new ECB(2, 46), new ECB(29, 47)),
        new ECBlocks(30, new ECB(42, 24), new ECB(1, 25)),
        new ECBlocks(30, new ECB(23, 15), new ECB(28, 16))
      ),
      new _Version(
        32,
        Int32Array.from([6, 34, 60, 86, 112, 138]),
        new ECBlocks(30, new ECB(17, 115)),
        new ECBlocks(28, new ECB(10, 46), new ECB(23, 47)),
        new ECBlocks(30, new ECB(10, 24), new ECB(35, 25)),
        new ECBlocks(30, new ECB(19, 15), new ECB(35, 16))
      ),
      new _Version(
        33,
        Int32Array.from([6, 30, 58, 86, 114, 142]),
        new ECBlocks(30, new ECB(17, 115), new ECB(1, 116)),
        new ECBlocks(28, new ECB(14, 46), new ECB(21, 47)),
        new ECBlocks(30, new ECB(29, 24), new ECB(19, 25)),
        new ECBlocks(30, new ECB(11, 15), new ECB(46, 16))
      ),
      new _Version(
        34,
        Int32Array.from([6, 34, 62, 90, 118, 146]),
        new ECBlocks(30, new ECB(13, 115), new ECB(6, 116)),
        new ECBlocks(28, new ECB(14, 46), new ECB(23, 47)),
        new ECBlocks(30, new ECB(44, 24), new ECB(7, 25)),
        new ECBlocks(30, new ECB(59, 16), new ECB(1, 17))
      ),
      new _Version(
        35,
        Int32Array.from([6, 30, 54, 78, 102, 126, 150]),
        new ECBlocks(30, new ECB(12, 121), new ECB(7, 122)),
        new ECBlocks(28, new ECB(12, 47), new ECB(26, 48)),
        new ECBlocks(30, new ECB(39, 24), new ECB(14, 25)),
        new ECBlocks(30, new ECB(22, 15), new ECB(41, 16))
      ),
      new _Version(
        36,
        Int32Array.from([6, 24, 50, 76, 102, 128, 154]),
        new ECBlocks(30, new ECB(6, 121), new ECB(14, 122)),
        new ECBlocks(28, new ECB(6, 47), new ECB(34, 48)),
        new ECBlocks(30, new ECB(46, 24), new ECB(10, 25)),
        new ECBlocks(30, new ECB(2, 15), new ECB(64, 16))
      ),
      new _Version(
        37,
        Int32Array.from([6, 28, 54, 80, 106, 132, 158]),
        new ECBlocks(30, new ECB(17, 122), new ECB(4, 123)),
        new ECBlocks(28, new ECB(29, 46), new ECB(14, 47)),
        new ECBlocks(30, new ECB(49, 24), new ECB(10, 25)),
        new ECBlocks(30, new ECB(24, 15), new ECB(46, 16))
      ),
      new _Version(
        38,
        Int32Array.from([6, 32, 58, 84, 110, 136, 162]),
        new ECBlocks(30, new ECB(4, 122), new ECB(18, 123)),
        new ECBlocks(28, new ECB(13, 46), new ECB(32, 47)),
        new ECBlocks(30, new ECB(48, 24), new ECB(14, 25)),
        new ECBlocks(30, new ECB(42, 15), new ECB(32, 16))
      ),
      new _Version(
        39,
        Int32Array.from([6, 26, 54, 82, 110, 138, 166]),
        new ECBlocks(30, new ECB(20, 117), new ECB(4, 118)),
        new ECBlocks(28, new ECB(40, 47), new ECB(7, 48)),
        new ECBlocks(30, new ECB(43, 24), new ECB(22, 25)),
        new ECBlocks(30, new ECB(10, 15), new ECB(67, 16))
      ),
      new _Version(
        40,
        Int32Array.from([6, 30, 58, 86, 114, 142, 170]),
        new ECBlocks(30, new ECB(19, 118), new ECB(6, 119)),
        new ECBlocks(28, new ECB(18, 47), new ECB(31, 48)),
        new ECBlocks(30, new ECB(34, 24), new ECB(34, 25)),
        new ECBlocks(30, new ECB(20, 15), new ECB(61, 16))
      )
    ];
  }
};
var FormatInformation = class _FormatInformation {
  constructor(errorCorrectionLevel, dataMask) {
    this.errorCorrectionLevel = errorCorrectionLevel;
    this.dataMask = dataMask;
  }
  static FORMAT_INFO_DECODE_LOOKUP = [
    [21522, 0],
    [20773, 1],
    [24188, 2],
    [23371, 3],
    [17913, 4],
    [16590, 5],
    [20375, 6],
    [19104, 7],
    [30660, 8],
    [29427, 9],
    [32170, 10],
    [30877, 11],
    [26159, 12],
    [25368, 13],
    [27713, 14],
    [26998, 15],
    [5769, 16],
    [5054, 17],
    [7399, 18],
    [6608, 19],
    [1890, 20],
    [597, 21],
    [3340, 22],
    [2107, 23],
    [13663, 24],
    [12392, 25],
    [16177, 26],
    [14854, 27],
    [9396, 28],
    [8579, 29],
    [11994, 30],
    [11245, 31]
  ];
  static numBitsDiffering(a, b) {
    let count = 0;
    let value = a ^ b;
    while (value !== 0) {
      count++;
      value &= value - 1;
    }
    return count;
  }
  static decodeFormatInformation(maskedFormatInfo1, maskedFormatInfo2) {
    const formatInfo = _FormatInformation.doDecodeFormatInformation(
      maskedFormatInfo1,
      maskedFormatInfo2
    );
    if (formatInfo !== null) return formatInfo;
    return _FormatInformation.doDecodeFormatInformation(
      maskedFormatInfo1 ^ 21522,
      maskedFormatInfo2 ^ 21522
    );
  }
  static doDecodeFormatInformation(maskedFormatInfo1, maskedFormatInfo2) {
    let bestDifference = Number.MAX_SAFE_INTEGER;
    let bestFormatInfo = 0;
    for (const decodeInfo of _FormatInformation.FORMAT_INFO_DECODE_LOOKUP) {
      const targetInfo = decodeInfo[0];
      if (targetInfo === maskedFormatInfo1 || targetInfo === maskedFormatInfo2) {
        return new _FormatInformation(
          ErrorCorrectionLevel.forBits(decodeInfo[1] >> 3 & 3),
          decodeInfo[1] & 7
        );
      }
      let bitsDifference = _FormatInformation.numBitsDiffering(maskedFormatInfo1, targetInfo);
      if (bitsDifference < bestDifference) {
        bestFormatInfo = decodeInfo[1];
        bestDifference = bitsDifference;
      }
      if (maskedFormatInfo1 !== maskedFormatInfo2) {
        bitsDifference = _FormatInformation.numBitsDiffering(maskedFormatInfo2, targetInfo);
        if (bitsDifference < bestDifference) {
          bestFormatInfo = decodeInfo[1];
          bestDifference = bitsDifference;
        }
      }
    }
    if (bestDifference <= 3) {
      return new _FormatInformation(
        ErrorCorrectionLevel.forBits(bestFormatInfo >> 3 & 3),
        bestFormatInfo & 7
      );
    }
    return null;
  }
  getErrorCorrectionLevel() {
    return this.errorCorrectionLevel;
  }
  getDataMask() {
    return this.dataMask;
  }
  hashCode() {
    return this.errorCorrectionLevel.getValue() << 3 | this.dataMask;
  }
  equals(o) {
    if (!(o instanceof _FormatInformation)) return false;
    return this.errorCorrectionLevel.equals(o.errorCorrectionLevel) && this.dataMask === o.dataMask;
  }
};
var DataMask = class _DataMask {
  static DATA_MASKS = [
    (i, j) => (i + j & 1) === 0,
    (i, _j) => (i & 1) === 0,
    (_i, j) => j % 3 === 0,
    (i, j) => (i + j) % 3 === 0,
    (i, j) => ((i / 2 | 0) + (j / 3 | 0) & 1) === 0,
    (i, j) => (i * j & 1) + i * j % 3 === 0,
    (i, j) => ((i * j & 1) + i * j % 3 & 1) === 0,
    (i, j) => ((i + j & 1) + i * j % 3 & 1) === 0
  ];
  static values() {
    return _DataMask.DATA_MASKS;
  }
  static isMasked(reference, i, j) {
    return _DataMask.DATA_MASKS[reference](i, j);
  }
  static unmaskBitMatrix(bits, dimension, reference) {
    for (let i = 0; i < dimension; i++) {
      for (let j = 0; j < dimension; j++) {
        if (_DataMask.isMasked(reference, i, j)) {
          bits.flip(j, i);
        }
      }
    }
  }
};

// src/modules/qr-decoder/reed-solomon.ts
var _log82 = createLogger("DECODER");
var AbstractGenericGF = class {
  expTable;
  logTable;
  exp(a) {
    return this.expTable[a];
  }
  log(a) {
    if (a === 0) throw new IllegalArgumentException();
    return this.logTable[a];
  }
  static addOrSubtract(a, b) {
    return a ^ b;
  }
};
var GenericGFPoly = class _GenericGFPoly {
  field;
  coefficients;
  constructor(field, coefficients) {
    if (coefficients.length === 0) throw new IllegalArgumentException();
    this.field = field;
    const coefficientsLength = coefficients.length;
    if (coefficientsLength > 1 && coefficients[0] === 0) {
      let firstNonZero = 1;
      while (firstNonZero < coefficientsLength && coefficients[firstNonZero] === 0) firstNonZero++;
      if (firstNonZero === coefficientsLength) {
        this.coefficients = Int32Array.from([0]);
      } else {
        this.coefficients = new Int32Array(coefficientsLength - firstNonZero);
        arraycopy(coefficients, firstNonZero, this.coefficients, 0, this.coefficients.length);
      }
    } else {
      this.coefficients = coefficients;
    }
  }
  getCoefficients() {
    return this.coefficients;
  }
  getDegree() {
    return this.coefficients.length - 1;
  }
  isZero() {
    return this.coefficients[0] === 0;
  }
  getCoefficient(degree) {
    return this.coefficients[this.coefficients.length - 1 - degree];
  }
  evaluateAt(a) {
    if (a === 0) return this.getCoefficient(0);
    const coefficients = this.coefficients;
    let result;
    if (a === 1) {
      result = 0;
      for (const coefficient of coefficients) {
        result = AbstractGenericGF.addOrSubtract(result, coefficient);
      }
      return result;
    }
    result = coefficients[0];
    const size = coefficients.length;
    for (let i = 1; i < size; i++) {
      result = AbstractGenericGF.addOrSubtract(this.field.multiply(a, result), coefficients[i]);
    }
    return result;
  }
  addOrSubtract(other) {
    if (!this.field.equals(other.field)) {
      throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
    }
    if (this.isZero()) return other;
    if (other.isZero()) return this;
    let smallerCoefficients = this.coefficients;
    let largerCoefficients = other.coefficients;
    if (smallerCoefficients.length > largerCoefficients.length) {
      const temp = smallerCoefficients;
      smallerCoefficients = largerCoefficients;
      largerCoefficients = temp;
    }
    const sumDiff = new Int32Array(largerCoefficients.length);
    const lengthDiff = largerCoefficients.length - smallerCoefficients.length;
    arraycopy(largerCoefficients, 0, sumDiff, 0, lengthDiff);
    for (let i = lengthDiff; i < largerCoefficients.length; i++) {
      sumDiff[i] = AbstractGenericGF.addOrSubtract(
        smallerCoefficients[i - lengthDiff],
        largerCoefficients[i]
      );
    }
    return new _GenericGFPoly(this.field, sumDiff);
  }
  multiply(other) {
    if (!this.field.equals(other.field)) {
      throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
    }
    if (this.isZero() || other.isZero()) return this.field.getZero();
    const aCoefficients = this.coefficients;
    const aLength = aCoefficients.length;
    const bCoefficients = other.coefficients;
    const bLength = bCoefficients.length;
    const product = new Int32Array(aLength + bLength - 1);
    for (let i = 0; i < aLength; i++) {
      const aCoeff = aCoefficients[i];
      for (let j = 0; j < bLength; j++) {
        product[i + j] = AbstractGenericGF.addOrSubtract(
          product[i + j],
          this.field.multiply(aCoeff, bCoefficients[j])
        );
      }
    }
    return new _GenericGFPoly(this.field, product);
  }
  multiplyScalar(scalar) {
    if (scalar === 0) return this.field.getZero();
    if (scalar === 1) return this;
    const size = this.coefficients.length;
    const product = new Int32Array(size);
    for (let i = 0; i < size; i++) {
      product[i] = this.field.multiply(this.coefficients[i], scalar);
    }
    return new _GenericGFPoly(this.field, product);
  }
  multiplyByMonomial(degree, coefficient) {
    if (degree < 0) throw new IllegalArgumentException();
    if (coefficient === 0) return this.field.getZero();
    const size = this.coefficients.length;
    const product = new Int32Array(size + degree);
    for (let i = 0; i < size; i++) {
      product[i] = this.field.multiply(this.coefficients[i], coefficient);
    }
    return new _GenericGFPoly(this.field, product);
  }
  divide(other) {
    if (!this.field.equals(other.field)) {
      throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
    }
    if (other.isZero()) throw new IllegalArgumentException("Divide by 0");
    let quotient = this.field.getZero();
    let remainder = this;
    const denominatorLeadingTerm = other.getCoefficient(other.getDegree());
    const inverseDenominatorLeadingTerm = this.field.inverse(denominatorLeadingTerm);
    while (remainder.getDegree() >= other.getDegree() && !remainder.isZero()) {
      const degreeDifference = remainder.getDegree() - other.getDegree();
      const scale = this.field.multiply(
        remainder.getCoefficient(remainder.getDegree()),
        inverseDenominatorLeadingTerm
      );
      const term = other.multiplyByMonomial(degreeDifference, scale);
      const iterationQuotient = this.field.buildMonomial(degreeDifference, scale);
      quotient = quotient.addOrSubtract(iterationQuotient);
      remainder = remainder.addOrSubtract(term);
    }
    return [quotient, remainder];
  }
  toString() {
    let result = "";
    for (let degree = this.getDegree(); degree >= 0; degree--) {
      let coefficient = this.getCoefficient(degree);
      if (coefficient !== 0) {
        if (coefficient < 0) {
          result += " - ";
          coefficient = -coefficient;
        } else if (result.length > 0) {
          result += " + ";
        }
        if (degree === 0 || coefficient !== 1) {
          const alphaPower = this.field.log(coefficient);
          if (alphaPower === 0) {
            result += "1";
          } else if (alphaPower === 1) {
            result += "a";
          } else {
            result += `a^${alphaPower}`;
          }
        }
        if (degree !== 0) {
          if (degree === 1) {
            result += "x";
          } else {
            result += `x^${degree}`;
          }
        }
      }
    }
    return result;
  }
};
var GenericGF = class _GenericGF extends AbstractGenericGF {
  constructor(primitive, size, generatorBase) {
    super();
    this.primitive = primitive;
    this.size = size;
    this.generatorBase = generatorBase;
    const expTable = new Int32Array(size);
    let x = 1;
    for (let i = 0; i < size; i++) {
      expTable[i] = x;
      x *= 2;
      if (x >= size) {
        x ^= primitive;
        x &= size - 1;
      }
    }
    this.expTable = expTable;
    const logTable = new Int32Array(size);
    for (let i = 0; i < size - 1; i++) {
      logTable[expTable[i]] = i;
    }
    this.logTable = logTable;
    this.zero = new GenericGFPoly(this, Int32Array.from([0]));
    this.one = new GenericGFPoly(this, Int32Array.from([1]));
  }
  static AZTEC_DATA_12 = new _GenericGF(4201, 4096, 1);
  static AZTEC_DATA_10 = new _GenericGF(1033, 1024, 1);
  static AZTEC_DATA_6 = new _GenericGF(67, 64, 1);
  static AZTEC_PARAM = new _GenericGF(19, 16, 1);
  static QR_CODE_FIELD_256 = new _GenericGF(285, 256, 0);
  static DATA_MATRIX_FIELD_256 = new _GenericGF(301, 256, 1);
  static AZTEC_DATA_8 = _GenericGF.DATA_MATRIX_FIELD_256;
  static MAXICODE_FIELD_64 = _GenericGF.AZTEC_DATA_6;
  zero;
  one;
  getZero() {
    return this.zero;
  }
  getOne() {
    return this.one;
  }
  buildMonomial(degree, coefficient) {
    if (degree < 0) throw new IllegalArgumentException();
    if (coefficient === 0) return this.zero;
    const coefficients = new Int32Array(degree + 1);
    coefficients[0] = coefficient;
    return new GenericGFPoly(this, coefficients);
  }
  inverse(a) {
    if (a === 0) throw new ArithmeticException();
    return this.expTable[this.size - this.logTable[a] - 1];
  }
  multiply(a, b) {
    if (a === 0 || b === 0) return 0;
    return this.expTable[(this.logTable[a] + this.logTable[b]) % (this.size - 1)];
  }
  getSize() {
    return this.size;
  }
  getGeneratorBase() {
    return this.generatorBase;
  }
  toString() {
    return `GF(0x${Integer.toHexString(this.primitive)},${this.size})`;
  }
  equals(o) {
    return o === this;
  }
};
var ReedSolomonDecoder = class {
  constructor(field) {
    this.field = field;
  }
  decode(received, twoS) {
    const poly = new GenericGFPoly(this.field, received);
    const syndromeCoefficients = new Int32Array(twoS);
    let noError = true;
    for (let i = 0; i < twoS; i++) {
      const evalResult = poly.evaluateAt(this.field.exp(i + this.field.getGeneratorBase()));
      syndromeCoefficients[syndromeCoefficients.length - 1 - i] = evalResult;
      if (evalResult !== 0) noError = false;
    }
    if (noError) return;
    const syndrome = new GenericGFPoly(this.field, syndromeCoefficients);
    const sigmaOmega = this.runEuclideanAlgorithm(
      this.field.buildMonomial(twoS, 1),
      syndrome,
      twoS
    );
    const sigma = sigmaOmega[0];
    const omega = sigmaOmega[1];
    const errorLocations = this.findErrorLocations(sigma);
    const errorMagnitudes = this.findErrorMagnitudes(omega, errorLocations);
    for (let i = 0; i < errorLocations.length; i++) {
      const position = received.length - 1 - this.field.log(errorLocations[i]);
      if (position < 0) throw new ReedSolomonException("Bad error location");
      received[position] = GenericGF.addOrSubtract(received[position], errorMagnitudes[i]);
    }
  }
  runEuclideanAlgorithm(a, b, R) {
    if (a.getDegree() < b.getDegree()) {
      const temp = a;
      a = b;
      b = temp;
    }
    let rLast = a;
    let r = b;
    let tLast = this.field.getZero();
    let t = this.field.getOne();
    while (r.getDegree() >= (R / 2 | 0)) {
      const rLastLast = rLast;
      const tLastLast = tLast;
      rLast = r;
      tLast = t;
      if (rLast.isZero()) throw new ReedSolomonException("r_{i-1} was zero");
      r = rLastLast;
      let q = this.field.getZero();
      const denominatorLeadingTerm = rLast.getCoefficient(rLast.getDegree());
      const dltInverse = this.field.inverse(denominatorLeadingTerm);
      while (r.getDegree() >= rLast.getDegree() && !r.isZero()) {
        const degreeDiff = r.getDegree() - rLast.getDegree();
        const scale = this.field.multiply(r.getCoefficient(r.getDegree()), dltInverse);
        q = q.addOrSubtract(this.field.buildMonomial(degreeDiff, scale));
        r = r.addOrSubtract(rLast.multiplyByMonomial(degreeDiff, scale));
      }
      t = q.multiply(tLast).addOrSubtract(tLastLast);
      if (r.getDegree() >= rLast.getDegree()) {
        throw new IllegalStateException("Division algorithm failed to reduce polynomial?");
      }
    }
    const sigmaTildeAtZero = t.getCoefficient(0);
    if (sigmaTildeAtZero === 0) throw new ReedSolomonException("sigmaTilde(0) was zero");
    const inverse = this.field.inverse(sigmaTildeAtZero);
    const sigma = t.multiplyScalar(inverse);
    const omega = r.multiplyScalar(inverse);
    return [sigma, omega];
  }
  findErrorLocations(errorLocator) {
    const numErrors = errorLocator.getDegree();
    if (numErrors === 1) return Int32Array.from([errorLocator.getCoefficient(1)]);
    const result = new Int32Array(numErrors);
    let e = 0;
    for (let i = 1; i < this.field.getSize() && e < numErrors; i++) {
      if (errorLocator.evaluateAt(i) === 0) {
        result[e] = this.field.inverse(i);
        e++;
      }
    }
    if (e !== numErrors) {
      throw new ReedSolomonException("Error locator degree does not match number of roots");
    }
    return result;
  }
  findErrorMagnitudes(errorEvaluator, errorLocations) {
    const s = errorLocations.length;
    const result = new Int32Array(s);
    for (let i = 0; i < s; i++) {
      const xiInverse = this.field.inverse(errorLocations[i]);
      let denominator = 1;
      for (let j = 0; j < s; j++) {
        if (i !== j) {
          const term = this.field.multiply(errorLocations[j], xiInverse);
          const termPlus1 = (term & 1) === 0 ? term | 1 : term & ~1;
          denominator = this.field.multiply(denominator, termPlus1);
        }
      }
      result[i] = this.field.multiply(
        errorEvaluator.evaluateAt(xiInverse),
        this.field.inverse(denominator)
      );
      if (this.field.getGeneratorBase() !== 0) {
        result[i] = this.field.multiply(result[i], xiInverse);
      }
    }
    return result;
  }
};

// src/modules/qr-decoder/perspective.ts
var _log83 = createLogger("DECODER");
var PerspectiveTransform = class _PerspectiveTransform {
  constructor(a11, a21, a31, a12, a22, a32, a13, a23, a33) {
    this.a11 = a11;
    this.a21 = a21;
    this.a31 = a31;
    this.a12 = a12;
    this.a22 = a22;
    this.a32 = a32;
    this.a13 = a13;
    this.a23 = a23;
    this.a33 = a33;
  }
  static quadrilateralToQuadrilateral(x0, y0, x1, y1, x2, y2, x3, y3, x0p, y0p, x1p, y1p, x2p, y2p, x3p, y3p) {
    const qToS = _PerspectiveTransform.quadrilateralToSquare(x0, y0, x1, y1, x2, y2, x3, y3);
    const sToQ = _PerspectiveTransform.squareToQuadrilateral(x0p, y0p, x1p, y1p, x2p, y2p, x3p, y3p);
    return sToQ.times(qToS);
  }
  transformPoints(points) {
    const { a11, a12, a13, a21, a22, a23, a31, a32, a33 } = this;
    for (let i = 0; i < points.length; i += 2) {
      const x = points[i];
      const y = points[i + 1];
      const denominator = a13 * x + a23 * y + a33;
      points[i] = (a11 * x + a21 * y + a31) / denominator;
      points[i + 1] = (a12 * x + a22 * y + a32) / denominator;
    }
  }
  transformPointsWithValues(xValues, yValues) {
    const { a11, a12, a13, a21, a22, a23, a31, a32, a33 } = this;
    const n = xValues.length;
    for (let i = 0; i < n; i++) {
      const x = xValues[i];
      const y = yValues[i];
      const denominator = a13 * x + a23 * y + a33;
      xValues[i] = (a11 * x + a21 * y + a31) / denominator;
      yValues[i] = (a12 * x + a22 * y + a32) / denominator;
    }
  }
  static squareToQuadrilateral(x0, y0, x1, y1, x2, y2, x3, y3) {
    const dx3 = x0 - x1 + x2 - x3;
    const dy3 = y0 - y1 + y2 - y3;
    if (dx3 === 0 && dy3 === 0) {
      return new _PerspectiveTransform(x1 - x0, x2 - x1, x0, y1 - y0, y2 - y1, y0, 0, 0, 1);
    } else {
      const dx1 = x1 - x2;
      const dx2 = x3 - x2;
      const dy1 = y1 - y2;
      const dy2 = y3 - y2;
      const denominator = dx1 * dy2 - dx2 * dy1;
      const a13 = (dx3 * dy2 - dx2 * dy3) / denominator;
      const a23 = (dx1 * dy3 - dx3 * dy1) / denominator;
      return new _PerspectiveTransform(
        x1 - x0 + a13 * x1,
        x3 - x0 + a23 * x3,
        x0,
        y1 - y0 + a13 * y1,
        y3 - y0 + a23 * y3,
        y0,
        a13,
        a23,
        1
      );
    }
  }
  static quadrilateralToSquare(x0, y0, x1, y1, x2, y2, x3, y3) {
    return _PerspectiveTransform.squareToQuadrilateral(
      x0,
      y0,
      x1,
      y1,
      x2,
      y2,
      x3,
      y3
    ).buildAdjoint();
  }
  buildAdjoint() {
    return new _PerspectiveTransform(
      this.a22 * this.a33 - this.a23 * this.a32,
      this.a23 * this.a31 - this.a21 * this.a33,
      this.a21 * this.a32 - this.a22 * this.a31,
      this.a13 * this.a32 - this.a12 * this.a33,
      this.a11 * this.a33 - this.a13 * this.a31,
      this.a12 * this.a31 - this.a11 * this.a32,
      this.a12 * this.a23 - this.a13 * this.a22,
      this.a13 * this.a21 - this.a11 * this.a23,
      this.a11 * this.a22 - this.a12 * this.a21
    );
  }
  times(other) {
    return new _PerspectiveTransform(
      this.a11 * other.a11 + this.a21 * other.a12 + this.a31 * other.a13,
      this.a11 * other.a21 + this.a21 * other.a22 + this.a31 * other.a23,
      this.a11 * other.a31 + this.a21 * other.a32 + this.a31 * other.a33,
      this.a12 * other.a11 + this.a22 * other.a12 + this.a32 * other.a13,
      this.a12 * other.a21 + this.a22 * other.a22 + this.a32 * other.a23,
      this.a12 * other.a31 + this.a22 * other.a32 + this.a32 * other.a33,
      this.a13 * other.a11 + this.a23 * other.a12 + this.a33 * other.a13,
      this.a13 * other.a21 + this.a23 * other.a22 + this.a33 * other.a23,
      this.a13 * other.a31 + this.a23 * other.a32 + this.a33 * other.a33
    );
  }
};
var GridSampler = class {
  static checkAndNudgePoints(image, points) {
    const width = image.getWidth();
    const height = image.getHeight();
    let nudged = true;
    for (let offset = 0; offset < points.length && nudged; offset += 2) {
      const x = Math.floor(points[offset]);
      const y = Math.floor(points[offset + 1]);
      if (x < -1 || x > width || y < -1 || y > height) {
        throw new NotFoundException();
      }
      nudged = false;
      if (x === -1) {
        points[offset] = 0;
        nudged = true;
      } else if (x === width) {
        points[offset] = width - 1;
        nudged = true;
      }
      if (y === -1) {
        points[offset + 1] = 0;
        nudged = true;
      } else if (y === height) {
        points[offset + 1] = height - 1;
        nudged = true;
      }
    }
    nudged = true;
    for (let offset = points.length - 2; offset >= 0 && nudged; offset -= 2) {
      const x = Math.floor(points[offset]);
      const y = Math.floor(points[offset + 1]);
      if (x < -1 || x > width || y < -1 || y > height) {
        throw new NotFoundException();
      }
      nudged = false;
      if (x === -1) {
        points[offset] = 0;
        nudged = true;
      } else if (x === width) {
        points[offset] = width - 1;
        nudged = true;
      }
      if (y === -1) {
        points[offset + 1] = 0;
        nudged = true;
      } else if (y === height) {
        points[offset + 1] = height - 1;
        nudged = true;
      }
    }
  }
};
var DefaultGridSampler = class extends GridSampler {
  sampleGrid(image, dimensionX, dimensionY, p1ToX, p1ToY, p2ToX, p2ToY, p3ToX, p3ToY, p4ToX, p4ToY, p1FromX, p1FromY, p2FromX, p2FromY, p3FromX, p3FromY, p4FromX, p4FromY) {
    const transform = PerspectiveTransform.quadrilateralToQuadrilateral(
      p1ToX,
      p1ToY,
      p2ToX,
      p2ToY,
      p3ToX,
      p3ToY,
      p4ToX,
      p4ToY,
      p1FromX,
      p1FromY,
      p2FromX,
      p2FromY,
      p3FromX,
      p3FromY,
      p4FromX,
      p4FromY
    );
    return this.sampleGridWithTransform(image, dimensionX, dimensionY, transform);
  }
  sampleGridWithTransform(image, dimensionX, dimensionY, transform) {
    if (dimensionX <= 0 || dimensionY <= 0) {
      throw new NotFoundException();
    }
    const bits = new BitMatrix(dimensionX, dimensionY);
    const points = new Float32Array(2 * dimensionX);
    for (let y = 0; y < dimensionY; y++) {
      const max = points.length;
      const iValue = y + 0.5;
      for (let x = 0; x < max; x += 2) {
        points[x] = x / 2 + 0.5;
        points[x + 1] = iValue;
      }
      transform.transformPoints(points);
      GridSampler.checkAndNudgePoints(image, points);
      try {
        for (let x = 0; x < max; x += 2) {
          if (image.get(Math.floor(points[x]), Math.floor(points[x + 1]))) {
            bits.set(x / 2, y);
          }
        }
      } catch (_e) {
        throw new NotFoundException();
      }
    }
    return bits;
  }
};
var MathUtils = class {
  static round(d) {
    return Math.round(d);
  }
  static distance(aX, aY, bX, bY) {
    const xDiff = aX - bX;
    const yDiff = aY - bY;
    return Math.sqrt(xDiff * xDiff + yDiff * yDiff);
  }
  static sum(array) {
    let count = 0;
    for (const a of array) count += a;
    return count;
  }
};

// src/modules/qr-decoder/result-types.ts
var _log84 = createLogger("DECODER");
var DecodeHintType = /* @__PURE__ */ ((DecodeHintType2) => {
  DecodeHintType2[DecodeHintType2["OTHER"] = 0] = "OTHER";
  DecodeHintType2[DecodeHintType2["PURE_BARCODE"] = 1] = "PURE_BARCODE";
  DecodeHintType2[DecodeHintType2["POSSIBLE_FORMATS"] = 2] = "POSSIBLE_FORMATS";
  DecodeHintType2[DecodeHintType2["TRY_HARDER"] = 3] = "TRY_HARDER";
  DecodeHintType2[DecodeHintType2["CHARACTER_SET"] = 4] = "CHARACTER_SET";
  DecodeHintType2[DecodeHintType2["ALLOWED_LENGTHS"] = 5] = "ALLOWED_LENGTHS";
  DecodeHintType2[DecodeHintType2["ASSUME_CODE_39_CHECK_DIGIT"] = 6] = "ASSUME_CODE_39_CHECK_DIGIT";
  DecodeHintType2[DecodeHintType2["ASSUME_GS1"] = 7] = "ASSUME_GS1";
  DecodeHintType2[DecodeHintType2["RETURN_CODABAR_START_END"] = 8] = "RETURN_CODABAR_START_END";
  DecodeHintType2[DecodeHintType2["NEED_RESULT_POINT_CALLBACK"] = 9] = "NEED_RESULT_POINT_CALLBACK";
  DecodeHintType2[DecodeHintType2["ALLOWED_EAN_EXTENSIONS"] = 10] = "ALLOWED_EAN_EXTENSIONS";
  return DecodeHintType2;
})(DecodeHintType || {});
var ResultPoint = class _ResultPoint {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  getX() {
    return this.x;
  }
  getY() {
    return this.y;
  }
  equals(other) {
    if (other instanceof _ResultPoint) {
      return this.x === other.x && this.y === other.y;
    }
    return false;
  }
  hashCode() {
    return 31 * Float.floatToIntBits(this.x) + Float.floatToIntBits(this.y);
  }
  toString() {
    return `(${this.x},${this.y})`;
  }
  static orderBestPatterns(patterns) {
    const zeroOneDistance = _ResultPoint.distance(patterns[0], patterns[1]);
    const oneTwoDistance = _ResultPoint.distance(patterns[1], patterns[2]);
    const zeroTwoDistance = _ResultPoint.distance(patterns[0], patterns[2]);
    let pointA;
    let pointB;
    let pointC;
    if (oneTwoDistance >= zeroOneDistance && oneTwoDistance >= zeroTwoDistance) {
      pointB = patterns[0];
      pointA = patterns[1];
      pointC = patterns[2];
    } else if (zeroTwoDistance >= oneTwoDistance && zeroTwoDistance >= zeroOneDistance) {
      pointB = patterns[1];
      pointA = patterns[0];
      pointC = patterns[2];
    } else {
      pointB = patterns[2];
      pointA = patterns[0];
      pointC = patterns[1];
    }
    if (_ResultPoint.crossProductZ(pointA, pointB, pointC) < 0) {
      const temp = pointA;
      pointA = pointC;
      pointC = temp;
    }
    patterns[0] = pointA;
    patterns[1] = pointB;
    patterns[2] = pointC;
  }
  static distance(pattern1, pattern2) {
    return MathUtils.distance(pattern1.x, pattern1.y, pattern2.x, pattern2.y);
  }
  static crossProductZ(pointA, pointB, pointC) {
    const bX = pointB.x;
    const bY = pointB.y;
    return (pointC.x - bX) * (pointA.y - bY) - (pointC.y - bY) * (pointA.x - bX);
  }
};
var Result = class {
  constructor(text, rawBytes, numBits = rawBytes == null ? 0 : 8 * rawBytes.length, resultPoints, format, timestamp = currentTimeMillis()) {
    this.text = text;
    this.rawBytes = rawBytes;
    this.numBits = numBits;
    this.resultPoints = resultPoints;
    this.format = format;
    this.timestamp = timestamp;
    if (numBits === void 0 || numBits === null) {
      this.numBits = rawBytes === null || rawBytes === void 0 ? 0 : 8 * rawBytes.length;
    }
    if (timestamp === void 0 || timestamp === null) {
      this.timestamp = currentTimeMillis();
    }
  }
  resultMetadata = null;
  getText() {
    return this.text;
  }
  getRawBytes() {
    return this.rawBytes;
  }
  getNumBits() {
    return this.numBits;
  }
  getResultPoints() {
    return this.resultPoints;
  }
  getBarcodeFormat() {
    return this.format;
  }
  getResultMetadata() {
    return this.resultMetadata;
  }
  putMetadata(type, value) {
    if (this.resultMetadata === null) {
      this.resultMetadata = /* @__PURE__ */ new Map();
    }
    this.resultMetadata.set(type, value);
  }
  putAllMetadata(metadata) {
    if (metadata !== null) {
      if (this.resultMetadata === null) {
        this.resultMetadata = metadata;
      } else {
        this.resultMetadata = new Map(metadata);
      }
    }
  }
  addResultPoints(newPoints) {
    const oldPoints = this.resultPoints;
    if (oldPoints === null) {
      this.resultPoints = newPoints;
    } else if (newPoints !== null && newPoints.length > 0) {
      const allPoints = new Array(oldPoints.length + newPoints.length);
      arraycopy(oldPoints, 0, allPoints, 0, oldPoints.length);
      arraycopy(newPoints, 0, allPoints, oldPoints.length, newPoints.length);
      this.resultPoints = allPoints;
    }
  }
  getTimestamp() {
    return this.timestamp;
  }
  toString() {
    return this.text;
  }
};
var DecoderResult = class {
  constructor(rawBytes, text, byteSegments, ecLevel, numBits) {
    this.rawBytes = rawBytes;
    this.text = text;
    this.byteSegments = byteSegments;
    this.ecLevel = ecLevel;
    this.numBits = numBits ?? (rawBytes == null ? 0 : 8 * rawBytes.length);
  }
  numBits;
  errorsCorrected = null;
  erasures = null;
  other = null;
  structuredAppendParity = -1;
  structuredAppendSequenceNumber = -1;
  symbologyModifier = 0;
  version = null;
  maskPattern = null;
  getRawBytes() {
    return this.rawBytes;
  }
  getNumBits() {
    return this.numBits;
  }
  setNumBits(numBits) {
    this.numBits = numBits;
  }
  getText() {
    return this.text;
  }
  getByteSegments() {
    return this.byteSegments;
  }
  getECLevel() {
    return this.ecLevel;
  }
  getErrorsCorrected() {
    return this.errorsCorrected;
  }
  setErrorsCorrected(errorsCorrected) {
    this.errorsCorrected = errorsCorrected;
  }
  getErasures() {
    return this.erasures;
  }
  setErasures(erasures) {
    this.erasures = erasures;
  }
  getOther() {
    return this.other;
  }
  setOther(other) {
    this.other = other;
  }
  hasStructuredAppend() {
    return this.structuredAppendParity >= 0 && this.structuredAppendSequenceNumber >= 0;
  }
  getStructuredAppendParity() {
    return this.structuredAppendParity;
  }
  getStructuredAppendSequenceNumber() {
    return this.structuredAppendSequenceNumber;
  }
  setStructuredAppendParity(parity) {
    this.structuredAppendParity = parity;
  }
  setStructuredAppendSequenceNumber(sequenceNumber) {
    this.structuredAppendSequenceNumber = sequenceNumber;
  }
  getSymbologyModifier() {
    return this.symbologyModifier;
  }
  setSymbologyModifier(modifier) {
    this.symbologyModifier = modifier;
  }
  getVersion() {
    return this.version;
  }
  setVersion(version) {
    this.version = version;
  }
  getMaskPattern() {
    return this.maskPattern;
  }
  setMaskPattern(maskPattern) {
    this.maskPattern = maskPattern;
  }
};

// src/modules/qr-decoder/qr-data-decoder.ts
var _log85 = createLogger("DECODER");
var BitMatrixParser = class {
  constructor(bitMatrix) {
    this.bitMatrix = bitMatrix;
    const dimension = bitMatrix.getHeight();
    if (dimension < 21 || (dimension & 3) !== 1) {
      throw new FormatException();
    }
  }
  parsedVersion = null;
  parsedFormatInfo = null;
  mirror = false;
  readFormatInformation() {
    if (this.parsedFormatInfo !== null) return this.parsedFormatInfo;
    let formatInfoBits1 = 0;
    for (let i = 0; i < 6; i++) {
      formatInfoBits1 = this.copyBit(i, 8, formatInfoBits1);
    }
    formatInfoBits1 = this.copyBit(7, 8, formatInfoBits1);
    formatInfoBits1 = this.copyBit(8, 8, formatInfoBits1);
    formatInfoBits1 = this.copyBit(8, 7, formatInfoBits1);
    for (let j = 5; j >= 0; j--) {
      formatInfoBits1 = this.copyBit(8, j, formatInfoBits1);
    }
    const dimension = this.bitMatrix.getHeight();
    let formatInfoBits2 = 0;
    const jMin = dimension - 7;
    for (let j = dimension - 1; j >= jMin; j--) {
      formatInfoBits2 = this.copyBit(8, j, formatInfoBits2);
    }
    for (let i = dimension - 8; i < dimension; i++) {
      formatInfoBits2 = this.copyBit(i, 8, formatInfoBits2);
    }
    this.parsedFormatInfo = FormatInformation.decodeFormatInformation(
      formatInfoBits1,
      formatInfoBits2
    );
    if (this.parsedFormatInfo !== null) return this.parsedFormatInfo;
    throw new FormatException();
  }
  readVersion() {
    if (this.parsedVersion !== null) return this.parsedVersion;
    const dimension = this.bitMatrix.getHeight();
    const provisionalVersion = (dimension - 17) / 4;
    if (provisionalVersion <= 6) {
      return Version.getVersionForNumber(provisionalVersion);
    }
    let versionBits = 0;
    const ijMin = dimension - 11;
    for (let j = 5; j >= 0; j--) {
      for (let i = dimension - 9; i >= ijMin; i--) {
        versionBits = this.copyBit(i, j, versionBits);
      }
    }
    let theParsedVersion = Version.decodeVersionInformation(versionBits);
    if (theParsedVersion !== null && theParsedVersion.getDimensionForVersion() === dimension) {
      this.parsedVersion = theParsedVersion;
      return theParsedVersion;
    }
    versionBits = 0;
    for (let i = 5; i >= 0; i--) {
      for (let j = dimension - 9; j >= ijMin; j--) {
        versionBits = this.copyBit(i, j, versionBits);
      }
    }
    theParsedVersion = Version.decodeVersionInformation(versionBits);
    if (theParsedVersion !== null && theParsedVersion.getDimensionForVersion() === dimension) {
      this.parsedVersion = theParsedVersion;
      return theParsedVersion;
    }
    throw new FormatException();
  }
  copyBit(i, j, versionBits) {
    const bit = this.mirror ? this.bitMatrix.get(j, i) : this.bitMatrix.get(i, j);
    return bit ? versionBits << 1 | 1 : versionBits << 1;
  }
  readCodewords() {
    const formatInfo = this.readFormatInformation();
    const version = this.readVersion();
    DataMask.unmaskBitMatrix(this.bitMatrix, this.bitMatrix.getHeight(), formatInfo.getDataMask());
    const functionPattern = version.buildFunctionPattern();
    let readingUp = true;
    const result = [];
    let resultOffset = 0;
    let currentByte = 0;
    let bitsRead = 0;
    const dimension = this.bitMatrix.getHeight();
    for (let j = dimension - 1; j > 0; j -= 2) {
      if (j === 6) j--;
      for (let count = 0; count < dimension; count++) {
        const i = readingUp ? dimension - 1 - count : count;
        for (let col = 0; col < 2; col++) {
          if (!functionPattern.get(j - col, i)) {
            bitsRead++;
            currentByte <<= 1;
            if (this.bitMatrix.get(j - col, i)) {
              currentByte |= 1;
            }
            if (bitsRead === 8) {
              result[resultOffset++] = currentByte;
              bitsRead = 0;
              currentByte = 0;
            }
          }
        }
      }
      readingUp = !readingUp;
    }
    if (resultOffset !== version.getTotalCodewords()) {
      throw new FormatException();
    }
    return new Uint8Array(result);
  }
  remask() {
    if (this.parsedFormatInfo === null) return;
    DataMask.unmaskBitMatrix(
      this.bitMatrix,
      this.bitMatrix.getHeight(),
      this.parsedFormatInfo.getDataMask()
    );
  }
  setMirror(mirror) {
    this.parsedVersion = null;
    this.parsedFormatInfo = null;
    this.mirror = mirror;
  }
  mirror_() {
    const dimension = this.bitMatrix.getHeight();
    for (let x = 0; x < dimension; x++) {
      for (let y = x + 1; y < dimension; y++) {
        if (this.bitMatrix.get(x, y) !== this.bitMatrix.get(y, x)) {
          this.bitMatrix.flip(y, x);
          this.bitMatrix.flip(x, y);
        }
      }
    }
  }
};
var QRDecoder = class _QRDecoder {
  rsDecoder;
  constructor() {
    this.rsDecoder = new ReedSolomonDecoder(GenericGF.QR_CODE_FIELD_256);
  }
  decode(bits, hints) {
    const parser = new BitMatrixParser(bits);
    let fe = null;
    let ce = null;
    try {
      return this.decodeBitMatrix(parser, hints);
    } catch (e) {
      fe = e;
    }
    try {
      parser.remask();
      parser.setMirror(true);
      parser.readVersion();
      parser.readFormatInformation();
      parser.mirror_();
      const result = this.decodeBitMatrix(parser, hints);
      result.setOther(result);
      return result;
    } catch (e) {
      ce = e;
    }
    if (fe !== null) throw fe;
    throw ce;
  }
  decodeBitMatrix(parser, hints) {
    const version = parser.readVersion();
    const formatInfo = parser.readFormatInformation();
    const ecLevel = formatInfo.getErrorCorrectionLevel();
    const maskPattern = formatInfo.getDataMask();
    const codewords = parser.readCodewords();
    const dataBlocks = this.getDataBlocks(codewords, version, ecLevel);
    let totalBytes = 0;
    for (const dataBlock of dataBlocks) {
      totalBytes += dataBlock.numDataCodewords;
    }
    const resultBytes = new Uint8Array(totalBytes);
    let resultOffset = 0;
    for (const dataBlock of dataBlocks) {
      const codewordBytes = dataBlock.codewords;
      const numDataCodewords = dataBlock.numDataCodewords;
      this.correctErrors(codewordBytes, numDataCodewords);
      for (let i = 0; i < numDataCodewords; i++) {
        resultBytes[resultOffset++] = codewordBytes[i];
      }
    }
    const result = this.decodeData(resultBytes, version, ecLevel, hints);
    result.setVersion(version.getVersionNumber());
    result.setMaskPattern(maskPattern);
    return result;
  }
  getDataBlocks(rawCodewords, version, ecLevel) {
    const ecBlocks = version.getECBlocksForLevel(ecLevel);
    let totalBlocks = 0;
    const ecBlockArray = ecBlocks.getECBlocks();
    for (const ecBlock of ecBlockArray) {
      totalBlocks += ecBlock.getCount();
    }
    const result = new Array(totalBlocks);
    let numResultBlocks = 0;
    for (const ecBlock of ecBlockArray) {
      for (let i = 0; i < ecBlock.getCount(); i++) {
        const numDataCodewords = ecBlock.getDataCodewords();
        const numBlockCodewords = ecBlocks.getECCodewordsPerBlock() + numDataCodewords;
        result[numResultBlocks++] = {
          codewords: new Int32Array(numBlockCodewords),
          numDataCodewords
        };
      }
    }
    const shorterBlocksTotalCodewords = result[0].codewords.length;
    let longerBlocksStartAt = result.length - 1;
    while (longerBlocksStartAt >= 0) {
      const numCodewords = result[longerBlocksStartAt].codewords.length;
      if (numCodewords === shorterBlocksTotalCodewords) break;
      longerBlocksStartAt--;
    }
    longerBlocksStartAt++;
    const shorterBlocksNumDataCodewords = shorterBlocksTotalCodewords - ecBlocks.getECCodewordsPerBlock();
    let rawCodewordsOffset = 0;
    for (let i = 0; i < shorterBlocksNumDataCodewords; i++) {
      for (let j = 0; j < numResultBlocks; j++) {
        result[j].codewords[i] = rawCodewords[rawCodewordsOffset++];
      }
    }
    for (let j = longerBlocksStartAt; j < numResultBlocks; j++) {
      result[j].codewords[shorterBlocksNumDataCodewords] = rawCodewords[rawCodewordsOffset++];
    }
    const max = result[0].codewords.length;
    for (let i = shorterBlocksNumDataCodewords; i < max; i++) {
      for (let j = 0; j < numResultBlocks; j++) {
        const jOffset = j < longerBlocksStartAt ? i : i + 1;
        result[j].codewords[jOffset] = rawCodewords[rawCodewordsOffset++];
      }
    }
    return result;
  }
  correctErrors(codewordBytes, numDataCodewords) {
    const numCodewords = codewordBytes.length;
    const codewordsInts = new Int32Array(numCodewords);
    for (let i = 0; i < numCodewords; i++) {
      codewordsInts[i] = codewordBytes[i] & 255;
    }
    try {
      this.rsDecoder.decode(codewordsInts, codewordBytes.length - numDataCodewords);
    } catch (_rse) {
      throw new ChecksumException();
    }
    for (let i = 0; i < numDataCodewords; i++) {
      codewordBytes[i] = codewordsInts[i];
    }
  }
  decodeData(bytes, version, ecLevel, hints) {
    const bits = new BitSource(bytes);
    const result = new StringBuilder();
    const byteSegments = [];
    let mode;
    let fc1InEffect = false;
    do {
      if (bits.available() < 4) {
        mode = Mode.TERMINATOR;
      } else {
        const modeBits = bits.readBits(4);
        mode = Mode.forBits(modeBits);
      }
      switch (mode) {
        case Mode.TERMINATOR:
          break;
        case Mode.FNC1_FIRST_POSITION:
        case Mode.FNC1_SECOND_POSITION:
          fc1InEffect = true;
          break;
        case Mode.STRUCTURED_APPEND:
          if (bits.available() < 16) throw new FormatException();
          bits.readBits(16);
          break;
        case Mode.ECI: {
          const _value = this.parseECIValue(bits);
          break;
        }
        case Mode.HANZI: {
          const subset = bits.readBits(4);
          const countHanzi = bits.readBits(mode.getCharacterCountBits(version));
          if (subset === 1) {
            this.decodeHanziSegment(bits, result, countHanzi);
          }
          break;
        }
        default: {
          const count = bits.readBits(mode.getCharacterCountBits(version));
          switch (mode) {
            case Mode.NUMERIC:
              this.decodeNumericSegment(bits, result, count);
              break;
            case Mode.ALPHANUMERIC:
              this.decodeAlphanumericSegment(bits, result, count, fc1InEffect);
              break;
            case Mode.BYTE:
              this.decodeByteSegment(bits, result, count, byteSegments, hints);
              break;
            case Mode.KANJI:
              this.decodeKanjiSegment(bits, result, count);
              break;
            default:
              throw new FormatException();
          }
        }
      }
    } while (mode !== Mode.TERMINATOR);
    return new DecoderResult(
      bytes,
      result.toString(),
      byteSegments.length === 0 ? null : byteSegments,
      ecLevel.toString()
    );
  }
  parseECIValue(bits) {
    const firstByte = bits.readBits(8);
    if ((firstByte & 128) === 0) return firstByte & 127;
    if ((firstByte & 192) === 128) {
      const secondByte = bits.readBits(8);
      return (firstByte & 63) << 8 | secondByte;
    }
    if ((firstByte & 224) === 192) {
      const secondThirdBytes = bits.readBits(16);
      return (firstByte & 31) << 16 | secondThirdBytes;
    }
    throw new FormatException();
  }
  decodeNumericSegment(bits, result, count) {
    while (count >= 3) {
      if (bits.available() < 10) throw new FormatException();
      const threeDigitsBits = bits.readBits(10);
      if (threeDigitsBits >= 1e3) throw new FormatException();
      result.append(String.fromCharCode(48 + Math.floor(threeDigitsBits / 100)));
      result.append(String.fromCharCode(48 + Math.floor(threeDigitsBits / 10 % 10)));
      result.append(String.fromCharCode(48 + threeDigitsBits % 10));
      count -= 3;
    }
    if (count === 2) {
      if (bits.available() < 7) throw new FormatException();
      const twoDigitsBits = bits.readBits(7);
      if (twoDigitsBits >= 100) throw new FormatException();
      result.append(String.fromCharCode(48 + Math.floor(twoDigitsBits / 10)));
      result.append(String.fromCharCode(48 + twoDigitsBits % 10));
    } else if (count === 1) {
      if (bits.available() < 4) throw new FormatException();
      const digitBits = bits.readBits(4);
      if (digitBits >= 10) throw new FormatException();
      result.append(String.fromCharCode(48 + digitBits));
    }
  }
  static ALPHANUMERIC_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:".split("");
  decodeAlphanumericSegment(bits, result, count, fc1InEffect) {
    const start = result.length();
    while (count > 1) {
      if (bits.available() < 11) throw new FormatException();
      const nextTwoCharsBits = bits.readBits(11);
      result.append(_QRDecoder.ALPHANUMERIC_CHARS[Math.floor(nextTwoCharsBits / 45)]);
      result.append(_QRDecoder.ALPHANUMERIC_CHARS[nextTwoCharsBits % 45]);
      count -= 2;
    }
    if (count === 1) {
      if (bits.available() < 6) throw new FormatException();
      result.append(_QRDecoder.ALPHANUMERIC_CHARS[bits.readBits(6)]);
    }
    if (fc1InEffect) {
      for (let i = start; i < result.length(); i++) {
        if (result.charAt(i) === "%") {
          if (i < result.length() - 1 && result.charAt(i + 1) === "%") {
            result.deleteCharAt(i + 1);
          } else {
            result.setCharAt(i, String.fromCharCode(29));
          }
        }
      }
    }
  }
  decodeByteSegment(bits, result, count, byteSegments, hints) {
    if (8 * count > bits.available()) throw new FormatException();
    const readBytes = new Uint8Array(count);
    for (let i = 0; i < count; i++) {
      readBytes[i] = bits.readBits(8);
    }
    let encoding;
    if (hints?.has(4)) {
      encoding = hints.get(4);
    } else {
      encoding = StringUtils.guessEncoding(readBytes, hints);
    }
    result.append(StringEncoding.decode(readBytes, encoding));
    byteSegments.push(readBytes);
  }
  decodeKanjiSegment(bits, result, count) {
    if (13 * count > bits.available()) throw new FormatException();
    const buffer = [];
    for (let i = 0; i < count; i++) {
      const twoBytes = bits.readBits(13);
      let assembledTwoBytes = (twoBytes / 192 | 0) << 8 | twoBytes % 192;
      if (assembledTwoBytes < 7936) {
        assembledTwoBytes += 33088;
      } else {
        assembledTwoBytes += 49472;
      }
      buffer.push(assembledTwoBytes >> 8 & 255);
      buffer.push(assembledTwoBytes & 255);
    }
    result.append(StringEncoding.decode(new Uint8Array(buffer), "SJIS"));
  }
  decodeHanziSegment(bits, result, count) {
    if (13 * count > bits.available()) throw new FormatException();
    const buffer = [];
    for (let i = 0; i < count; i++) {
      const twoBytes = bits.readBits(13);
      let assembledTwoBytes = (twoBytes / 96 | 0) << 8 | twoBytes % 96;
      if (assembledTwoBytes < 2560) {
        assembledTwoBytes += 41377;
      } else {
        assembledTwoBytes += 42657;
      }
      buffer.push(assembledTwoBytes >> 8 & 255);
      buffer.push(assembledTwoBytes & 255);
    }
    result.append(StringEncoding.decode(new Uint8Array(buffer), "GB2312"));
  }
};
var BitSource = class {
  constructor(bytes) {
    this.bytes = bytes;
  }
  byteOffset = 0;
  bitOffset = 0;
  totalBitsRead = 0;
  available() {
    return 8 * (this.bytes.length - this.byteOffset) - this.bitOffset;
  }
  /**
   * Get current position for diagnostic logging
   */
  getPosition() {
    return {
      byteOffset: this.byteOffset,
      bitOffset: this.bitOffset,
      totalBitsRead: this.totalBitsRead,
      available: this.available()
    };
  }
  readBits(numBits) {
    if (numBits < 1 || numBits > 32 || numBits > this.available()) {
      const pos = this.getPosition();
      const context = {
        requestedBits: numBits,
        availableBits: pos.available,
        byteOffset: pos.byteOffset,
        bitOffset: pos.bitOffset,
        totalBitsRead: pos.totalBitsRead,
        totalBytes: this.bytes.length,
        // Show remaining bytes as hex for debugging
        remainingBytesHex: Array.from(
          this.bytes.slice(pos.byteOffset, Math.min(pos.byteOffset + 8, this.bytes.length))
        ).map((b) => b.toString(16).padStart(2, "0")).join(" ")
      };
      throw new FormatException(
        `BitSource overrun: requested ${numBits} bits but only ${pos.available} available. Position: byte ${pos.byteOffset}, bit ${pos.bitOffset}. This often indicates corrupted terminator/padding in QR-Art. Context: ${JSON.stringify(context)}`
      );
    }
    const originalNumBits = numBits;
    let result = 0;
    if (this.bitOffset > 0) {
      const bitsLeft = 8 - this.bitOffset;
      const toRead = Math.min(numBits, bitsLeft);
      const bitsToNotRead = bitsLeft - toRead;
      const mask = 255 >> 8 - toRead << bitsToNotRead;
      result = (this.bytes[this.byteOffset] & mask) >> bitsToNotRead;
      numBits -= toRead;
      this.bitOffset += toRead;
      if (this.bitOffset === 8) {
        this.bitOffset = 0;
        this.byteOffset++;
      }
    }
    if (numBits > 0) {
      while (numBits >= 8) {
        result = result << 8 | this.bytes[this.byteOffset] & 255;
        this.byteOffset++;
        numBits -= 8;
      }
      if (numBits > 0) {
        const bitsToNotRead = 8 - numBits;
        const mask = 255 >> bitsToNotRead << bitsToNotRead;
        result = result << numBits | (this.bytes[this.byteOffset] & mask) >> bitsToNotRead;
        this.bitOffset += numBits;
      }
    }
    this.totalBitsRead += originalNumBits;
    return result;
  }
};

// src/modules/qr-decoder/pattern-finder.ts
var _log86 = createLogger("DECODER");
var FinderPattern = class _FinderPattern extends ResultPoint {
  constructor(posX, posY, estimatedModuleSize, count = 1) {
    super(posX, posY);
    this.estimatedModuleSize = estimatedModuleSize;
    this.count = count;
  }
  getEstimatedModuleSize() {
    return this.estimatedModuleSize;
  }
  getCount() {
    return this.count;
  }
  incrementCount() {
    this.count++;
  }
  aboutEquals(moduleSize, i, j) {
    if (Math.abs(i - this.getY()) <= moduleSize && Math.abs(j - this.getX()) <= moduleSize) {
      const moduleSizeDiff = Math.abs(moduleSize - this.estimatedModuleSize);
      return moduleSizeDiff <= 1 || moduleSizeDiff <= this.estimatedModuleSize;
    }
    return false;
  }
  combineEstimate(i, j, newModuleSize) {
    const combinedCount = this.count + 1;
    const combinedX = (this.count * this.getX() + j) / combinedCount;
    const combinedY = (this.count * this.getY() + i) / combinedCount;
    const combinedModuleSize = (this.count * this.estimatedModuleSize + newModuleSize) / combinedCount;
    return new _FinderPattern(combinedX, combinedY, combinedModuleSize, combinedCount);
  }
};
var FinderPatternInfo = class {
  constructor(bottomLeft, topLeft, topRight) {
    this.bottomLeft = bottomLeft;
    this.topLeft = topLeft;
    this.topRight = topRight;
  }
  getBottomLeft() {
    return this.bottomLeft;
  }
  getTopLeft() {
    return this.topLeft;
  }
  getTopRight() {
    return this.topRight;
  }
};
var AlignmentPattern = class _AlignmentPattern extends ResultPoint {
  constructor(posX, posY, estimatedModuleSize) {
    super(posX, posY);
    this.estimatedModuleSize = estimatedModuleSize;
  }
  aboutEquals(moduleSize, i, j) {
    if (Math.abs(i - this.getY()) <= moduleSize && Math.abs(j - this.getX()) <= moduleSize) {
      const moduleSizeDiff = Math.abs(moduleSize - this.estimatedModuleSize);
      return moduleSizeDiff <= 1 || moduleSizeDiff <= this.estimatedModuleSize;
    }
    return false;
  }
  combineEstimate(i, j, newModuleSize) {
    const combinedX = (this.getX() + j) / 2;
    const combinedY = (this.getY() + i) / 2;
    const combinedModuleSize = (this.estimatedModuleSize + newModuleSize) / 2;
    return new _AlignmentPattern(combinedX, combinedY, combinedModuleSize);
  }
};
var FinderPatternFinder = class _FinderPatternFinder {
  constructor(image, resultPointCallback) {
    this.image = image;
    this.resultPointCallback = resultPointCallback;
  }
  static CENTER_QUORUM = 2;
  static MIN_SKIP = 3;
  static MAX_MODULES = 97;
  possibleCenters = [];
  hasSkipped = false;
  crossCheckStateCount = new Int32Array(5);
  find(hints) {
    const tryHarder = hints?.get(3) === true;
    const image = this.image;
    const maxI = image.getHeight();
    const maxJ = image.getWidth();
    let iSkip = Math.floor(3 * maxI / (4 * _FinderPatternFinder.MAX_MODULES));
    if (iSkip < _FinderPatternFinder.MIN_SKIP || tryHarder) {
      iSkip = _FinderPatternFinder.MIN_SKIP;
    }
    let done = false;
    const stateCount = new Int32Array(5);
    for (let i = iSkip - 1; i < maxI && !done; i += iSkip) {
      _FinderPatternFinder.doClearCounts(stateCount);
      let currentState = 0;
      for (let j = 0; j < maxJ; j++) {
        if (image.get(j, i)) {
          if ((currentState & 1) === 1) currentState++;
          stateCount[currentState]++;
        } else {
          if ((currentState & 1) === 0) {
            if (currentState === 4) {
              if (_FinderPatternFinder.foundPatternCross(stateCount)) {
                const confirmed = this.handlePossibleCenter(stateCount, i, j);
                if (confirmed) {
                  iSkip = 2;
                  if (this.hasSkipped) {
                    done = this.haveMultiplyConfirmedCenters();
                  } else {
                    const rowSkip = this.findRowSkip();
                    if (rowSkip > stateCount[2]) {
                      i += rowSkip - stateCount[2] - iSkip;
                      j = maxJ - 1;
                    }
                  }
                } else {
                  _FinderPatternFinder.doShiftCounts2(stateCount);
                  currentState = 3;
                  continue;
                }
                currentState = 0;
                _FinderPatternFinder.doClearCounts(stateCount);
              } else {
                _FinderPatternFinder.doShiftCounts2(stateCount);
                currentState = 3;
              }
            } else {
              stateCount[++currentState]++;
            }
          } else {
            stateCount[currentState]++;
          }
        }
      }
      if (_FinderPatternFinder.foundPatternCross(stateCount)) {
        const confirmed = this.handlePossibleCenter(stateCount, i, maxJ);
        if (confirmed) {
          iSkip = stateCount[0];
          if (this.hasSkipped) {
            done = this.haveMultiplyConfirmedCenters();
          }
        }
      }
    }
    const patternInfo = this.selectBestPatterns();
    ResultPoint.orderBestPatterns(patternInfo);
    return new FinderPatternInfo(patternInfo[0], patternInfo[1], patternInfo[2]);
  }
  static doClearCounts(counts) {
    counts.fill(0);
  }
  static doShiftCounts2(stateCount) {
    stateCount[0] = stateCount[2];
    stateCount[1] = stateCount[3];
    stateCount[2] = stateCount[4];
    stateCount[3] = 1;
    stateCount[4] = 0;
  }
  static foundPatternCross(stateCount) {
    let totalModuleSize = 0;
    for (let i = 0; i < 5; i++) {
      const count = stateCount[i];
      if (count === 0) return false;
      totalModuleSize += count;
    }
    if (totalModuleSize < 7) return false;
    const moduleSize = totalModuleSize / 7;
    const maxVariance = moduleSize / 2;
    return Math.abs(moduleSize - stateCount[0]) < maxVariance && Math.abs(moduleSize - stateCount[1]) < maxVariance && Math.abs(3 * moduleSize - stateCount[2]) < 3 * maxVariance && Math.abs(moduleSize - stateCount[3]) < maxVariance && Math.abs(moduleSize - stateCount[4]) < maxVariance;
  }
  getCrossCheckStateCount() {
    this.crossCheckStateCount.fill(0);
    return this.crossCheckStateCount;
  }
  crossCheckVertical(startI, centerJ, maxCount, originalStateCountTotal) {
    const image = this.image;
    const maxI = image.getHeight();
    const stateCount = this.getCrossCheckStateCount();
    let i = startI;
    while (i >= 0 && image.get(centerJ, i)) {
      stateCount[2]++;
      i--;
    }
    if (i < 0) return NaN;
    while (i >= 0 && !image.get(centerJ, i) && stateCount[1] <= maxCount) {
      stateCount[1]++;
      i--;
    }
    if (i < 0 || stateCount[1] > maxCount) return NaN;
    while (i >= 0 && image.get(centerJ, i) && stateCount[0] <= maxCount) {
      stateCount[0]++;
      i--;
    }
    if (stateCount[0] > maxCount) return NaN;
    i = startI + 1;
    while (i < maxI && image.get(centerJ, i)) {
      stateCount[2]++;
      i++;
    }
    if (i === maxI) return NaN;
    while (i < maxI && !image.get(centerJ, i) && stateCount[3] < maxCount) {
      stateCount[3]++;
      i++;
    }
    if (i === maxI || stateCount[3] >= maxCount) return NaN;
    while (i < maxI && image.get(centerJ, i) && stateCount[4] < maxCount) {
      stateCount[4]++;
      i++;
    }
    if (stateCount[4] >= maxCount) return NaN;
    const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
    if (5 * Math.abs(stateCountTotal - originalStateCountTotal) >= 2 * originalStateCountTotal)
      return NaN;
    return _FinderPatternFinder.foundPatternCross(stateCount) ? _FinderPatternFinder.centerFromEnd(stateCount, i) : NaN;
  }
  crossCheckHorizontal(startJ, centerI, maxCount, originalStateCountTotal) {
    const image = this.image;
    const maxJ = image.getWidth();
    const stateCount = this.getCrossCheckStateCount();
    let j = startJ;
    while (j >= 0 && image.get(j, centerI)) {
      stateCount[2]++;
      j--;
    }
    if (j < 0) return NaN;
    while (j >= 0 && !image.get(j, centerI) && stateCount[1] <= maxCount) {
      stateCount[1]++;
      j--;
    }
    if (j < 0 || stateCount[1] > maxCount) return NaN;
    while (j >= 0 && image.get(j, centerI) && stateCount[0] <= maxCount) {
      stateCount[0]++;
      j--;
    }
    if (stateCount[0] > maxCount) return NaN;
    j = startJ + 1;
    while (j < maxJ && image.get(j, centerI)) {
      stateCount[2]++;
      j++;
    }
    if (j === maxJ) return NaN;
    while (j < maxJ && !image.get(j, centerI) && stateCount[3] < maxCount) {
      stateCount[3]++;
      j++;
    }
    if (j === maxJ || stateCount[3] >= maxCount) return NaN;
    while (j < maxJ && image.get(j, centerI) && stateCount[4] < maxCount) {
      stateCount[4]++;
      j++;
    }
    if (stateCount[4] >= maxCount) return NaN;
    const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
    if (5 * Math.abs(stateCountTotal - originalStateCountTotal) >= originalStateCountTotal)
      return NaN;
    return _FinderPatternFinder.foundPatternCross(stateCount) ? _FinderPatternFinder.centerFromEnd(stateCount, j) : NaN;
  }
  handlePossibleCenter(stateCount, i, j) {
    const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
    let centerJ = _FinderPatternFinder.centerFromEnd(stateCount, j);
    const centerI = this.crossCheckVertical(i, Math.floor(centerJ), stateCount[2], stateCountTotal);
    if (!Number.isNaN(centerI)) {
      centerJ = this.crossCheckHorizontal(
        Math.floor(centerJ),
        Math.floor(centerI),
        stateCount[2],
        stateCountTotal
      );
      if (!Number.isNaN(centerJ)) {
        const estimatedModuleSize = stateCountTotal / 7;
        let found = false;
        for (let index = 0; index < this.possibleCenters.length; index++) {
          const center = this.possibleCenters[index];
          if (center.aboutEquals(estimatedModuleSize, centerI, centerJ)) {
            this.possibleCenters[index] = center.combineEstimate(
              centerI,
              centerJ,
              estimatedModuleSize
            );
            found = true;
            break;
          }
        }
        if (!found) {
          const point = new FinderPattern(centerJ, centerI, estimatedModuleSize);
          this.possibleCenters.push(point);
          if (this.resultPointCallback) {
            this.resultPointCallback(point);
          }
        }
        return true;
      }
    }
    return false;
  }
  static centerFromEnd(stateCount, end) {
    return end - stateCount[4] - stateCount[3] - stateCount[2] / 2;
  }
  findRowSkip() {
    const max = this.possibleCenters.length;
    if (max <= 1) return 0;
    let firstConfirmedCenter = null;
    for (const center of this.possibleCenters) {
      if (center.getCount() >= _FinderPatternFinder.CENTER_QUORUM) {
        if (firstConfirmedCenter === null) {
          firstConfirmedCenter = center;
        } else {
          this.hasSkipped = true;
          return Math.floor(
            (Math.abs(firstConfirmedCenter.getX() - center.getX()) - Math.abs(firstConfirmedCenter.getY() - center.getY())) / 2
          );
        }
      }
    }
    return 0;
  }
  haveMultiplyConfirmedCenters() {
    let confirmedCount = 0;
    let totalModuleSize = 0;
    const max = this.possibleCenters.length;
    for (const pattern of this.possibleCenters) {
      if (pattern.getCount() >= _FinderPatternFinder.CENTER_QUORUM) {
        confirmedCount++;
        totalModuleSize += pattern.getEstimatedModuleSize();
      }
    }
    if (confirmedCount < 3) return false;
    const average = totalModuleSize / max;
    let totalDeviation = 0;
    for (const pattern of this.possibleCenters) {
      totalDeviation += Math.abs(pattern.getEstimatedModuleSize() - average);
    }
    return totalDeviation <= 0.05 * totalModuleSize;
  }
  selectBestPatterns() {
    const startSize = this.possibleCenters.length;
    if (startSize < 3) throw new NotFoundException();
    this.possibleCenters.sort((a, b) => a.getEstimatedModuleSize() - b.getEstimatedModuleSize());
    let distortion = Number.MAX_VALUE;
    const bestPatterns = new Array(3);
    for (let i = 0; i < startSize - 2; i++) {
      const fpi = this.possibleCenters[i];
      const minModuleSize = fpi.getEstimatedModuleSize();
      for (let j = i + 1; j < startSize - 1; j++) {
        const fpj = this.possibleCenters[j];
        const squares0 = _FinderPatternFinder.squaredDistance(fpi, fpj);
        for (let k = j + 1; k < startSize; k++) {
          const fpk = this.possibleCenters[k];
          const maxModuleSize = fpk.getEstimatedModuleSize();
          if (maxModuleSize > minModuleSize * 1.4) continue;
          const a = squares0;
          const b = _FinderPatternFinder.squaredDistance(fpj, fpk);
          const c = _FinderPatternFinder.squaredDistance(fpi, fpk);
          let sides;
          if (a >= b && a >= c) {
            sides = [a, b, c];
          } else if (b >= a && b >= c) {
            sides = [b, a, c];
          } else {
            sides = [c, a, b];
          }
          const d = Math.abs(sides[1] - sides[2]) / Math.min(sides[1], sides[2]);
          if (d < 0.1) {
            const estimatedModuleCount = Math.sqrt(sides[0]) / ((fpi.getEstimatedModuleSize() + fpk.getEstimatedModuleSize()) / 2);
            const distanceFromIdeal = Math.abs(estimatedModuleCount - 14);
            if (distanceFromIdeal < distortion) {
              distortion = distanceFromIdeal;
              bestPatterns[0] = fpi;
              bestPatterns[1] = fpj;
              bestPatterns[2] = fpk;
            }
          }
        }
      }
    }
    if (distortion === Number.MAX_VALUE) throw new NotFoundException();
    return bestPatterns;
  }
  static squaredDistance(a, b) {
    const x = a.getX() - b.getX();
    const y = a.getY() - b.getY();
    return x * x + y * y;
  }
};
var AlignmentPatternFinder = class {
  constructor(image, startX, startY, width, height, moduleSize, resultPointCallback) {
    this.image = image;
    this.startX = startX;
    this.startY = startY;
    this.width = width;
    this.height = height;
    this.moduleSize = moduleSize;
    this.resultPointCallback = resultPointCallback;
  }
  possibleCenters = [];
  crossCheckStateCount = new Int32Array(3);
  find() {
    const startX = this.startX;
    const height = this.height;
    const maxJ = startX + this.width;
    const middleI = this.startY + height / 2;
    const stateCount = new Int32Array(3);
    for (let iGen = 0; iGen < height; iGen++) {
      const i = middleI + ((iGen & 1) === 0 ? (iGen + 1) / 2 : -((iGen + 1) / 2));
      stateCount[0] = 0;
      stateCount[1] = 0;
      stateCount[2] = 0;
      let j = startX;
      while (j < maxJ && !this.image.get(j, Math.floor(i))) j++;
      let currentState = 0;
      while (j < maxJ) {
        if (this.image.get(j, Math.floor(i))) {
          if (currentState === 1) {
            stateCount[1]++;
          } else {
            if (currentState === 2) {
              if (this.foundPatternCross(stateCount)) {
                const confirmed = this.handlePossibleCenter(stateCount, Math.floor(i), j);
                if (confirmed !== null) return confirmed;
              }
              stateCount[0] = stateCount[2];
              stateCount[1] = 1;
              stateCount[2] = 0;
              currentState = 1;
            } else {
              stateCount[++currentState]++;
            }
          }
        } else {
          if (currentState === 1) currentState++;
          stateCount[currentState]++;
        }
        j++;
      }
      if (this.foundPatternCross(stateCount)) {
        const confirmed = this.handlePossibleCenter(stateCount, Math.floor(i), maxJ);
        if (confirmed !== null) return confirmed;
      }
    }
    if (this.possibleCenters.length !== 0) {
      return this.possibleCenters[0];
    }
    throw new NotFoundException();
  }
  foundPatternCross(stateCount) {
    const moduleSize = this.moduleSize;
    const maxVariance = moduleSize / 2;
    for (let i = 0; i < 3; i++) {
      if (Math.abs(moduleSize - stateCount[i]) >= maxVariance) return false;
    }
    return true;
  }
  crossCheckVertical(startI, centerJ, maxCount, originalStateCountTotal) {
    const image = this.image;
    const maxI = image.getHeight();
    const stateCount = this.crossCheckStateCount;
    stateCount[0] = 0;
    stateCount[1] = 0;
    stateCount[2] = 0;
    let i = startI;
    while (i >= 0 && image.get(centerJ, i) && stateCount[1] <= maxCount) {
      stateCount[1]++;
      i--;
    }
    if (i < 0 || stateCount[1] > maxCount) return NaN;
    while (i >= 0 && !image.get(centerJ, i) && stateCount[0] <= maxCount) {
      stateCount[0]++;
      i--;
    }
    if (stateCount[0] > maxCount) return NaN;
    i = startI + 1;
    while (i < maxI && image.get(centerJ, i) && stateCount[1] <= maxCount) {
      stateCount[1]++;
      i++;
    }
    if (i === maxI || stateCount[1] > maxCount) return NaN;
    while (i < maxI && !image.get(centerJ, i) && stateCount[2] <= maxCount) {
      stateCount[2]++;
      i++;
    }
    if (stateCount[2] > maxCount) return NaN;
    const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2];
    if (5 * Math.abs(stateCountTotal - originalStateCountTotal) >= 2 * originalStateCountTotal)
      return NaN;
    return this.foundPatternCross(stateCount) ? i - stateCount[2] - stateCount[1] / 2 : NaN;
  }
  handlePossibleCenter(stateCount, i, j) {
    const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2];
    const centerJ = j - stateCount[2] - stateCount[1] / 2;
    const centerI = this.crossCheckVertical(
      i,
      Math.floor(centerJ),
      2 * stateCount[1],
      stateCountTotal
    );
    if (!Number.isNaN(centerI)) {
      const estimatedModuleSize = (stateCount[0] + stateCount[1] + stateCount[2]) / 3;
      for (const center of this.possibleCenters) {
        if (center.aboutEquals(estimatedModuleSize, centerI, centerJ)) {
          return center.combineEstimate(centerI, centerJ, estimatedModuleSize);
        }
      }
      const point = new AlignmentPattern(centerJ, centerI, estimatedModuleSize);
      this.possibleCenters.push(point);
      if (this.resultPointCallback) {
        this.resultPointCallback(point);
      }
    }
    return null;
  }
};

// src/modules/qr-decoder/qr-detector.ts
var _log87 = createLogger("DECODER");
var DetectorResult = class {
  constructor(bits, points) {
    this.bits = bits;
    this.points = points;
  }
  getBits() {
    return this.bits;
  }
  getPoints() {
    return this.points;
  }
};
var Detector = class _Detector {
  constructor(image) {
    this.image = image;
  }
  resultPointCallback;
  detect(hints) {
    this.resultPointCallback = hints?.get(9);
    const finder = new FinderPatternFinder(this.image, this.resultPointCallback);
    const info = finder.find(hints);
    return this.processFinderPatternInfo(info);
  }
  processFinderPatternInfo(info) {
    const topLeft = info.getTopLeft();
    const topRight = info.getTopRight();
    const bottomLeft = info.getBottomLeft();
    const moduleSize = this.calculateModuleSize(topLeft, topRight, bottomLeft);
    if (moduleSize < 1) {
      throw new NotFoundException();
    }
    const dimension = _Detector.computeDimension(topLeft, topRight, bottomLeft, moduleSize);
    const provisionalVersion = Version.getProvisionalVersionForDimension(dimension);
    const modulesBetweenFPCenters = provisionalVersion.getDimensionForVersion() - 7;
    let alignmentPattern = null;
    if (provisionalVersion.getAlignmentPatternCenters().length > 0) {
      const bottomRightX = topRight.getX() - topLeft.getX() + bottomLeft.getX();
      const bottomRightY = topRight.getY() - topLeft.getY() + bottomLeft.getY();
      const correctionToTopLeft = 1 - 3 / modulesBetweenFPCenters;
      const estAlignmentX = Math.floor(
        topLeft.getX() + correctionToTopLeft * (bottomRightX - topLeft.getX())
      );
      const estAlignmentY = Math.floor(
        topLeft.getY() + correctionToTopLeft * (bottomRightY - topLeft.getY())
      );
      for (let i = 4; i <= 16; i <<= 1) {
        try {
          alignmentPattern = this.findAlignmentInRegion(
            moduleSize,
            estAlignmentX,
            estAlignmentY,
            i
          );
          break;
        } catch (_re) {
        }
      }
    }
    const transform = _Detector.createTransform(
      topLeft,
      topRight,
      bottomLeft,
      alignmentPattern,
      dimension
    );
    const bits = _Detector.sampleGrid(this.image, transform, dimension);
    let points;
    if (alignmentPattern === null) {
      points = [bottomLeft, topLeft, topRight];
    } else {
      points = [bottomLeft, topLeft, topRight, alignmentPattern];
    }
    return new DetectorResult(bits, points);
  }
  static createTransform(topLeft, topRight, bottomLeft, alignmentPattern, dimension) {
    const dimMinusThree = dimension - 3.5;
    let bottomRightX;
    let bottomRightY;
    let sourceBottomRightX;
    let sourceBottomRightY;
    if (alignmentPattern !== null) {
      bottomRightX = alignmentPattern.getX();
      bottomRightY = alignmentPattern.getY();
      sourceBottomRightX = dimMinusThree - 3;
      sourceBottomRightY = sourceBottomRightX;
    } else {
      bottomRightX = topRight.getX() - topLeft.getX() + bottomLeft.getX();
      bottomRightY = topRight.getY() - topLeft.getY() + bottomLeft.getY();
      sourceBottomRightX = dimMinusThree;
      sourceBottomRightY = dimMinusThree;
    }
    return PerspectiveTransform.quadrilateralToQuadrilateral(
      3.5,
      3.5,
      dimMinusThree,
      3.5,
      sourceBottomRightX,
      sourceBottomRightY,
      3.5,
      dimMinusThree,
      topLeft.getX(),
      topLeft.getY(),
      topRight.getX(),
      topRight.getY(),
      bottomRightX,
      bottomRightY,
      bottomLeft.getX(),
      bottomLeft.getY()
    );
  }
  static sampleGrid(image, transform, dimension) {
    const sampler = new DefaultGridSampler();
    return sampler.sampleGridWithTransform(image, dimension, dimension, transform);
  }
  static computeDimension(topLeft, topRight, bottomLeft, moduleSize) {
    const tltrCentersDimension = MathUtils.round(
      ResultPoint.distance(topLeft, topRight) / moduleSize
    );
    const tlblCentersDimension = MathUtils.round(
      ResultPoint.distance(topLeft, bottomLeft) / moduleSize
    );
    let dimension = Math.floor((tltrCentersDimension + tlblCentersDimension) / 2) + 7;
    switch (dimension & 3) {
      case 0:
        dimension++;
        break;
      case 2:
        dimension--;
        break;
      case 3:
        throw new NotFoundException();
    }
    return dimension;
  }
  calculateModuleSize(topLeft, topRight, bottomLeft) {
    return (this.calculateModuleSizeOneWay(topLeft, topRight) + this.calculateModuleSizeOneWay(topLeft, bottomLeft)) / 2;
  }
  calculateModuleSizeOneWay(pattern, otherPattern) {
    const moduleSizeEst1 = this.sizeOfBlackWhiteBlackRunBothWays(
      Math.floor(pattern.getX()),
      Math.floor(pattern.getY()),
      Math.floor(otherPattern.getX()),
      Math.floor(otherPattern.getY())
    );
    const moduleSizeEst2 = this.sizeOfBlackWhiteBlackRunBothWays(
      Math.floor(otherPattern.getX()),
      Math.floor(otherPattern.getY()),
      Math.floor(pattern.getX()),
      Math.floor(pattern.getY())
    );
    if (Number.isNaN(moduleSizeEst1)) return moduleSizeEst2 / 7;
    if (Number.isNaN(moduleSizeEst2)) return moduleSizeEst1 / 7;
    return (moduleSizeEst1 + moduleSizeEst2) / 14;
  }
  sizeOfBlackWhiteBlackRunBothWays(fromX, fromY, toX, toY) {
    let result = this.sizeOfBlackWhiteBlackRun(fromX, fromY, toX, toY);
    let scale = 1;
    let otherToX = fromX - (toX - fromX);
    if (otherToX < 0) {
      scale = fromX / (fromX - otherToX);
      otherToX = 0;
    } else if (otherToX >= this.image.getWidth()) {
      scale = (this.image.getWidth() - 1 - fromX) / (otherToX - fromX);
      otherToX = this.image.getWidth() - 1;
    }
    let otherToY = Math.floor(fromY - (toY - fromY) * scale);
    scale = 1;
    if (otherToY < 0) {
      scale = fromY / (fromY - otherToY);
      otherToY = 0;
    } else if (otherToY >= this.image.getHeight()) {
      scale = (this.image.getHeight() - 1 - fromY) / (otherToY - fromY);
      otherToY = this.image.getHeight() - 1;
    }
    otherToX = Math.floor(fromX + (otherToX - fromX) * scale);
    result += this.sizeOfBlackWhiteBlackRun(fromX, fromY, otherToX, otherToY);
    return result - 1;
  }
  sizeOfBlackWhiteBlackRun(fromX, fromY, toX, toY) {
    const steep = Math.abs(toY - fromY) > Math.abs(toX - fromX);
    if (steep) {
      let temp = fromX;
      fromX = fromY;
      fromY = temp;
      temp = toX;
      toX = toY;
      toY = temp;
    }
    const dx = Math.abs(toX - fromX);
    const dy = Math.abs(toY - fromY);
    let error = -dx / 2;
    const xstep = fromX < toX ? 1 : -1;
    const ystep = fromY < toY ? 1 : -1;
    let state = 0;
    const xLimit = toX + xstep;
    for (let x = fromX, y = fromY; x !== xLimit; x += xstep) {
      const realX = steep ? y : x;
      const realY = steep ? x : y;
      if (state === 1) {
        if (this.image.get(realX, realY)) state++;
      } else {
        if (!this.image.get(realX, realY)) state++;
      }
      if (state === 3) {
        const diffX = x - fromX;
        const diffY = y - fromY;
        return Math.sqrt(diffX * diffX + diffY * diffY);
      }
      error += dy;
      if (error > 0) {
        if (y === toY) break;
        y += ystep;
        error -= dx;
      }
    }
    if (state === 2) {
      const diffX = toX + xstep - fromX;
      const diffY = toY - fromY;
      return Math.sqrt(diffX * diffX + diffY * diffY);
    }
    return NaN;
  }
  findAlignmentInRegion(overallEstModuleSize, estAlignmentX, estAlignmentY, allowanceFactor) {
    const allowance = Math.floor(allowanceFactor * overallEstModuleSize);
    const alignmentAreaLeftX = Math.max(0, estAlignmentX - allowance);
    const alignmentAreaRightX = Math.min(this.image.getWidth() - 1, estAlignmentX + allowance);
    if (alignmentAreaRightX - alignmentAreaLeftX < overallEstModuleSize * 3) {
      throw new NotFoundException();
    }
    const alignmentAreaTopY = Math.max(0, estAlignmentY - allowance);
    const alignmentAreaBottomY = Math.min(this.image.getHeight() - 1, estAlignmentY + allowance);
    if (alignmentAreaBottomY - alignmentAreaTopY < overallEstModuleSize * 3) {
      throw new NotFoundException();
    }
    const alignmentFinder = new AlignmentPatternFinder(
      this.image,
      alignmentAreaLeftX,
      alignmentAreaTopY,
      alignmentAreaRightX - alignmentAreaLeftX,
      alignmentAreaBottomY - alignmentAreaTopY,
      overallEstModuleSize,
      this.resultPointCallback
    );
    return alignmentFinder.find();
  }
};

// src/modules/qr-decoder/reader.ts
var _log88 = createLogger("DECODER");
var Reader = class {
  decoder = new QRDecoder();
  /**
   * Decode a QR code from a BinaryBitmap
   */
  decode(image, hints) {
    let decoderResult;
    let points;
    if (hints?.get(1 /* PURE_BARCODE */)) {
      const bits = this.extractPureBits(image.getBlackMatrix());
      decoderResult = this.decoder.decode(bits, hints);
      points = [];
    } else {
      const detectorResult = new Detector(image.getBlackMatrix()).detect(hints);
      decoderResult = this.decoder.decode(detectorResult.getBits(), hints);
      points = detectorResult.getPoints();
    }
    if (decoderResult.getOther() instanceof QRCodeDecoderMetaData) {
      decoderResult.getOther().applyMirroredCorrection(points);
    }
    const result = new Result(
      decoderResult.getText(),
      decoderResult.getRawBytes(),
      void 0,
      points,
      "QR_CODE" /* QR_CODE */,
      Date.now()
    );
    const byteSegments = decoderResult.getByteSegments();
    if (byteSegments) {
      result.putMetadata(2 /* BYTE_SEGMENTS */, byteSegments);
    }
    const ecLevel = decoderResult.getECLevel();
    if (ecLevel) {
      result.putMetadata(3 /* ERROR_CORRECTION_LEVEL */, ecLevel);
    }
    if (decoderResult.hasStructuredAppend()) {
      result.putMetadata(
        9 /* STRUCTURED_APPEND_SEQUENCE */,
        decoderResult.getStructuredAppendSequenceNumber()
      );
      result.putMetadata(
        10 /* STRUCTURED_APPEND_PARITY */,
        decoderResult.getStructuredAppendParity()
      );
    }
    result.putMetadata(
      11 /* SYMBOLOGY_IDENTIFIER */,
      decoderResult.getSymbologyModifier()
    );
    const version = decoderResult.getVersion();
    if (version !== null) {
      result.putMetadata(13 /* QR_VERSION */, version);
    }
    const maskPattern = decoderResult.getMaskPattern();
    if (maskPattern !== null) {
      result.putMetadata(12 /* QR_MASK_PATTERN */, maskPattern);
    }
    return result;
  }
  /**
   * Reset decoder state
   */
  reset() {
  }
  /**
   * Extract pure bits from a perfectly aligned QR code image
   */
  extractPureBits(image) {
    const leftTopBlack = image.getTopLeftOnBit();
    const rightBottomBlack = image.getBottomRightOnBit();
    if (!(leftTopBlack && rightBottomBlack)) {
      throw NotFoundException.getNotFoundInstance();
    }
    const moduleSize = this.moduleSize(leftTopBlack, image);
    let top = leftTopBlack[1];
    const bottom = rightBottomBlack[1];
    let left = leftTopBlack[0];
    let right = rightBottomBlack[0];
    if (left >= right || top >= bottom) {
      throw NotFoundException.getNotFoundInstance();
    }
    if (bottom - top !== right - left) {
      right = left + (bottom - top);
      if (right >= image.getWidth()) {
        throw NotFoundException.getNotFoundInstance();
      }
    }
    const matrixWidth = Math.round((right - left + 1) / moduleSize);
    const matrixHeight = Math.round((bottom - top + 1) / moduleSize);
    if (matrixWidth <= 0 || matrixHeight <= 0) {
      throw NotFoundException.getNotFoundInstance();
    }
    if (matrixHeight !== matrixWidth) {
      throw NotFoundException.getNotFoundInstance();
    }
    const nudge = Math.floor(moduleSize / 2);
    top += nudge;
    left += nudge;
    const bits = new BitMatrix(matrixWidth, matrixHeight);
    for (let y = 0; y < matrixHeight; y++) {
      const iOffset = top + Math.floor(y * moduleSize);
      for (let x = 0; x < matrixWidth; x++) {
        if (image.get(left + Math.floor(x * moduleSize), iOffset)) {
          bits.set(x, y);
        }
      }
    }
    return bits;
  }
  moduleSize(leftTopBlack, image) {
    const height = image.getHeight();
    const width = image.getWidth();
    let x = leftTopBlack[0];
    let y = leftTopBlack[1];
    let inBlack = true;
    let transitions = 0;
    while (x < width && y < height) {
      if (inBlack !== image.get(x, y)) {
        if (++transitions === 5) {
          break;
        }
        inBlack = !inBlack;
      }
      x++;
      y++;
    }
    if (x === width || y === height) {
      throw NotFoundException.getNotFoundInstance();
    }
    return (x - leftTopBlack[0]) / 7;
  }
};
var QRCodeDecoderMetaData = class {
  constructor(mirrored) {
    this.mirrored = mirrored;
  }
  isMirrored() {
    return this.mirrored;
  }
  applyMirroredCorrection(points) {
    if (!(this.mirrored && points) || points.length < 3) {
      return;
    }
    const temp = points[0];
    points[0] = points[2];
    points[2] = temp;
  }
};

// src/modules/qr-decoder/decoder-adapter.ts
var qrDecoderLog7 = createLogger("DECODER");
function createLuminanceSource(imageData) {
  const { data, width, height } = imageData;
  const luminances = new Uint8ClampedArray(width * height);
  for (let i = 0; i < width * height; i++) {
    const idx = i * 4;
    const a = data[idx + 3] / 255;
    if (a <= 0) {
      luminances[i] = 255;
    } else if (a >= 1) {
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      luminances[i] = Math.round((r + 2 * g + b) / 4);
    } else {
      const inv = 1 - a;
      const r = data[idx] * a + 255 * inv;
      const g = data[idx + 1] * a + 255 * inv;
      const b = data[idx + 2] * a + 255 * inv;
      luminances[i] = Math.round((r + 2 * g + b) / 4);
    }
  }
  return new RGBALuminanceSource(luminances, width, height);
}
function decodeQR2(imageData, options = {}) {
  const { inversionAttempts = "attemptBoth" } = options;
  const tryHarderHints = /* @__PURE__ */ new Map();
  tryHarderHints.set(3 /* TRY_HARDER */, true);
  if (inversionAttempts !== "onlyInvert") {
    qrDecoderLog7.trace("strategy: Trying Normal + TRY_HARDER");
    const result = tryDecode2(imageData, false, tryHarderHints);
    if (result) return result;
  }
  if (inversionAttempts !== "dontInvert") {
    qrDecoderLog7.trace("strategy: Trying Inverted + TRY_HARDER");
    const result = tryDecode2(imageData, true, tryHarderHints);
    if (result) return result;
  }
  const pureHints = /* @__PURE__ */ new Map();
  pureHints.set(3 /* TRY_HARDER */, true);
  pureHints.set(1 /* PURE_BARCODE */, true);
  if (inversionAttempts !== "onlyInvert") {
    qrDecoderLog7.trace("strategy: Trying Normal + TRY_HARDER + PURE_BARCODE");
    const result = tryDecode2(imageData, false, pureHints);
    if (result) return result;
  }
  if (inversionAttempts !== "onlyInvert") {
    qrDecoderLog7.trace("strategy: Trying Normal + GlobalHistogramBinarizer");
    const result = tryDecodeWithGlobalBinarizer(imageData, false, tryHarderHints);
    if (result) return result;
  }
  if (inversionAttempts !== "dontInvert") {
    qrDecoderLog7.trace("strategy: Trying Inverted + GlobalHistogramBinarizer");
    const result = tryDecodeWithGlobalBinarizer(imageData, true, tryHarderHints);
    if (result) return result;
  }
  qrDecoderLog7.trace("strategy: Trying Custom decoder fallback");
  const customResult = decodeQR(imageData, options);
  if (customResult?.success) {
    qrDecoderLog7.trace("strategy: SUCCESS - Custom decoder worked");
    return customResult;
  }
  qrDecoderLog7.trace("strategy: All strategies exhausted - no QR code detected");
  return null;
}
function tryDecodeWithGlobalBinarizer(imageData, invert2, hints) {
  try {
    const source = createLuminanceSource(invert2 ? invertImageData2(imageData) : imageData);
    const binarizer = new GlobalHistogramBinarizer(source);
    const bitmap = new BinaryBitmap(binarizer);
    const reader = new Reader();
    const result = reader.decode(bitmap, hints);
    qrDecoderLog7.trace("decoder: GlobalHistogramBinarizer decode succeeded");
    return extractDecodeResult(result, imageData);
  } catch (err) {
    if (err instanceof NotFoundException) {
      qrDecoderLog7.trace("decoder: GlobalHistogramBinarizer NotFoundException", { invert: invert2 });
    } else {
      qrDecoderLog7.trace("decoder: GlobalHistogramBinarizer Error", { error: String(err), invert: invert2 });
    }
    return null;
  }
}
function extractDecodeResult(result, imageData) {
  const text = result.getText();
  const metadata = result.getResultMetadata();
  const eccLevel = metadata?.get(3 /* ERROR_CORRECTION_LEVEL */) || null;
  const maskPattern = metadata?.get(12 /* QR_MASK_PATTERN */) ?? null;
  const versionFromMetadata = metadata?.get(13 /* QR_VERSION */);
  const orientation = metadata?.get(1 /* ORIENTATION */) ?? null;
  const structuredAppendSequence = metadata?.get(9 /* STRUCTURED_APPEND_SEQUENCE */) ?? null;
  const structuredAppendParity = metadata?.get(10 /* STRUCTURED_APPEND_PARITY */) ?? null;
  const byteSegments = metadata?.get(2 /* BYTE_SEGMENTS */);
  let dataBytes = null;
  if (byteSegments && byteSegments.length > 0) {
    let totalLength = 0;
    for (const segment of byteSegments) totalLength += segment.length;
    dataBytes = new Uint8Array(totalLength);
    let offset = 0;
    for (const segment of byteSegments) {
      dataBytes.set(segment, offset);
      offset += segment.length;
    }
  }
  const points = result.getResultPoints();
  let location = {
    topLeftCorner: { x: 0, y: 0 },
    topRightCorner: { x: imageData.width, y: 0 },
    bottomLeftCorner: { x: 0, y: imageData.height },
    bottomRightCorner: { x: imageData.width, y: imageData.height }
  };
  if (points && points.length >= 3) {
    location = {
      bottomLeftCorner: { x: points[0].getX(), y: points[0].getY() },
      topLeftCorner: { x: points[1].getX(), y: points[1].getY() },
      topRightCorner: { x: points[2].getX(), y: points[2].getY() },
      bottomRightCorner: points.length >= 4 ? { x: points[3].getX(), y: points[3].getY() } : {
        x: points[2].getX() - points[1].getX() + points[0].getX(),
        y: points[2].getY() - points[1].getY() + points[0].getY()
      }
    };
  }
  const version = typeof versionFromMetadata === "number" && versionFromMetadata >= 1 && versionFromMetadata <= 40 ? versionFromMetadata : null;
  const numBits = result.getNumBits() || null;
  const errorsCorrectedFromMeta = metadata?.get(14 /* QR_ERRORS_CORRECTED */);
  const erasuresFromMeta = metadata?.get(15 /* QR_ERASURES */);
  const errorsCorrected = typeof errorsCorrectedFromMeta === "number" ? errorsCorrectedFromMeta : null;
  const erasures = typeof erasuresFromMeta === "number" ? erasuresFromMeta : null;
  const encodingMode = detectEncodingMode(text);
  const decoderMetadata = {
    version,
    maskPattern,
    eccLevel,
    errorsCorrected,
    erasures,
    numBits,
    orientation,
    structuredAppendSequence,
    structuredAppendParity,
    hasStructuredAppend: structuredAppendSequence !== null && structuredAppendSequence >= 0,
    byteSegmentCount: byteSegments?.length ?? 0,
    totalByteLength: dataBytes?.length ?? 0
  };
  return {
    success: true,
    data: text,
    dataBytes,
    error: null,
    location,
    version,
    eccLevel,
    maskPattern,
    encodingMode,
    errorsCorrected,
    erasures,
    orientation,
    numBits,
    structuredAppendSequence,
    structuredAppendParity,
    decoderMetadata,
    structurallyValid: true,
    // ZXing decoder would have failed if segments were corrupt
    segmentCount: byteSegments?.length ?? 1,
    // Approximate from byte segments
    segments: void 0
    // Not available from ZXing decoder
  };
}
function tryDecode2(imageData, invert2, hints) {
  const hintDesc = hints ? Array.from(hints.keys()).map((k) => DecodeHintType[k]).join("+") : "none";
  qrDecoderLog7.trace("decoder: Starting decode attempt", {
    width: imageData.width,
    height: imageData.height,
    invert: invert2,
    hints: hintDesc
  });
  try {
    const source = createLuminanceSource(invert2 ? invertImageData2(imageData) : imageData);
    const binarizer = new HybridBinarizer(source);
    const bitmap = new BinaryBitmap(binarizer);
    const reader = new Reader();
    const result = reader.decode(bitmap, hints);
    qrDecoderLog7.trace("decoder: Reader.decode() succeeded", { hints: hintDesc });
    const text = result.getText();
    const metadata = result.getResultMetadata();
    const eccLevel = metadata?.get(3 /* ERROR_CORRECTION_LEVEL */) || null;
    const maskPattern = metadata?.get(12 /* QR_MASK_PATTERN */) ?? null;
    const versionFromMetadata = metadata?.get(13 /* QR_VERSION */);
    const orientation = metadata?.get(1 /* ORIENTATION */) ?? null;
    const structuredAppendSequence = metadata?.get(9 /* STRUCTURED_APPEND_SEQUENCE */) ?? null;
    const structuredAppendParity = metadata?.get(10 /* STRUCTURED_APPEND_PARITY */) ?? null;
    const byteSegments = metadata?.get(2 /* BYTE_SEGMENTS */);
    let dataBytes = null;
    if (byteSegments && byteSegments.length > 0) {
      let totalLength = 0;
      for (const segment of byteSegments) {
        totalLength += segment.length;
      }
      dataBytes = new Uint8Array(totalLength);
      let offset = 0;
      for (const segment of byteSegments) {
        dataBytes.set(segment, offset);
        offset += segment.length;
      }
    }
    const points = result.getResultPoints();
    let location = {
      topLeftCorner: { x: 0, y: 0 },
      topRightCorner: { x: imageData.width, y: 0 },
      bottomLeftCorner: { x: 0, y: imageData.height },
      bottomRightCorner: { x: imageData.width, y: imageData.height }
    };
    if (points && points.length >= 3) {
      location = {
        bottomLeftCorner: { x: points[0].getX(), y: points[0].getY() },
        topLeftCorner: { x: points[1].getX(), y: points[1].getY() },
        topRightCorner: { x: points[2].getX(), y: points[2].getY() },
        bottomRightCorner: points.length >= 4 ? { x: points[3].getX(), y: points[3].getY() } : {
          x: points[2].getX() - points[1].getX() + points[0].getX(),
          y: points[2].getY() - points[1].getY() + points[0].getY()
        }
      };
    }
    const version = typeof versionFromMetadata === "number" && versionFromMetadata >= 1 && versionFromMetadata <= 40 ? versionFromMetadata : null;
    const numBits = result.getNumBits() || null;
    const errorsCorrectedFromMeta = metadata?.get(14 /* QR_ERRORS_CORRECTED */);
    const erasuresFromMeta = metadata?.get(15 /* QR_ERASURES */);
    const errorsCorrected = typeof errorsCorrectedFromMeta === "number" ? errorsCorrectedFromMeta : null;
    const erasures = typeof erasuresFromMeta === "number" ? erasuresFromMeta : null;
    const encodingMode = detectEncodingMode(text);
    const decoderMetadata = {
      version,
      maskPattern,
      eccLevel,
      errorsCorrected,
      erasures,
      numBits,
      orientation,
      structuredAppendSequence,
      structuredAppendParity,
      hasStructuredAppend: structuredAppendSequence !== null && structuredAppendSequence >= 0,
      byteSegmentCount: byteSegments?.length ?? 0,
      totalByteLength: dataBytes?.length ?? 0
    };
    return {
      success: true,
      data: text,
      dataBytes,
      error: null,
      location,
      version,
      // From decoder metadata, not estimated
      eccLevel,
      maskPattern,
      // From decoder metadata, not estimated
      encodingMode,
      errorsCorrected,
      erasures,
      orientation,
      numBits,
      structuredAppendSequence,
      structuredAppendParity,
      decoderMetadata,
      // Complete metadata for debugging
      structurallyValid: true,
      // ZXing decoder would have failed if segments were corrupt
      segmentCount: byteSegments?.length ?? 1,
      // Approximate from byte segments
      segments: void 0
      // Not available from ZXing decoder
    };
  } catch (err) {
    if (err instanceof NotFoundException) {
      qrDecoderLog7.trace("decoder: DECODE FAILED - NotFoundException", {
        message: err.message || "No QR code found in image",
        invert: invert2
      });
    } else if (err instanceof FormatException) {
      qrDecoderLog7.trace("decoder: DECODE FAILED - FormatException", {
        message: err.message || "QR code format error",
        invert: invert2
      });
    } else if (err instanceof ChecksumException) {
      qrDecoderLog7.trace("decoder: DECODE FAILED - ChecksumException", {
        message: err.message || "QR code checksum error",
        invert: invert2
      });
    } else {
      qrDecoderLog7.trace("decoder: DECODE FAILED - Unknown exception", {
        errorType: err?.constructor?.name || "Unknown",
        message: err instanceof Error ? err.message : String(err),
        invert: invert2
      });
    }
    return null;
  }
}
function detectEncodingMode(text) {
  if (/^\d+$/.test(text)) return "numeric";
  if (/^[0-9A-Z $%*+\-./:]+$/.test(text)) return "alphanumeric";
  if (/[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]/.test(text)) return "kanji";
  return "byte";
}
function invertImageData2(imageData) {
  const data = new Uint8ClampedArray(imageData.data.length);
  for (let i = 0; i < imageData.data.length; i += 4) {
    data[i] = 255 - imageData.data[i];
    data[i + 1] = 255 - imageData.data[i + 1];
    data[i + 2] = 255 - imageData.data[i + 2];
    data[i + 3] = imageData.data[i + 3];
  }
  return new ImageData(data, imageData.width, imageData.height);
}

// src/modules/qr-decoder/decode-canvas.ts
var _log89 = createLogger("DECODER");

// src/modules/qr-decoder/index.ts
var _log90 = createLogger("DECODER");

// src/modules/qr-generator/render-modes.ts
var _log91 = createLogger("GENERATE");
function computeDarkFactor(intensity, minFactor = 0.55) {
  const i = Math.max(0, Math.min(1, intensity));
  return 1 - (1 - minFactor) * i;
}
function computeLightBlend(intensity, maxBlend = 0.4) {
  const i = Math.max(0, Math.min(1, intensity));
  return maxBlend * i;
}
function applyBrightnessCurve(brightness2, curve) {
  if (curve === "s-curve" || curve === "s_curve") {
    return brightness2 * brightness2 * (3 - 2 * brightness2);
  }
  if (curve === "gamma") {
    return brightness2 ** 0.7;
  }
  return brightness2;
}
var DUOTONE_MAX_LIGHTEN = 0.5;
function applyQROverlayMode(overlayMode, isDark2, brightness2, overlayData, row, col, moduleCount, effectiveIntensity, config, isFunctionalPattern = false) {
  const result = {
    moduleColor: isDark2 ? config.fgColor : config.bgColor,
    moduleSizeModifier: 1,
    moduleOpacity: 1,
    waveOffsetX: 0,
    waveOffsetY: 0,
    drawOutlineOnly: false,
    useHalftoneRendering: false,
    halftoneBrightness: 0.5,
    shouldDrawCell: isDark2
  };
  const overlayWithColors = overlayData;
  switch (overlayMode) {
    case "halftone":
      if (isDark2) {
        if (config.halftoneCell || config.halftoneDotShape || config.brightnessCurve) {
          result.useHalftoneRendering = true;
          const transformedBrightness = applyBrightnessCurve(brightness2, config.brightnessCurve);
          result.halftoneBrightness = 0.5 + (transformedBrightness - 0.5) * effectiveIntensity;
        } else {
          const intensity = effectiveIntensity;
          const minSize = 0.15 + 0.1 * (1 - intensity);
          const maxSize = 1;
          const sizeRange = maxSize - minSize;
          const darknessInfluence = (1 - brightness2) * intensity;
          const baseSize = minSize + sizeRange * (1 - intensity) * 0.5;
          result.moduleSizeModifier = baseSize + darknessInfluence * (maxSize - baseSize);
        }
      }
      break;
    case "halftone-dithered": {
      result.useHalftoneRendering = true;
      result.shouldDrawCell = true;
      const htdColor = overlayWithColors.colors?.[row]?.[col];
      const htdTransformed = applyBrightnessCurve(brightness2, config.brightnessCurve);
      if (isDark2) {
        result.halftoneBrightness = 0.5 + (htdTransformed - 0.5) * effectiveIntensity;
        if (htdColor) {
          const dkF = computeDarkFactor(effectiveIntensity, 0.35);
          result.moduleColor = `rgb(${Math.round(htdColor.r * dkF)},${Math.round(htdColor.g * dkF)},${Math.round(htdColor.b * dkF)})`;
        }
      } else {
        result.halftoneBrightness = Math.max(
          0.68,
          0.5 + (htdTransformed - 0.5) * effectiveIntensity
        );
        if (htdColor) {
          const ltBlend = computeLightBlend(effectiveIntensity, 0.72);
          const lightR = Math.round(htdColor.r + (255 - htdColor.r) * ltBlend);
          const lightG = Math.round(htdColor.g + (255 - htdColor.g) * ltBlend);
          const lightB = Math.round(htdColor.b + (255 - htdColor.b) * ltBlend);
          result.moduleColor = `rgb(${lightR},${lightG},${lightB})`;
        }
      }
      break;
    }
    case "blend":
      if (isDark2) {
        const blendColor = overlayWithColors.colors?.[row]?.[col];
        if (blendColor) {
          const blendAmount = effectiveIntensity;
          const darkFactor = computeDarkFactor(blendAmount, 0.75);
          const darkR = Math.round(blendColor.r * darkFactor);
          const darkG = Math.round(blendColor.g * darkFactor);
          const darkB = Math.round(blendColor.b * darkFactor);
          result.moduleColor = blendColors(
            config.fgColor,
            `rgb(${darkR},${darkG},${darkB})`,
            blendAmount
          );
        }
      }
      break;
    case "brightness":
      if (isDark2) {
        const threshold2 = 1 - effectiveIntensity;
        if (brightness2 > threshold2) {
          result.moduleOpacity = 0;
        }
      }
      break;
    case "gapfill":
      if (isDark2) {
        result.moduleColor = config.fgColor;
      } else {
        const gapColor = overlayWithColors.colors?.[row]?.[col];
        if (gapColor) {
          const fadeAmount = computeLightBlend(effectiveIntensity, 0.75);
          const colorStr = `rgb(${gapColor.r},${gapColor.g},${gapColor.b})`;
          result.moduleColor = blendColors(config.bgColor, colorStr, fadeAmount);
          result.shouldDrawCell = true;
        }
      }
      break;
    case "pixelate":
      if (isDark2) {
        const blockSize = 3;
        const blockRow = Math.floor(row / blockSize) * blockSize;
        const blockCol = Math.floor(col / blockSize) * blockSize;
        let avgR = 0, avgG = 0, avgB = 0, pixCount = 0;
        for (let br = 0; br < blockSize && blockRow + br < moduleCount; br++) {
          for (let bc = 0; bc < blockSize && blockCol + bc < moduleCount; bc++) {
            const c = overlayWithColors.colors?.[blockRow + br]?.[blockCol + bc];
            if (c) {
              avgR += c.r;
              avgG += c.g;
              avgB += c.b;
              pixCount++;
            }
          }
        }
        if (pixCount > 0) {
          avgR = Math.round(avgR / pixCount);
          avgG = Math.round(avgG / pixCount);
          avgB = Math.round(avgB / pixCount);
          const pixIntensity = effectiveIntensity;
          const darkFactor = computeDarkFactor(pixIntensity, 0.7);
          const darkR = Math.round(avgR * darkFactor);
          const darkG = Math.round(avgG * darkFactor);
          const darkB = Math.round(avgB * darkFactor);
          const blockColor = `rgb(${darkR},${darkG},${darkB})`;
          result.moduleColor = blendColors(config.fgColor, blockColor, pixIntensity);
        }
      }
      break;
    case "duotone":
      if (isDark2) {
        const duotoneArr = config.duotoneColors || [];
        const shadowColor = duotoneArr[0] || config.fgColor;
        const highlightColor = duotoneArr[1] || null;
        const duoIntensity = effectiveIntensity;
        if (highlightColor) {
          const shadowParsed = parseColor(shadowColor) ?? { r: 0, g: 0, b: 0, a: 1 };
          const highlightParsed = parseColor(highlightColor) ?? { r: 0, g: 0, b: 0, a: 1 };
          const duoR = Math.round(
            shadowParsed.r + (highlightParsed.r - shadowParsed.r) * brightness2
          );
          const duoG = Math.round(
            shadowParsed.g + (highlightParsed.g - shadowParsed.g) * brightness2
          );
          const duoB = Math.round(
            shadowParsed.b + (highlightParsed.b - shadowParsed.b) * brightness2
          );
          const duoColor = `rgb(${duoR},${duoG},${duoB})`;
          result.moduleColor = blendColors(config.fgColor, duoColor, duoIntensity);
        } else if (brightness2 > 0.5) {
          const shadowParsed = parseColor(shadowColor) ?? { r: 0, g: 0, b: 0, a: 1 };
          const lightenAmt = (brightness2 - 0.5) * 2 * duoIntensity;
          const lightR = Math.min(
            255,
            Math.round(shadowParsed.r + (255 - shadowParsed.r) * lightenAmt * DUOTONE_MAX_LIGHTEN)
          );
          const lightG = Math.min(
            255,
            Math.round(shadowParsed.g + (255 - shadowParsed.g) * lightenAmt * DUOTONE_MAX_LIGHTEN)
          );
          const lightB = Math.min(
            255,
            Math.round(shadowParsed.b + (255 - shadowParsed.b) * lightenAmt * DUOTONE_MAX_LIGHTEN)
          );
          result.moduleColor = `rgb(${lightR},${lightG},${lightB})`;
        } else {
          result.moduleColor = blendColors(
            config.fgColor,
            shadowColor,
            duoIntensity * (0.5 - brightness2) * 2
          );
        }
      }
      break;
    case "outline":
      if (isDark2) {
        result.drawOutlineOnly = true;
        const outlineColor = overlayWithColors.colors?.[row]?.[col];
        if (outlineColor) {
          const outlineBlend = effectiveIntensity;
          const darkFactor = computeDarkFactor(outlineBlend, 0.75);
          const darkR = Math.round(outlineColor.r * darkFactor);
          const darkG = Math.round(outlineColor.g * darkFactor);
          const darkB = Math.round(outlineColor.b * darkFactor);
          const colorStr = `rgb(${darkR},${darkG},${darkB})`;
          result.moduleColor = blendColors(config.fgColor, colorStr, outlineBlend);
        }
      }
      break;
    case "wave":
      if (isDark2) {
        const waveIntensity = effectiveIntensity;
        const waveStrength = (1 - brightness2) * waveIntensity * 4;
        result.waveOffsetX = Math.sin(row * 0.5 + col * 0.15) * waveStrength;
        result.waveOffsetY = Math.cos(col * 0.5 + row * 0.15) * waveStrength;
        const waveColor = overlayWithColors.colors?.[row]?.[col];
        if (waveColor && waveIntensity > 0) {
          const darkFactor = computeDarkFactor(waveIntensity, 0.7);
          const colorStr = `rgb(${Math.round(waveColor.r * darkFactor)},${Math.round(waveColor.g * darkFactor)},${Math.round(waveColor.b * darkFactor)})`;
          result.moduleColor = blendColors(config.fgColor, colorStr, waveIntensity);
        }
      }
      break;
    case "mosaic": {
      result.shouldDrawCell = true;
      const mosaicColor = overlayWithColors.colors?.[row]?.[col];
      if (mosaicColor) {
        const mosaicIntensity = effectiveIntensity;
        if (isDark2) {
          const darkFactor = computeDarkFactor(mosaicIntensity, 0.08);
          result.moduleColor = `rgb(${Math.round(mosaicColor.r * darkFactor)},${Math.round(mosaicColor.g * darkFactor)},${Math.round(mosaicColor.b * darkFactor)})`;
        } else {
          const blendToWhite = 0.72 + computeLightBlend(mosaicIntensity, 0.24);
          const lightR = Math.round(mosaicColor.r + (255 - mosaicColor.r) * blendToWhite);
          const lightG = Math.round(mosaicColor.g + (255 - mosaicColor.g) * blendToWhite);
          const lightB = Math.round(mosaicColor.b + (255 - mosaicColor.b) * blendToWhite);
          result.moduleColor = `rgb(${lightR},${lightG},${lightB})`;
        }
      }
      break;
    }
    case "dither":
    case "extreme": {
      const ditherColor = overlayWithColors.colors?.[row]?.[col];
      if (!ditherColor) break;
      const isExtreme = overlayMode === "extreme";
      const blendPresFunctional = config.blendPreservations === true && isFunctionalPattern;
      const functionalExtremeBlend = isExtreme && blendPresFunctional;
      const preserveBoost = blendPresFunctional ? 1.14 : 1;
      const darkBlend = isExtreme ? Math.min(1, effectiveIntensity * 1.18 * preserveBoost) : Math.min(1, effectiveIntensity * 0.82 * preserveBoost);
      const darkFactor = computeDarkFactor(
        darkBlend,
        functionalExtremeBlend ? 0.22 : isExtreme ? 0.44 : 0.68
      );
      const darkR = Math.round(ditherColor.r * darkFactor);
      const darkG = Math.round(ditherColor.g * darkFactor);
      const darkB = Math.round(ditherColor.b * darkFactor);
      const darkColor = `rgb(${darkR},${darkG},${darkB})`;
      if (isDark2) {
        result.moduleColor = blendColors(config.fgColor, darkColor, darkBlend);
        break;
      }
      if (isExtreme || blendPresFunctional) {
        const lightMix = computeLightBlend(
          effectiveIntensity,
          functionalExtremeBlend ? 0.62 : blendPresFunctional ? isExtreme ? 0.42 : 0.36 : isExtreme ? 0.34 : 0.25
        );
        const whiteBase = functionalExtremeBlend ? 0.58 : isExtreme ? 0.82 : 0.7;
        const whitePush = functionalExtremeBlend ? 0.32 : isExtreme ? 0.18 : 0.3;
        const lightR = Math.round(
          ditherColor.r + (255 - ditherColor.r) * (whiteBase + lightMix * whitePush)
        );
        const lightG = Math.round(
          ditherColor.g + (255 - ditherColor.g) * (whiteBase + lightMix * whitePush)
        );
        const lightB = Math.round(
          ditherColor.b + (255 - ditherColor.b) * (whiteBase + lightMix * whitePush)
        );
        result.moduleColor = blendColors(
          config.bgColor,
          `rgb(${lightR},${lightG},${lightB})`,
          lightMix
        );
        result.shouldDrawCell = true;
      }
      break;
    }
    case "artwork": {
      result.shouldDrawCell = isDark2;
      result.moduleColor = isDark2 ? config.fgColor : config.bgColor;
      result.moduleSizeModifier = 1;
      break;
    }
  }
  return result;
}

// src/modules/qr-generator/render-loop.ts
function renderModules(ctx, qr, config, moduleCount, moduleSize, margin, overlayData, ditherPattern, effectiveIntensity, drawnFinderPatterns, drawnAlignmentPatterns, version, gradientFill, useGradient) {
  const cornerRadius = config.cornerRadius || 0;
  const dotRotation = config.dotRotationDeg || 0;
  const timingStyle = config.timingStyle || "match_module";
  for (let row = 0; row < moduleCount; row++) {
    for (let col = 0; col < moduleCount; col++) {
      if (drawnFinderPatterns.has(`${row},${col}`)) continue;
      if (drawnAlignmentPatterns.has(`${row},${col}`)) continue;
      const isDark2 = ditherPattern ? ditherPattern[row][col] : qr.isDark(row, col);
      const x = (col + margin) * moduleSize;
      const y = (row + margin) * moduleSize;
      const isFinder = isFinderPattern(row, col, moduleCount);
      const isTiming = isTimingPattern(row, col, moduleCount);
      const isAlignment = isAlignmentPattern(row, col, moduleCount, version);
      const isFormat = isFormatInfo2(row, col, moduleCount);
      const isVersion = isVersionInfo2(row, col, moduleCount, version);
      const isInAlignmentSet = drawnAlignmentPatterns.has(`${row},${col}`);
      const isFixedDark = row === moduleCount - 8 && col === 8;
      const protectFormat = config.protectFormatInfo;
      const protectVersion = config.protectVersionInfo;
      const applyOverlay = overlayData && !(config.preserveFinders && isFinder) && !(config.preserveTiming && isTiming) && !(config.preserveAlignment && isAlignment) && !(protectFormat && isFormat) && !(protectVersion && isVersion);
      const isFunctionalPattern = isFinder || isTiming || isAlignment || isFormat || isVersion || isFixedDark || isInAlignmentSet;
      const effectiveBgColor = validateColor(config.bgColor, "#ffffff");
      const effectiveFgColor = validateColor(config.fgColor, "#000000");
      let moduleColor = isDark2 ? effectiveFgColor : effectiveBgColor;
      const needsExplicitLightModules = config.transparentBg === true;
      let moduleSizeModifier = 1;
      let moduleOpacity = 1;
      let waveOffsetX = 0;
      let waveOffsetY = 0;
      let drawOutlineOnly = false;
      let useHalftoneRendering = false;
      let halftoneBrightness = 0.5;
      let shouldDrawCell = isDark2 || needsExplicitLightModules;
      if (applyOverlay) {
        const brightness2 = overlayData[row][col];
        const modeResult = applyQROverlayMode(
          config.overlayMode,
          isDark2,
          brightness2,
          overlayData,
          row,
          col,
          moduleCount,
          effectiveIntensity,
          config,
          isFunctionalPattern
        );
        moduleColor = modeResult.moduleColor;
        moduleSizeModifier = modeResult.moduleSizeModifier;
        moduleOpacity = modeResult.moduleOpacity;
        waveOffsetX = modeResult.waveOffsetX;
        waveOffsetY = modeResult.waveOffsetY;
        drawOutlineOnly = modeResult.drawOutlineOnly;
        useHalftoneRendering = modeResult.useHalftoneRendering;
        halftoneBrightness = modeResult.halftoneBrightness;
        shouldDrawCell = modeResult.shouldDrawCell || needsExplicitLightModules;
      }
      if (shouldDrawCell && moduleOpacity > 0) {
        ctx.save();
        ctx.globalAlpha = moduleOpacity;
        let finalModuleColor = moduleColor;
        if (isDark2 && config.perModuleColorMode && config.perModuleColorMode !== "solid" && overlayData) {
          finalModuleColor = applyPerModuleColor(
            config.perModuleColorMode,
            moduleColor,
            overlayData,
            row,
            col,
            moduleCount,
            config
          );
        }
        const paletteBrightness = overlayData?.[row]?.[col] ?? 0.5;
        if (isDark2 && config.palette && config.palette.length > 0) {
          finalModuleColor = applyPaletteColor(
            row,
            col,
            moduleCount,
            paletteBrightness,
            config.palette,
            config
          );
        }
        if (isDark2 && config.contrastGuard && config.minContrastRatio) {
          finalModuleColor = ensureContrast(
            finalModuleColor,
            config.bgColor,
            config.minContrastRatio
          );
        }
        if (isDark2 && useGradient && gradientFill) {
          ctx.fillStyle = gradientFill;
        } else {
          ctx.fillStyle = finalModuleColor;
        }
        let gap = config.moduleGap ? moduleSize * config.moduleGap / 100 : 0;
        const gapMode = config.gapMode || "none";
        let strokeWidth = 0;
        if (gapMode === "inset") {
          gap = Math.max(gap, moduleSize * 0.1);
        } else if (gapMode === "stroke") {
          strokeWidth = Math.max(1, moduleSize * 0.15);
          gap = strokeWidth;
        } else if (gapMode === "negative_space") {
          gap = Math.max(gap, moduleSize * 0.2);
        }
        const adjustedSize = (moduleSize - gap) * moduleSizeModifier;
        const offset = (moduleSize - adjustedSize) / 2;
        let drawX = x + offset + waveOffsetX;
        let drawY = y + offset + waveOffsetY;
        if (config.moduleJitterPx && config.moduleJitterPx > 0) {
          const jitterSeed = (row * 31 + col * 17 + (config.frameIndex || 0) * 13) % 1e3;
          const jitterX = (jitterSeed % 100 / 100 - 0.5) * 2 * config.moduleJitterPx;
          const jitterY = (jitterSeed * 7 % 100 / 100 - 0.5) * 2 * config.moduleJitterPx;
          drawX += jitterX;
          drawY += jitterY;
        }
        const pixelSnap = config.pixelSnap || "floor";
        if (pixelSnap === "floor") {
          drawX = Math.floor(drawX);
          drawY = Math.floor(drawY);
        } else if (pixelSnap === "round") {
          drawX = Math.round(drawX);
          drawY = Math.round(drawY);
        } else if (pixelSnap === "ceil") {
          drawX = Math.ceil(drawX);
          drawY = Math.ceil(drawY);
        }
        if (drawOutlineOnly || gapMode === "stroke" && isDark2) {
          ctx.strokeStyle = finalModuleColor;
          ctx.lineWidth = strokeWidth || 1;
          ctx.strokeRect(
            drawX + ctx.lineWidth / 2,
            drawY + ctx.lineWidth / 2,
            adjustedSize - ctx.lineWidth,
            adjustedSize - ctx.lineWidth
          );
        } else if (useHalftoneRendering) {
          if (config.overlayMode === "halftone-dithered") {
            const cellColor = overlayData?.colors?.[row]?.[col];
            if (cellColor) {
              if (isDark2) {
                const darkBackdrop = 0.5;
                const backR = Math.round(cellColor.r * darkBackdrop);
                const backG = Math.round(cellColor.g * darkBackdrop);
                const backB = Math.round(cellColor.b * darkBackdrop);
                ctx.fillStyle = `rgb(${backR},${backG},${backB})`;
              } else {
                const lightBlend = 0.46;
                const backR = Math.round(cellColor.r + (255 - cellColor.r) * lightBlend);
                const backG = Math.round(cellColor.g + (255 - cellColor.g) * lightBlend);
                const backB = Math.round(cellColor.b + (255 - cellColor.b) * lightBlend);
                ctx.fillStyle = `rgb(${backR},${backG},${backB})`;
              }
              ctx.fillRect(drawX, drawY, adjustedSize, adjustedSize);
              ctx.fillStyle = finalModuleColor;
            }
          }
          drawHalftoneModule(
            ctx,
            drawX,
            drawY,
            adjustedSize,
            halftoneBrightness,
            config,
            row,
            col
          );
        } else if (isTiming) {
          drawTimingModule(
            ctx,
            drawX,
            drawY,
            adjustedSize,
            timingStyle,
            config
          );
        } else {
          drawModule(
            ctx,
            drawX,
            drawY,
            adjustedSize,
            config.moduleStyle,
            {
              cornerRadius,
              rotation: dotRotation
            }
          );
        }
        ctx.restore();
      }
    }
  }
}

// src/modules/qr-generator/scaled-render.ts
var log13 = createLogger("GENERATE");
async function generateScaledQR(qr, config, overlayCanvas, moduleCount, scale, createCanvasFn, canvasFactory, storeMatrixFn) {
  const pixelData = await generatePixelDecisionMatrix(
    qr,
    config,
    overlayCanvas,
    moduleCount,
    createCanvasFn,
    canvasFactory
  );
  const { matrix, colors } = pixelData;
  const scaledSize = matrix.length;
  const quietZoneMin = config.quietZoneMinEnforce === false ? 0 : 4;
  const marginModules = Math.max(quietZoneMin, config.margin);
  const subPixelSize = Math.max(0.5, config.moduleSize / scale);
  const effectiveModuleSize = subPixelSize * scale;
  const frameExtra = config.frameStyle && config.frameStyle !== "none" ? effectiveModuleSize * 4 : 0;
  const marginPx = marginModules * effectiveModuleSize;
  const size = Math.round(scaledSize * subPixelSize + marginPx * 2 + frameExtra);
  const canvas = await createCanvasFn(size, size);
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = false;
  const effectiveBgColor = validateColor(config.bgColor, "#ffffff");
  const effectiveFgColor = validateColor(config.fgColor, "#000000");
  const needsExplicitLightModules = config.transparentBg === true;
  if (!config.transparentBg) {
    ctx.fillStyle = effectiveBgColor;
    ctx.fillRect(0, 0, size, size);
  }
  drawFrameBackground(ctx, size, effectiveModuleSize, marginModules, config);
  const gradientFill = createGradientFill(ctx, config, size);
  const useGradient = config.gradient && config.gradient.type !== "none";
  const useColorRendering = Boolean(overlayCanvas && config.colorMode !== "bw");
  const isDitheredMode = config.overlayMode === "dithered" || config.overlayMode === "blue_noise" || config.overlayMode === "blue-noise";
  const forceBinaryFunctionPatterns = isDitheredMode;
  const isSubpixelMode = config.overlayMode === "subpixel" || config.overlayMode === "subpixel-size";
  const needsBothDarkAndLightColors = isSubpixelMode;
  const subpixelToneStrength = Math.max(0, Math.min(1, (config.overlayIntensity ?? 100) / 100));
  const subpixelDarkTargetLuma = 0.2 - subpixelToneStrength * 0.1;
  const subpixelLightTargetLuma = 0.8 + subpixelToneStrength * 0.15;
  const subpixelDarkChroma = 1.15 + subpixelToneStrength * 0.35;
  const subpixelLightChroma = 0.92 - subpixelToneStrength * 0.24;
  const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
  const preserveFunctional = config.preserveFunctionalPatterns === true;
  const preserveFinders = config.preserveFinders !== false;
  const preserveTiming = preserveFunctional ? config.preserveTiming !== false : config.preserveTiming === true;
  const preserveAlignment = preserveFunctional ? config.preserveAlignment !== false : config.preserveAlignment === true;
  const protectFormat = preserveFunctional ? config.protectFormatInfo !== false : config.protectFormatInfo === true;
  const protectVersion = preserveFunctional ? config.protectVersionInfo !== false : config.protectVersionInfo === true;
  const preserveFixedDark = preserveFunctional;
  const qrDrawSize = scaledSize * subPixelSize;
  const ditherBackdropAlpha = Math.max(0, Math.min(0.75, config.ditherBackdropAlpha ?? 0.4));
  const ditherBackdropWash = Math.max(0, Math.min(1, config.ditherBackdropWash ?? 0.18));
  const bgRgb = parseColor(effectiveBgColor) ?? { r: 255, g: 255, b: 255, a: 1 };
  const bgLuma = (0.299 * bgRgb.r + 0.587 * bgRgb.g + 0.114 * bgRgb.b) / 255;
  const ditherPaperOverlayMix = isDitheredMode && overlayCanvas && useColorRendering ? Math.max(0, Math.min(1, ditherBackdropAlpha * (1 - ditherBackdropWash))) : 0;
  const debug = config.debugOverlayDither === true;
  if (debug) {
    log13.debug("ScaledRender start", {
      moduleCount,
      scale,
      scaledSize,
      overlayMode: config.overlayMode,
      colorMode: config.colorMode,
      useColorRendering,
      needsBothDarkAndLightColors,
      protectFormatInfo: config.protectFormatInfo,
      protectVersionInfo: config.protectVersionInfo,
      preserveFinders: config.preserveFinders,
      preserveTiming: config.preserveTiming,
      preserveAlignment: config.preserveAlignment,
      finderDitherStrength: config.finderDitherStrength,
      blendPreservations: config.blendPreservations,
      hasColors: !!(colors?.length && colors[0]?.length),
      sampleColor: colors?.[5]?.[5]
    });
  }
  if (isDitheredMode && overlayCanvas && useColorRendering) {
    ctx.save();
    ctx.globalAlpha = ditherBackdropAlpha;
    ctx.drawImage(overlayCanvas, marginPx, marginPx, qrDrawSize, qrDrawSize);
    if (ditherBackdropWash > 0) {
      ctx.globalCompositeOperation = "source-atop";
      ctx.globalAlpha = ditherBackdropWash;
      ctx.fillStyle = effectiveBgColor;
      ctx.fillRect(marginPx, marginPx, qrDrawSize, qrDrawSize);
      ctx.globalCompositeOperation = "source-over";
    }
    ctx.restore();
  }
  const adjustLumaPreserveChroma = (c, targetLuma, chromaScale) => {
    if (!c) return { r: 128, g: 128, b: 128 };
    const gray = (c.r + c.g + c.b) / 3;
    let r = gray + (c.r - gray) * chromaScale;
    let g = gray + (c.g - gray) * chromaScale;
    let b = gray + (c.b - gray) * chromaScale;
    const currentLuma = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    const delta = (targetLuma - currentLuma) * 255;
    r = Math.max(0, Math.min(255, r + delta));
    g = Math.max(0, Math.min(255, g + delta));
    b = Math.max(0, Math.min(255, b + delta));
    return { r: Math.round(r), g: Math.round(g), b: Math.round(b) };
  };
  const defaultDotMin = subPixelSize * 0.14;
  const defaultDotMax = subPixelSize * 0.62;
  const dotMinRadiusPx = Math.max(
    0.02,
    Math.min(subPixelSize * 0.42, config.dotMinRadiusPx ?? defaultDotMin)
  );
  const dotMaxRadiusPx = Math.max(
    dotMinRadiusPx + Math.max(0.01, subPixelSize * 0.08),
    Math.min(subPixelSize * 0.78, config.dotMaxRadiusPx ?? defaultDotMax)
  );
  const maxRadiusBound = subPixelSize * 0.78;
  const qrFirstLightBoost = config.qrFirstMode ? 1.3 : 1;
  const lightGrainDensity = Math.max(
    0,
    Math.min(0.025, (config.lightGrainDensity ?? 4e-3) * qrFirstLightBoost)
  );
  const lightGrainAlpha = Math.max(
    0,
    Math.min(0.1, (config.lightGrainAlpha ?? 0.05) * (config.qrFirstMode ? 1.15 : 1))
  );
  const seed = config.seed ?? 1337;
  const radiusBins = 9;
  const hash01 = (x, y, s) => {
    const n = Math.sin(x * 12.9898 + y * 78.233 + s * 37.719) * 43758.5453;
    return n - Math.floor(n);
  };
  const quantizeRadius = (r) => {
    const t = Math.max(
      0,
      Math.min(1, (r - dotMinRadiusPx) / Math.max(1e-6, dotMaxRadiusPx - dotMinRadiusPx))
    );
    const q = Math.round(t * (radiusBins - 1)) / Math.max(1, radiusBins - 1);
    return dotMinRadiusPx + q * (dotMaxRadiusPx - dotMinRadiusPx);
  };
  const localVariance = (x, y) => {
    const c = colors[y]?.[x];
    if (!c) return 0;
    const luma = (p) => (0.299 * p.r + 0.587 * p.g + 0.114 * p.b) / 255;
    const center = luma(c);
    let sum = 0;
    let n = 0;
    const nb = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1]
    ];
    for (const [ox, oy] of nb) {
      const p = colors[y + oy]?.[x + ox];
      if (!p) continue;
      const d = luma(p) - center;
      sum += d * d;
      n++;
    }
    return n > 0 ? Math.min(1, Math.sqrt(sum / n) * 3) : 0;
  };
  const drawDitherDot = (x, y, radius, jitterN) => {
    const jitterAmp = subPixelSize * 0.2;
    const jxA = hash01(x * 1.37, y * 0.83, seed + 11) - 0.5;
    const jxB = hash01(x * 0.61, y * 1.91, seed + 53) - 0.5;
    const jyA = hash01(x * 0.79, y * 1.23, seed + 29) - 0.5;
    const jyB = hash01(x * 1.71, y * 0.57, seed + 89) - 0.5;
    const jx = (jxA * 0.66 + jxB * 0.34) * 2 * jitterAmp * jitterN;
    const jy = (jyA * 0.66 + jyB * 0.34) * 2 * jitterAmp * jitterN;
    ctx.beginPath();
    ctx.arc(
      x + subPixelSize / 2 + jx,
      y + subPixelSize / 2 + jy,
      Math.min(radius, maxRadiusBound),
      0,
      Math.PI * 2
    );
    ctx.fill();
  };
  const isFinderSeparator3 = (row, col) => row === 7 && col <= 7 || col === 7 && row <= 7 || row === 7 && col >= moduleCount - 8 || col === moduleCount - 8 && row <= 7 || row === moduleCount - 8 && col <= 7 || col === 7 && row >= moduleCount - 8;
  const isFinderRegion = (row, col) => isFinderPattern(row, col, moduleCount) || isFinderSeparator3(row, col);
  const shouldForceBinaryModule = (row, col) => {
    if (!isLocked(row, col, moduleCount, version)) return false;
    if (row === moduleCount - 8 && col === 8) return preserveFixedDark;
    if (isFinderPattern(row, col, moduleCount) || isFinderSeparator3(row, col)) {
      return preserveFinders;
    }
    if (isTimingPattern(row, col, moduleCount)) return preserveTiming;
    if (isAlignmentPattern(row, col, moduleCount, version)) return preserveAlignment;
    if (isFormatInfo(row, col, moduleCount)) return protectFormat;
    if (isVersionInfo(row, col, moduleCount, version)) return protectVersion;
    return false;
  };
  const enforceQuietZoneClean = () => {
    if (marginPx <= 0) return;
    const qrStart = marginPx;
    const qrSize = moduleCount * effectiveModuleSize;
    const qrEnd = qrStart + qrSize;
    if (config.transparentBg) {
      ctx.clearRect(0, 0, size, qrStart);
      ctx.clearRect(0, qrStart, qrStart, qrSize);
      ctx.clearRect(qrEnd, qrStart, Math.max(0, size - qrEnd), qrSize);
      ctx.clearRect(0, qrEnd, size, Math.max(0, size - qrEnd));
      return;
    }
    ctx.fillStyle = effectiveBgColor;
    ctx.fillRect(0, 0, size, qrStart);
    ctx.fillRect(0, qrStart, qrStart, qrSize);
    ctx.fillRect(qrEnd, qrStart, Math.max(0, size - qrEnd), qrSize);
    ctx.fillRect(0, qrEnd, size, Math.max(0, size - qrEnd));
  };
  const drawStrictFunctionOverlay = () => {
    for (let row = 0; row < moduleCount; row++) {
      for (let col = 0; col < moduleCount; col++) {
        if (!shouldForceBinaryModule(row, col)) continue;
        const x = marginPx + col * effectiveModuleSize;
        const y = marginPx + row * effectiveModuleSize;
        ctx.fillStyle = qr.isDark(row, col) ? effectiveFgColor : effectiveBgColor;
        ctx.fillRect(x, y, effectiveModuleSize, effectiveModuleSize);
      }
    }
  };
  const finderContrastBoost = !preserveFinders;
  const alignmentContrastBoost = !preserveAlignment;
  const timingContrastBoost = !preserveTiming;
  const formatContrastBoost = !protectFormat;
  const versionContrastBoost = !protectVersion;
  const fixedDarkContrastBoost = !preserveFixedDark;
  const rawFinderDitherStrength = typeof config.finderDitherStrength === "number" && Number.isFinite(config.finderDitherStrength) ? config.finderDitherStrength : 65;
  const finderDitherStrength = Math.max(0, Math.min(100, rawFinderDitherStrength));
  const finderStrengthN = finderDitherStrength / 100;
  const blendPreservations = config.blendPreservations === true;
  const blendChannelToward = (src, target, t) => Math.round(src + (target - src) * Math.max(0, Math.min(1, t)));
  const sampleModuleOverlayColor = (row, col) => {
    if (!colors?.length) return null;
    const px = Math.max(0, Math.min(scaledSize - 1, Math.floor((col + 0.5) * scale)));
    const py = Math.max(0, Math.min(scaledSize - 1, Math.floor((row + 0.5) * scale)));
    return colors[py]?.[px] ?? null;
  };
  const estimatePaperLuma = (sampled) => {
    if (!sampled) return bgLuma;
    const sampledLuma = (0.299 * sampled.r + 0.587 * sampled.g + 0.114 * sampled.b) / 255;
    return bgLuma * (1 - ditherPaperOverlayMix) + sampledLuma * ditherPaperOverlayMix;
  };
  const getPreservationBlendTargetForScaledPixel = (moduleRow, moduleCol, scaledRow, scaledCol) => {
    const moduleDark = qr.isDark(moduleRow, moduleCol);
    const sampled = colors[scaledRow]?.[scaledCol] ?? sampleModuleOverlayColor(moduleRow, moduleCol);
    if (!sampled) {
      return moduleDark ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 };
    }
    const pixelDark = matrix[scaledRow]?.[scaledCol] === true;
    if (isDitheredMode) {
      if (moduleDark) {
        return pixelDark ? adjustLumaPreserveChroma(sampled, 0.04, 1.65) : adjustLumaPreserveChroma(sampled, 0.18, 1.3);
      }
      return pixelDark ? adjustLumaPreserveChroma(sampled, 0.9, 0.9) : adjustLumaPreserveChroma(sampled, 0.97, 0.8);
    }
    if (moduleDark) {
      return pixelDark ? adjustLumaPreserveChroma(sampled, 0.08, 1.28) : adjustLumaPreserveChroma(sampled, 0.2, 1.14);
    }
    return pixelDark ? adjustLumaPreserveChroma(sampled, 0.88, 0.95) : adjustLumaPreserveChroma(sampled, 0.97, 0.84);
  };
  const isPatternBoostModule = (row, col) => {
    const isFinderBoostModule = finderContrastBoost && isFinderRegion(row, col);
    const isAlignmentBoostModule = alignmentContrastBoost && isAlignmentPattern(row, col, moduleCount, version);
    const isTimingBoostModule = timingContrastBoost && isTimingPattern(row, col, moduleCount);
    const isFormatBoostModule = formatContrastBoost && isFormatInfo(row, col, moduleCount);
    const isVersionBoostModule = versionContrastBoost && isVersionInfo(row, col, moduleCount, version);
    const isFixedDarkBoostModule = fixedDarkContrastBoost && row === moduleCount - 8 && col === 8;
    return isFinderBoostModule || isAlignmentBoostModule || isTimingBoostModule || isFormatBoostModule || isVersionBoostModule || isFixedDarkBoostModule;
  };
  const drawPatternContrastBoostOverlay = () => {
    if (finderStrengthN <= 0) return;
    if (!(finderContrastBoost || alignmentContrastBoost || timingContrastBoost || formatContrastBoost || versionContrastBoost || fixedDarkContrastBoost)) {
      return;
    }
    if (blendPreservations) {
      const imageData = ctx.getImageData(0, 0, size, size);
      const data = imageData.data;
      for (let row = 0; row < moduleCount; row++) {
        for (let col = 0; col < moduleCount; col++) {
          if (!isPatternBoostModule(row, col)) continue;
          const x = marginPx + col * effectiveModuleSize;
          const y = marginPx + row * effectiveModuleSize;
          const x0 = Math.max(0, Math.floor(x));
          const y0 = Math.max(0, Math.floor(y));
          const x1 = Math.min(size, Math.ceil(x + effectiveModuleSize));
          const y1 = Math.min(size, Math.ceil(y + effectiveModuleSize));
          for (let py = y0; py < y1; py++) {
            let idx = (py * size + x0) * 4;
            const scaledRow = Math.max(
              0,
              Math.min(scaledSize - 1, Math.floor((py - marginPx) / Math.max(1e-6, subPixelSize)))
            );
            for (let px = x0; px < x1; px++) {
              const scaledCol = Math.max(
                0,
                Math.min(scaledSize - 1, Math.floor((px - marginPx) / Math.max(1e-6, subPixelSize)))
              );
              const sampled = colors[scaledRow]?.[scaledCol] ?? sampleModuleOverlayColor(row, col);
              const paperLuma = estimatePaperLuma(sampled ?? null);
              const pixelLuma = (0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2]) / 255;
              const moduleDark = qr.isDark(row, col);
              const rawInkContrast = paperLuma - pixelLuma;
              const inkCoverageN = isDitheredMode ? moduleDark ? Math.max(0, Math.min(1, (rawInkContrast - 0.015) / 0.28)) : Math.max(0, Math.min(1, (rawInkContrast + 0.03) / 0.22)) : 1;
              if (inkCoverageN <= 1e-3) {
                idx += 4;
                continue;
              }
              const target = getPreservationBlendTargetForScaledPixel(
                row,
                col,
                scaledRow,
                scaledCol
              );
              const t = finderStrengthN * inkCoverageN;
              data[idx] = blendChannelToward(data[idx], target.r, t);
              data[idx + 1] = blendChannelToward(data[idx + 1], target.g, t);
              data[idx + 2] = blendChannelToward(data[idx + 2], target.b, t);
              idx += 4;
            }
          }
        }
      }
      ctx.putImageData(imageData, 0, 0);
      return;
    }
    ctx.save();
    ctx.globalAlpha = finderStrengthN;
    for (let row = 0; row < moduleCount; row++) {
      for (let col = 0; col < moduleCount; col++) {
        if (!isPatternBoostModule(row, col)) continue;
        const x = marginPx + col * effectiveModuleSize;
        const y = marginPx + row * effectiveModuleSize;
        ctx.fillStyle = qr.isDark(row, col) ? "rgb(0,0,0)" : "rgb(255,255,255)";
        ctx.fillRect(x, y, effectiveModuleSize, effectiveModuleSize);
      }
    }
    ctx.restore();
  };
  for (let y = 0; y < scaledSize; y++) {
    for (let x = 0; x < scaledSize; x++) {
      const isDark2 = matrix[y]?.[x];
      const color = colors[y]?.[x] ?? null;
      const shouldDrawLightPixel = !isDitheredMode && (needsExplicitLightModules || needsBothDarkAndLightColors && useColorRendering);
      if (debug && y === Math.floor(scaledSize / 2) && (x === Math.floor(scaledSize / 2) || x === Math.floor(scaledSize / 2) + 4)) {
        log13.debug("ScaledRender samplePixel", {
          y,
          x,
          isDark: isDark2,
          color
        });
      }
      const dx = marginPx + x * subPixelSize;
      const dy = marginPx + y * subPixelSize;
      const moduleRow = Math.floor(y / scale);
      const moduleCol = Math.floor(x / scale);
      const moduleLocked = shouldForceBinaryModule(moduleRow, moduleCol);
      if (!isDark2) {
        if (isDitheredMode) {
          const sourceLuma = color ? (0.299 * color.r + 0.587 * color.g + 0.114 * color.b) / 255 : 1;
          const toneN = 1 - sourceLuma;
          const varN = localVariance(x, y);
          const noiseN = hash01(x, y, seed + 149);
          const grainChance = Math.max(
            0,
            Math.min(
              config.qrFirstMode ? 0.2 : 0.08,
              lightGrainDensity * (0.9 + toneN * 1.5 + varN * 1.1 + (noiseN - 0.5) * 0.3)
            )
          );
          if (grainChance > 0 && hash01(x, y, seed + 131) < grainChance) {
            const lightTarget = Math.max(
              0.32,
              Math.min(0.76, 0.46 + sourceLuma * 0.22 - varN * 0.06)
            );
            const grain = color ? adjustLumaPreserveChroma(color, lightTarget, 1.42) : { r: 226, g: 226, b: 226 };
            ctx.fillStyle = `rgb(${grain.r},${grain.g},${grain.b})`;
            const prevAlpha = ctx.globalAlpha;
            const alpha = Math.min(
              0.12,
              Math.max(
                0.02,
                lightGrainAlpha * (0.55 + toneN * 0.4 + varN * 0.18 + (noiseN - 0.5) * 0.08)
              )
            );
            ctx.globalAlpha = alpha;
            const grainRadius = Math.max(
              0.04,
              quantizeRadius(dotMinRadiusPx * (0.95 + toneN * 0.7 + varN * 0.22 + noiseN * 0.16))
            );
            drawDitherDot(dx, dy, grainRadius, 0.25 + 0.08 * noiseN);
            ctx.globalAlpha = prevAlpha;
          }
          continue;
        }
        if (!shouldDrawLightPixel) continue;
      }
      if (isDark2) {
        if (isDitheredMode) {
          const sourceLuma = color ? (0.299 * color.r + 0.587 * color.g + 0.114 * color.b) / 255 : 0.5;
          let drawLuma = sourceLuma;
          if (useColorRendering && color) {
            const tone = (1 - sourceLuma) ** 0.86;
            const targetLuma = Math.max(0.04, Math.min(0.21, 0.04 + (1 - tone) * 0.17));
            const dark = adjustLumaPreserveChroma(color, targetLuma, 1.62);
            const darkR = dark.r;
            const darkG = dark.g;
            const darkB = dark.b;
            ctx.fillStyle = `rgb(${darkR},${darkG},${darkB})`;
            drawLuma = (0.299 * darkR + 0.587 * darkG + 0.114 * darkB) / 255;
          } else {
            const mono = Math.round(Math.max(8, Math.min(76, 8 + sourceLuma * 68)));
            ctx.fillStyle = `rgb(${mono},${mono},${mono})`;
            drawLuma = mono / 255;
          }
          const varN = localVariance(x, y);
          const noiseN = hash01(x, y, seed);
          const toneN = (1 - drawLuma) ** 0.9;
          if (!moduleLocked) {
            const dropoutNoise = hash01(x, y, seed + 257);
            const dropoutChance = Math.max(
              0,
              Math.min(0.05, 4e-3 + (1 - toneN) * 0.03 + varN * 0.012)
            );
            if (dropoutNoise < dropoutChance) continue;
          }
          const radiusT = Math.max(
            0,
            Math.min(1, 0.16 + toneN * 0.68 + varN * 0.22 + (noiseN - 0.5) * 0.34)
          );
          const rawRadius = dotMinRadiusPx + radiusT * (dotMaxRadiusPx - dotMinRadiusPx);
          const radius = quantizeRadius(Math.max(dotMinRadiusPx, rawRadius));
          const jitterN = 0.66 + 0.34 * hash01(x, y, seed + 7);
          drawDitherDot(dx, dy, radius, jitterN);
        } else if (useColorRendering && color) {
          if (needsBothDarkAndLightColors) {
            const dark = adjustLumaPreserveChroma(
              color,
              subpixelDarkTargetLuma,
              subpixelDarkChroma
            );
            ctx.fillStyle = `rgb(${dark.r},${dark.g},${dark.b})`;
          } else {
            ctx.fillStyle = `rgb(${color.r},${color.g},${color.b})`;
          }
          ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
        } else {
          ctx.fillStyle = useGradient && gradientFill ? gradientFill : effectiveFgColor;
          ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
        }
      } else {
        if (needsBothDarkAndLightColors && useColorRendering && color) {
          const light = adjustLumaPreserveChroma(
            color,
            subpixelLightTargetLuma,
            subpixelLightChroma
          );
          ctx.fillStyle = `rgb(${light.r},${light.g},${light.b})`;
          ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
        } else {
          ctx.fillStyle = effectiveBgColor;
          ctx.fillRect(dx, dy, subPixelSize, subPixelSize);
        }
      }
    }
  }
  drawPatternContrastBoostOverlay();
  if (forceBinaryFunctionPatterns) {
    drawStrictFunctionOverlay();
  }
  const shouldDrawFindersFirst = !forceBinaryFunctionPatterns && (config.preserveFinders !== false || !overlayCanvas);
  const finderPositions = [
    { row: 0, col: 0 },
    // Top-left
    { row: 0, col: moduleCount - 7 },
    // Top-right
    { row: moduleCount - 7, col: 0 }
    // Bottom-left
  ];
  if (shouldDrawFindersFirst) {
    for (const pos of finderPositions) {
      const x = marginPx + pos.col * effectiveModuleSize;
      const y = marginPx + pos.row * effectiveModuleSize;
      if (forceBinaryFunctionPatterns) {
        drawFinderPatternComplete(ctx, x, y, effectiveModuleSize, {
          ...config,
          gradient: { type: "none", stops: [] },
          fgColor: effectiveFgColor,
          bgColor: effectiveBgColor
        });
      } else {
        drawFinderPatternComplete(ctx, x, y, effectiveModuleSize, config);
      }
    }
  }
  const shouldDrawAlignmentFirst = !forceBinaryFunctionPatterns && (config.preserveAlignment !== false || !overlayCanvas);
  if (version >= 2 && shouldDrawAlignmentFirst) {
    const alignPositions = getAlignmentPositionsCached(version, moduleCount);
    const alignmentStyle = config.alignmentStyle || "match_finder";
    for (const pos of alignPositions) {
      const centerX = marginPx + (pos.col + 0.5) * effectiveModuleSize;
      const centerY = marginPx + (pos.row + 0.5) * effectiveModuleSize;
      if (forceBinaryFunctionPatterns) {
        drawAlignmentPattern(ctx, centerX, centerY, effectiveModuleSize, alignmentStyle, {
          ...config,
          gradient: { type: "none", stops: [] },
          fgColor: effectiveFgColor,
          bgColor: effectiveBgColor
        });
      } else {
        drawAlignmentPattern(ctx, centerX, centerY, effectiveModuleSize, alignmentStyle, config);
      }
    }
  }
  const shouldPreserveTimingModules = !forceBinaryFunctionPatterns && preserveTiming;
  if (shouldPreserveTimingModules) {
    const timingStyle = config.timingStyle || "match_module";
    const timingRow = 6;
    for (let col = 8; col < moduleCount - 8; col++) {
      const isDark2 = qr.isDark(timingRow, col);
      const x = marginPx + col * effectiveModuleSize;
      const y = marginPx + timingRow * effectiveModuleSize;
      if (isDark2) {
        ctx.fillStyle = forceBinaryFunctionPatterns ? effectiveFgColor : useGradient && gradientFill ? gradientFill : effectiveFgColor;
        drawTimingModule(ctx, x, y, effectiveModuleSize, timingStyle, config);
      } else {
        ctx.fillStyle = effectiveBgColor;
        ctx.fillRect(x, y, effectiveModuleSize, effectiveModuleSize);
      }
    }
    const timingCol = 6;
    for (let row = 8; row < moduleCount - 8; row++) {
      const isDark2 = qr.isDark(row, timingCol);
      const x = marginPx + timingCol * effectiveModuleSize;
      const y = marginPx + row * effectiveModuleSize;
      if (isDark2) {
        ctx.fillStyle = forceBinaryFunctionPatterns ? effectiveFgColor : useGradient && gradientFill ? gradientFill : effectiveFgColor;
        drawTimingModule(ctx, x, y, effectiveModuleSize, timingStyle, config);
      } else {
        ctx.fillStyle = effectiveBgColor;
        ctx.fillRect(x, y, effectiveModuleSize, effectiveModuleSize);
      }
    }
  }
  const shouldProtectFormatInfo = !forceBinaryFunctionPatterns && protectFormat;
  const shouldProtectVersionInfo = !forceBinaryFunctionPatterns && protectVersion;
  if (shouldProtectFormatInfo || shouldProtectVersionInfo) {
    let formatCount = 0;
    let versionCount = 0;
    for (let row = 0; row < moduleCount; row++) {
      for (let col = 0; col < moduleCount; col++) {
        const isFormat = shouldProtectFormatInfo && isFormatInfo(row, col, moduleCount);
        const isVersion = shouldProtectVersionInfo && isVersionInfo(row, col, moduleCount, version);
        if (!(isFormat || isVersion)) continue;
        const isDark2 = qr.isDark(row, col);
        const x = marginPx + col * effectiveModuleSize;
        const y = marginPx + row * effectiveModuleSize;
        if (isDark2) {
          ctx.fillStyle = forceBinaryFunctionPatterns ? effectiveFgColor : useGradient && gradientFill ? gradientFill : effectiveFgColor;
        } else {
          ctx.fillStyle = effectiveBgColor;
        }
        ctx.fillRect(x, y, effectiveModuleSize, effectiveModuleSize);
        if (isFormat) formatCount++;
        if (isVersion) versionCount++;
      }
    }
    const dmRow = moduleCount - 8;
    const dmCol = 8;
    if (dmRow >= 0 && dmRow < moduleCount && dmCol >= 0 && dmCol < moduleCount) {
      const x = marginPx + dmCol * effectiveModuleSize;
      const y = marginPx + dmRow * effectiveModuleSize;
      ctx.fillStyle = forceBinaryFunctionPatterns ? effectiveFgColor : useGradient && gradientFill ? gradientFill : effectiveFgColor;
      ctx.fillRect(x, y, effectiveModuleSize, effectiveModuleSize);
    }
    if (debug) {
      log13.debug("ScaledRender preserved", {
        protectFormat: shouldProtectFormatInfo,
        protectVersion: shouldProtectVersionInfo,
        formatCount,
        versionCount,
        preservedTiming: shouldPreserveTimingModules
      });
    }
  }
  enforceQuietZoneClean();
  drawFrame(ctx, size, effectiveModuleSize, marginModules, config);
  storeMatrixFn(qr, moduleCount);
  return canvas;
}

// src/modules/qr-generator/qr-generator-class.ts
var log14 = createLogger("GENERATE");
var MatrixWrapper = class {
  matrix;
  moduleCount;
  constructor(matrix) {
    this.matrix = matrix;
    this.moduleCount = matrix.length;
  }
  // Required by QRCodeInstance interface but not used for rendering
  addData(_data, _mode) {
  }
  // Required by QRCodeInstance interface but not used for rendering
  make(_maskPattern) {
  }
  getModuleCount() {
    return this.moduleCount;
  }
  isDark(row, col) {
    return this.matrix[row]?.[col] ?? false;
  }
};
var QRGenerator = class _QRGenerator {
  qrcode;
  canvasFactory;
  _lastMatrix = null;
  _lastModuleCount = 0;
  _ditherPatchCache = /* @__PURE__ */ new Map();
  static DITHER_PATCH_CACHE_MAX_ENTRIES = 64;
  static DITHER_PATCH_CACHE_TTL_MS = 5 * 60 * 1e3;
  /**
   * Create a QR generator instance
   * @param canvasFactory - Optional canvas factory for non-browser environments
   */
  constructor(canvasFactory = null) {
    this.qrcode = qrcode;
    this.canvasFactory = canvasFactory || defaultBrowserCanvasFactory;
  }
  /**
   * Get the QR matrix from the last generate() call
   * Returns a 2D boolean array where true = dark module, false = light module
   */
  getLastMatrix() {
    if (!this._lastMatrix) return null;
    return {
      matrix: this._lastMatrix,
      moduleCount: this._lastModuleCount
    };
  }
  /**
   * Store the QR matrix for vector SVG export
   * Reusable helper to avoid code duplication across render methods
   */
  storeMatrix(qr, moduleCount) {
    const matrix = [];
    for (let row = 0; row < moduleCount; row++) {
      matrix[row] = [];
      for (let col = 0; col < moduleCount; col++) {
        matrix[row][col] = qr.isDark(row, col);
      }
    }
    this._lastMatrix = matrix;
    this._lastModuleCount = moduleCount;
  }
  /**
   * Store a pre-computed matrix directly (without iterating through QRCodeInstance)
   */
  storeMatrixDirect(matrix, moduleCount) {
    this._lastMatrix = matrix;
    this._lastModuleCount = moduleCount;
  }
  /**
   * Create a canvas using the configured factory
   */
  async createCanvas(width, height) {
    return this.canvasFactory.createCanvas(width, height);
  }
  async loadLibrary() {
  }
  /**
   * Build QR matrix with caching
   */
  buildQRMatrix(config, typeNumber, encodingMode, maskPatternConfig, characterEncodingConfig) {
    const qrCacheKey = `${config.content}:${config.errorCorrection}:${typeNumber}:${encodingMode}:${maskPatternConfig}:${characterEncodingConfig}`;
    const cachedQr = qrMatrixCache.get(qrCacheKey);
    if (cachedQr) {
      return { qr: cachedQr.qr, moduleCount: cachedQr.moduleCount };
    }
    const qr = this.qrcode(typeNumber, config.errorCorrection);
    if (characterEncodingConfig === "utf8") {
      setStringToBytes((s) => {
        const encoder = new TextEncoder();
        return Array.from(encoder.encode(s));
      });
    } else if (characterEncodingConfig === "shift-jis") {
      setStringToBytes(createShiftJISEncoder());
    } else {
      resetStringToBytes();
    }
    const modeMap = {
      numeric: "Numeric",
      alphanumeric: "Alphanumeric",
      byte: "Byte",
      kanji: "Kanji",
      auto: void 0
    };
    const libraryMode = modeMap[encodingMode] || void 0;
    qr.addData(config.content, libraryMode);
    const maskPattern = typeof maskPatternConfig === "number" && maskPatternConfig >= 0 && maskPatternConfig <= 7 ? maskPatternConfig : void 0;
    qr.make(maskPattern);
    const moduleCount = qr.getModuleCount();
    resetStringToBytes();
    qrMatrixCache.set(qrCacheKey, { qr, moduleCount });
    return { qr, moduleCount };
  }
  /**
   * Draw finder and alignment patterns
   */
  drawStructuralPatterns(ctx, config, moduleCount, moduleSize, margin, overlayData, version) {
    const drawnFinderPatterns = /* @__PURE__ */ new Set();
    const drawnAlignmentPatterns = /* @__PURE__ */ new Set();
    const shouldDrawFindersFirst = config.preserveFinders !== false || !overlayData;
    const finderPositions = [
      { row: 0, col: 0 },
      { row: 0, col: moduleCount - 7 },
      { row: moduleCount - 7, col: 0 }
    ];
    if (shouldDrawFindersFirst) {
      for (const pos of finderPositions) {
        const x = (pos.col + margin) * moduleSize;
        const y = (pos.row + margin) * moduleSize;
        drawFinderPatternComplete(ctx, x, y, moduleSize, config);
        for (let r = pos.row; r < pos.row + 7; r++) {
          for (let c = pos.col; c < pos.col + 7; c++) {
            drawnFinderPatterns.add(`${r},${c}`);
          }
        }
      }
    }
    const shouldDrawAlignmentFirst = config.preserveAlignment !== false || !overlayData;
    const alignmentStyle = config.alignmentStyle || "match_finder";
    if (version >= 2 && shouldDrawAlignmentFirst) {
      const alignPositions = getAlignmentPositionsCached(version, moduleCount);
      for (const pos of alignPositions) {
        const centerX = (pos.col + margin) * moduleSize + moduleSize / 2;
        const centerY = (pos.row + margin) * moduleSize + moduleSize / 2;
        drawAlignmentPattern(
          ctx,
          centerX,
          centerY,
          moduleSize,
          alignmentStyle,
          config
        );
        for (let r = pos.row - 2; r <= pos.row + 2; r++) {
          for (let c = pos.col - 2; c <= pos.col + 2; c++) {
            drawnAlignmentPatterns.add(`${r},${c}`);
          }
        }
      }
    }
    return { drawnFinderPatterns, drawnAlignmentPatterns };
  }
  async generate(config, overlayCanvas = null) {
    if (!this.qrcode) {
      await this.loadLibrary();
    }
    let encodingMode = config.encodingMode || "auto";
    const content = config.content || "";
    encodingMode = getCompatibleMode(content, encodingMode);
    let typeNumber = config.typeNumber;
    if (typeNumber === 0) {
      typeNumber = calculateOptimalVersion(
        config.content,
        config.errorCorrection
      );
    }
    let processedOverlayCanvas = overlayCanvas;
    if (overlayCanvas && hasGeometricTransforms(config)) {
      processedOverlayCanvas = await applyGeometricTransforms(
        overlayCanvas,
        config,
        this.createCanvas.bind(this)
      );
    }
    const needsPreprocessing = hasPreprocessingOptions(config);
    log14.trace("Preprocessing check", {
      hasOverlay: !!processedOverlayCanvas,
      needsPreprocessing,
      overlayMode: config.overlayMode,
      colorMode: config.colorMode,
      filterGrayscale: config.filterGrayscale,
      filterBrightness: config.filterBrightness,
      filterContrast: config.filterContrast
    });
    if (processedOverlayCanvas && needsPreprocessing) {
      log14.trace("Preprocessing overlay", {
        overlayMode: config.overlayMode,
        colorMode: config.colorMode,
        filterBrightness: config.filterBrightness,
        filterContrast: config.filterContrast,
        filterGamma: config.filterGamma,
        filterSaturation: config.filterSaturation,
        filterHue: config.filterHue,
        filterBlur: config.filterBlur,
        filterSharpen: config.filterSharpen,
        filterPosterize: config.filterPosterize,
        filterThreshold: config.filterThreshold,
        filterEdgeDetect: config.filterEdgeDetect,
        filterInvert: config.filterInvert,
        filterGrayscale: config.filterGrayscale
      });
      processedOverlayCanvas = await preprocessOverlay(
        processedOverlayCanvas,
        config,
        this.createCanvas.bind(this)
      );
      log14.trace("Preprocessing complete", {
        width: processedOverlayCanvas.width,
        height: processedOverlayCanvas.height
      });
    } else if (processedOverlayCanvas) {
      log14.trace("Skipping preprocessing - no filters to apply");
    }
    const maskPatternConfig = typeof config.maskPattern === "number" ? config.maskPattern : void 0;
    const characterEncodingConfig = config.characterEncoding || "default";
    const { qr, moduleCount } = this.buildQRMatrix(
      config,
      typeNumber,
      encodingMode,
      maskPatternConfig,
      characterEncodingConfig
    );
    const vr = verifyQRStructure(qr, typeNumber || void 0);
    if (!vr.ok) {
      log14.warn("QR structural check failed", {
        moduleCount,
        version: vr.version,
        issues: vr.issues
      });
    }
    const overlayModeWithDefault = processedOverlayCanvas && !config.overlayMode ? "dithered" : config.overlayMode;
    const effectiveOverlayMode = overlayModeWithDefault;
    const effectiveConfig = {
      ...config,
      typeNumber,
      overlayMode: effectiveOverlayMode
    };
    const scale = getScaleFactor(effectiveOverlayMode, effectiveConfig);
    log14.debug("Overlay mode resolution", {
      hasOverlay: !!processedOverlayCanvas,
      configOverlayMode: config.overlayMode,
      effectiveOverlayMode,
      scale,
      willUseScaledPath: scale > 1 && !!processedOverlayCanvas,
      colorMode: config.colorMode,
      overlayIntensity: config.overlayIntensity
    });
    if (scale > 1 && processedOverlayCanvas) {
      const renderScaled = async (cfg) => await generateScaledQR(
        qr,
        cfg,
        processedOverlayCanvas,
        moduleCount,
        scale,
        this.createCanvas.bind(this),
        this.canvasFactory,
        this.storeMatrix.bind(this)
      );
      if (effectiveConfig.overlayMode === "dithered" || effectiveConfig.forceScaledOverlay === true) {
        const decodeCanvasData = (c) => {
          const ctx2 = c.getContext("2d");
          if (!ctx2) return null;
          const imageData = ctx2.getImageData(0, 0, c.width, c.height);
          return decodeQR2(imageData, { inversionAttempts: "attemptBoth" });
        };
        const clamp2 = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
        const scanGateProfile = effectiveConfig.scanGateProfile ?? "full";
        const isPreviewScanGate = scanGateProfile === "preview";
        const isScanGateDisabled = scanGateProfile === "off";
        const skipScanGateEscalation = effectiveConfig.preserveFinders === false && effectiveConfig.blendPreservations !== true;
        const edgeImprintThreshold = clamp2(effectiveConfig.edgeImprintThreshold ?? 0.2, 0.05, 0.5);
        const toneStdThreshold = clamp2(effectiveConfig.toneStdThreshold ?? 0.12, 0.05, 0.3);
        const edgeWorsenLimit = clamp2(effectiveConfig.edgeImprintWorsenLimit ?? 0.015, 0, 0.2);
        const fixedVisualPolicy = {
          overlayMode: effectiveConfig.overlayMode,
          colorMode: effectiveConfig.colorMode,
          renderScalePerModule: effectiveConfig.renderScalePerModule,
          ditherKind: effectiveConfig.ditherKind,
          ditherMode: effectiveConfig.ditherMode,
          ditherStrength: effectiveConfig.ditherStrength,
          finderDitherStrength: effectiveConfig.finderDitherStrength,
          blendPreservations: effectiveConfig.blendPreservations,
          ditherScale: effectiveConfig.ditherScale,
          ditherSerpentine: effectiveConfig.ditherSerpentine,
          diffusionKernel: effectiveConfig.diffusionKernel,
          orderedMatrix: effectiveConfig.orderedMatrix,
          blueNoiseTileSize: effectiveConfig.blueNoiseTileSize,
          blueNoiseSeed: effectiveConfig.blueNoiseSeed,
          colorDither: effectiveConfig.colorDither,
          dotMinRadiusPx: effectiveConfig.dotMinRadiusPx,
          dotMaxRadiusPx: effectiveConfig.dotMaxRadiusPx,
          seed: effectiveConfig.seed
        };
        const patchSignature = (patch) => JSON.stringify({
          d: patch.darkMinOccupancy ?? null,
          l: patch.lightMaxOccupancy ?? null,
          i: patch.optimizeIterations ?? null,
          o: patch.overlayIntensity ?? null,
          b: patch.qrBitBiasStrength ?? null,
          q: patch.qrFirstMode ?? null,
          f: patch.preserveFinders ?? null
        });
        const buildScanCacheKey = (preserveFindersValue) => [
          effectiveConfig.content,
          effectiveConfig.errorCorrection,
          moduleCount,
          effectiveConfig.overlayMode,
          effectiveConfig.colorMode,
          scanGateProfile,
          Math.round(effectiveConfig.overlayIntensity ?? 100),
          Math.round(effectiveConfig.ditherStrength ?? 50),
          Math.round(effectiveConfig.finderDitherStrength ?? 65),
          effectiveConfig.blendPreservations === true ? 1 : 0,
          effectiveConfig.ditherKind ?? "none",
          effectiveConfig.ditherMode ?? "none",
          Math.round(effectiveConfig.ditherScale ?? 1),
          effectiveConfig.ditherSerpentine === false ? 0 : 1,
          effectiveConfig.diffusionKernel ?? "floyd_steinberg",
          effectiveConfig.orderedMatrix ?? "bayer4",
          Math.round(effectiveConfig.blueNoiseTileSize ?? 64),
          effectiveConfig.blueNoiseSeed ?? "noise-seed:auto",
          effectiveConfig.colorDither ?? "none",
          Math.round(effectiveConfig.renderScalePerModule ?? 18),
          preserveFindersValue ? 1 : 0,
          effectiveConfig.preserveTiming === true ? 1 : 0,
          effectiveConfig.preserveAlignment === true ? 1 : 0,
          effectiveConfig.protectFormatInfo === true ? 1 : 0,
          effectiveConfig.protectVersionInfo === true ? 1 : 0,
          effectiveConfig.qrFirstMode === true ? 1 : 0,
          effectiveConfig.seed ?? "seed:auto"
        ].join("|");
        const scanCacheKey = buildScanCacheKey(effectiveConfig.preserveFinders !== false);
        const getCachedPatch = () => {
          const resolvedKey = scanCacheKey;
          const entry = this._ditherPatchCache.get(resolvedKey);
          if (!entry) return null;
          if (Date.now() - entry.updatedAt > _QRGenerator.DITHER_PATCH_CACHE_TTL_MS) {
            this._ditherPatchCache.delete(resolvedKey);
            return null;
          }
          return { ...entry.patch };
        };
        const rememberPatch = (patch) => {
          this._ditherPatchCache.set(scanCacheKey, {
            patch: { ...patch },
            updatedAt: Date.now()
          });
          if (this._ditherPatchCache.size <= _QRGenerator.DITHER_PATCH_CACHE_MAX_ENTRIES) return;
          let oldestKey = null;
          let oldestAt = Number.POSITIVE_INFINITY;
          for (const [k, v] of this._ditherPatchCache.entries()) {
            if (v.updatedAt < oldestAt) {
              oldestAt = v.updatedAt;
              oldestKey = k;
            }
          }
          if (oldestKey) this._ditherPatchCache.delete(oldestKey);
        };
        const useFinderRelaxedAttempts = skipScanGateEscalation && !isScanGateDisabled;
        const baseAttempts = useFinderRelaxedAttempts ? [
          {
            darkMinOccupancy: clamp2(effectiveConfig.darkMinOccupancy ?? 0.46, 0.4, 0.56),
            lightMaxOccupancy: clamp2(effectiveConfig.lightMaxOccupancy ?? 0.54, 0.44, 0.6),
            optimizeIterations: Math.max(4, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(92, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(
              (effectiveConfig.qrBitBiasStrength ?? 0.04) + 0.03,
              0,
              0.24
            )
          },
          {
            darkMinOccupancy: clamp2(effectiveConfig.darkMinOccupancy ?? 0.5, 0.46, 0.58),
            lightMaxOccupancy: clamp2(effectiveConfig.lightMaxOccupancy ?? 0.5, 0.42, 0.54),
            optimizeIterations: Math.max(6, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(84, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(
              (effectiveConfig.qrBitBiasStrength ?? 0.04) + 0.05,
              0,
              0.24
            )
          },
          {
            darkMinOccupancy: clamp2(effectiveConfig.darkMinOccupancy ?? 0.54, 0.5, 0.6),
            lightMaxOccupancy: clamp2(effectiveConfig.lightMaxOccupancy ?? 0.46, 0.4, 0.5),
            optimizeIterations: Math.max(7, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(76, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(
              (effectiveConfig.qrBitBiasStrength ?? 0.04) + 0.07,
              0,
              0.24
            )
          }
        ] : isPreviewScanGate ? [
          {
            darkMinOccupancy: clamp2(effectiveConfig.darkMinOccupancy ?? 0, 0, 1),
            lightMaxOccupancy: clamp2(effectiveConfig.lightMaxOccupancy ?? 1, 0, 1),
            optimizeIterations: Math.max(2, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(100, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(effectiveConfig.qrBitBiasStrength ?? 0.04, 0, 0.24)
          },
          {
            darkMinOccupancy: clamp2(effectiveConfig.darkMinOccupancy ?? 0.56, 0.54, 0.62),
            lightMaxOccupancy: clamp2(effectiveConfig.lightMaxOccupancy ?? 0.44, 0.38, 0.46),
            optimizeIterations: Math.max(4, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(62, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(
              (effectiveConfig.qrBitBiasStrength ?? 0.04) + 0.1,
              0,
              0.28
            )
          }
        ] : [
          {
            darkMinOccupancy: effectiveConfig.darkMinOccupancy ?? 0,
            lightMaxOccupancy: effectiveConfig.lightMaxOccupancy ?? 1,
            optimizeIterations: Math.max(4, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(100, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(effectiveConfig.qrBitBiasStrength ?? 0.04, 0, 0.24)
          },
          {
            darkMinOccupancy: clamp2(effectiveConfig.darkMinOccupancy ?? 0.5, 0.5, 0.56),
            lightMaxOccupancy: clamp2(effectiveConfig.lightMaxOccupancy ?? 0.5, 0.44, 0.5),
            optimizeIterations: Math.max(6, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(82, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(
              (effectiveConfig.qrBitBiasStrength ?? 0.04) + 0.03,
              0,
              0.24
            )
          },
          {
            darkMinOccupancy: clamp2(effectiveConfig.darkMinOccupancy ?? 0.53, 0.51, 0.56),
            lightMaxOccupancy: clamp2(effectiveConfig.lightMaxOccupancy ?? 0.47, 0.44, 0.49),
            optimizeIterations: Math.max(7, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(74, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(
              (effectiveConfig.qrBitBiasStrength ?? 0.04) + 0.06,
              0,
              0.24
            )
          },
          {
            darkMinOccupancy: clamp2(effectiveConfig.darkMinOccupancy ?? 0.55, 0.53, 0.58),
            lightMaxOccupancy: clamp2(effectiveConfig.lightMaxOccupancy ?? 0.45, 0.42, 0.47),
            optimizeIterations: Math.max(8, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(66, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(
              (effectiveConfig.qrBitBiasStrength ?? 0.04) + 0.09,
              0,
              0.24
            )
          },
          {
            darkMinOccupancy: clamp2(effectiveConfig.darkMinOccupancy ?? 0.57, 0.55, 0.6),
            lightMaxOccupancy: clamp2(effectiveConfig.lightMaxOccupancy ?? 0.43, 0.4, 0.45),
            optimizeIterations: Math.max(9, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(58, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(
              (effectiveConfig.qrBitBiasStrength ?? 0.04) + 0.12,
              0,
              0.24
            )
          },
          {
            darkMinOccupancy: clamp2(effectiveConfig.darkMinOccupancy ?? 0.58, 0.56, 0.62),
            lightMaxOccupancy: clamp2(effectiveConfig.lightMaxOccupancy ?? 0.42, 0.38, 0.44),
            optimizeIterations: Math.max(10, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(50, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(
              (effectiveConfig.qrBitBiasStrength ?? 0.04) + 0.16,
              0,
              0.28
            )
          }
        ];
        const attempts = [];
        const seenAttemptSignatures = /* @__PURE__ */ new Set();
        const pushUniqueAttempt = (patch) => {
          const sig = patchSignature(patch);
          if (seenAttemptSignatures.has(sig)) return;
          seenAttemptSignatures.add(sig);
          attempts.push(patch);
        };
        const cachedPatch = getCachedPatch();
        if (cachedPatch) pushUniqueAttempt(cachedPatch);
        if (baseAttempts.length > 0) {
          pushUniqueAttempt(baseAttempts[0]);
          for (const patch of baseAttempts.slice(1)) pushUniqueAttempt(patch);
        }
        const buildAttemptConfig = (patch) => ({
          ...effectiveConfig,
          ...fixedVisualPolicy,
          preserveFunctionalPatterns: effectiveConfig.preserveFunctionalPatterns,
          preserveFinders: patch.preserveFinders !== void 0 ? patch.preserveFinders : effectiveConfig.preserveFinders,
          forceCenterLock: false,
          cleanupSpeckle: false,
          darkMinOccupancy: patch.darkMinOccupancy,
          lightMaxOccupancy: patch.lightMaxOccupancy,
          optimizeIterations: patch.optimizeIterations,
          overlayIntensity: patch.overlayIntensity ?? effectiveConfig.overlayIntensity,
          qrBitBiasStrength: patch.qrBitBiasStrength ?? effectiveConfig.qrBitBiasStrength,
          qrFirstMode: patch.qrFirstMode ?? effectiveConfig.qrFirstMode ?? false
        });
        const buildDecodeRescuePatches = () => {
          const baseDark = clamp2(effectiveConfig.darkMinOccupancy ?? 0.56, 0.5, 0.62);
          const baseLight = clamp2(effectiveConfig.lightMaxOccupancy ?? 0.44, 0.38, 0.5);
          const baseBias = clamp2(effectiveConfig.qrBitBiasStrength ?? 0.04, 0, 0.32);
          const previewRescueIntensities = [54, 46, 38, 30, 24];
          const fullRescueIntensities = [58, 50, 42, 34, 26, 18];
          const intensities = isPreviewScanGate ? previewRescueIntensities : fullRescueIntensities;
          return intensities.map((overlayIntensity, idx) => ({
            darkMinOccupancy: clamp2(baseDark + idx * 0.01, 0.5, 0.64),
            lightMaxOccupancy: clamp2(baseLight - idx * 0.01, 0.36, 0.5),
            optimizeIterations: Math.max(4 + idx, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(overlayIntensity, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(baseBias + 0.1 + idx * 0.03, 0, 0.34)
          }));
        };
        const buildFinderRescuePatches = () => {
          if (effectiveConfig.preserveFinders !== false || isScanGateDisabled) return [];
          const baseDark = clamp2(effectiveConfig.darkMinOccupancy ?? 0.56, 0.52, 0.66);
          const baseLight = clamp2(effectiveConfig.lightMaxOccupancy ?? 0.44, 0.34, 0.48);
          const baseBias = clamp2(effectiveConfig.qrBitBiasStrength ?? 0.04, 0, 0.32);
          const previewRescueIntensities = [50, 42, 34, 26, 18];
          const fullRescueIntensities = [58, 50, 42, 34, 26, 18];
          const intensities = isPreviewScanGate ? previewRescueIntensities : fullRescueIntensities;
          return intensities.map((overlayIntensity, idx) => ({
            preserveFinders: true,
            darkMinOccupancy: clamp2(baseDark + idx * 0.01, 0.52, 0.7),
            lightMaxOccupancy: clamp2(baseLight - idx * 0.01, 0.3, 0.48),
            optimizeIterations: Math.max(6 + idx, effectiveConfig.optimizeIterations ?? 6),
            overlayIntensity: Math.min(overlayIntensity, effectiveConfig.overlayIntensity ?? 100),
            qrBitBiasStrength: clamp2(baseBias + 0.12 + idx * 0.03, 0, 0.36)
          }));
        };
        const computeFinalRasterMetrics = (src) => {
          const ctx2 = src.getContext("2d");
          if (!ctx2) return null;
          const { width, height } = src;
          const imageData = ctx2.getImageData(0, 0, width, height).data;
          const grayAt2 = (x, y) => {
            const xx = Math.max(0, Math.min(width - 1, Math.round(x)));
            const yy = Math.max(0, Math.min(height - 1, Math.round(y)));
            const i = (yy * width + xx) * 4;
            return (0.299 * imageData[i] + 0.587 * imageData[i + 1] + 0.114 * imageData[i + 2]) / 255;
          };
          const quietZoneMin2 = effectiveConfig.quietZoneMinEnforce === false ? 0 : 4;
          const marginModules = Math.max(quietZoneMin2, effectiveConfig.margin);
          const qrPitch = width / Math.max(1, moduleCount + marginModules * 2);
          const qrSpan2 = moduleCount * qrPitch;
          const qrStartX = (width - qrSpan2) / 2;
          const qrStartY = (height - qrSpan2) / 2;
          let boundary = 0;
          let nonBoundary = 0;
          let bc = 0;
          let nc = 0;
          let sum = 0;
          let sumSq = 0;
          let cnt = 0;
          for (let yy = qrStartY + 1; yy < qrStartY + qrSpan2 - 1; yy += Math.max(1, qrPitch / 2)) {
            for (let xx = qrStartX + 1; xx < qrStartX + qrSpan2 - 1; xx += 1) {
              const g = grayAt2(xx, yy);
              sum += g;
              sumSq += g * g;
              cnt++;
              const d = Math.abs(g - grayAt2(xx + 1, yy));
              const rel = (xx - qrStartX + 1) / Math.max(1e-6, qrPitch);
              const frac = Math.abs(rel - Math.round(rel));
              if (frac < 0.08) {
                boundary += d;
                bc++;
              } else {
                nonBoundary += d;
                nc++;
              }
            }
          }
          const mean = sum / Math.max(1, cnt);
          const toneStd = Math.sqrt(Math.max(0, sumSq / Math.max(1, cnt) - mean * mean));
          return {
            edgeImprint: boundary / Math.max(1, bc) - nonBoundary / Math.max(1, nc),
            toneStd
          };
        };
        const toFinalRasterCanvas = async (src) => {
          if (typeof document === "undefined" || typeof HTMLCanvasElement === "undefined" || typeof Image === "undefined" || !(src instanceof HTMLCanvasElement) || typeof src.toDataURL !== "function") {
            return src;
          }
          try {
            const pngDataUrl = src.toDataURL("image/png");
            const image = await new Promise((resolve, reject) => {
              const img = new Image();
              img.onload = () => resolve(img);
              img.onerror = () => reject(new Error("final-raster roundtrip failed"));
              img.src = pngDataUrl;
            });
            const out = document.createElement("canvas");
            out.width = src.width;
            out.height = src.height;
            const outCtx = out.getContext("2d");
            if (!outCtx) return src;
            outCtx.imageSmoothingEnabled = false;
            outCtx.drawImage(image, 0, 0, out.width, out.height);
            return out;
          } catch {
            return src;
          }
        };
        const runDecode = (src) => {
          const decoded = decodeCanvasData(src);
          return decoded?.success === true && decoded?.data === effectiveConfig.content;
        };
        const scenarioSeed = effectiveConfig.seed ?? 1337;
        const seeded01 = (salt) => {
          const n = Math.sin((scenarioSeed + salt) * 12.9898) * 43758.5453;
          return n - Math.floor(n);
        };
        const decodeScenarios = async (canvas2, prevEdgeImprint2) => {
          if (isScanGateDisabled) {
            return { ok: true, baseDecodeOk: true, metrics: null, evaluatedCanvas: canvas2 };
          }
          const finalRaster = isPreviewScanGate ? canvas2 : await toFinalRasterCanvas(canvas2);
          if (!runDecode(finalRaster)) {
            return { ok: false, baseDecodeOk: false, metrics: null, evaluatedCanvas: finalRaster };
          }
          if (skipScanGateEscalation) {
            const baseMetrics2 = isPreviewScanGate ? null : computeFinalRasterMetrics(finalRaster);
            return {
              ok: true,
              baseDecodeOk: true,
              metrics: baseMetrics2,
              evaluatedCanvas: finalRaster
            };
          }
          if (isPreviewScanGate) {
            return { ok: true, baseDecodeOk: true, metrics: null, evaluatedCanvas: finalRaster };
          }
          const baseMetrics = computeFinalRasterMetrics(finalRaster);
          if (baseMetrics) {
            if (baseMetrics.edgeImprint > edgeImprintThreshold || baseMetrics.toneStd < toneStdThreshold) {
              return {
                ok: false,
                baseDecodeOk: true,
                metrics: baseMetrics,
                evaluatedCanvas: finalRaster
              };
            }
            if (prevEdgeImprint2 !== null && baseMetrics.edgeImprint > prevEdgeImprint2 + edgeWorsenLimit) {
              return {
                ok: false,
                baseDecodeOk: true,
                metrics: baseMetrics,
                evaluatedCanvas: finalRaster
              };
            }
          }
          const scenarios = [
            {
              blur: 0.8 + seeded01(11) * 0.4,
              exposure: -0.24 + seeded01(13) * 0.08,
              skewX: finalRaster.width * 0.02,
              skewY: finalRaster.height * 0.012,
              downscale: 0.9
            },
            {
              blur: 1 + seeded01(17) * 0.5,
              exposure: 0.18 + seeded01(19) * 0.12,
              skewX: finalRaster.width * 0.028,
              skewY: finalRaster.height * 0.018,
              downscale: 0.82
            }
          ];
          for (const s of scenarios) {
            const sim = await this.createCanvas(finalRaster.width, finalRaster.height);
            const simCtx = sim.getContext("2d");
            if (!simCtx)
              return {
                ok: false,
                baseDecodeOk: true,
                metrics: baseMetrics,
                evaluatedCanvas: finalRaster
              };
            const dsW = Math.max(1, Math.round(finalRaster.width * s.downscale));
            const dsH = Math.max(1, Math.round(finalRaster.height * s.downscale));
            const ds = await this.createCanvas(dsW, dsH);
            const dsCtx = ds.getContext("2d");
            if (!dsCtx)
              return {
                ok: false,
                baseDecodeOk: true,
                metrics: baseMetrics,
                evaluatedCanvas: finalRaster
              };
            dsCtx.imageSmoothingEnabled = true;
            dsCtx.drawImage(finalRaster, 0, 0, dsW, dsH);
            if ("filter" in simCtx) {
              simCtx.filter = `blur(${s.blur}px)`;
            }
            simCtx.setTransform(1, -s.skewY / sim.height, s.skewX / sim.width, 1, 0, 0);
            simCtx.drawImage(
              ds,
              0,
              0,
              dsW,
              dsH,
              0,
              0,
              Math.max(1, sim.width - Math.abs(s.skewX)),
              Math.max(1, sim.height - Math.abs(s.skewY))
            );
            simCtx.setTransform(1, 0, 0, 1, 0, 0);
            if ("filter" in simCtx) {
              simCtx.filter = "none";
            }
            if (s.exposure !== 0) {
              simCtx.globalCompositeOperation = "source-atop";
              if (s.exposure > 0) {
                simCtx.fillStyle = `rgba(255,255,255,${Math.min(0.35, s.exposure)})`;
              } else {
                simCtx.fillStyle = `rgba(0,0,0,${Math.min(0.35, Math.abs(s.exposure))})`;
              }
              simCtx.fillRect(0, 0, sim.width, sim.height);
              simCtx.globalCompositeOperation = "source-over";
            }
            if (!runDecode(sim)) {
              return {
                ok: false,
                baseDecodeOk: true,
                metrics: baseMetrics,
                evaluatedCanvas: finalRaster
              };
            }
          }
          return {
            ok: true,
            baseDecodeOk: true,
            metrics: baseMetrics,
            evaluatedCanvas: finalRaster
          };
        };
        let lastCanvas = null;
        let bestBaseDecodable = null;
        let bestBaseDecodablePatch = null;
        let prevEdgeImprint = null;
        for (const patch of attempts) {
          const attemptCanvas = await renderScaled(buildAttemptConfig(patch));
          try {
            const evaluated = await decodeScenarios(attemptCanvas, prevEdgeImprint);
            lastCanvas = evaluated.evaluatedCanvas;
            if (evaluated.baseDecodeOk && !bestBaseDecodable) {
              bestBaseDecodable = evaluated.evaluatedCanvas;
              bestBaseDecodablePatch = patch;
            }
            if (evaluated.metrics && (prevEdgeImprint === null || evaluated.metrics.edgeImprint < prevEdgeImprint)) {
              prevEdgeImprint = evaluated.metrics.edgeImprint;
            }
            if (evaluated.ok) {
              rememberPatch(patch);
              return evaluated.evaluatedCanvas;
            }
            if (skipScanGateEscalation) {
              if (evaluated.baseDecodeOk) {
                rememberPatch(patch);
                return evaluated.evaluatedCanvas;
              }
            }
          } catch {
            lastCanvas = attemptCanvas;
            if (skipScanGateEscalation) {
            }
          }
        }
        if (bestBaseDecodable) {
          if (bestBaseDecodablePatch) rememberPatch(bestBaseDecodablePatch);
          return bestBaseDecodable;
        }
        const lastPatch = attempts[attempts.length - 1] || {};
        if (skipScanGateEscalation) {
          const finderRescuePatches = buildFinderRescuePatches();
          for (const patch of finderRescuePatches) {
            const rescueCanvas = await renderScaled(buildAttemptConfig(patch));
            const rescueRaster = isPreviewScanGate ? rescueCanvas : await toFinalRasterCanvas(rescueCanvas);
            if (runDecode(rescueRaster)) {
              rememberPatch(patch);
              return rescueRaster;
            }
            lastCanvas = rescueRaster;
          }
          const fallback = lastCanvas || await renderScaled(buildAttemptConfig(lastPatch));
          if (Object.keys(lastPatch).length > 0) rememberPatch(lastPatch);
          return fallback;
        }
        const rescuePatches = [...buildDecodeRescuePatches(), ...buildFinderRescuePatches()];
        for (const patch of rescuePatches) {
          const rescueCanvas = await renderScaled(buildAttemptConfig(patch));
          const rescueRaster = isPreviewScanGate ? rescueCanvas : await toFinalRasterCanvas(rescueCanvas);
          if (runDecode(rescueRaster)) {
            rememberPatch(patch);
            return rescueRaster;
          }
          lastCanvas = rescueRaster;
        }
        const requireDecodableResult = !isScanGateDisabled;
        if (!requireDecodableResult && effectiveConfig.qrFirstMode !== true) {
          return lastCanvas || await renderScaled(buildAttemptConfig(lastPatch));
        }
        let qrFirstLast = null;
        const qrFirstIntensities = isPreviewScanGate ? [62, 54, 46, 38, 30, 22] : [70, 62, 54, 46, 38, 30, 22];
        for (const intensity of qrFirstIntensities) {
          const qrFirstFallback = await renderScaled({
            ...buildAttemptConfig(lastPatch),
            qrFirstMode: true,
            overlayIntensity: Math.min(intensity, effectiveConfig.overlayIntensity ?? 100)
          });
          const fallbackRaster = isPreviewScanGate ? qrFirstFallback : await toFinalRasterCanvas(qrFirstFallback);
          qrFirstLast = fallbackRaster;
          if (runDecode(fallbackRaster)) {
            if (effectiveConfig.qrFirstMode === true) {
              rememberPatch({
                ...lastPatch,
                qrFirstMode: true,
                overlayIntensity: Math.min(intensity, effectiveConfig.overlayIntensity ?? 100)
              });
            }
            return fallbackRaster;
          }
        }
        return qrFirstLast ?? (lastCanvas || await renderScaled(buildAttemptConfig(lastPatch)));
      }
      return await renderScaled(effectiveConfig);
    }
    let ditherPattern = null;
    let overlayData = null;
    let effectiveIntensity = 0;
    if (effectiveConfig.overlayMode !== "center") {
      const overlayResult = await prepareUnifiedOverlayData(
        qr,
        effectiveConfig,
        processedOverlayCanvas,
        moduleCount,
        this.createCanvas.bind(this)
      );
      ditherPattern = overlayResult.ditherPattern;
      overlayData = overlayResult.overlayData;
      effectiveIntensity = overlayResult.effectiveIntensity;
    }
    const moduleSize = config.moduleSize;
    const quietZoneMin = config.quietZoneMinEnforce === false ? 0 : 4;
    const margin = Math.max(config.margin, quietZoneMin);
    const frameExtra = config.frameStyle && config.frameStyle !== "none" ? moduleSize * 4 : 0;
    const size = moduleCount * moduleSize + margin * 2 * moduleSize + frameExtra;
    const canvas = await this.createCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    const effectiveBgColor = validateColor(config.bgColor, "#ffffff");
    if (!config.transparentBg) {
      ctx.fillStyle = effectiveBgColor;
      ctx.fillRect(0, 0, size, size);
    }
    drawFrameBackground(ctx, size, moduleSize, margin, config);
    const version = config.typeNumber || Math.ceil((moduleCount - 17) / 4);
    const gradientFill = createGradientFill(ctx, config, size);
    const useGradient = config.gradient && config.gradient.type !== "none";
    const { drawnFinderPatterns, drawnAlignmentPatterns } = this.drawStructuralPatterns(
      ctx,
      config,
      moduleCount,
      moduleSize,
      margin,
      overlayData,
      version
    );
    renderModules(
      ctx,
      qr,
      effectiveConfig,
      // Use effectiveConfig with corrected overlayMode
      moduleCount,
      moduleSize,
      margin,
      overlayData,
      ditherPattern,
      effectiveIntensity,
      drawnFinderPatterns,
      drawnAlignmentPatterns,
      version,
      gradientFill,
      useGradient ?? false
    );
    const qrStart = margin * moduleSize;
    const qrSpan = moduleCount * moduleSize;
    const qrEnd = qrStart + qrSpan;
    if (config.transparentBg) {
      ctx.clearRect(0, 0, size, qrStart);
      ctx.clearRect(0, qrStart, qrStart, qrSpan);
      ctx.clearRect(qrEnd, qrStart, Math.max(0, size - qrEnd), qrSpan);
      ctx.clearRect(0, qrEnd, size, Math.max(0, size - qrEnd));
    } else {
      ctx.fillStyle = effectiveBgColor;
      ctx.fillRect(0, 0, size, qrStart);
      ctx.fillRect(0, qrStart, qrStart, qrSpan);
      ctx.fillRect(qrEnd, qrStart, Math.max(0, size - qrEnd), qrSpan);
      ctx.fillRect(0, qrEnd, size, Math.max(0, size - qrEnd));
    }
    if (processedOverlayCanvas && config.overlayMode === "center") {
      log14.debug("Drawing center logo", {
        canvasSize: size,
        logoSize: config.logoSize,
        overlayWidth: processedOverlayCanvas.width,
        overlayHeight: processedOverlayCanvas.height,
        colorMode: config.colorMode
      });
      drawCenterLogo(ctx, processedOverlayCanvas, size, config.logoSize);
    }
    drawFrame(ctx, size, moduleSize, margin, config);
    this.storeMatrix(qr, moduleCount);
    return canvas;
  }
  /**
   * Render a pre-computed boolean matrix with full styling.
   * Used by QR-Art to render matrices that were modified via RS basis manipulation.
   *
   * This method bypasses the encoding stage and directly renders the provided matrix
   * using the same styling pipeline as generate() (structural patterns, module styles,
   * gradients, frames, etc.).
   *
   * @param matrix - Pre-computed boolean matrix (true = dark module)
   * @param config - Rendering configuration (same as generate())
   * @returns Rendered canvas with proper styling
   */
  async renderFromMatrix(matrix, config) {
    const moduleCount = matrix.length;
    if (moduleCount === 0) {
      throw new Error("Empty matrix provided to renderFromMatrix");
    }
    const qr = new MatrixWrapper(matrix);
    const version = Math.ceil((moduleCount - 17) / 4);
    const rawMatrixRender = config.rawMatrixRender === true;
    const effectiveConfig = rawMatrixRender ? {
      ...config,
      typeNumber: version,
      overlayMode: void 0,
      moduleStyle: "square",
      moduleGap: 0,
      gapMode: "none",
      cornerRadius: 0,
      finderStyle: "square",
      eyeOuterStyle: "square",
      eyeInnerStyle: "square",
      alignmentStyle: "square",
      timingStyle: "square",
      preserveFinders: true,
      preserveTiming: true,
      preserveAlignment: true,
      gradient: { type: "none" },
      frameStyle: "none",
      frameText: void 0,
      frameColor: void 0,
      frameTextColor: void 0,
      fgColor: "#000000",
      bgColor: "#ffffff",
      transparentBg: false
    } : {
      ...config,
      typeNumber: version,
      // Disable overlay processing - the matrix already represents the final QR
      overlayMode: void 0
    };
    const moduleSize = config.moduleSize || 10;
    const quietZoneMin = config.quietZoneMinEnforce === false ? 0 : 4;
    const margin = Math.max(config.margin || 4, quietZoneMin);
    const frameExtra = config.frameStyle && config.frameStyle !== "none" ? moduleSize * 4 : 0;
    const size = moduleCount * moduleSize + margin * 2 * moduleSize + frameExtra;
    const canvas = await this.createCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    const effectiveBgColor = validateColor(config.bgColor, "#ffffff");
    if (!config.transparentBg) {
      ctx.fillStyle = effectiveBgColor;
      ctx.fillRect(0, 0, size, size);
    }
    drawFrameBackground(ctx, size, moduleSize, margin, effectiveConfig);
    const gradientFill = createGradientFill(ctx, effectiveConfig, size);
    const useGradient = config.gradient && config.gradient.type !== "none";
    const { drawnFinderPatterns, drawnAlignmentPatterns } = this.drawStructuralPatterns(
      ctx,
      effectiveConfig,
      moduleCount,
      moduleSize,
      margin,
      null,
      // No overlay data
      version
    );
    renderModules(
      ctx,
      qr,
      effectiveConfig,
      moduleCount,
      moduleSize,
      margin,
      null,
      // No overlay data
      null,
      // No dither pattern - use qr.isDark() which reads from our matrix
      0,
      // No effective intensity
      drawnFinderPatterns,
      drawnAlignmentPatterns,
      version,
      gradientFill,
      useGradient ?? false
    );
    drawFrame(ctx, size, moduleSize, margin, effectiveConfig);
    this.storeMatrixDirect(matrix, moduleCount);
    log14.debug("renderFromMatrix complete", {
      moduleCount,
      version,
      canvasSize: size,
      moduleSize,
      margin
    });
    return canvas;
  }
};

// src/modules/qr-generator/index.ts
var _log92 = createLogger("GENERATE");

// netlify/functions/qr.ts
Sentry2.init({
  dsn: "https://6935e811c47169e037e31209f2d46fbd@o4510808522489856.ingest.us.sentry.io/4510808547917824",
  sendDefaultPii: true,
  release: `anqr@${package_default.version}`,
  tracesSampleRate: 0.1,
  // 10% of transactions for performance monitoring
  environment: "production"
});
var MAX_SERVER_IMAGE_SIZE = 2048;
var MAX_DATA_LENGTH = 4096;
var MAX_OVERLAY_BYTES = 5 * 1024 * 1024;
var MAX_OVERLAY_PIXELS = 10 * 1024 * 1024;
var MAX_GIF_FRAMES = 60;
var MAX_GIF_DURATION_MS = 1e4;
var FETCH_TIMEOUT_MS = 1e4;
var DEFAULT_SERVER_DITHER = "ordered_bayer";
var DEFAULT_OUTPUT_FORMAT = "gif";
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};
function isPrivateOrReservedIP(ip) {
  if (ip === "localhost" || ip === "127.0.0.1" || ip === "::1") {
    return true;
  }
  const ipv4Match = ip.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (ipv4Match) {
    const [, a, b, c, _d] = ipv4Match.map(Number);
    if (a === 10) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 169 && b === 254) return true;
    if (a === 127) return true;
    if (a === 0) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    if (a === 192 && b === 0 && c === 0) return true;
    if (a === 192 && b === 0 && c === 2) return true;
    if (a === 198 && b === 51 && c === 100) return true;
    if (a === 203 && b === 0 && c === 113) return true;
    if (a >= 224 && a <= 239) return true;
    if (a >= 240) return true;
  }
  if (ip.startsWith("fe80:") || // link-local
  ip.startsWith("fc") || ip.startsWith("fd") || // unique local
  ip === "::1" || ip.startsWith("::ffff:")) {
    return true;
  }
  return false;
}
async function _isPrivateHostname(hostname) {
  if (isPrivateOrReservedIP(hostname)) {
    return true;
  }
  const lowerHost = hostname.toLowerCase();
  if (lowerHost.endsWith(".local") || lowerHost.endsWith(".localhost") || lowerHost.endsWith(".internal") || lowerHost.includes("127.0.0.1") || lowerHost.includes("0.0.0.0")) {
    return true;
  }
  return false;
}
var nodeCanvasFactory = {
  createCanvas: async (width, height) => {
    return createCanvas(width, height);
  },
  loadImage: async (src) => {
    return loadImage(src);
  }
};
function createTextWatermark(text, fontSize = 14, fontFamily = "sans-serif", color = "#000000") {
  const measureCanvas = createCanvas(1, 1);
  const measureCtx = measureCanvas.getContext("2d");
  measureCtx.font = `${fontSize}px ${fontFamily}`;
  const metrics = measureCtx.measureText(text);
  const textHeight = fontSize * 1.2;
  const canvas = createCanvas(Math.ceil(metrics.width) + 10, Math.ceil(textHeight) + 10);
  const ctx = canvas.getContext("2d");
  ctx.font = `${fontSize}px ${fontFamily}`;
  ctx.fillStyle = color;
  ctx.textBaseline = "middle";
  ctx.fillText(text, 5, canvas.height / 2);
  return canvas;
}
function getWatermarkPositions(position, canvasWidth, canvasHeight, watermarkWidth, watermarkHeight, margin = 10) {
  const positions = [];
  switch (position) {
    case "center":
      positions.push({
        x: (canvasWidth - watermarkWidth) / 2,
        y: (canvasHeight - watermarkHeight) / 2
      });
      break;
    case "corners":
      positions.push(
        { x: margin, y: margin },
        { x: canvasWidth - watermarkWidth - margin, y: margin },
        { x: margin, y: canvasHeight - watermarkHeight - margin },
        { x: canvasWidth - watermarkWidth - margin, y: canvasHeight - watermarkHeight - margin }
      );
      break;
    case "edges":
      positions.push(
        { x: (canvasWidth - watermarkWidth) / 2, y: margin },
        { x: (canvasWidth - watermarkWidth) / 2, y: canvasHeight - watermarkHeight - margin },
        { x: margin, y: (canvasHeight - watermarkHeight) / 2 },
        { x: canvasWidth - watermarkWidth - margin, y: (canvasHeight - watermarkHeight) / 2 }
      );
      break;
    case "quiet_zone":
      positions.push({ x: margin / 2, y: canvasHeight - watermarkHeight - margin / 2 });
      break;
  }
  return positions;
}
function applyBlendMode(ctx, blend) {
  switch (blend) {
    case "multiply":
      ctx.globalCompositeOperation = "multiply";
      break;
    case "screen":
      ctx.globalCompositeOperation = "screen";
      break;
    case "overlay":
      ctx.globalCompositeOperation = "overlay";
      break;
    default:
      ctx.globalCompositeOperation = "source-over";
      break;
  }
}
function applyWatermarkServer(source, options) {
  if (!options.enabled || options.kind === "text" && !options.text) {
    return source;
  }
  const result = createCanvas(source.width, source.height);
  const ctx = result.getContext("2d");
  if (options.position === "behind") {
    drawWatermarkLayerServer(ctx, options, source.width, source.height);
    ctx.drawImage(source, 0, 0);
  } else {
    ctx.drawImage(source, 0, 0);
    drawWatermarkLayerServer(ctx, options, source.width, source.height);
  }
  return result;
}
function drawWatermarkLayerServer(ctx, options, canvasWidth, canvasHeight) {
  let watermarkCanvas = null;
  if (options.kind === "text" && options.text) {
    watermarkCanvas = createTextWatermark(options.text, 14, "sans-serif", "#000000");
  } else if ((options.kind === "image" || options.kind === "pattern") && options.imageCanvas) {
    watermarkCanvas = options.imageCanvas;
  }
  if (!watermarkCanvas) return;
  ctx.save();
  applyBlendMode(ctx, options.blend);
  ctx.globalAlpha = options.opacity / 100;
  const positions = getWatermarkPositions(
    options.position,
    canvasWidth,
    canvasHeight,
    watermarkCanvas.width,
    watermarkCanvas.height,
    10
  );
  for (const pos of positions) {
    ctx.drawImage(watermarkCanvas, pos.x, pos.y);
  }
  ctx.restore();
}
function calculateCrc32(data) {
  let crc = 4294967295;
  const table = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    table[n] = c;
  }
  for (const byte of data) {
    crc = table[(crc ^ byte) & 255] ^ crc >>> 8;
  }
  return (crc ^ 4294967295) >>> 0;
}
function createPngTextChunk(keyword, text) {
  const keywordBytes = new TextEncoder().encode(keyword);
  const textBytes = new TextEncoder().encode(text);
  const chunkData = new Uint8Array(keywordBytes.length + 1 + textBytes.length);
  chunkData.set(keywordBytes, 0);
  chunkData.set([0], keywordBytes.length);
  chunkData.set(textBytes, keywordBytes.length + 1);
  const chunkType = new TextEncoder().encode("tEXt");
  const chunk = new Uint8Array(4 + 4 + chunkData.length + 4);
  const dataView = new DataView(chunk.buffer);
  dataView.setUint32(0, chunkData.length, false);
  chunk.set(chunkType, 4);
  chunk.set(chunkData, 8);
  const crcData = new Uint8Array(4 + chunkData.length);
  crcData.set(chunkType, 0);
  crcData.set(chunkData, 4);
  const crc = calculateCrc32(crcData);
  dataView.setUint32(8 + chunkData.length, crc, false);
  return chunk;
}
function createPngPhysChunk(dpi) {
  const pixelsPerMeter = Math.round(dpi / 0.0254);
  const chunkData = new Uint8Array(9);
  const chunkDataView = new DataView(chunkData.buffer);
  chunkDataView.setUint32(0, pixelsPerMeter, false);
  chunkDataView.setUint32(4, pixelsPerMeter, false);
  chunkData[8] = 1;
  const chunkType = new TextEncoder().encode("pHYs");
  const chunk = new Uint8Array(4 + 4 + 9 + 4);
  const chunkView = new DataView(chunk.buffer);
  chunkView.setUint32(0, 9, false);
  chunk.set(chunkType, 4);
  chunk.set(chunkData, 8);
  const crcData = new Uint8Array(4 + 9);
  crcData.set(chunkType, 0);
  crcData.set(chunkData, 4);
  const crc = calculateCrc32(crcData);
  chunkView.setUint32(17, crc, false);
  return chunk;
}
function embedPngMetadataAndDpi(pngBuffer, metadata, dpi) {
  const data = new Uint8Array(pngBuffer);
  const pngSignature = [137, 80, 78, 71, 13, 10, 26, 10];
  for (let i = 0; i < 8; i++) {
    if (data[i] !== pngSignature[i]) {
      return pngBuffer;
    }
  }
  const chunks = [];
  if (dpi && dpi > 0 && dpi !== 72) {
    chunks.push(createPngPhysChunk(dpi));
  }
  if (metadata) {
    const keywordMap = {
      title: "Title",
      author: "Author",
      description: "Description",
      copyright: "Copyright",
      creationTime: "Creation Time",
      software: "Software"
    };
    for (const [key, value] of Object.entries(metadata)) {
      if (value && typeof value === "string") {
        const keyword = keywordMap[key] || key;
        chunks.push(createPngTextChunk(keyword, value));
      }
    }
  }
  if (chunks.length === 0) {
    return pngBuffer;
  }
  const ihdrEnd = 33;
  const totalChunksSize = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
  const newPng = new Uint8Array(data.length + totalChunksSize);
  newPng.set(data.slice(0, ihdrEnd), 0);
  let offset = ihdrEnd;
  for (const chunk of chunks) {
    newPng.set(chunk, offset);
    offset += chunk.length;
  }
  newPng.set(data.slice(ihdrEnd), offset);
  return Buffer.from(newPng);
}
function encodeGif(canvas, colors = 256, disposal = 2) {
  if (!isGifEncodingAvailable()) {
    throw new Error("GIF encoder is unavailable in this runtime");
  }
  const width = canvas.width;
  const height = canvas.height;
  const ctx = canvas.getContext("2d");
  const imageData = ctx.getImageData(0, 0, width, height);
  const { data } = imageData;
  const gif = createGifEncoder();
  const palette = quantizeGifPalette(data, Math.min(256, Math.max(2, colors)));
  const index = indexGifPixels(data, palette);
  gif.writeFrame(index, width, height, {
    palette,
    delay: 100,
    repeat: 0,
    disposal
  });
  gif.finish();
  return Buffer.from(gif.bytes());
}
function encodeAnimatedGif(frames, frameDelayMs = 100, colors = 256, disposal = 1) {
  if (!isGifEncodingAvailable()) {
    throw new Error("GIF encoder is unavailable in this runtime");
  }
  if (frames.length === 0) {
    throw new Error("No frames to encode");
  }
  const width = frames[0].width;
  const height = frames[0].height;
  const gif = createGifEncoder();
  const paletteSize = Math.min(256, Math.max(2, colors));
  const delayMs = Math.max(20, frameDelayMs);
  for (let i = 0; i < frames.length; i++) {
    const frame = frames[i];
    const ctx = frame.getContext("2d");
    const imageData = ctx.getImageData(0, 0, width, height);
    const { data } = imageData;
    const palette = quantizeGifPalette(data, paletteSize);
    const index = indexGifPixels(data, palette);
    const frameOptions = {
      palette,
      delay: delayMs,
      disposal
    };
    if (i === 0) {
      frameOptions.repeat = 0;
    }
    gif.writeFrame(index, width, height, frameOptions);
  }
  gif.finish();
  return Buffer.from(gif.bytes());
}
function generatePatternFramesServer(sourceCanvas, pattern, frameCount = 24, seed = 0, easing = "linear") {
  if (pattern === "none") {
    return [sourceCanvas];
  }
  const frames = [];
  const width = sourceCanvas.width;
  const height = sourceCanvas.height;
  const sourceCtx = sourceCanvas.getContext("2d");
  const sourceData = sourceCtx.getImageData(0, 0, width, height);
  for (let i = 0; i < frameCount; i++) {
    const linearProgress = i / frameCount;
    const progress = applyAnimationEasing(linearProgress, easing);
    const frame = createCanvas(width, height);
    const ctx = frame.getContext("2d");
    const frameData = ctx.createImageData(width, height);
    frameData.data.set(sourceData.data);
    switch (pattern) {
      case "pulse":
        applyAnimationPulse(frameData.data, progress, seed);
        break;
      case "wave":
        applyAnimationWave(frameData.data, progress, width, height, seed);
        break;
      case "scanline":
        applyAnimationScanline(frameData.data, progress, width, height, seed);
        break;
      case "shimmer":
        applyAnimationShimmer(frameData.data, progress, width, height, seed);
        break;
      case "drift":
        applyAnimationDrift(frameData.data, progress, width, height, seed);
        break;
      case "color_cycle":
        applyAnimationColorCycle(frameData.data, progress, seed);
        break;
    }
    ctx.putImageData(frameData, 0, 0);
    frames.push(frame);
  }
  return frames;
}
function cropOverlayServer(source, centerX, centerY, sizeFraction) {
  const minDim = Math.min(source.width, source.height);
  const cropSize = Math.round(minDim * Math.max(0.1, Math.min(1, sizeFraction)));
  let cropX = Math.round(source.width * centerX - cropSize / 2);
  let cropY = Math.round(source.height * centerY - cropSize / 2);
  cropX = Math.max(0, Math.min(source.width - cropSize, cropX));
  cropY = Math.max(0, Math.min(source.height - cropSize, cropY));
  const result = createCanvas(cropSize, cropSize);
  const ctx = result.getContext("2d");
  ctx.drawImage(source, cropX, cropY, cropSize, cropSize, 0, 0, cropSize, cropSize);
  return result;
}
function rgbToGrayServer(r, g, b) {
  return 0.299 * r + 0.587 * g + 0.114 * b;
}
function convolveServer(data, width, height, kernel, divisor) {
  const result = new Uint8ClampedArray(data);
  const kSize = kernel.length;
  const kHalf = Math.floor(kSize / 2);
  const div = divisor ?? (kernel.flat().reduce((a, b) => a + b, 0) || 1);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let r = 0, g = 0, b = 0;
      for (let ky = 0; ky < kSize; ky++) {
        for (let kx = 0; kx < kSize; kx++) {
          const px = Math.max(0, Math.min(width - 1, x + kx - kHalf));
          const py = Math.max(0, Math.min(height - 1, y + ky - kHalf));
          const idx2 = (py * width + px) * 4;
          const weight = kernel[ky][kx];
          r += data[idx2] * weight;
          g += data[idx2 + 1] * weight;
          b += data[idx2 + 2] * weight;
        }
      }
      const idx = (y * width + x) * 4;
      result[idx] = Math.max(0, Math.min(255, Math.round(r / div)));
      result[idx + 1] = Math.max(0, Math.min(255, Math.round(g / div)));
      result[idx + 2] = Math.max(0, Math.min(255, Math.round(b / div)));
    }
  }
  return result;
}
function blurServer(data, width, height, radius) {
  if (radius <= 0) return data;
  const size = 2 * Math.min(radius, 10) + 1;
  const kernel = Array(size).fill(null).map(() => Array(size).fill(1));
  return convolveServer(data, width, height, kernel);
}
function sharpenServer(data, width, height, amount) {
  if (amount <= 0) return data;
  const strength = amount / 100;
  const kernel = [
    [0, -strength, 0],
    [-strength, 1 + 4 * strength, -strength],
    [0, -strength, 0]
  ];
  return convolveServer(data, width, height, kernel, 1);
}
function posterizeServer(data, levels) {
  if (levels <= 1) return data;
  const result = new Uint8ClampedArray(data);
  const step = 255 / (levels - 1);
  for (let i = 0; i < result.length; i += 4) {
    result[i] = Math.round(Math.round(result[i] / step) * step);
    result[i + 1] = Math.round(Math.round(result[i + 1] / step) * step);
    result[i + 2] = Math.round(Math.round(result[i + 2] / step) * step);
  }
  return result;
}
function thresholdServer(data, level) {
  const result = new Uint8ClampedArray(data);
  for (let i = 0; i < result.length; i += 4) {
    const gray = rgbToGrayServer(result[i], result[i + 1], result[i + 2]);
    const value = gray > level ? 255 : 0;
    result[i] = value;
    result[i + 1] = value;
    result[i + 2] = value;
  }
  return result;
}
function sobelEdgeServer(data, width, height) {
  const result = new Uint8ClampedArray(data.length);
  const sobelX = [
    [-1, 0, 1],
    [-2, 0, 2],
    [-1, 0, 1]
  ];
  const sobelY = [
    [-1, -2, -1],
    [0, 0, 0],
    [1, 2, 1]
  ];
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      let gx = 0, gy = 0;
      for (let ky = -1; ky <= 1; ky++) {
        for (let kx = -1; kx <= 1; kx++) {
          const idx2 = ((y + ky) * width + (x + kx)) * 4;
          const gray = rgbToGrayServer(data[idx2], data[idx2 + 1], data[idx2 + 2]);
          gx += gray * sobelX[ky + 1][kx + 1];
          gy += gray * sobelY[ky + 1][kx + 1];
        }
      }
      const magnitude = Math.min(255, Math.sqrt(gx * gx + gy * gy));
      const idx = (y * width + x) * 4;
      result[idx] = magnitude;
      result[idx + 1] = magnitude;
      result[idx + 2] = magnitude;
      result[idx + 3] = data[idx + 3];
    }
  }
  return result;
}
function cannyEdgeServer(data, width, height, lowThreshold = 50, highThreshold = 150) {
  const sobelResult = sobelEdgeServer(data, width, height);
  const result = new Uint8ClampedArray(sobelResult);
  for (let i = 0; i < result.length; i += 4) {
    const magnitude = result[i];
    const value = magnitude > highThreshold ? 255 : magnitude > lowThreshold ? 128 : 0;
    result[i] = value;
    result[i + 1] = value;
    result[i + 2] = value;
  }
  return result;
}
function applyOverlayFiltersServer(source, options) {
  const result = createCanvas(source.width, source.height);
  const resultCtx = result.getContext("2d");
  resultCtx.drawImage(source, 0, 0);
  const imageData = resultCtx.getImageData(0, 0, result.width, result.height);
  const data = imageData.data;
  const brightness2 = (options.brightness ?? 0) / 100;
  const contrast2 = (options.contrast ?? 0) / 100;
  const gamma2 = options.gamma ?? 1;
  const saturation2 = (options.saturation ?? 0) / 100;
  const hue = (options.hue ?? 0) * (Math.PI / 180);
  const invert2 = options.invert ?? false;
  const blurRadius = options.blur ?? 0;
  const sharpenAmount = options.sharpen ?? 0;
  const posterizeLevels = options.posterize ?? 0;
  const thresholdLevel = options.threshold;
  const edgeMode = options.edge ?? "off";
  const contrastFactor = (1 + contrast2) / (1 - contrast2 * 0.5);
  for (let i = 0; i < data.length; i += 4) {
    let r = data[i] / 255;
    let g = data[i + 1] / 255;
    let b = data[i + 2] / 255;
    if (invert2) {
      r = 1 - r;
      g = 1 - g;
      b = 1 - b;
    }
    r += brightness2;
    g += brightness2;
    b += brightness2;
    r = (r - 0.5) * contrastFactor + 0.5;
    g = (g - 0.5) * contrastFactor + 0.5;
    b = (b - 0.5) * contrastFactor + 0.5;
    if (gamma2 !== 1) {
      r = Math.max(0, r) ** (1 / gamma2);
      g = Math.max(0, g) ** (1 / gamma2);
      b = Math.max(0, b) ** (1 / gamma2);
    }
    if (saturation2 !== 0 || hue !== 0) {
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      let h = 0;
      let s = 0;
      const l = (max + min) / 2;
      if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r:
            h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
            break;
          case g:
            h = ((b - r) / d + 2) / 6;
            break;
          case b:
            h = ((r - g) / d + 4) / 6;
            break;
        }
      }
      h += hue / (2 * Math.PI);
      if (h > 1) h -= 1;
      if (h < 0) h += 1;
      s = Math.max(0, Math.min(1, s * (1 + saturation2)));
      if (s === 0) {
        r = g = b = l;
      } else {
        const hue2rgb = (p2, q2, t) => {
          if (t < 0) t += 1;
          if (t > 1) t -= 1;
          if (t < 1 / 6) return p2 + (q2 - p2) * 6 * t;
          if (t < 1 / 2) return q2;
          if (t < 2 / 3) return p2 + (q2 - p2) * (2 / 3 - t) * 6;
          return p2;
        };
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r = hue2rgb(p, q, h + 1 / 3);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1 / 3);
      }
    }
    data[i] = Math.round(Math.max(0, Math.min(1, r)) * 255);
    data[i + 1] = Math.round(Math.max(0, Math.min(1, g)) * 255);
    data[i + 2] = Math.round(Math.max(0, Math.min(1, b)) * 255);
  }
  if (blurRadius > 0) {
    const blurred = blurServer(data, result.width, result.height, blurRadius);
    data.set(blurred);
  }
  if (sharpenAmount > 0) {
    const sharpened = sharpenServer(data, result.width, result.height, sharpenAmount);
    data.set(sharpened);
  }
  if (posterizeLevels > 1) {
    const posterized = posterizeServer(data, posterizeLevels);
    data.set(posterized);
  }
  if (thresholdLevel !== void 0) {
    const thresholded = thresholdServer(data, thresholdLevel);
    data.set(thresholded);
  }
  if (edgeMode === "sobel") {
    const edges = sobelEdgeServer(data, result.width, result.height);
    data.set(edges);
  } else if (edgeMode === "canny") {
    const edges = cannyEdgeServer(data, result.width, result.height);
    data.set(edges);
  }
  resultCtx.putImageData(imageData, 0, 0);
  return result;
}
function flipOverlayServer(source, horizontal, vertical) {
  if (!(horizontal || vertical)) return source;
  const result = createCanvas(source.width, source.height);
  const ctx = result.getContext("2d");
  ctx.translate(horizontal ? source.width : 0, vertical ? source.height : 0);
  ctx.scale(horizontal ? -1 : 1, vertical ? -1 : 1);
  ctx.drawImage(source, 0, 0);
  return result;
}
function rotateOverlayServer(source, degrees) {
  if (degrees === 0) return source;
  const radians = degrees * Math.PI / 180;
  const sin = Math.abs(Math.sin(radians));
  const cos = Math.abs(Math.cos(radians));
  const newWidth = Math.round(source.width * cos + source.height * sin);
  const newHeight = Math.round(source.width * sin + source.height * cos);
  const result = createCanvas(newWidth, newHeight);
  const ctx = result.getContext("2d");
  ctx.translate(newWidth / 2, newHeight / 2);
  ctx.rotate(radians);
  ctx.drawImage(source, -source.width / 2, -source.height / 2);
  return result;
}
function isGifBuffer(buffer) {
  return isGifSignature(buffer);
}
function parseGifFramesServer(arrayBuffer, disposalHandling = "respect") {
  const decoded = decodeGif(arrayBuffer);
  if (decoded.frames.length === 0) {
    throw new Error("No frames found in GIF");
  }
  const framesToProcess = decoded.frames.slice(0, MAX_GIF_FRAMES);
  if (decoded.frames.length > MAX_GIF_FRAMES) {
  }
  const totalDuration = framesToProcess.reduce((sum, f) => sum + f.delay, 0);
  if (totalDuration > MAX_GIF_DURATION_MS) {
  }
  const { width, height } = decoded;
  const compositeCanvas = createCanvas(width, height);
  const compositeCtx = compositeCanvas.getContext("2d");
  const animationFrames = [];
  for (const frame of framesToProcess) {
    const { dims, patch, disposalType, delay } = frame;
    const effectiveDisposal = disposalHandling === "simplify" && disposalType === 3 ? 2 : disposalType;
    let restoreData = null;
    if (effectiveDisposal === 3) {
      restoreData = compositeCtx.getImageData(dims.left, dims.top, dims.width, dims.height);
    }
    const imageData = compositeCtx.createImageData(dims.width, dims.height);
    imageData.data.set(new Uint8ClampedArray(patch));
    const patchCanvas = createCanvas(dims.width, dims.height);
    const patchCtx = patchCanvas.getContext("2d");
    patchCtx.putImageData(imageData, 0, 0);
    compositeCtx.drawImage(patchCanvas, dims.left, dims.top);
    const outputCanvas = createCanvas(width, height);
    const outputCtx = outputCanvas.getContext("2d");
    outputCtx.drawImage(compositeCanvas, 0, 0);
    animationFrames.push({
      canvas: outputCanvas,
      delay,
      // already in milliseconds (gifuct-js converts centiseconds internally)
      disposalType: effectiveDisposal
    });
    if (effectiveDisposal === 2) {
      compositeCtx.clearRect(dims.left, dims.top, dims.width, dims.height);
    } else if (effectiveDisposal === 3 && restoreData) {
      compositeCtx.putImageData(restoreData, dims.left, dims.top);
    }
  }
  return animationFrames;
}
function decimateFramesToMaxFps(frames, targetFps) {
  if (frames.length <= 1 || targetFps <= 0) {
    return frames;
  }
  const totalDelay = frames.reduce((sum, f) => sum + (f.delay || 100), 0);
  const avgDelay = totalDelay / frames.length;
  const sourceFps = avgDelay > 0 ? 1e3 / avgDelay : 0;
  if (!sourceFps || sourceFps <= targetFps) {
    return frames;
  }
  const ratio = sourceFps / targetFps;
  const keepIndices = [];
  let accumulator = 0;
  for (let i = 0; i < frames.length; i++) {
    accumulator += 1;
    if (accumulator >= ratio) {
      keepIndices.push(i);
      accumulator -= ratio;
    }
  }
  if (keepIndices.length === 0) {
    keepIndices.push(0);
  }
  if (keepIndices[0] !== 0) {
    keepIndices.unshift(0);
  }
  if (keepIndices[keepIndices.length - 1] !== frames.length - 1) {
    keepIndices.push(frames.length - 1);
  }
  return keepIndices.map((idx) => frames[idx]).filter(Boolean);
}
function encodeAnimatedGifWithDelays(frames, colors = 256, disposal = 1) {
  if (!isGifEncodingAvailable()) {
    throw new Error("GIF encoder is unavailable in this runtime");
  }
  if (frames.length === 0) {
    throw new Error("No frames to encode");
  }
  const width = frames[0].canvas.width;
  const height = frames[0].canvas.height;
  const gif = createGifEncoder();
  const paletteSize = Math.min(256, Math.max(2, colors));
  for (let i = 0; i < frames.length; i++) {
    const frame = frames[i];
    const ctx = frame.canvas.getContext("2d");
    const imageData = ctx.getImageData(0, 0, width, height);
    const { data } = imageData;
    const palette = quantizeGifPalette(data, paletteSize);
    const index = indexGifPixels(data, palette);
    const delayMs = Math.max(20, frame.delay);
    const frameOptions = {
      palette,
      delay: delayMs,
      disposal
    };
    if (i === 0) {
      frameOptions.repeat = 0;
    }
    gif.writeFrame(index, width, height, frameOptions);
  }
  gif.finish();
  return Buffer.from(gif.bytes());
}
function parseGradientStops(stopsParam) {
  const parts = stopsParam.split(",");
  const stops = [];
  for (let i = 0; i < parts.length - 1; i += 2) {
    const color = `#${parts[i]}`;
    const pos = Number.parseFloat(parts[i + 1]);
    if (!Number.isNaN(pos)) {
      stops.push({ color, pos });
    }
  }
  return stops.length > 0 ? stops : [
    { color: "#000000", pos: 0 },
    { color: "#000000", pos: 1 }
  ];
}
async function fetchImageWithBuffer(url) {
  try {
    let parsedUrl;
    try {
      parsedUrl = new URL(url);
      if (!["http:", "https:"].includes(parsedUrl.protocol)) {
        return null;
      }
      if (isPrivateOrReservedIP(parsedUrl.hostname)) {
        return null;
      }
    } catch {
      return null;
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    const response = await fetch(url, {
      headers: {
        "User-Agent": "ANQR-QR-Generator/1.0"
      },
      signal: controller.signal,
      redirect: "follow"
      // Follows up to 20 redirects by default; MAX_REDIRECTS is for documentation
    });
    clearTimeout(timeoutId);
    if (!response.ok) {
      return null;
    }
    const contentType = response.headers.get("Content-Type") || "";
    const validImageTypes = [
      "image/png",
      "image/jpeg",
      "image/gif",
      "image/webp",
      "image/svg+xml",
      "image/bmp"
    ];
    const isImage = validImageTypes.some((type) => contentType.toLowerCase().startsWith(type));
    if (!isImage && contentType && !contentType.startsWith("application/octet-stream")) {
      return null;
    }
    const reader = response.body?.getReader();
    if (!reader) {
      return null;
    }
    const chunks = [];
    let totalBytes = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        totalBytes += value.byteLength;
        if (totalBytes > MAX_OVERLAY_BYTES) {
          reader.cancel();
          return null;
        }
        chunks.push(value);
      }
    } catch (_streamError) {
      return null;
    }
    const arrayBuffer = new Uint8Array(totalBytes);
    let offset = 0;
    for (const chunk of chunks) {
      arrayBuffer.set(chunk, offset);
      offset += chunk.byteLength;
    }
    const buffer = Buffer.from(arrayBuffer);
    let isAnimatedGif = false;
    if (isGifBuffer(arrayBuffer)) {
      try {
        const decoded = decodeGif(arrayBuffer);
        isAnimatedGif = decoded.frames.length > 1;
      } catch (_e) {
      }
    }
    const img = await nodeCanvasFactory.loadImage(buffer);
    if (!(img.width && img.height) || img.width <= 0 || img.height <= 0) {
      return null;
    }
    const pixelCount = img.width * img.height;
    if (pixelCount > MAX_OVERLAY_PIXELS) {
      return null;
    }
    const canvas = createCanvas(img.width, img.height);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);
    return {
      canvas,
      arrayBuffer,
      isAnimatedGif
    };
  } catch (_error) {
    return null;
  }
}
async function fetchImageAsCanvas(url) {
  const result = await fetchImageWithBuffer(url);
  return result?.canvas ?? null;
}
async function handler(request) {
  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: CORS_HEADERS
    });
  }
  const url = new URL(request.url);
  const params = url.searchParams;
  const data = params.get("data");
  if (!data) {
    return new Response('Missing required "data" parameter', {
      status: 400,
      headers: CORS_HEADERS
    });
  }
  if (data.length > MAX_DATA_LENGTH) {
    return new Response(`Data too long: ${data.length} characters (max: ${MAX_DATA_LENGTH})`, {
      status: 400,
      headers: CORS_HEADERS
    });
  }
  const lang = params.get("lang") || void 0;
  void lang;
  const sizeParam = Number.parseInt(params.get("size") || "400", 10);
  const modulePxParam = params.get("modulePx") ? Number.parseInt(params.get("modulePx"), 10) : null;
  const widthParam = params.get("w") ? Number.parseInt(params.get("w"), 10) : null;
  const heightParam = params.get("h") ? Number.parseInt(params.get("h"), 10) : null;
  const outputWidth = Math.min(MAX_SERVER_IMAGE_SIZE, Math.max(50, widthParam ?? sizeParam));
  const outputHeight = Math.min(MAX_SERVER_IMAGE_SIZE, Math.max(50, heightParam ?? sizeParam));
  const size = Math.max(outputWidth, outputHeight);
  const fg = params.get("fg") || "000000";
  const bg = params.get("bg") || "ffffff";
  const ec = params.get("ec")?.toUpperCase() || "H";
  const margin = Math.min(20, Math.max(0, Number.parseInt(params.get("margin") || "4", 10)));
  const transparent = params.get("transparent") === "1";
  const encodingMode = params.get("enc") || "auto";
  const version = params.get("v") ? Number.parseInt(params.get("v"), 10) : 0;
  const maskPatternParam = params.get("mask");
  const parsedMask = maskPatternParam ? Number.parseInt(maskPatternParam, 10) : NaN;
  const maskPattern = maskPatternParam === "auto" || !maskPatternParam || Number.isNaN(parsedMask) ? "auto" : Math.min(7, Math.max(0, parsedMask));
  const charsetParam = params.get("charset") || "default";
  const characterEncoding = ["default", "utf8", "shift-jis"].includes(charsetParam) ? charsetParam : "default";
  const borderModulesExtra = Math.min(
    10,
    Math.max(0, Number.parseInt(params.get("border") || "0", 10))
  );
  const quietZoneMinEnforce = params.has("qzEnforce") ? params.get("qzEnforce") !== "0" : void 0;
  const crispEdges = params.get("crisp") !== "0";
  const pixelSnap = params.get("snap") || "floor";
  const perModuleColorMode = params.get("modColor") || "solid";
  const contrastGuard = params.get("cGuard") === "1";
  const minContrastRatio = Number.parseFloat(params.get("minContrast") || "4.5");
  const renderSeed = params.get("seed") ? Number.parseInt(params.get("seed") || "0", 10) : void 0;
  const moduleStyle = params.get("style") || "square";
  const finderStyle = params.get("finder") || "square";
  const eyeOuterStyle = params.get("eyeOuter") || finderStyle;
  const eyeInnerStyle = params.get("eyeInner") || finderStyle;
  const eyeScale = Math.min(
    150,
    Math.max(50, Number.parseInt(params.get("eyeScale") || "100", 10))
  );
  const cornerRadius = Math.min(100, Math.max(0, Number.parseInt(params.get("radius") || "0", 10)));
  const moduleGap = Math.min(50, Math.max(0, Number.parseInt(params.get("gap") || "0", 10)));
  const gapMode = params.get("gapMode") || "none";
  const dotRotationDeg = Number.parseInt(params.get("dotRot") || "0", 10);
  const frameStyle = params.get("frame") || "none";
  const frameText = params.get("frameText") || "";
  const gradientType = params.get("grad") || "none";
  const gradientAngle = Number.parseInt(params.get("gradAngle") || "0", 10);
  const gradientStopsParam = params.get("gradStops");
  const gradientStops = gradientStopsParam ? parseGradientStops(gradientStopsParam) : void 0;
  const alignmentStyle = params.get("align") || "match_finder";
  const timingStyle = params.get("timing") || "match_module";
  const preserveFinders = params.get("keepFinders") !== "0";
  const preserveTiming = params.get("keepTiming") === "1";
  const preserveAlignment = params.get("keepAlign") === "1";
  const protectFormatInfo = params.get("protectFmt") === "1";
  const protectVersionInfo = params.get("protectVer") === "1";
  const eccAwareEnabled = params.get("eccAware") === "1";
  const eccAwareRiskBudget = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("eccRisk") || "50", 10))
  );
  const eccAwareWeightMap = params.get("eccMap") || "distance_to_finders";
  const overlayUrl = params.get("img");
  const legacySubpixel = params.get("subpixel") === "1";
  const overlayMode = params.get("mode") || (legacySubpixel ? "subpixel" : overlayUrl ? "dithered" : void 0);
  const overlayIntensity = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("intensity") || "100", 10))
  );
  const colorMode = params.get("colorMode") || "color";
  const logoSize = Math.min(50, Math.max(5, Number.parseInt(params.get("logoSize") || "25", 10)));
  const overlayBrightness = Math.min(
    100,
    Math.max(-100, Number.parseInt(params.get("brightness") || "0", 10))
  );
  const overlayContrast = Math.min(
    100,
    Math.max(-100, Number.parseInt(params.get("contrast") || "0", 10))
  );
  const overlayGamma = Math.max(0.1, Math.min(3, Number.parseFloat(params.get("gamma") || "1")));
  const overlaySaturation = Math.min(
    100,
    Math.max(-100, Number.parseInt(params.get("saturation") || "0", 10))
  );
  const overlayHueRotate = Number.parseInt(params.get("hue") || "0", 10);
  const overlayInvert = params.get("invert") === "1";
  const overlayBlur = Math.max(0, Number.parseInt(params.get("blur") || "0", 10));
  const overlaySharpen = Math.max(0, Number.parseInt(params.get("sharpen") || "0", 10));
  const overlayPosterize = Math.max(0, Number.parseInt(params.get("posterize") || "0", 10));
  const overlayThresholdParam = params.get("threshold");
  const overlayThreshold = overlayThresholdParam ? Math.min(255, Math.max(0, Number.parseInt(overlayThresholdParam, 10))) : void 0;
  const overlayEdgeDetect = params.get("edge") || "off";
  const overlayFit = params.get("fit") || "cover";
  const overlayRotate = Number.parseInt(params.get("rot") || "0", 10);
  const overlayFlipX = params.get("flipX") === "1";
  const overlayFlipY = params.get("flipY") === "1";
  const ditherKindParam = params.get("ditherKind");
  const ditherKind = ditherKindParam || DEFAULT_SERVER_DITHER;
  const diffusionKernel = params.get("diffusionKernel") || "floyd_steinberg";
  const ditherStrength = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("ditherStrength") || "50", 10))
  );
  const finderDitherStrength = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("finderDither") || "65", 10))
  );
  const blendPreservations = params.get("blendPres") === "1";
  const ditherSerpentine = params.get("serpentine") === "1";
  const orderedMatrix = params.get("matrix") || "bayer4";
  const blueNoiseTileSize = Number.parseInt(params.get("bnTile") || "64", 10);
  const blueNoiseSeed = Number.parseInt(params.get("bnSeed") || "0", 10);
  const colorDither = params.get("colorDither") || "none";
  const subpixelGridSize = params.get("spGrid") || "3x3";
  const subpixelGridNum = params.get("spGridNum") ? Number.parseInt(params.get("spGridNum") || "3", 10) : void 0;
  const subpixelCenterRule = params.get("spCenter") || "strict";
  const subpixelNeutralColor = params.get("spNeutral") ? `#${params.get("spNeutral")}` : "#808080";
  const subpixelFinderOverride = params.get("spFinder") || "solid";
  const halftoneCell = params.get("htCell") || "per_module";
  const halftoneDotShape = params.get("htDot") || "circle";
  const brightnessCurve = params.get("htCurve") || "linear";
  const duotoneColor1 = params.get("duo1") ? `#${params.get("duo1")}` : "#000000";
  const duotoneColor2 = params.get("duo2") ? `#${params.get("duo2")}` : "#ffffff";
  const paletteParam = params.get("palette");
  const palette = paletteParam ? paletteParam.split(",").map((c) => c.startsWith("#") ? c : `#${c}`) : void 0;
  const maxOverlayIntensityL = Number.parseInt(
    params.get("maxIntL") || params.get("maxOverlayIntensityL") || "100",
    10
  );
  const maxOverlayIntensityM = Number.parseInt(
    params.get("maxIntM") || params.get("maxOverlayIntensityM") || "100",
    10
  );
  const maxOverlayIntensityQ = Number.parseInt(
    params.get("maxIntQ") || params.get("maxOverlayIntensityQ") || "100",
    10
  );
  const maxOverlayIntensityH = Number.parseInt(
    params.get("maxIntH") || params.get("maxOverlayIntensityH") || "100",
    10
  );
  let outputFormat = params.get("format") || DEFAULT_OUTPUT_FORMAT;
  const outputQuality = Math.max(0, Math.min(1, Number.parseFloat(params.get("quality") || "0.9")));
  const outputDpi = Math.max(1, Math.min(1200, Number.parseInt(params.get("dpi") || "72", 10)));
  const watermarkEnabled = params.get("wmEn") === "1";
  const watermarkKind = params.get("wmKind") || "text";
  const watermarkText = params.get("wmText") || "";
  const watermarkImageUrl = params.get("wmImg") || void 0;
  const watermarkPosition = params.get("wmPos") || "center";
  const watermarkOpacity = Math.min(
    100,
    Math.max(0, Number.parseInt(params.get("wmOpacity") || "50", 10))
  );
  const watermarkBlend = params.get("wmBlend") || "normal";
  const animationPattern = params.get("animPattern") || "none";
  const animationLoop = params.get("loop") !== "0";
  const animationBounce = params.get("bounce") === "1";
  const animationReverse = params.get("reverse") === "1";
  const animationColorCycle = params.get("colorCycle") === "1";
  const animationInterpolate = params.get("interp") || "none";
  const animationTemporalDither = params.get("tempDither") || "off";
  const animationStartFrame = Number.parseInt(params.get("startF") || "0", 10);
  const animationMaxFrames = Number.parseInt(params.get("maxF") || "0", 10);
  const animationFrameStep = Number.parseInt(params.get("stepF") || "1", 10);
  const animationModuleJitter = Number.parseFloat(params.get("jitter") || "0");
  const animationFramesRaw = Number.parseInt(params.get("animFrames") || "24", 10);
  const animationFrames = Math.min(
    60,
    Math.max(1, Number.isNaN(animationFramesRaw) ? 24 : animationFramesRaw)
  );
  const animationSpeedRaw = Number.parseInt(
    params.get("animSpeed") || params.get("speed") || "100",
    10
  );
  const animationSpeed = Math.min(
    1e3,
    Math.max(10, Number.isNaN(animationSpeedRaw) ? 100 : animationSpeedRaw)
  );
  const animationSeed = Number.parseInt(params.get("animSeed") || "0", 10);
  const animationEasing = params.get("easing") || "linear";
  const webpQuality = Math.min(100, Math.max(0, Number.parseInt(params.get("webpQ") || "90", 10)));
  const _jpegQuality = Math.min(100, Math.max(0, Number.parseInt(params.get("jpegQ") || "92", 10)));
  const gifPaletteSize = params.get("gifPal");
  const gifColors = Math.min(
    256,
    Math.max(2, Number.parseInt(params.get("gifColors") || gifPaletteSize || "256", 10))
  );
  const gifQuantizer = params.get("gifQuant") || void 0;
  const gifDither = params.get("gifDith") || void 0;
  const gifTransparentColor = params.get("gifTrans") ? `#${params.get("gifTrans")}` : void 0;
  void gifQuantizer;
  void gifDither;
  void gifTransparentColor;
  const metaTitle = params.get("metaTitle") || void 0;
  const metaAuthor = params.get("metaAuthor") || void 0;
  const metaCopyright = params.get("metaCopy") || void 0;
  const metaDescription = params.get("metaDesc") || void 0;
  const metaLicense = params.get("metaLic") || void 0;
  const metaCreationTime = params.get("metaTime") === "1";
  const metaCustomKv = params.get("metaKv") || void 0;
  const cropEnabled = params.get("cropEn") === "1";
  const cropX = Number.parseFloat(params.get("cropX") || "0.5");
  const cropY = Number.parseFloat(params.get("cropY") || "0.5");
  const cropSize = Number.parseFloat(params.get("cropSize") || "1");
  const overlayType = params.get("ovType") || "static";
  const overlayFramePick = params.get("ovFramePick") || "all";
  const gifUseFrameDelays = params.get("gifDelays") !== "0";
  const gifDisposalHandling = params.get("gifDispH") || "respect";
  const gifMaxFps = Number.parseInt(params.get("gifMaxFps") || "0", 10);
  const lockFinders = params.get("lockF") !== "0";
  const lockTiming = params.get("lockT") !== "0";
  const lockAlign = params.get("lockA") !== "0";
  const lockFormat = params.get("lockFmt") !== "0";
  const lockVersion = params.get("lockV") !== "0";
  const safetyMode = params.get("safeMode") || "off";
  const safetyMinModulePx = Number.parseInt(params.get("safeMinPx") || "2", 10);
  const safetyMinQuietZone = Number.parseInt(params.get("safeMinQz") || "4", 10);
  const autoPickVersion = params.get("autoVer") !== "0";
  const autoPickEcc = params.get("autoEcc") === "1";
  const autoReduceIntensity = params.get("autoReduce") === "1";
  const qaContrastCheckClientOnly = params.get("qaContrast") === "1";
  const qaSimulateBlurClientOnly = Number.parseFloat(params.get("qaBlur") || "0");
  const qaSimulateNoiseClientOnly = Number.parseInt(params.get("qaNoise") || "0", 10);
  const qaSimulateRotationClientOnly = Number.parseInt(params.get("qaRot") || "0", 10);
  const qaShowHeatmapClientOnly = params.get("qaHeatmap") === "1";
  if (qaContrastCheckClientOnly || qaSimulateBlurClientOnly || qaSimulateNoiseClientOnly || qaSimulateRotationClientOnly || qaShowHeatmapClientOnly) {
  }
  const bgOverride = params.get("bgOver") ? `#${params.get("bgOver")}` : void 0;
  const formatExtra = params.get("fmtExtra") || "none";
  const filename = params.get("fname") || "anqr-qrcode";
  const includeQuietZone = params.get("inclQz") !== "0";
  const gifDisposal = params.get("gifDisp") || "restore_bg";
  const gifDisposalCode = gifDisposal === "none" ? 0 : gifDisposal === "keep" ? 1 : gifDisposal === "restore_previous" ? 3 : 2;
  const svgTrueVector = params.get("svgVec") === "1";
  const svgShapePrecision = params.get("svgPrec") || "pixel";
  const svgEmbedRasterOverlay = params.get("svgEmbed") !== "0";
  void svgTrueVector;
  const paletteMode = params.get("paletteMode") || "position";
  if (!["L", "M", "Q", "H"].includes(ec)) {
    return new Response('Invalid "ec" parameter. Use L, M, Q, or H', {
      status: 400,
      headers: CORS_HEADERS
    });
  }
  const validModuleStyles = ["square", "rounded", "dots", "diamond", "connected"];
  if (!validModuleStyles.includes(moduleStyle)) {
    return new Response(`Invalid "style" parameter. Use one of: ${validModuleStyles.join(", ")}`, {
      status: 400,
      headers: CORS_HEADERS
    });
  }
  try {
    const qrGenerator = new QRGenerator(nodeCanvasFactory);
    const estimatedVersion = calculateOptimalVersion(data, ec);
    const estimatedModuleCount = estimatedVersion * 4 + 17;
    const totalMargin = margin + borderModulesExtra;
    const moduleSize = modulePxParam ? Math.max(1, Math.min(50, modulePxParam)) : Math.max(
      1,
      Math.floor((size - totalMargin * 2) / (estimatedModuleCount + totalMargin * 2))
    );
    const config = {
      content: data,
      typeNumber: version,
      // 0 = auto-detect
      errorCorrection: ec,
      encodingMode,
      maskPattern,
      characterEncoding,
      seed: renderSeed,
      moduleSize,
      margin: margin + borderModulesExtra,
      quietZoneMinEnforce,
      crispEdges,
      pixelSnap,
      fgColor: `#${fg}`,
      bgColor: `#${bg}`,
      transparentBg: transparent,
      moduleStyle,
      finderStyle,
      alignmentStyle,
      timingStyle,
      eyeOuterStyle,
      eyeInnerStyle,
      eyeScale,
      cornerRadius,
      moduleGap,
      gapMode,
      dotRotationDeg,
      frameStyle,
      frameText,
      perModuleColorMode,
      contrastGuard,
      minContrastRatio,
      overlayMode,
      overlayIntensity,
      colorMode,
      logoSize,
      preserveFinders,
      preserveTiming,
      preserveAlignment,
      protectFormatInfo,
      protectVersionInfo,
      eccAwareEnabled,
      eccAwareRiskBudget,
      eccAwareWeightMap,
      overlayBrightness,
      overlayContrast,
      overlayGamma,
      overlaySaturation,
      overlayHueRotate,
      invertImage: overlayInvert,
      overlayBlur,
      overlaySharpen,
      overlayPosterize,
      overlayThreshold,
      overlayEdgeDetect,
      overlayFit,
      overlayRotate,
      overlayFlipX,
      overlayFlipY,
      // Dither options
      ditherKind,
      diffusionKernel,
      ditherStrength,
      finderDitherStrength,
      blendPreservations,
      ditherSerpentine,
      orderedMatrix,
      blueNoiseTileSize,
      blueNoiseSeed,
      colorDither,
      // Subpixel options
      subpixelGridSize,
      subpixelGrid: subpixelGridNum,
      subpixelCenterRule,
      subpixelNeutralColor,
      subpixelFinderOverride,
      // Halftone options
      halftoneCell,
      halftoneDotShape,
      brightnessCurve,
      duotoneColors: [duotoneColor1, duotoneColor2],
      // Palette
      palette,
      gradient: gradientType === "none" ? void 0 : {
        type: gradientType,
        angle: gradientAngle,
        stops: gradientStops
      },
      // Per-ECC intensity limits
      maxOverlayIntensityByEcc: {
        L: maxOverlayIntensityL,
        M: maxOverlayIntensityM,
        Q: maxOverlayIntensityQ,
        H: maxOverlayIntensityH
      },
      // Animation settings (pattern-based animation is supported server-side)
      animationPattern,
      animationFrames,
      animationSpeed,
      animationSeed,
      animationLoop,
      animationBounce,
      animationReverse,
      animationInterpolate,
      animationTemporalDither,
      animationStartFrame,
      animationMaxFrames,
      animationFrameStep,
      moduleJitterPx: animationModuleJitter,
      // Limited server-side support
      colorCycle: animationColorCycle,
      // Supported via color cycle pattern
      // Crop settings
      cropEnabled,
      cropX,
      cropY,
      cropSize,
      // Overlay type
      overlayType,
      overlayFramePick,
      // GIF overlay
      gifUseFrameDelays,
      gifDisposalHandling,
      // Safety locks
      lockFinders,
      lockTiming,
      lockAlign,
      lockFormat,
      lockVersion,
      safetyMode,
      safetyMinModulePx,
      safetyMinQuietZone,
      // Auto-tuning hints
      autoPickVersion,
      autoPickEcc,
      autoReduceIntensity,
      // Output extras
      bgOverride,
      formatExtra,
      filename,
      includeQuietZone,
      svgShapePrecision,
      svgEmbedRasterOverlay,
      // Palette
      paletteMode
    };
    let overlayCanvas = null;
    let overlayFrames = [];
    let hasAnimatedOverlay = false;
    if (overlayUrl && overlayMode) {
      const fetchedImage = await fetchImageWithBuffer(overlayUrl);
      if (fetchedImage) {
        const hasFilters = overlayBrightness !== 0 || overlayContrast !== 0 || overlayGamma !== 1 || overlaySaturation !== 0 || overlayHueRotate !== 0 || overlayInvert || overlayBlur > 0 || overlaySharpen > 0 || overlayPosterize > 1 || overlayEdgeDetect !== "off";
        const filterOptions = {
          brightness: overlayBrightness,
          contrast: overlayContrast,
          gamma: overlayGamma,
          saturation: overlaySaturation,
          hue: overlayHueRotate,
          invert: overlayInvert,
          blur: overlayBlur,
          sharpen: overlaySharpen,
          posterize: overlayPosterize,
          threshold: overlayThreshold,
          // Only applied if explicitly specified via URL param
          edge: overlayEdgeDetect
        };
        const preprocessCanvas = (canvas2) => {
          let processed = canvas2;
          if (cropEnabled && cropSize < 1) {
            processed = cropOverlayServer(processed, cropX, cropY, cropSize);
          }
          if (overlayRotate !== 0) {
            processed = rotateOverlayServer(processed, overlayRotate);
          }
          if (overlayFlipX || overlayFlipY) {
            processed = flipOverlayServer(processed, overlayFlipX, overlayFlipY);
          }
          if (hasFilters) {
            processed = applyOverlayFiltersServer(processed, filterOptions);
          }
          return processed;
        };
        if (fetchedImage.isAnimatedGif) {
          outputFormat = "gif";
          hasAnimatedOverlay = true;
          const rawFrames = parseGifFramesServer(
            fetchedImage.arrayBuffer,
            gifDisposalHandling === "simplify" ? "simplify" : "respect"
          );
          overlayFrames = rawFrames.map((frame) => ({
            ...frame,
            canvas: preprocessCanvas(frame.canvas)
          }));
          if (gifMaxFps > 0 && overlayFrames.length > 1 && !Number.isNaN(gifMaxFps)) {
            overlayFrames = decimateFramesToMaxFps(overlayFrames, gifMaxFps);
          }
          overlayCanvas = overlayFrames[0]?.canvas ?? preprocessCanvas(fetchedImage.canvas);
        } else {
          overlayCanvas = preprocessCanvas(fetchedImage.canvas);
        }
      }
    }
    let canvas = await qrGenerator.generate(config, overlayCanvas);
    let watermarkImageCanvas = null;
    if (watermarkEnabled && (watermarkKind === "image" || watermarkKind === "pattern") && watermarkImageUrl) {
      watermarkImageCanvas = await fetchImageAsCanvas(watermarkImageUrl);
    }
    if (watermarkEnabled) {
      canvas = applyWatermarkServer(canvas, {
        enabled: watermarkEnabled,
        kind: watermarkKind,
        text: watermarkText,
        imageCanvas: watermarkImageCanvas,
        position: watermarkPosition,
        opacity: watermarkOpacity,
        blend: watermarkBlend
      });
    }
    let outputCanvas = canvas;
    if (canvas.width !== outputWidth || canvas.height !== outputHeight) {
      outputCanvas = createCanvas(outputWidth, outputHeight);
      const ctx = outputCanvas.getContext("2d");
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(canvas, 0, 0, outputWidth, outputHeight);
    }
    const metadata = metaTitle || metaAuthor || metaCopyright || metaDescription || metaLicense || metaCreationTime || metaCustomKv ? {
      title: metaTitle,
      author: metaAuthor,
      copyright: metaCopyright,
      description: metaDescription,
      creationTime: metaCreationTime ? (/* @__PURE__ */ new Date()).toISOString() : void 0,
      software: "ANQR - anqr.link",
      // Custom key-value pairs are stored in description if provided
      // Format: key1=value1;key2=value2
      ...metaCustomKv && !metaDescription ? { description: metaCustomKv } : {}
    } : void 0;
    let animationFrameCanvases = [];
    const animatedOverlayFrames = [];
    if (outputFormat === "gif") {
      if (hasAnimatedOverlay && overlayFrames.length > 1) {
        for (const overlayFrame of overlayFrames) {
          const frameCanvas = await qrGenerator.generate(config, overlayFrame.canvas);
          let scaledFrame = frameCanvas;
          if (frameCanvas.width !== outputWidth || frameCanvas.height !== outputHeight) {
            scaledFrame = createCanvas(outputWidth, outputHeight);
            const ctx = scaledFrame.getContext("2d");
            ctx.imageSmoothingEnabled = false;
            ctx.drawImage(frameCanvas, 0, 0, outputWidth, outputHeight);
          }
          if (watermarkEnabled) {
            scaledFrame = applyWatermarkServer(scaledFrame, {
              enabled: watermarkEnabled,
              kind: watermarkKind,
              text: watermarkText,
              imageCanvas: watermarkImageCanvas,
              position: watermarkPosition,
              opacity: watermarkOpacity,
              blend: watermarkBlend
            });
          }
          animatedOverlayFrames.push({
            canvas: scaledFrame,
            delay: overlayFrame.delay,
            disposalType: overlayFrame.disposalType
          });
        }
      } else if (animationPattern !== "none") {
        animationFrameCanvases = generatePatternFramesServer(
          outputCanvas,
          animationPattern,
          animationFrames,
          animationSeed,
          animationEasing
        );
      }
    }
    let outputBuffer;
    let contentType;
    switch (outputFormat) {
      case "gif":
        if (animatedOverlayFrames.length > 1) {
          outputBuffer = encodeAnimatedGifWithDelays(
            animatedOverlayFrames,
            gifColors,
            gifDisposalCode
          );
        } else if (animationFrameCanvases.length > 1) {
          outputBuffer = encodeAnimatedGif(
            animationFrameCanvases,
            animationSpeed,
            gifColors,
            gifDisposalCode
          );
        } else {
          outputBuffer = encodeGif(outputCanvas, gifColors, gifDisposalCode);
        }
        contentType = "image/gif";
        break;
      case "webp": {
        const finalWebpQuality = webpQuality !== 90 ? webpQuality : Math.round(outputQuality * 100);
        outputBuffer = outputCanvas.toBuffer("image/webp", finalWebpQuality);
        contentType = "image/webp";
        break;
      }
      default:
        outputBuffer = outputCanvas.toBuffer("image/png");
        if (metadata || outputDpi !== 72) {
          outputBuffer = embedPngMetadataAndDpi(outputBuffer, metadata, outputDpi);
        }
        contentType = "image/png";
        break;
    }
    const etag = `"${createHash("md5").update(outputBuffer).digest("hex")}"`;
    return new Response(new Uint8Array(outputBuffer), {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "public, max-age=31536000, immutable",
        ETag: etag,
        Vary: "Accept-Encoding",
        ...CORS_HEADERS
      }
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    Sentry2.captureException(error);
    return new Response(`Error generating QR code: ${message}`, {
      status: 500,
      headers: CORS_HEADERS
    });
  }
}
var qr_default = handler;
var __test = {
  nodeCanvasFactory,
  isPrivateOrReservedIP,
  _isPrivateHostname,
  createTextWatermark,
  getWatermarkPositions,
  applyBlendMode,
  applyWatermarkServer,
  calculateCrc32,
  createPngTextChunk,
  createPngPhysChunk,
  embedPngMetadataAndDpi,
  encodeGif,
  encodeAnimatedGif,
  generatePatternFramesServer,
  cropOverlayServer,
  rgbToGrayServer,
  convolveServer,
  blurServer,
  sharpenServer,
  posterizeServer,
  thresholdServer,
  sobelEdgeServer,
  cannyEdgeServer,
  applyOverlayFiltersServer,
  flipOverlayServer,
  rotateOverlayServer,
  isGifBuffer,
  parseGifFramesServer,
  decimateFramesToMaxFps,
  encodeAnimatedGifWithDelays,
  parseGradientStops,
  fetchImageWithBuffer,
  fetchImageAsCanvas
};
export {
  __test,
  qr_default as default
};
