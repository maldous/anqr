#!/usr/bin/env node
// AUTO-GENERATED FACADE.
// Original file has been decomposed into sibling modules under the matching directory.
export * from "./linear-all/index.mjs";
export * from "./linear-all/runtime.mjs";
