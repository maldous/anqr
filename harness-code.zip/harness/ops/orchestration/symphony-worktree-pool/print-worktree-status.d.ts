export function printWorktreeStatus(): void;
