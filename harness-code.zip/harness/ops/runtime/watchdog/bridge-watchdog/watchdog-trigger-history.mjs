export const watchdogTriggerHistory = [];
