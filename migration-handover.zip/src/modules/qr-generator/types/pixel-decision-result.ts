// Shim
export * from "../../../../packages/domain/qr/src/qr-generator/types/pixel-decision-result";
