// Shim
export * from "../../../packages/domain/qr/src/qr-encoder/qr-data-segment";
