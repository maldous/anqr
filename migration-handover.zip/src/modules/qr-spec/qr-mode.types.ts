// Shim
export * from "../../../packages/domain/qr/src/qr-spec/qr-mode.types";
