# Types

## Purpose

Types contains the code, configuration, or support files that implement this part of the harness architecture.

## Contents

- 1 immediate file
- 0 child directories

## Key Files

- `mjs-shim.d.ts` - Type declaration file for the sibling module surface.

## Subdirectories

- No child directories in this directory.

## Operational Notes

- Current on-disk inventory: 1 immediate file(s) and 0 child directories.
- This README was refreshed against the current source tree rather than older intent docs alone.

## Review Focus

Check that the current implementation in this directory still matches its intended role in the harness architecture.
