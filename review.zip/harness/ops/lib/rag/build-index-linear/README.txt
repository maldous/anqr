Build Index Linear provides Linear-facing behavior for this part of the harness.
