# Harness Index

This section is the canonical harness doctrine for ANQR 1.0 foundation work.

## Read order

1. [01-operating-model.md](/home/user/src/anqr/docs/harness/01-operating-model.md)
2. [02-runtime-and-services.md](/home/user/src/anqr/docs/harness/02-runtime-and-services.md)
3. [03-workspace-governance.md](/home/user/src/anqr/docs/harness/03-workspace-governance.md)
4. [04-provider-routing.md](/home/user/src/anqr/docs/harness/04-provider-routing.md)
5. [05-quality-gates.md](/home/user/src/anqr/docs/harness/05-quality-gates.md)
6. [05-runtime-contract.md](/home/user/src/anqr/docs/harness/05-runtime-contract.md)
7. [06-evidence-and-reporting.md](/home/user/src/anqr/docs/harness/06-evidence-and-reporting.md)
8. [07-secrets-redaction-and-operator-access.md](/home/user/src/anqr/docs/harness/07-secrets-redaction-and-operator-access.md)
9. [08-runbooks.md](/home/user/src/anqr/docs/harness/08-runbooks.md)
10. [09-archive-policy.md](/home/user/src/anqr/docs/harness/09-archive-policy.md)
11. [10-audit-reference.md](/home/user/src/anqr/docs/harness/10-audit-reference.md)
12. [11-adaptive-context.md](/home/user/src/anqr/docs/harness/11-adaptive-context.md)
13. [12-concurrent-execution-with-worktrees.md](/home/user/src/anqr/docs/harness/12-concurrent-execution-with-worktrees.md)
14. [workspace/README.md](/home/user/src/anqr/docs/harness/workspace/README.md)

## Scope

This section governs:

- `harness/ops/*`
- `services/systemd/*`
- the fresh Linear workspace model
- evidence and gate policy for agent-driven delivery

It does not redefine the product architecture itself. For that, use [README.md](/home/user/src/anqr/README.md) and [docs/program/01-anqr-1.0-definition.md](/home/user/src/anqr/docs/program/01-anqr-1.0-definition.md).
