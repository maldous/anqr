# Harness Audit Reference

This document provides a comprehensive reference of all harness components for audit purposes.

---

## 1. Executive Summary

The ANQR harness is an AI-assisted engineering automation system that:

- Picks up work items (Linear issues) from a backlog
- Executes them through Symphony Bridge for routed provider selection, with Codebuff Bridge retained for OpenClaw failover and HTTP parity
- Validates results through quality gates
- Reports evidence and updates issue state

**Key Components:**

- **Symphony Runner** - Main execution engine that picks up issues and executes via AI
- **Symphony Bridge** - OpenAI-compatible HTTP gateway (port 4319) using AI SDK with tool execution
- **Codebuff Bridge** - OpenAI-compatible HTTP gateway (port 4318) for Codebuff SDK
- **Credit-gate** - Provider selection and auto-fallback system with 40+ providers, 4-tier ranking, dynamic tool-capability probing
- **Queue Control** - Queue maintenance and backup feeding
- **Linear Guardian** - Issue hygiene enforcement
- **Harness Report** - Continuous health monitoring

---

## 2. Systemd Services

| Service                    | Timer        | Purpose                                  | Script                             |
| -------------------------- | ------------ | ---------------------------------------- | ---------------------------------- |
| `anqr-linear-runner@*`     | Every 2 min  | Execute Linear issues via AI (one per @) | `symphony-runner.mjs`              |
| `anqr-queue-feeder`        | Every 15 min | Queue maintenance + backup feed          | `symphony-queue-control.mjs --all` |
| `anqr-nightly`             | Daily 02:00  | Full nightly pipeline                    | `nightly-ops-pass.mjs`             |
| `anqr-email-ingest`        | Every 5 min  | Email → Linear issues                    | `email-ingest.mjs`                 |
| `anqr-symphony-router`     | Always-on    | Global orchestration (control plane)     | `symphony-agent-router.mjs`        |
| `anqr-symphony-executor@*` | Always-on    | Worktree executors (execution plane)     | `symphony-openai-bridge.mjs`       |

### Service Installation

```bash
# Copy service files
cp services/systemd/anqr-symphony-router.service ~/.config/systemd/user/
cp services/systemd/anqr-symphony-executor@.service ~/.config/systemd/user/
cp services/systemd/anqr-linear-runner@.service ~/.config/systemd/user/
cp services/systemd/anqr-linear-runner@.timer ~/.config/systemd/user/
cp services/systemd/anqr-discord-router.service ~/.config/systemd/user/
cp services/systemd/anqr-ops.env ~/.config/systemd/user/

# Edit anqr-ops.env with real API keys
systemctl --user daemon-reload

# Enable services
systemctl --user enable --now anqr-symphony-router.service
systemctl --user enable --now anqr-symphony-executor@{1..8}.service
systemctl --user enable --now anqr-linear-runner@{1..4}.timer
```

---

## 3. Ports and Network

| Port      | Service            | Protocol                 | Auth                                   |
| --------- | ------------------ | ------------------------ | -------------------------------------- |
| 4319      | Symphony Router    | HTTP (OpenAI-compatible) | Bearer: `local-symphony`               |
| 4321-4328 | Symphony Executors | HTTP (OpenAI-compatible) | Bearer: `local-symphony`               |
| 18789     | OpenClaw           | HTTP (OpenAI-compatible) | Token from `~/.openclaw/openclaw.json` |
| 18790     | Discord Router     | HTTP                     | -                                      |
| 11434     | Ollama             | HTTP                     | Local only                             |

---

## 4. Environment Files

### Sources (in priority order)

1. **Project-local**: `.env` - Developer/operator superset
2. **Harness runtime**: `~/.config/symphony/anqr.env` - Provider tokens for symphony
3. **Systemd**: `~/.config/systemd/user/anqr-ops.env` - Service environment
4. **Template**: `services/systemd/anqr-ops.env` - Repo-stored template (no secrets)

### Required Environment Variables

#### Linear

- `LINEAR_API_KEY` - Linear API key for issue management

#### Codebuff

- `CODEBUFF_API_KEY` - Single account (tried in paid mode first, then free mode)

#### Provider Tokens

- `OPENAI_API_KEY` - OpenAI/Codex (gpt-5.4)
- `GROQ_TOKEN` - Groq (llama-3.3-70b-versatile)
- `MISTRAL_TOKEN` - Mistral (mistral-small-latest)
- `GEMINI_TOKEN` - Google Gemini (gemini-2.5-flash)
- `OPENROUTER_TOKEN` - OpenRouter (40+ free models)
- `SAMBANOVA_TOKEN` - SambaNova (Meta-Llama-3.3-70B)
- `CEREBRAS_TOKEN` - Cerebras (llama3.1-8b)
- `GITHUB_MODELS_TOKEN` - GitHub Models (gpt-4.1-mini)

#### Local Models

- `OLLAMA_API_BASE` - Ollama endpoint (default: http://localhost:11434)

#### Optional

- `SONAR_HOST_URL` - SonarQube URL
- `SONAR_TOKEN` / `SONARQUBE_TOKEN` - SonarQube authentication

#### Bridge Configuration

- `CODEBUFF_BRIDGE_PORT` - Port for Codebuff bridge (default: 4318)
- `CODEBUFF_BRIDGE_API_KEY` - Bearer token for Codebuff bridge (default: local-bridge)
- `CODEBUFF_BRIDGE_CWD` - Working directory for Codebuff
- `CODEBUFF_BRIDGE_URL` - Override URL for bridge
- `CODEBUFF_MODEL_ID` - Model ID to advertise (default: codebuff/base)
- `SYMPHONY_BRIDGE_PORT` - Port for Symphony bridge (default: 4319)
- `SYMPHONY_BRIDGE_API_KEY` - Bearer token for Symphony bridge (default: local-symphony)
- `SYMPHONY_BRIDGE_ACCEPTED_TOKENS` - Additional accepted tokens (comma-separated)
- `SYMPHONY_MODEL_ID` - Model ID to advertise (default: symphony/main)

#### Symphony Runtime

- `ANQR_SYMPHONY_HOST_ID` - Unique identifier for this host
- `ANQR_SYMPHONY_LEASE_MS` - Lease duration for issue ownership (default: 120000)
- `ANQR_SYMPHONY_HISTORY_LIMIT` - Number of recent runs to keep in history

#### Email Ingest

- `ANQR_INGEST_EMAIL` - Email address for ingest processing

#### Linear

- `LINEAR_WORKSPACE` - Linear workspace identifier

---

## 5. AI Providers (40+)

### Provider Tier System

The credit-gate classifies every provider into one of four tiers. `getRankedProviders()` partitions providers by tier — safety-net providers are always appended last regardless of score.

| Tier               | Providers                                                             | Score ceiling | Ranking behavior                |
| ------------------ | --------------------------------------------------------------------- | ------------- | ------------------------------- |
| `paid`             | codex, codebuff                                                       | none          | Probed first; uses paid credits |
| `free-cloud`       | groq, mistral, gemini, openrouter, sambanova, cerebras, github-models | none          | Dynamic scoring (default tier)  |
| `local-proxy`      | openclaw, codebuff-bridge                                             | none          | Local HTTP gateways             |
| `local-safety-net` | ollama-local, ollama-qwen2.5-coder-3b, ollama-qwen2.5-coder-0.5b      | **0.25**      | Always rank last                |

### Primary Providers (Selected by Credit-gate)

| Priority | Provider    | Tier         | Model                   | Type | API Endpoint                                            | SDK     |
| -------- | ----------- | ------------ | ----------------------- | ---- | ------------------------------------------------------- | ------- |
| 1        | codex       | `paid`       | gpt-5.4                 | HTTP | https://api.openai.com/v1                               | No      |
| 2        | codebuff    | `paid`       | codebuff/base@latest    | SDK  | @codebuff/sdk                                           | **Yes** |
| 3        | groq        | `free-cloud` | llama-3.3-70b-versatile | HTTP | https://api.groq.com/openai/v1                          | No      |
| 4        | mistral     | `free-cloud` | mistral-small-latest    | HTTP | https://api.mistral.ai/v1                               | No      |
| 5        | gemini      | `free-cloud` | gemini-2.5-flash        | HTTP | https://generativelanguage.googleapis.com/v1beta/openai | No      |
| 6        | gemini-lite | `free-cloud` | gemini-2.5-flash-lite   | HTTP | https://generativelanguage.googleapis.com/v1beta/openai | No      |

### OpenRouter Free Models (28 models, priority 8-35)

| Model ID                                                      | Provider                        |
| ------------------------------------------------------------- | ------------------------------- |
| nvidia/nemotron-3-super-120b-a12b:free                        | openrouter-nemotron-super       |
| nvidia/nemotron-3-nano-30b-a3b:free                           | openrouter-nemotron-nano-30b    |
| qwen/qwen3-next-80b-a3b-instruct:free                         | openrouter-qwen3-next-80b       |
| stepfun/step-3.5-flash:free                                   | openrouter-step3-5-flash        |
| arcee-ai/trinity-mini:free                                    | openrouter-trinity-mini         |
| nvidia/nemotron-nano-9b-v2:free                               | openrouter-nemotron-nano-9b     |
| minimax/minimax-m2.5:free                                     | openrouter-minimax-m2.5         |
| qwen/qwen3-coder:free                                         | openrouter-qwen3-coder          |
| liquid/lfm-2.5-1.2b-thinking:free                             | openrouter-lfm-2.5-thinking     |
| liquid/lfm-2.5-1.2b-instruct:free                             | openrouter-lfm-2.5-instruct     |
| nvidia/nemotron-nano-12b-v2-vl:free                           | openrouter-nemotron-nano-12b-vl |
| arcee-ai/trinity-large-preview:free                           | openrouter-trinity-large        |
| mistralai/mistral-small-3.1-24b-instruct:free                 | openrouter-mistral-small-3.1    |
| meta-llama/llama-3.3-70b-instruct:free                        | openrouter-llama-3.3-70b        |
| qwen/qwen3-4b:free                                            | openrouter-qwen3-4b             |
| openai/gpt-oss-120b:free                                      | openrouter-gpt-oss-120b         |
| openai/gpt-oss-20b:free                                       | openrouter-gpt-oss-20b          |
| meta-llama/llama-3.2-3b-instruct:free                         | openrouter-llama-3.2-3b         |
| cognitivecomputations/dolphin-mistral-24b-venice-edition:free | openrouter-dolphin-mistral      |
| google/gemma-3-27b-it:free                                    | openrouter-gemma-3-27b          |
| z-ai/glm-4.5-air:free                                         | openrouter-glm-4.5-air          |
| google/gemma-3n-e2b-it:free                                   | openrouter-gemma-3n-e2b         |
| google/gemma-3-4b-it:free                                     | openrouter-gemma-3-4b           |
| google/gemma-3n-e4b-it:free                                   | openrouter-gemma-3n-e4b         |
| google/gemma-3-12b-it:free                                    | openrouter-gemma-3-12b          |
| nousresearch/hermes-3-llama-3.1-405b:free                     | openrouter-hermes-3-405b        |

### Additional Providers

| Priority | Provider                  | Tier               | Model                       | API Endpoint                          |
| -------- | ------------------------- | ------------------ | --------------------------- | ------------------------------------- |
| 36       | sambanova                 | `free-cloud`       | Meta-Llama-3.3-70B-Instruct | https://api.sambanova.ai/v1           |
| 37       | cerebras                  | `free-cloud`       | llama3.1-8b                 | https://api.cerebras.ai/v1            |
| 38       | github-models             | `free-cloud`       | gpt-4.1-mini                | https://models.github.ai/inference/v1 |
| 39       | codebuff-bridge           | `local-proxy`      | codebuff/base               | http://127.0.0.1:4318/v1              |
| 40       | ollama-local              | `local-safety-net` | qwen3-coder-next:latest     | http://localhost:11434                |
| 41       | ollama-qwen2.5-coder-3b   | `local-safety-net` | qwen2.5-coder:3b-instruct   | http://localhost:11434                |
| 42       | ollama-qwen2.5-coder-0.5b | `local-safety-net` | qwen2.5-coder:0.5b          | http://localhost:11434                |

---

## 6. Bridges

### Codebuff Bridge (Port 4318)

**Purpose**: Exposes Codebuff SDK as OpenAI-compatible HTTP API for OpenClaw integration

**Endpoints**:

- `GET /v1/models` - List models
- `POST /v1/chat/completions` - Chat completion (streaming & non-streaming)
- `POST /chat/completions` - Alternative endpoint for OpenClaw
- `GET /health` - Health check (no auth)

**Configuration**:

- Port: `CODEBUFF_BRIDGE_PORT` (default: 4318)
- Auth: `CODEBUFF_BRIDGE_API_KEY` (default: local-bridge)
- Model: `CODEBUFF_MODEL_ID` (default: codebuff/base)
- Working Dir: `CODEBUFF_BRIDGE_CWD` (default: project root)

**Features**:

- Automatic paid → free mode fallback
- Mode re-validation every 5 hours
- Streaming via Server-Sent Events (SSE)

### Symphony Bridge (Port 4319)

**Purpose**: OpenAI-compatible gateway with AI SDK for provider communication and tool execution. The harness runner uses this as its only model surface.

**Endpoints**:

- `GET /v1/models` - List models
- `POST /v1/chat/completions` - Chat completion (streaming & non-streaming)
- `GET /health` - Health check (no auth)
- `GET /v1/metrics` - Bridge + credit-gate metrics
- `GET /v1/stats` - Provider statistics

**Configuration**:

- Port: `SYMPHONY_BRIDGE_PORT` (default: 4319)
- Auth: `SYMPHONY_BRIDGE_API_KEY` (default: local-symphony)
- Model: `SYMPHONY_MODEL_ID` (default: symphony/main)

**AI SDK Providers Supported**:

- codebuff (@codebuff/sdk)
- groq (@ai-sdk/groq)
- openrouter (@openrouter/ai-sdk-provider)
- openclaw (OpenAI-compatible)
- mistral (OpenAI-compatible)
- gemini (@ai-sdk/google)
- codex (OpenAI-compatible)

**Tools Available**:

- `exec` - Execute shell commands
- `read` - Read files from filesystem
- `glob` - Find files matching pattern

Tool execution is handled automatically by AI SDK via `maxSteps` (default: 10 iterations).

**Dynamic Tool-Capability Probing**:

At startup, the bridge probes each available provider with a minimal `generateText` call using `toolChoice: "auto"` and a simple `add(2, 2)` tool to determine whether it supports structured tool calling. Providers in `KNOWN_TOOL_CAPABLE` (`codex`, `codebuff`) skip probing entirely and return `known-capable` immediately. Providers that emit raw JSON tool output instead of structured `toolCalls` are excluded from selection. A delayed retry (60s) re-probes rate-limited or errored providers. OpenRouter models share probe results (one probe covers all 27 models).

The `GET /health` endpoint exposes `toolProbe` with:

| Field          | Type       | Description                                                       |
| -------------- | ---------- | ----------------------------------------------------------------- |
| `capable`      | `string[]` | Providers confirmed to support structured tool calls              |
| `excluded`     | `string[]` | Providers excluded (raw JSON tool output detected)                |
| `unclassified` | `string[]` | Available but not yet classified (rate-limited, errored, timeout) |
| `blocked`      | `object[]` | Providers blocked from bridge, with `{ name, reason }`            |

**Bridge Provider Blocklist**:

- `openclaw` — Blocked to prevent routing loop (bridge → openclaw → bridge)

---

## 7. OpenClaw Integration

### Overview

OpenClaw is an external AI agent framework that provides autonomous code editing capabilities. It should prefer Symphony Bridge as the primary route, while keeping pinned fallbacks that mirror Symphony's provider inventory.

### How OpenClaw Uses Symphony and Codebuff

OpenClaw acts as a wrapper layer that can route requests to multiple backends:

```
┌─────────────────────────────────────────────────────────────┐
│                    OpenClaw Agent                            │
│              (External AI Agent Framework)                  │
└────────────────────────┬────────────────────────────────────┘
                         │
         ┌───────────────┼───────────────┐
         │               │               │
         ▼               ▼               ▼
┌─────────────────┐ ┌──────────┐ ┌─────────────────┐
│ Symphony Bridge │ │Codebuff  │ │ OpenClaw Native │
│    (port 4319)  │ │ Bridge   │ │    Models       │
│                 │ │(4318)    │ │  (free-rider)   │
└────────┬────────┘ └────┬─────┘ └────────┬────────┘
         │               │               │
         ▼               ▼               ▼
┌─────────────────────────────────────────────────────────────┐
│              Credit-Gate Provider Selection                 │
│         (40+ providers with auto-fallback)                  │
│   groq, openrouter, mistral, gemini, codex, ollama...       │
└─────────────────────────────────────────────────────────────┘
```

### Provider Cascade (Priority Order)

1. **Primary**: `symphony-bridge/symphony/main` (port 4319)
   - Routes to Symphony Bridge
   - Uses AI SDK with credit-gate for provider autoselection
   - Provides tool execution and provider attribution
   - Bearer token: `local-symphony`

2. **Pinned fallbacks**: `symphony-bridge/symphony/*`
   - Direct routes for Codex, Codebuff, Groq, Mistral, Gemini, OpenRouter, SambaNova, Cerebras, and Ollama
   - Keeps OpenClaw's fallback inventory aligned with Symphony's provider inventory

3. **Final local fallback**: `codebuff-bridge/codebuff/base` (port 4318)
   - Routes to Codebuff Bridge
   - Uses Codebuff SDK directly with paid → free account rotation
   - Bearer token: `local-bridge`

### Configuration (`.openclaw/models.json`)

Provider key order matters — the TUI `/models` picker iterates in JSON insertion order. Symphony-bridge must come first, codebuff-bridge last.

```json
{
  "providers": {
    "symphony-bridge": {
      "baseUrl": "http://127.0.0.1:4319/v1",
      "apiKey": "local-symphony",
      "api": "openai-completions",
      "models": [
        { "id": "symphony/main" },
        { "id": "symphony/text" },
        { "id": "symphony/codex" },
        { "id": "symphony/codebuff" },
        { "id": "symphony/codebuff-bridge" },
        { "id": "symphony/groq" },
        { "id": "symphony/mistral" },
        { "id": "symphony/gemini" },
        { "id": "symphony/gemini-lite" },
        { "id": "symphony/openrouter" },
        { "id": "symphony/sambanova" },
        { "id": "symphony/cerebras" },
        { "id": "symphony/ollama-local" }
      ]
    },
    "ollama": {
      "baseUrl": "http://localhost:11434/v1",
      "apiKey": "ollama",
      "api": "openai-completions",
      "models": [
        { "id": "qwen2.5-coder:0.5b" },
        { "id": "qwen2.5-coder:3b-instruct" },
        { "id": "qwen3-coder-next:latest" }
      ]
    },
    "codebuff-bridge": {
      "baseUrl": "http://127.0.0.1:4318/v1",
      "apiKey": "local-bridge",
      "api": "openai-completions",
      "models": [{ "id": "codebuff/base" }]
    }
  },
  "agents": {
    "defaults": {
      "model": {
        "primary": "symphony-bridge/symphony/main",
        "fallbacks": [
          "symphony-bridge/symphony/codex",
          "symphony-bridge/symphony/codebuff",
          "symphony-bridge/symphony/codebuff-bridge",
          "symphony-bridge/symphony/groq",
          "symphony-bridge/symphony/mistral",
          "symphony-bridge/symphony/gemini",
          "symphony-bridge/symphony/gemini-lite",
          "symphony-bridge/symphony/openrouter",
          "symphony-bridge/symphony/sambanova",
          "symphony-bridge/symphony/cerebras",
          "symphony-bridge/symphony/ollama-local",
          "symphony-bridge/symphony/text",
          "ollama/qwen2.5-coder:0.5b",
          "ollama/qwen2.5-coder:3b-instruct",
          "ollama/qwen3-coder-next:latest",
          "codebuff-bridge/codebuff/base"
        ]
      }
    }
  }
}
```

### Runtime Integration

When Symphony Runner executes an issue, it can:

1. **Direct Mode**: Use Codebuff SDK directly (via port 4318 bridge)
2. **Symphony Bridge Mode**: Use credit-gate providers via port 4319
3. **OpenClaw Mode**: Delegate to OpenClaw which uses Symphony/Codebuff as backends

This gives the system multiple layers of fallback:

- Within Symphony: credit-gate tries 40+ providers
- Within Codebuff: paid → free mode fallback
- Within OpenClaw: cascades through Symphony → Codebuff → native models

---

## 8. Makefile Targets

```makefile
# Harness
harness-quick          # Run quick harness report
harness-continuous     # Run continuous harness report
harness-full           # Run full harness report
harness-doctor         # Run harness runtime diagnostics
quality-harness        # Run deeper harness and ops dry-run checks

# Symphony
symphony-run           # Run symphony runner once
symphony-run-dry-run   # Dry-run symphony runner
symphony-status        # Show symphony status

# Bridge
codebuff-bridge        # Start Codebuff OpenAI-compatible bridge
```

---

## 9. Package.json Scripts

```json
{
  "harness:quick": "node harness/ops/harness-report.mjs quick",
  "harness:continuous": "node harness/ops/harness-report.mjs continuous",
  "harness:full": "node harness/ops/harness-report.mjs full",
  "harness:doctor": "node harness/ops/harness-doctor.mjs",

  "symphony:run": "node harness/ops/symphony-runner.mjs --once",
  "symphony:run:dry-run": "node harness/ops/symphony-runner.mjs --once --dry-run",
  "symphony:status": "node harness/ops/symphony-runner.mjs --status",

  "nightly": "node harness/ops/nightly-ops-pass.mjs",
  "nightly:dry-run": "node harness/ops/nightly-ops-pass.mjs --dry-run",

  "sonar:mail": "node harness/ops/sonar-linear-mail.mjs",
  "sonar:export": "bash harness/sonar-export.sh"
}
```

---

## 10. Control Flow

```
                    ┌─────────────────┐
                    │  Linear Issues  │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  Queue Control  │
                    │ (symphony-queue-│
                    │   control.mjs)  │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │ Symphony Runner │
                    │(symphony-runner)│
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
     ┌────────▼────┐  ┌──────▼──────┐  ┌───▼────┐
     │Codebuff SDK │  │Symphony    │  │Fallback│
     │             │  │Bridge      │  │Providers│
     │(local)      │  │(AI SDK)    │  │(40+)   │
     └─────────────┘  └────────────┘  └────────┘
              │              │              │
              └──────────────┼──────────────┘
                             │
                    ┌────────▼────────┐
                    │ Quality Gates   │
                    │ - typecheck     │
                    │ - lint          │
                    │ - depcruise     │
                    │ - tests         │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │ Evidence Report │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  Update Linear  │
                    │  + Notify       │
                    └─────────────────┘
```

---

## 11. Quality Gates

| Check           | Classification | Command                      |
| --------------- | -------------- | ---------------------------- |
| repo-structure  | Blocking       | Auto-check on file existence |
| typecheck       | Blocking       | `npm run typecheck:all`      |
| lint            | Blocking       | `npm run lint:all`           |
| test-unit       | Blocking       | `npm run test:unit`          |
| depcruise       | Blocking       | `npm run depcruise:all`      |
| ast-density     | Blocking       | `npm run audit:ast`          |
| cspell-coverage | Advisory       | `npx cspell`                 |
| docs-freshness  | Advisory       | Manual review                |
| ollama-health   | Advisory       | Check local model            |
| sonar-audit     | Advisory       | `npm run sonar:mail`         |

---

## 12. State Files

| File                                       | Purpose                     |
| ------------------------------------------ | --------------------------- |
| `reports/symphony/state.json`              | Symphony runner state       |
| `reports/symphony/provider-failures.json`  | Provider failure timestamps |
| `reports/symphony/provider-stats.json`     | Provider metrics and scores |
| `reports/codebuff/latest-{timestamp}.json` | Codebuff execution reports  |

**In-memory state** (not persisted, rebuilt at startup):

| State                     | Location                 | Purpose                                                                    |
| ------------------------- | ------------------------ | -------------------------------------------------------------------------- |
| `toolCapableProviders`    | Symphony Bridge (memory) | Set of providers confirmed to support structured tools                     |
| `nonToolCapableProviders` | Symphony Bridge (memory) | Set of providers excluded from tool-bearing requests                       |
| Adaptive context state    | Symphony Bridge (memory) | Per-provider dynamic token ceilings, rate-limit throttles, TPM/RPM windows |
| Session provider map      | Symphony Bridge (memory) | Sticky session → provider assignments (cleared on failure)                 |

---

## 13. Files Reference

### Root Entry Points (Stable Contract)

- `harness/ops/harness-report.mjs` - Health monitoring
- `harness/ops/linear-guardian.mjs` - Issue hygiene
- `harness/ops/symphony-queue-control.mjs` - Queue maintenance
- `harness/ops/symphony-runner.mjs` - Issue execution
- `harness/ops/nightly-ops-pass.mjs` - Nightly pipeline
- `harness/ops/email-ingest.mjs` - Email → issues
- `harness/ops/notify.mjs` - Notifications
- `harness/ops/harness-doctor.mjs` - Diagnostics

### Integration Scripts

- `harness/ops/integrations/model/codebuff-openai-bridge.mjs` - Codebuff bridge
- `harness/ops/integrations/model/symphony-openai-bridge.mjs` - Symphony bridge
- `harness/ops/integrations/model/symphony-credit-gate.mjs` - Provider selection
- `harness/ops/integrations/linear/linear-client.mjs` - Linear API helper
- `harness/ops/integrations/sonar/sonar-linear-audit.mjs` - Sonar sync

### Core Modules

- `harness/ops/core/symphony-state.mjs` - State management
- `harness/ops/core/symphony-validation.mjs` - Validation manifest
- `harness/ops/symphony-config.mjs` - Configuration constants

---

## 14. Deprecation Notes

- `codebuff-sdk-runner.mjs` - Deprecated. All Codebuff calls go through HTTP bridge.
- Legacy copies under subdirectories exist but root entrypoints remain stable.

---

_Last updated: 2026-03-27_
