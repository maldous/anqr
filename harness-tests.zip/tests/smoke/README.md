Smoke tests only.
